"""Predeclared subsets and simple mathematical forms of known inputs."""
import gzip
import json

import numpy as np
import pandas as pd

from build_features import FEATURES, HERE, ORIGINS, SLOTS, TRAIN, load_baseline, save_block


def subset(name, block, include):
    recipe = json.loads((FEATURES/f"{block}.json").read_text())
    rows = [c for c in recipe["columns"] if "mean" in c]
    take = [j for j,r in enumerate(rows) if include(r["name"])]
    save = dict(provenance=recipe["provenance"],columns=[rows[j] for j in take])
    source = np.load(FEATURES/f"{block}.npy",mmap_mode="r")
    np.save(FEATURES/f"{name}.npy",source[:,:,take])
    (FEATURES/f"{name}.json").write_text(json.dumps(save,indent=2))


def offshore():
    data = json.load(gzip.open(HERE/"sources/offshore_jma.gz","rt"))
    d = data["locations"]
    index = pd.to_datetime(d[0]["hourly"]["time"],utc=True).as_unit("s").astype("int64").to_numpy()
    grid = np.searchsorted(index,SLOTS//3600*3600)
    assert np.array_equal(index[grid],SLOTS//3600*3600)
    labels = [r[0] for r in data["sites"]]
    def stack(field):
        return np.stack([np.asarray(x["hourly"][field],dtype="float32")[grid] for x in d],axis=-1)
    speed = stack("wind_speed_10m_previous_day1")
    speed_older = stack("wind_speed_10m_previous_day2")
    rad = np.deg2rad(stack("wind_direction_10m_previous_day1"))
    provenance = "Open-Meteo JMA GSM archived offshore forecasts issued at least 24h before delivery. Seven geographically selected GB sites, equal weights for groups."
    save_block("offshore_spatial", {
        **{f"offshore_speed_{key}":speed[:,:,j] for j,key in enumerate(labels)},
        "offshore_EW_flow_mean":(np.sin(rad)*speed).mean(-1),
        "offshore_NS_flow_mean":(np.cos(rad)*speed).mean(-1),
        "offshore_regional_spread":speed.std(-1),
    },TRAIN,SLOTS.shape,provenance)
    transform = np.maximum(0,np.minimum(12,speed)**3-3**3)
    save_block("offshore_power", {
        "offshore_mean_wind_curve":transform.mean(-1),
        "offshore_east_power_proxy":transform[:,:,:5].mean(-1),
        "offshore_west_power_proxy":transform[:,:,5:].mean(-1),
        "offshore_east_west_contrast":transform[:,:,:5].mean(-1)-transform[:,:,5:].mean(-1),
        "regional_forecast_change_of_speed":(speed-speed_older).mean(-1),
    },TRAIN,SLOTS.shape,provenance+" Capped cubic is a sensitivity feature; installed capacities and hub-height profiles are not inferred.")


def electricity():
    native = load_baseline()
    p = native("PRICES_forward")
    base = native("PRICES_seasonal_mean")
    load = native("NDF_forward")
    wind = native("WINDFOR_forward")
    scale = 100
    scope = f"Previously published auction price and existing grid forecasts; signed transformations use the fixed {scale} GBP/MWh scale."
    save_block("price_monotone",{
        "auction_price_signed_log":np.sign(p)*np.log1p(np.abs(p)/scale),
        "auction_price_negative":np.where(np.isfinite(p),p<0,np.nan),
        "auction_price_positive_sqrt":np.where(np.isfinite(p),np.sqrt(np.maximum(p,0)),np.nan),
        "auction_price_spread_scaled":(p-base)/np.maximum(25,np.abs(base)),
        "auction_price_signed_asinh_spread":np.arcsinh((p-base)/scale),
        "price_weighted_net_load":p*(load-wind),
    },TRAIN,SLOTS.shape,scope)
    net = load-wind
    save_block("net_load_nonlinear",{
        "net_demand_gw":net/1000,
        "above_25gw_nonwind_load":np.maximum(0,net/1000-25),
        "below_15gw_nonwind_load":np.maximum(0,15-net/1000),
        "wind_potential_saturation":np.minimum(1,np.maximum(0,wind/np.maximum(1000,load))),
        "net_demand_ramp":net-np.roll(net,1,axis=1),
    },TRAIN,SLOTS.shape,
        "Physically related existing features, no same-slot realised demand/generation. The first-ramp row compares two already-available forecast values.")


if __name__=="__main__":
    subset("price_shape", "forecast_shape", lambda x:x.startswith("PRICES"))
    subset("demand_shape", "forecast_shape", lambda x:x.startswith("NDF"))
    subset("scarcity_shape", "forecast_shape", lambda x:not x.startswith(("PRICES","NDF")))
    electricity()
    offshore()
