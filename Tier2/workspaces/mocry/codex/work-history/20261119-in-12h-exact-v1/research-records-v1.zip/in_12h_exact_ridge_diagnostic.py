"""Compare frozen Ridge and hybrid forecasts with all target substitutions."""
from itertools import product

import numpy as np
import pandas as pd

from in_12h_exact_replay import (
    CONFIG, HORIZON, OUTPUT, SPLITS, references, residuals, rolling, settle, verify_trace,
)


TARGETS = ("price", "generation", "demand")
CASES = tuple(product((False, True), repeat=len(TARGETS)))


def forecast_errors(path, truth, sd):
    error = path - truth
    actual_gap = truth[:, :, 1] - truth[:, :, 2]
    predicted_gap = path[:, :, 1] - path[:, :, 2]
    gap_sign_correct = (actual_gap >= 0) == (predicted_gap >= 0)
    near_balance = np.abs(actual_gap) < 500
    normal_mse = np.square(error/sd).mean((0, 1))
    mae = np.abs(error).mean((0, 1))
    return dict(
        joint_MSE=normal_mse.mean(), price_MSE=normal_mse[0],
        generation_MSE=normal_mse[1], demand_MSE=normal_mse[2],
        price_MAE_GBP_MWh=mae[0], generation_MAE_GW=mae[1]/500, demand_MAE_GW=mae[2]/500,
        gap_MAE_GW=np.abs(predicted_gap-actual_gap).mean()/500,
        gap_sign_accuracy=gap_sign_correct.mean(), near_balance_sign_accuracy=gap_sign_correct[near_balance].mean(),
        near_balance_slots=int(near_balance.sum()),
    )


def main():
    ridges, _ = residuals(CONFIG["original_ridge"])
    archived = pd.read_csv(OUTPUT/"returns.csv").set_index(["split", "policy", "method"])
    errors, cash, actions = [], [], []
    with np.load(OUTPUT/"issued_hybrid.npz") as forecasts:
        for split, (stamps, base, sd, truth) in references().items():
            if split not in SPLITS:
                continue
            np.testing.assert_array_equal(stamps, forecasts[f"{split}_utc"])
            count = len(stamps)
            ridge = base + sd * ridges[split][:count]
            ridge[:, :, 1:] = np.maximum(0, ridge[:, :, 1:])
            hybrid = forecasts[f"{split}_hybrid_path"]
            signal = forecasts[f"{split}_common_current_price"]
            for name, path in (("original_ridge", ridge), ("in-12h-exact", hybrid)):
                errors.append(dict(split=split, model=name, **forecast_errors(path, truth, sd)))
            actual = truth[:, 0]
            horizon = np.minimum(HORIZON, count - np.arange(count))
            for policy in ("A", "B"):
                endpoints = {}
                for mask in CASES:
                    path = np.where(mask, hybrid, ridge)
                    score = rolling.first_scores(policy, path, horizon, first_signal=signal)
                    trace = []
                    summary, _ = settle(policy, actual, signal, score, trace)
                    trace = np.asarray(trace)
                    gross = summary["gross"]
                    attributed = verify_trace(trace, actual, signal, policy, gross)
                    substituted = "+".join(t for t, use in zip(TARGETS, mask) if use) or "none"
                    cash.append(dict(split=split, policy=policy, hybrid_targets=substituted,
                                     gross_GBP=gross, cycles=summary["cycle"], **attributed))
                    if all(mask) or not any(mask):
                        name = "in-12h-exact" if all(mask) else "ridge_before_features"
                        np.testing.assert_allclose(gross, archived.loc[(split, policy, name), "gross_GBP"],
                                                   atol=0.0001, rtol=0)
                        endpoints[name] = trace
                original, mixed = (endpoints[k] for k in ("ridge_before_features", "in-12h-exact"))
                # Execution requests and feasible flows can differ when the actual state clips an action.
                same_request = np.isclose(original[:, 1], mixed[:, 1], atol=1e-6, rtol=0)
                same_flow = np.isclose(original[:, 2:4], mixed[:, 2:4], atol=0.1, rtol=0).all(1)
                actions.append(dict(split=split, policy=policy, slots=count,
                                    same_requested_action=same_request.mean(), same_charge_and_discharge=same_flow.mean()))
                print(split, policy, "reproduced and substituted", flush=True)
    for name, result in (("ridge_forecast_comparison.csv", errors),
                         ("ridge_target_substitutions.csv", cash),
                         ("ridge_action_comparison.csv", actions)):
        pd.DataFrame(result).to_csv(OUTPUT/name, index=False)


if __name__ == "__main__":
    main()
