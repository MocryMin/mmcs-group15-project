"""Compare nominal and real currency on the price forecast channels."""
import json

import numpy as np
import pandas as pd

from build_features import FEATURES, ORIGINS, P, SLOTS, TRAIN, load_baseline, save_block


def main():
    series = pd.read_csv(P/"tier1-multiproduct-20261110-v6/inputs/CPI.csv",dtype="str")
    contains_month = series.Title.str.fullmatch(r"\d{4} [A-Z]{3}",na=False)
    series = series[contains_month]
    months=pd.to_datetime(series.Title,format="%Y %b").dt.to_period("M")
    cpi = pd.Series(pd.to_numeric(series.iloc[:,1]).to_numpy(),index=months)
    origin_month = pd.to_datetime(ORIGINS,unit="s").to_period("M")
    active = cpi.reindex(origin_month-2).to_numpy()[:,None]
    older = cpi.reindex(origin_month-14).to_numpy()[:,None]
    from_now = 108.7/active
    x = load_baseline()
    p=x("PRICES_forward")
    recent=x("past_auction_0")[:,-1:]
    mean=x("PRICES_seasonal_mean")
    source="ONS D7BT/MM23 CPI all items. Use only the CPI from two calendar months before issue, accounting for publication lag. 108.7 preserves the frozen project constant for 2020 GBP. The original current-revised CPI series is used, so original release versions are not independently verified."
    save_block("real_price",{
        "real_N2EX_forward_GBP2020":p*from_now,
        "real_N2EX_season_shape_GBP2020":(p-mean)*from_now,
        "real_N2EX_vs_completed_recent":(p-recent)*from_now,
        "CPI_implied_discount_factor":from_now,
    },TRAIN,SLOTS.shape,source)
    meta = json.loads((FEATURES/"gas_prices.json").read_text())["columns"][0]
    gas=np.load(FEATURES/"gas_prices.npy",mmap_mode="r")[:,:,0]*meta["std"]+meta["mean"]
    save_block("macro_and_real_fuel", {
        "CPI_change_from_year_ago":active/older-1,
        "real_gas_GBP2020_per_MWhth":gas*from_now,
        "real_spark_proxy":(p-2*gas)*from_now,
    },TRAIN,SLOTS.shape,source+" Gas input from National Gas PUBOB603. The proxy assumes 50% fuel conversion without carbon adjustment.")


if __name__=="__main__":
    main()
