"""Compare feature changes in the independently fitted direct ridge model."""
import json
import os
import time
from pathlib import Path

for k in ("OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","OMP_NUM_THREADS"):
    os.environ[k]="6"

import numpy as np
from scipy.linalg import eigh

from build_features import BASE, CUTS, FEATURES, HERE


def evaluate(pred,y):
    e=np.square(pred-y,dtype="float64")
    return {"12h":e.mean(),"4h":e[:,:8].mean(),"30min":e[:,0].mean(),
            **{f"12h_{name}":score for name,score in zip(("price","generation","demand"),e.mean((0,1)))}}


def fit(names, deadline):
    features=[np.concatenate([np.load(BASE/"inputs.npy",mmap_mode="r"),
                              np.load(BASE/"summer-2026/inputs.npy",mmap_mode="r")])]
    for name in names:
        features.append(np.load(FEATURES/f"{name}.npy",mmap_mode="r"))
    data=np.concatenate(features,axis=-1)
    parts=np.split(data.reshape(len(data),-1),CUTS)
    with np.load(BASE/"targets.npz") as main,np.load(BASE/"summer-2026/targets.npz") as b:
        y=[*np.split(main["y"],CUTS[:2]),b["y"]]
    x=parts[0].astype("float64")
    train_y=y[0].reshape(len(y[0]),72).astype("float64")
    xm=x.mean(0)
    ym=train_y.mean(0)
    x-=xm
    train_y-=ym
    eigen,v=eigh(x.T@x,check_finite=False)
    numerator=v.T@(x.T@train_y)
    del x,train_y,data
    validation=parts[1].astype("float64")-xm
    projected=validation@v
    winning=None
    all_scores=[]
    for alpha in (.01,.1,1,10,100,1000,10000,100000):
        if time.time()>=deadline:
            return None
        weights=numerator/(np.maximum(0,eigen[:,None])+alpha)
        pv=(projected@weights+ym).reshape(y[1].shape)
        mse=np.square(pv-y[1]).mean()
        all_scores.append([alpha,float(mse)])
        if winning is None or mse<winning[0]:
            winning=mse,alpha,v@weights
    _,alpha,w=winning
    predictions={(s):(x.astype("float64")@w+ym-xm@w).reshape(target.shape).astype("float32")
                 for s,x,target in zip(("val","test25","test26"),parts[1:],y[1:])}
    path=HERE/"ridge"/("+".join(names) or "original")
    path.mkdir(exist_ok=True,parents=True)
    np.savez_compressed(path/"weights.npz",weight=w,bias=ym-xm@w,alpha=alpha)
    np.savez_compressed(path/"predictions.npz",**predictions)
    row={"blocks":names,"alpha":alpha,"columns":len(xm),"validation_grid":all_scores}
    row.update({s:evaluate(pred,target) for (s,pred),target in zip(predictions.items(),y[1:])})
    (path/"result.json").write_text(json.dumps(row,indent=2))
    return row


if __name__=="__main__":
    import sys
    for specification in sys.argv[2:]:
        cutoff=float(sys.argv[1])
        if time.time()>=cutoff:
            break
        names=specification.split("+") if specification!="original" else []
        outcome=fit(names,cutoff)
        if outcome:
            print(specification,outcome["alpha"],[outcome[s]["12h"] for s in ("val","test25","test26")],flush=True)
