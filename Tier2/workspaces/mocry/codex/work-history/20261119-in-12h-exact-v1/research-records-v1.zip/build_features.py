"""Build aligned, train-scaled feature blocks for the half-hour as-of experiments."""
import gzip
import json
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
P = HERE.parent
BASE = P / 'tier2b-asof-20261119'
LEGACY = P / 'tier2b-feature-engineering-20261110' / 'research'
FEATURES = HERE / 'blocks'
FEATURES.mkdir(exist_ok=True)
TARGETS = ('price', 'generation', 'demand')


def time_and_splits():
    with np.load(BASE / 'targets.npz') as original, np.load(BASE / 'summer-2026/targets.npz') as summer:
        origins = np.concatenate([original['utc'], summer['utc']])
        sizes = np.r_[original['split_sizes'], len(summer['utc'])]
    slots = origins[:, None] + np.arange(24) * 1800
    return origins, slots, sizes


def save_block(name, columns, train, shape, provenance):
    matrix = []
    records = []
    for label, values in columns.items():
        values = np.broadcast_to(np.asarray(values, dtype='float32'), shape)
        finite = np.isfinite(values)
        if finite[:train].mean() < .05:
            records.append({'name': label, 'excluded': 'training coverage below 5%'})
            continue
        mu = np.mean(values[:train][finite[:train]], dtype='float64')
        sd = np.std(values[:train][finite[:train]], dtype='float64')
        if sd < 1e-8:
            records.append({'name': label, 'excluded': 'constant on train'})
            continue
        matrix.append(np.where(finite, (values-mu)/sd, 0).astype('float32'))
        records.append({'name': label, 'mean': mu, 'std': sd,
                        'coverage': [float(p.mean()) for p in np.split(finite, CUTS)]})
    if not matrix:
        raise ValueError(f'No populated features for {name}')
    np.save(FEATURES / f'{name}.npy', np.stack(matrix, axis=-1))
    (FEATURES / f'{name}.json').write_text(json.dumps(
        {'provenance': provenance, 'columns': records}, indent=2), encoding='utf-8')
    print(name, len(matrix), flush=True)


def load_baseline():
    x = np.concatenate([np.load(BASE / 'inputs.npy'), np.load(BASE / 'summer-2026/inputs.npy')])
    schema = json.loads((BASE / 'features.json').read_text())
    names = schema['names']

    def native(name):
        j = names.index(name)
        raw = x[:, :, j] * schema['std'][j] + schema['mean'][j]
        for indicator in (name+'_observed', name+'_known'):
            if indicator in names:
                k = names.index(indicator)
                known = x[:, :, k] * schema['std'][k] + schema['mean'][k] > .5
                return np.where(known, raw, np.nan)
        return raw

    return native


def forecast_shape_columns(native):
    latest = native('five_minute_demand_lag_0')[:, :1]
    forecast = {}
    for name, baseline in [('PRICES','PRICES'),('NDF','FUELINST')]:
        a = native(name+'_forward')
        forecast[name+'_vs_season'] = a - native(baseline+'_seasonal_mean')
        forecast[name+'_from_start'] = a - a[:, :1]
        lagged = np.concatenate([np.full((len(a),1),np.nan), a[:, :-1]],axis=1)
        forecast[name+'_step_change'] = a - lagged
        forecast[name+'_relative_to_recent'] = a - (native('past_auction_0')[:, -1:] if name=='PRICES' else latest)
    wind, demand = native('WINDFOR_forward'), native('NDF_forward')
    forecast['net_demand_after_wind_forecast'] = demand-wind
    forecast['wind_share_of_forecast_demand'] = wind / np.maximum(1000, demand)
    forecast['modelled_gap_simple'] = native('AGPT_seasonal_mean')-demand
    forecast['recent_generation_minus_demand'] = native('AGPT_history_0')[:, -1:] - latest
    return forecast


def internal():
    native = load_baseline()
    recent = {}
    for series in ('AGPT','FUELINST','INDO','ITSDO'):
        a = native(series+'_history_0')
        for span in (1, 4, 12, 24):
            window = a[:, -span:]
            valid = np.isfinite(window)
            value = np.nansum(window, axis=1, keepdims=True)/np.maximum(valid.sum(1, keepdims=True), 1)
            recent[f'{series}_recent_{span}'] = np.where(valid.any(1,keepdims=True), value, np.nan)
        for lag in (2, 8, 23):
            recent[f'{series}_change_{lag}'] = a[:, -1:] - a[:, -(lag+1):-lag]
    latest = native('five_minute_demand_lag_0')[:, :1]
    for lag in (1, 3, 5):
        recent[f'five_min_change_{lag}'] = latest-native(f'five_minute_demand_lag_{lag}')[:, :1]
    save_block('recent', recent, TRAIN, SLOTS.shape, 'Completed/published training inputs only; window means and slopes.')
    save_block('forecast_shape', forecast_shape_columns(native), TRAIN, SLOTS.shape,
               'Known forward prices and demand/wind forecasts; level, trend and scarcity proxies.')

    calendar = {}
    shape = SLOTS.shape
    times = pd.to_datetime(SLOTS.ravel(), unit='s', utc=True).tz_convert('Europe/London')
    minutes = times.hour.to_numpy()*60 + times.minute.to_numpy()
    weekday = times.dayofweek.to_numpy()
    for k in (1,2,3,4):
        phase = 2*np.pi*k*minutes/1440
        calendar[f'local_time_sin{k}'] = np.sin(phase).reshape(shape)
        calendar[f'local_time_cos{k}'] = np.cos(phase).reshape(shape)
    for k in range(7):
        calendar[f'weekday_{k}'] = (weekday==k).reshape(shape)
    for k in (2,3):
        phase=2*np.pi*k*times.dayofyear.to_numpy()/365.2425
        calendar[f'season_sin{k}'] = np.sin(phase).reshape(shape)
        calendar[f'season_cos{k}'] = np.cos(phase).reshape(shape)
    save_block('calendar', calendar, TRAIN, shape, 'Calendar known at time of issue, Europe/London time including DST.')
    holidays = json.loads((LEGACY/'govuk_bank_holidays.json').read_text(encoding='utf-8-sig'))
    local_days = times.tz_localize(None).normalize().to_numpy(dtype='datetime64[D]')
    signals = {}
    for name in ('england-and-wales','scotland'):
        days = np.array([r['date'] for r in holidays[name]['events']],dtype='datetime64[D]')
        for shift in (-1,0,1):
            signals[f'{name}_relative_day_{shift}']=np.isin(local_days+np.timedelta64(shift,'D'),days).reshape(shape)
    signals['christmas_week'] = ((times.month==12)&(times.day>=24)).reshape(shape)
    save_block('holiday', signals, TRAIN, shape, 'GOV.UK bank holiday calendar; local-day and adjacent-day flags.')


def archived_weather():
    for name, filename, fields in (
        ('daily_temp','gfs_temperature_day2',('mean',)),
        ('daily_wind','jma_wind_day2',('wind_mean','wind_cubic_mean')),
        ('daily_cloud','jma_solar_proxy_day2',('cloud_mean','daylight_cloud_index')),
    ):
        document = json.loads((LEGACY/(filename+'.json')).read_text())
        columns = {}
        days, inverse = np.unique(SLOTS//86400, return_inverse=True)
        assert np.all((days[inverse].reshape(SLOTS.shape)*86400 + 23*3600 - 48*3600) <= ORIGINS[:,None])
        keys = pd.to_datetime(days,unit='D').strftime('%Y-%m-%d')
        for j, region in enumerate(document['locations']):
            df = pd.DataFrame(region['days']).set_index('date')
            for field in fields:
                a = df[field].reindex(keys).to_numpy(dtype='float32')
                columns[f'{name}_{field}_{j}'] = a[inverse].reshape(SLOTS.shape)
        if name=='daily_temp':
            mean = np.nanmean(np.stack(list(columns.values())), axis=0)
            columns['mean_heating_degrees'] = np.maximum(15-mean,0)
            columns['mean_cooling_degrees'] = np.maximum(mean-22,0)
        save_block(name, columns, TRAIN, SLOTS.shape, document['url'])


def forecast_weather():
    for name in ('temp-hourly','wind-hourly','cloud-hourly','solar-hourly','hubwind-hourly'):
        source = HERE/'sources'/f'{name}.gz'
        if not source.exists():
            continue
        with gzip.open(source, 'rt', encoding='utf-8') as f:
            data = json.load(f)
        columns = {}
        hours, indices = np.unique(SLOTS//3600, return_inverse=True)
        times = pd.to_datetime(hours, unit='h', utc=True)
        for j, region in enumerate(data['locations']):
            frame = pd.DataFrame(region['hourly'])
            frame.index = pd.to_datetime(frame.pop('time'),utc=True)
            aligned = frame.reindex(times)
            for feature in aligned:
                lead = int(feature.rsplit('day',1)[1]) * 24
                assert np.all((hours[indices].reshape(SLOTS.shape)*3600 - lead*3600) <= ORIGINS[:,None])
                values = aligned[feature].to_numpy('float32')[indices].reshape(SLOTS.shape)
                if 'direction' in feature:
                    columns[f'{feature}_{j}_sin'] = np.sin(np.deg2rad(values))
                    columns[f'{feature}_{j}_cos'] = np.cos(np.deg2rad(values))
                else:
                    columns[f'{feature}_{j}'] = values
        save_block(name, columns, TRAIN, SLOTS.shape, data['url'])


ORIGINS, SLOTS, SIZES = time_and_splits()
TRAIN = SIZES[0]
CUTS = np.cumsum(SIZES)[:-1]


if __name__ == '__main__':
    import argparse
    parser=argparse.ArgumentParser()
    parser.add_argument('--weather-only',action='store_true')
    if not parser.parse_args().weather_only:
        internal()
        archived_weather()
    forecast_weather()
