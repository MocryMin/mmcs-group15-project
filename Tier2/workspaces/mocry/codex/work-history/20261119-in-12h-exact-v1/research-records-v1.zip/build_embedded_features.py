"""Use released NESO half-hourly embedded wind and solar forecast vintages."""
import argparse

import numpy as np
import pandas as pd

from build_features import HERE, ORIGINS, SLOTS, TRAIN, load_baseline, save_block

FIELDS = [
    "EMBEDDED_WIND_FORECAST", "EMBEDDED_WIND_CAPACITY",
    "EMBEDDED_SOLAR_FORECAST", "EMBEDDED_SOLAR_CAPACITY",
]


def seconds(date):
    return pd.to_datetime(date, format="mixed", utc=True).dt.as_unit("s").astype("int64").to_numpy()


def read_archive(files):
    needed = ["DATE_GMT","TIME_GMT","FORECAST_DATETIME","SETTLEMENT_DATE","SETTLEMENT_PERIOD",*FIELDS]
    arrays = []
    for file in files:
        size = 0
        for df in pd.read_csv(file, usecols=lambda s:s.upper() in needed, chunksize=250_000,
                              dtype={"TIME_GMT":"string"}, low_memory=False):
            df.columns = df.columns.str.upper()
            date = seconds(df.DATE_GMT.str.slice(0,10))
            clock = df.TIME_GMT.str.split(":", n=2, expand=True)
            minute = pd.to_numeric(clock[0]).to_numpy()*60 + pd.to_numeric(clock[1]).to_numpy()
            period = df.SETTLEMENT_PERIOD.to_numpy()
            # Midnight follows the previous interval, with the GMT date of the new day.
            delivery = date + (minute-30)*60
            settlement_start = (pd.to_datetime(df.SETTLEMENT_DATE.str.slice(0,10),format="mixed")
                                .dt.tz_localize("Europe/London").dt.tz_convert("UTC")
                                .dt.as_unit("s").astype("int64").to_numpy())
            aligned = delivery == settlement_start + (period-1)*1800
            if aligned.mean() < .98:
                raise ValueError(f"Unexpected settlement-clock alignment in {file.name}: {aligned.mean():.3%}")
            published = seconds(df.FORECAST_DATETIME)
            keep = aligned & (published >= delivery-36*3600) & (published < delivery) & (delivery % 1800==0)
            if keep.any():
                part = df.loc[keep,FIELDS].apply(pd.to_numeric,errors="coerce")
                part["obs"] = delivery[keep]
                part["pub"] = published[keep]
                arrays.append(part)
                size += len(part)
        print(file.name, size, flush=True)
    return pd.concat(arrays,ignore_index=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--files",nargs="+",required=True)
    args = parser.parse_args()
    files = [HERE/"sources"/name for name in args.files]
    frame = read_archive(files)
    frame.sort_values(["obs","pub"],kind="stable",inplace=True)
    frame.drop_duplicates(["obs","pub"],keep="last",inplace=True)
    obs,pub = frame.obs.to_numpy("int64"),frame.pub.to_numpy("int64")
    stamp = obs//1800*1_000_000_000+pub-1609459200
    values = frame[FIELDS].to_numpy("float32")

    def lookup(guard):
        cutoff = ORIGINS[:,None]-guard
        position = np.searchsorted(stamp,SLOTS//1800*1_000_000_000+cutoff-1609459200,side="right")-1
        known = (position>=0)&(obs[position]==SLOTS)&(pub[position]<=cutoff)
        return np.where(known[:,:,None],values[position],np.nan),np.where(known,ORIGINS[:,None]-pub[position],np.nan)

    selected, age = lookup(10*60)
    older, _ = lookup(4*3600)
    wind,wcap,solar,scap = selected.transpose(2,0,1)
    source = "NESO Embedded Wind and Solar Forecast annual archive. Forecast_Datetime + 10 min guard. TIME_GMT represents settlement interval end."
    save_block("embedded_solar", {
        "embedded_solar_forward":solar,
        "embedded_solar_fraction":solar/np.maximum(1,scap),
        "embedded_solar_recent_revision":solar-older[:,:,2],
        "embedded_solar_age":np.log1p(age/60),
        "embedded_solar_known":np.isfinite(solar),
    }, TRAIN, SLOTS.shape, source)
    save_block("embedded_wind", {
        "embedded_wind_forward":wind,
        "embedded_wind_fraction":wind/np.maximum(1,wcap),
        "embedded_wind_recent_revision":wind-older[:,:,0],
    }, TRAIN, SLOTS.shape, source)
    x = load_baseline()
    total_embedded = wind+solar
    forecast_demand,forecast_wind = x("NDF_forward"),x("WINDFOR_forward")
    save_block("embedded_interactions", {
        "embedded_solar_ramp": solar - solar[:,:1],
        "all_wind_and_solar_proxy":total_embedded+forecast_wind,
        "demand_net_large_wind_and_embedded":forecast_demand-forecast_wind-total_embedded,
        "seasonal_generation_plus_embedded_proxy":x("AGPT_seasonal_mean")+total_embedded,
    },TRAIN,SLOTS.shape,source+" Electricity-accounting scopes differ. These are predictors and do not determine a new system balance.")
    print(len(frame), float(np.isfinite(solar).mean()), float(np.isfinite(wind).mean()),flush=True)


if __name__=="__main__":
    main()
