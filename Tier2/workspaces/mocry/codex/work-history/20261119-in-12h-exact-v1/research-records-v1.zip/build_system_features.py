"""Build features using only system outlooks and plant notices released by each origin."""
from collections import defaultdict
import gzip
from heapq import heappop, heappush
import json

import numpy as np
import pandas as pd

from build_features import HERE, ORIGINS, SLOTS, TRAIN, save_block

SOURCES = HERE / "sources"
EPOCH = 1609459200
STRIDE = 1_000_000_000


def outlook(dataset,delay_minutes=0):
    files = sorted(SOURCES.glob(f"{dataset}-*.gz"))
    frame = pd.concat((pd.read_csv(f) for f in files), ignore_index=True)
    frame.sort_values(["obs", "pub"], kind="stable", inplace=True)
    frame.drop_duplicates(["obs", "pub"], keep="last", inplace=True)
    obs = frame.obs.to_numpy("int64")
    pub = frame.pub.to_numpy("int64")
    assert (obs % 1800 == 0).all()
    assert (pub > EPOCH).all() and pub.max() - EPOCH < STRIDE
    archive_key = obs // 1800 * STRIDE + pub - EPOCH

    def lookup(issue, delivery):
        key = delivery // 1800 * STRIDE + issue - EPOCH
        index = np.searchsorted(archive_key, key, side="right") - 1
        known = (index >= 0) & (obs[index] == delivery) & (pub[index] <= issue)
        return index, known

    cutoff = ORIGINS[:,None]-delay_minutes*60
    index, known = lookup(cutoff, SLOTS)
    previous, earlier = lookup(cutoff - 7200, SLOTS)
    values = frame.value.to_numpy("float32")
    level = np.where(known, values[index], np.nan)
    used = np.where(known, pub[index], -1)
    assert (used <= cutoff).all()
    sample = np.random.default_rng(413).integers(0, len(ORIGINS), 12)
    for row in sample:
        for step in (0, 12, 23):
            eligible = np.flatnonzero((obs == SLOTS[row, step]) & (pub <= cutoff[row,0]))
            assert used[row, step] == (pub[eligible[-1]] if eligible.size else -1)
    raw = {
        f"{dataset}_forward": level,
        f"{dataset}_forecast_age": np.where(known, np.log1p(np.maximum(0, ORIGINS[:, None] - used) / 60), np.nan),
        f"{dataset}_known": known,
    }
    if dataset == "lolpdrm":
        raw["loss_of_load_probability"] = np.where(known, frame.probability.to_numpy("float32")[index], np.nan)
    details = {
        f"{dataset}_revision_vs_two_hours": np.where(known & earlier, level - values[previous], np.nan),
        f"{dataset}_lead_change": level - level[:, :1],
        f"{dataset}_negative_indicator": np.where(known, level < 0, np.nan),
    }
    source = "Elexon BMRS publication-vintage archive. National boundary N for MELNGC and IMBALNGC."
    if dataset in {"indgen", "inddem", "tsdf"}:
        source = f"Elexon BMRS {dataset.upper()} publication vintages, Great Britain national boundary N."
    if delay_minutes:
        name = f"{dataset}_delay{delay_minutes}"
        source += f" Forecast publication buffer: {delay_minutes} minutes before each origin."
        save_block(name,raw,TRAIN,SLOTS.shape,source)
    else:
        save_block(dataset, raw, TRAIN, SLOTS.shape, source)
        save_block(dataset + "_derived", details, TRAIN, SLOTS.shape, source + " Older snapshot also forecast for same delivery.")
    print(dataset, len(files), len(frame), float(known.mean()), flush=True)
    return level


def fuel_group(fuel):
    if fuel in {"Fossil Gas", "Nuclear", "Biomass"}:
        return fuel
    if fuel in {"Wind Offshore", "Wind Onshore"}:
        return "wind"
    return "other"


def plant_outages(strict=True):
    path_list = sorted(SOURCES.glob("remit-*.gz"))
    all_rows = [r for f in path_list for r in json.load(gzip.open(f, "rt"))["records"]]
    all_rows.sort(key=lambda r: (r["pub"], r["revision"]))
    # Keep dismissal records, which can omit all of the fields of the original notice.
    wanted = {r["mrid"] for r in all_rows
              if r.get("zone") == "10YGB----------A" and r.get("type") == "Production unavailability"}
    records = [r for r in all_rows if r["mrid"] in wanted]
    groups = ["Fossil Gas", "Nuclear", "Biomass", "wind", "other"]
    levels = np.zeros((*SLOTS.shape, len(groups)), dtype="float32")
    planned = np.zeros(SLOTS.shape, dtype="float32")
    new = np.zeros(SLOTS.shape, dtype="float32")
    active = {}
    latest = {}
    expiry = []
    release = []
    position = 0
    for i, origin in enumerate(ORIGINS):
        while position < len(records) and records[position]["pub"] <= origin:
            r = records[position]
            position += 1
            key, version = r["mrid"], (r["revision"], r["pub"])
            if key in latest and version <= latest[key]:
                continue
            latest[key] = version
            outside_scope = strict and (r.get("zone") != "10YGB----------A"
                                        or r.get("type") != "Production unavailability")
            if r["status"] != "Active" or outside_scope:
                active.pop(key, None)
                continue
            start, end = r["start"], r["end"]
            capacity = r.get("unavailable")
            if not (start and end and start < end and capacity is not None and capacity > 0):
                active.pop(key, None)
                continue
            active[key] = r
            heappush(expiry, (end, key, version))
            if r.get("kind") == "Unplanned":
                release.append(r["pub"])
        while expiry and expiry[0][0] <= origin:
            _, key, version = heappop(expiry)
            if latest.get(key) == version:
                active.pop(key, None)
        by_asset = defaultdict(list)
        for r in active.values():
            if r["start"] >= origin + 24 * 1800:
                continue
            by_asset[r["asset"]].append(r)
        # Retain the maximum reported outage for each unit at each delivery slot.
        # A half-hour boundary covers that delivery slot, without prorating internal changes.
        for asset, reports in by_asset.items():
            mws = np.zeros(24, dtype="float32")
            planned_mws = np.zeros(24, dtype="float32")
            for r in reports:
                lo = max(0, (r["start"] - origin) // 1800)
                hi = min(24, (r["end"] - origin + 1799) // 1800)
                mws[lo:hi] = np.maximum(mws[lo:hi], r["unavailable"])
                if r.get("kind") == "Planned":
                    planned_mws[lo:hi] = np.maximum(planned_mws[lo:hi], r["unavailable"])
            group = fuel_group(reports[-1].get("fuel"))
            levels[i, :, groups.index(group)] += mws
            planned[i] += planned_mws
        count = 0
        for published in reversed(release):
            if published <= origin - 6 * 3600:
                break
            count += 1
        new[i] = count
    total = levels.sum(-1)
    source = "Elexon public GB production-unavailability REMIT notices. Latest revision by origin; inactive and dismissed notices are removed; overlaps on one unit use the maximum MW."
    suffix = "_strict" if strict else ""
    if strict:
        source += " Each active notice individually matches the explicit GB zone and production event type."
    save_block("remit_core"+suffix, {"reported_unit_unavailability_mw": total,
                             "reported_planned_unavailability_mw": planned,
                             "unplanned_release_count_6h": np.log1p(new)},
               TRAIN, SLOTS.shape, source)
    save_block("remit_by_fuel"+suffix,
               {"remit_" + group: levels[:, :, j] for j, group in enumerate(groups)},
               TRAIN, SLOTS.shape, source)
    print("remit", len(path_list), len(all_rows), len(records), np.quantile(total, [0, .1, .5, .9, 1]), flush=True)


if __name__ == "__main__":
    import sys
    for name in sys.argv[1:]:
        if name == "remit":
            plant_outages()
        elif name == "remit_original":
            plant_outages(strict=False)
        else:
            outlook(name)
