"""Estimate a calibrated shortage probability from already-published grid plans."""
import json
import os
import time

for variable in ("OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","OMP_NUM_THREADS"):
    os.environ[variable]="5"

import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import expit

from build_features import BASE, CUTS, HERE, ORIGINS, SLOTS, TRAIN, load_baseline, save_block
from build_physical_features import read


def build():
    native=load_baseline()
    generation=read("indgen")["indgen_forward"]/1000  # GW
    transmission=read("tsdf")["tsdf_forward"]/1000
    wind=native("WINDFOR_forward")/1000
    realized=native("five_minute_demand_lag_0")[:,:1]/1000
    plan_margin=generation-transmission
    lead=np.broadcast_to(np.arange(24)[None,:]/24,SLOTS.shape)
    stamp=SLOTS%86400/86400
    features={
        "gap":-plan_margin,
        "g":generation,
        "d":transmission,
        "external_d":native("NDF_forward")/1000,
        "wind":wind,
        "wind_share":wind/np.maximum(1,transmission),
        "realized_recent_forecast_offset":realized-transmission,
        "planned_forecast_correction":generation-native("AGPT_seasonal_mean")/1000,
        "h":lead,
        "hour_sin":np.sin(2*np.pi*stamp),
        "hour_cos":np.cos(2*np.pi*stamp),
        "gap_hinge_above1":np.maximum(0,-plan_margin-1),
        "gap_hinge_above3":np.maximum(0,-plan_margin-3),
        "gap_hinge_below1":np.maximum(0,plan_margin-1),
        "interaction":-plan_margin*lead,
    }
    x=np.stack(list(features.values()),axis=-1).astype("float32")
    return list(features),x,plan_margin


def targets():
    physical=[]
    for file in (BASE/"targets.npz",BASE/"summer-2026/targets.npz"):
        with np.load(file) as a:
            physical.append(a["y"][:,:,1:]*a["target_sd"][1:]+a["baseline"][:,:,1:])
    full=np.concatenate(physical,axis=0)
    return (full[:,:,1]>full[:,:,0]).astype("float32")


def logistic(raw,f):
    mean=np.nanmean(raw,axis=0)
    sd=np.nanstd(raw,axis=0)
    sd=np.maximum(.02,sd)
    X=(np.where(np.isfinite(raw),raw,mean)-mean)/sd
    sample=X.shape[0]
    target=f.astype("float64")

    def value(w):
        eta=w[0]+X@w[1:]
        error=expit(eta)-target
        penalty=.0005
        loss=(np.logaddexp(0,eta)-target*eta).mean()+.5*penalty*np.dot(w[1:],w[1:])
        gradient=np.r_[error.mean(),X.T@error/sample+penalty*w[1:]]
        return loss,gradient

    best=minimize(value,np.zeros(X.shape[1]+1),jac=True,method="L-BFGS-B",options={"maxiter":100,"ftol":1e-8})
    return best.x,mean,sd,bool(best.success)


def main(deadline):
    names,x,margin=build()
    y=targets()
    boundaries=pd.to_datetime(["2022-07-01","2023-01-01","2023-07-01","2024-01-01","2024-07-01","2025-01-01"],utc=True)
    boundaries=boundaries.as_unit("s").asi8.tolist()
    probability=np.full(SLOTS.shape,np.nan,dtype="float32")
    logit=probability.copy()
    calibrations=[]
    for lo,hi in zip(boundaries,[*boundaries[1:],ORIGINS[-1]+1800]):
        if time.time()>=deadline:
            return
        # Use history only, including a gap before the forward-chaining cut.
        limit=TRAIN if lo==boundaries[-1] else np.searchsorted(ORIGINS,lo-7*86400)
        subset=x[:limit:2].reshape(-1,x.shape[-1])
        fitted=logistic(subset,y[:limit:2].reshape(-1))
        beta,mu,sd,convergence=fitted
        use=(ORIGINS>=lo)&(ORIGINS<hi)
        current=x[use]
        z=(np.where(np.isfinite(current),current,mu)-mu)/sd
        candidate=z@beta[1:]+beta[0]
        probability[use]=expit(candidate)
        logit[use]=candidate
        calibrations.append({"cut":str(pd.Timestamp(lo,unit="s",tz="UTC")),
                             "train_origins_used":len(subset)//24,"converged":convergence,
                             "beta":beta.tolist(),"mean":mu.tolist(),"scale":sd.tolist()})
        print("calibrated",calibrations[-1]["cut"],len(subset),flush=True)
    controls=(margin<0).astype("float32")
    valid=np.isfinite(probability)
    brief={"features":names,"calibrations":calibrations}
    for name,pred in (("asof_logistic",probability),("sign_of_published_margin",controls)):
        error=np.where(valid,(pred-y)**2,np.nan)
        brief[name]=[float(np.nanmean(group)) for group in np.split(error,CUTS)]
    save_block("gap_probability",{
        "shortage_probability_from_public_plan":probability,
        "shortage_log_odds_from_public_plan":logit,
        "trained_shortage_probability_available":valid,
    },TRAIN,SLOTS.shape,"A per-delivery shortage probability from released Elexon/NESO signals, trained with forward-chained logistic calibration on the original train split. Final coefficients are fixed for all held-out windows. First early training segment is unavailable.")
    (HERE/"gap_probability_audit.json").write_text(json.dumps(brief,indent=2))
    print({name:brief[name] for name in ("asof_logistic","sign_of_published_margin")},flush=True)


if __name__=="__main__":
    import sys
    main(float(sys.argv[1]))
