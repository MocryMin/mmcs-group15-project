"""Summarize held-out forecasts and paired moving-block uncertainty."""
import argparse
import csv
import json
from collections import defaultdict

import numpy as np

from build_features import BASE, CUTS, FEATURES, HERE, ORIGINS, TARGETS

SPLITS = ("val", "test25", "test26")
METRICS = ("12h", "4h", "30min", *(f"12h_{t}" for t in TARGETS))


def read_runs():
    for file in sorted((HERE/"runs").glob("*/*/seed-*/result.json")):
        record = json.loads(file.read_text())
        yield file, record


def export_runs():
    grouped = defaultdict(list)
    with (HERE/"run_scores.csv").open("w",newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["stage","case","seed","parameters","selected_update","seconds","split",*METRICS])
        for file,record in read_runs():
            stage,case = file.parent.parent.parent.name,file.parent.parent.name
            for split in (*SPLITS,"test24"):
                if split in record:
                    scores = [record[split][key] for key in METRICS]
                    writer.writerow([stage,case,record["seed"],record["parameters"],record["step"],
                                     record["seconds"],split,*scores])
                    grouped[stage,case,split].append(scores)
    with (HERE/"mean_scores.csv").open("w",newline="") as f:
        writer=csv.writer(f)
        writer.writerow(["stage","case","split","seeds",*METRICS,*(f"seed_sd_{m}" for m in METRICS)])
        for (stage,case,split),scores in sorted(grouped.items()):
            sd = np.std(scores,axis=0,ddof=1) if len(scores)>1 else [""]*len(METRICS)
            writer.writerow([stage,case,split,len(scores),*np.mean(scores,axis=0),*sd])


def export_feature_catalogue():
    labels=["block","feature","provenance","training_mean","training_sd",
            "coverage_train","coverage_val","coverage_test25","coverage_test26","excluded_reason"]
    with (HERE/"feature_catalogue.csv").open("w",newline="",encoding="utf-8") as f:
        writer=csv.writer(f)
        writer.writerow(labels)
        for block in sorted(FEATURES.glob("*.json")):
            payload=json.loads(block.read_text(encoding="utf-8"))
            for details in payload["columns"]:
                writer.writerow([block.stem,details["name"],payload["provenance"],
                    details.get("mean",""),details.get("std",""),*details.get("coverage",[""]*4),details.get("excluded","")])


def paired(base, alternative, block_days=7):
    ref = dict(zip(SPLITS,np.split(ORIGINS,CUTS)[1:]))
    with np.load(BASE/"targets.npz") as a, np.load(BASE/"summer-2026/targets.npz") as b:
        val,target25 = np.split(a["y"],CUTS[:2])[1:]
        y = dict(zip(SPLITS,[val,target25,b["y"]]))
        scales = a["target_sd"]
    by_split = {s:[] for s in SPLITS}
    raw_units = {s:[] for s in SPLITS}
    for folder in sorted(base.glob("seed-*")):
        original = folder/"predictions.npz"
        updated = alternative/folder.name/"predictions.npz"
        if not original.exists() or not updated.exists():
            continue
        with np.load(original) as a, np.load(updated) as b:
            for s in SPLITS:
                e,p = a[s]-y[s],b[s]-y[s]
                by_split[s].append([e.astype("float64")**2,p.astype("float64")**2])
                raw_units[s].append([np.abs(e*scales).mean((0,1)),np.abs(p*scales).mean((0,1))])
    for s in SPLITS:
        if not by_split[s]:
            continue
        base_loss,new_loss = np.mean(by_split[s],axis=0)
        # First average over paired random seeds at each origin, then resample
        # calendar blocks of origins. This keeps the overlap between 12 h labels.
        days = ref[s]//86400
        _,index = np.unique(days,return_inverse=True)
        count = np.bincount(index)
        rng = np.random.default_rng(209)
        length = len(count)
        n_blocks = int(np.ceil(length/block_days))
        starts = rng.integers(0,length-block_days+1,size=(6000,n_blocks))
        resampled = (starts[:,:,None] + np.arange(block_days)[None,None,:]).reshape(6000,-1)[:,:length]
        for scope,horizon in [("12h",24),("4h",8),("30min",1)]:
            baseline = base_loss[:,:horizon].mean(1)
            candidate = new_loss[:,:horizon].mean(1)
            for target in range(-1,3):
                b = baseline.mean(1) if target<0 else baseline[:,target]
                c = candidate.mean(1) if target<0 else candidate[:,target]
                g = np.bincount(index,weights=b)
                h = np.bincount(index,weights=c)
                samples = 100*(1-h[resampled].sum(1)/g[resampled].sum(1))
                point = 100*(1-c.mean()/b.mean())
                bounds = np.quantile(samples,[.025,.975])
                yield dict(split=s,scope=scope,metric="standardized_mse",target="overall" if target<0 else TARGETS[target],
                           seeds=len(by_split[s]),base_error=b.mean(),variant_error=c.mean(),
                           reduction_pct=point,block_days=block_days,block95_lower=bounds[0],block95_upper=bounds[1])
        before, after=np.mean(raw_units[s],axis=0)
        for i,name in enumerate(TARGETS):
            yield dict(split=s,scope="12h",metric="physical_mae",target=name,seeds=len(by_split[s]),
                       base_error=before[i],variant_error=after[i],reduction_pct=100*(1-after[i]/before[i]),
                       block_days="",block95_lower="",block95_upper="")


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--pairs",nargs="*",help="Two paths under runs separated by '='. Defaults to paired_recipes.json.")
    p.add_argument("--block-days",type=int,choices=(7,14,28),default=7)
    args=p.parse_args()
    if args.block_days==7:
        export_runs()
        export_feature_catalogue()
    rows=[]
    comparisons=args.pairs if args.pairs is not None else json.loads((HERE/"paired_recipes.json").read_text())
    for pair in comparisons:
        left,right=pair.split("=")
        for row in paired(HERE/"runs"/left,HERE/"runs"/right,args.block_days):
            rows.append(dict(base=left,variant=right,**row))
    if rows:
        filename="paired_block_intervals.csv" if args.block_days==7 else f"paired_block{args.block_days}_intervals.csv"
        with (HERE/filename).open("w",newline="") as f:
            writer=csv.DictWriter(f,rows[0].keys()); writer.writeheader();writer.writerows(rows)


if __name__=="__main__":
    main()
