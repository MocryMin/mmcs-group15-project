# Tier 2B 特征的数据来源与可用时间

预测从 $t$ 开始，每 30 分钟更新一次。对未来第 $h$ 个半小时交付槽，所有输入都在 $t$ 时读取。预测有 24 个交付槽。既有 59 个输入的定义、误差目标和标签修复规则见 [原截至时点研究](../tier2b-asof-20261119/sources.md)。此次的额外特征按原日期划分、在训练集定标；各组的列名、定标值和覆盖率在 `blocks/*.json`。

| 数据 | 采用的字段或构造 | 时间边界 |
|:--|:--|:--|
| [Elexon BMRS](https://data.elexon.co.uk/swagger/index.html) 的 TSDF、INDGEN、INDDEM | 英国输电系统需求预报、指示性发电及需求计划。采用全国边界 `N` 的水平、修订量及跨源差 | 对每个交付槽选 `publishTime ≤ t` 的最后一条。另测 30、120 和 360 分钟数据延迟 |
| [Elexon BMRS](https://data.elexon.co.uk/swagger/index.html) 的 IMBALNGC、MELNGC、LOLPDRM | 失衡指示、发电裕度、失负荷概率及折减裕度 | 同上。前三个全国规划序列及三项风险序列按各自发布时间拼接，逐半小时匹配 |
| [Elexon FUELINST](https://bmrs.elexon.co.uk/api-documentation/endpoint/datasets/FUELINST) | 分燃料与跨境流量、变化量、近期发电结构 | 底层记录的五分钟区间已完成且相应版本已发布 |
| [Elexon REMIT](https://bmrs.elexon.co.uk/remit) | 公开电厂计划和非计划停机 MW、最近停机公告数量 | 按可见修订重建有效区间，撤销、失效立即移出。同一机组同槽多条记录取最大 MW |
| [NESO 嵌入式风光预报](https://www.neso.energy/data-portal/embedded-wind-and-solar-forecasts) | 每 30 分钟的配电侧风电和光伏预报、装机比例、相对早期版本的修订 | `Forecast_Datetime + 10 分钟 ≤ t`。对 GMT 时刻、结算日期和结算期做交叉核对。2026 夏季使用同一官方 CKAN 档的按日期切片 |
| [Open-Meteo Previous Runs](https://open-meteo.com/en/docs/previous-runs-api) | JMA GSM、GFS 等历史预报中的温度、风速／风向、云量和短波辐照。测试多个城市和近海位置 | 使用比对应交付小时早至少 24 或 48 小时的版本。个别天气模型仅从 2024 年左右有可用记录。一般区域模型、单一风场经纬度模型分别处理 |
| [课程风场脚本](../../../materials/sync-20261114-tutor-intake/farm_generator.py) | 56.5°N、2.7°W、75 台 15 MW、100 m 轮毂、课件的分段功率曲线。用该坐标的 JMA／GFS 预报估计课内独立风场日均发电 | 在天气版本最短提前期上再加 1 小时。指数和风速偏移只在训练期选取。课件 ERA5 再分析用于生成历史标签，预测输入采用天气预报档 |
| [National Gas Data Portal](https://data.nationalgas.com/find-gas-data) | 英国天然气 OCM（On-the-day Commodity Market，当日商品市场）SAP 系统平均价和 SMP 系统边际价 | 公布时间按两项源字段中较晚的时间再加 1 小时处理；每个时点选最后一个已可用气日。价格从便士/kWh 换算为英镑/MWh（热值） |
| [NESO GTMA](https://www.neso.energy/data-portal/historic-gtma-grid-trade-master-agreement-trades-data) | 英国电网运营商真实电力交易，成交量、成交价、买卖差和笔数 | 主实验用历史月底档，并延后完整一个月后使用且检查更新时间；另对每日文件做至少 49 小时延迟的敏感性分析。课程模拟客户自身交易没有对应历史记录 |
| [英国碳价与成本控制机制表](https://www.gov.uk/government/publications/taking-part-in-the-uk-emissions-trading-scheme-markets/cost-containment-mechanism-ccm-trigger-prices-and-average-monthly-prices-full-table) | 英国排放配额的月均历史价格、月差、距触发水平、近似燃气边际成本 | 监测月份结束后使用上一个完整月均值。非常规修订和逐行发布日期无独立快照；有关组作为有公布滞后假设的研究 |
| [政府商业账单补贴](https://www.gov.uk/guidance/energy-bill-relief-scheme-help-for-businesses-and-other-non-domestic-customers) / [UK ETS 2023 决定](https://www.gov.uk/government/consultations/developing-the-uk-emissions-trading-scheme-uk-ets) / [政府节假日](https://www.gov.uk/bank-holidays) | 政策公告、实施日期和节假日变量 | 政策从公告后的预先已知适用区间生效。对本研究的含义是统计预测特征 |
| [ONS D7BT / MM23 CPI](https://www.ons.gov.uk/economy/inflationandpriceindices/timeseries/d7bt/mm23) | 用两个自然月前的 CPI 把已知名义报价映射到目标口径的 2020 英镑 | 正式历史版档经核查存在，批量端点限流。实验使用课内现存 CPI 版档及两月滞后，属于版本敏感性 |
| [Nord Pool N2EX 拍卖](https://support.nordpoolgroup.com/support/solutions/articles/8000088463-about-the-n2ex-day-ahead-auction) | 英国日前拍卖结果、价差、先前已知报价水平 | 继承原代码的交付日 00:00 UTC 可用规则。将可见性提前到交付前一天下午/晚上是另外的敏感性，实际逐日发布和修订时间无法从现有存档重放 |

市场指数的最终结算价是模型标签，课程重建把每日均值和小时形状拼合。数据源和电网覆盖范围的差异进入模型估计；例如 TSDF、NDF、INDGEN 与课程构造系统的实际供需数字各有各的定义。独立风场按课内日均划分到同日各时段。三个模型目标沿用同一标签，以保持横向比较。

原始数据、抓取回执和可复核的紧凑分块位于 `sources/`。从文件名前缀可找到采集脚本和特征生成脚本。英国 EUA/UKA 的 ICE 交易报告采用数据使用条款入口，本轮分析使用政府公开的英国配额月均价格。全国供需预报、选定天气输入和交易迟滞来源已在上表列出。
