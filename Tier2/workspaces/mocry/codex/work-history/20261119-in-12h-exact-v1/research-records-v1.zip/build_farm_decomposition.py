"""Use the course's additive generation balance to test a separate farm forecast."""
import json

import numpy as np
import pandas as pd

from build_farm_weather import label_days
from build_features import BASE, FEATURES, HERE, SLOTS, TRAIN


def main():
    key = "farm_weather_hub"
    definition = json.loads((FEATURES / f"{key}.json").read_text())
    head = definition["columns"][0]
    assert head["name"] == "inch_cape_GFS_hub_daily_power"
    assert min(head["coverage"]) == 1.0
    encoded = np.load(FEATURES / f"{key}.npy", mmap_mode="r")[:, :, 0]
    forecast_mw = encoded * head["std"] + head["mean"]
    days = SLOTS // 86400 * 86400
    unique, indexes = np.unique(days, return_inverse=True)
    farm = label_days()
    actual_mw = farm.reindex(unique).to_numpy()[indexes].reshape(days.shape)
    assert np.isfinite(actual_mw).all() and np.isfinite(forecast_mw).all()
    train_days = np.unique(days[:TRAIN])
    train_mw = farm.reindex(train_days).to_numpy()
    train_month = pd.to_datetime(train_days, unit="s", utc=True).month
    monthly_mw = pd.Series(train_mw, index=train_month).groupby(level=0).mean()
    months = pd.to_datetime(unique, unit="s", utc=True).month
    climatology = monthly_mw.reindex(months).to_numpy()[indexes].reshape(days.shape)
    with np.load(BASE / "targets.npz") as targets:
        # Power (MW averaged over half an hour) becomes MWh before standardizing.
        factor = 0.5 / targets["target_sd"][1]
    forecast = ((forecast_mw - climatology) * factor).astype("float32")
    training_actual = ((actual_mw[:TRAIN] - climatology[:TRAIN]) * factor).astype("float32")
    np.savez_compressed(HERE / "farm_decomposition_offsets.npz",
                       forecast=forecast, training_actual=training_actual)
    print("Stored weather forecasts and training-only farm label corrections", flush=True)


if __name__ == "__main__":
    main()
