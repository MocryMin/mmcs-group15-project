"""Translate an archived forecast into the independent farm's daily model output."""
import gzip
import json

import numpy as np
import pandas as pd

from build_features import CUTS, HERE, ORIGINS, P, SLOTS, TRAIN, save_block

FARM_CAPACITY_MW=75*15
CURVE_SPEED=np.array([0,3,5,7,9,11,12,13,25,26])
CURVE_SHARE=np.array([0,0,.08,.28,.54,.85,1,1,1,0])


class Weather:
    def __init__(self,name,height):
        file=HERE/"sources"/f"{name}.gz"
        source=json.load(gzip.open(file,"rt",encoding="utf-8"))
        self.source=source["url"]
        data=source["payload"]["hourly"]
        self.t=pd.to_datetime(data["time"],utc=True).as_unit("s").astype("int64").to_numpy()
        self.v=np.array([data[f"wind_speed_{height}m_previous_day{m}"] for m in (1,2)],dtype="float32")
        self.height=height

    def forecast(self,hours,origins):
        slots=np.searchsorted(self.t,hours)
        assert np.array_equal(self.t[slots],hours)
        # Previous Runs labels each valid time with minimum lead. Leave an extra full
        # hour, so every selected vintage is available conservatively before issue.
        fresh=(hours-25*3600<=origins)&np.isfinite(self.v[0,slots])
        older=(hours-49*3600<=origins)&np.isfinite(self.v[1,slots])
        use=np.where(fresh,self.v[0,slots],np.where(older,self.v[1,slots],np.nan))
        return use


def power(speeds):
    return FARM_CAPACITY_MW*np.interp(speeds,CURVE_SPEED,CURVE_SHARE,left=0,right=0)


def daily(archive,d,origins,exponent=1/7,bias=0):
    view=archive.forecast(d+3600*np.arange(24)[None,:],origins)
    return np.mean(power(view*(100/archive.height)**exponent+bias),axis=1,keepdims=True)


def label_days():
    daily_wind=pd.read_csv(P/"tier1-multiproduct-20261110-v6/inputs/wind_farm_generation.csv")
    index=pd.to_datetime(daily_wind.date,utc=True).dt.as_unit("s").astype("int64")
    assert daily_wind.wind_farm_MW.max()<=FARM_CAPACITY_MW
    return pd.Series(daily_wind.wind_farm_MW.to_numpy(),index=index)


def choice(today,tomorrow,dates):
    return np.where(SLOTS<dates+86400,today,tomorrow)


def main():
    jma=Weather("inch_cape_jma",10)
    gfs=Weather("inch_cape_gfs",80)
    physics="Course farm_generator.py, site 56.5 N/2.7 W, 75 × 15 MW, 100-m hub and the published turbine power curve. Weather is Open-Meteo Previous Runs JMA or GFS, guarded by 1h on top of vintage's lower-bound issue time. ERA5 future reanalysis is excluded from inputs."
    orig=ORIGINS[:,None]
    d=orig//86400*86400
    measured=label_days()
    pc=daily(jma,d,orig)
    pn=daily(jma,d+86400,orig)
    speed = jma.forecast(SLOTS//3600*3600,orig)
    forecast = choice(pc,pn,d)
    slot_power = power(speed*10**(1/7))
    save_block("farm_weather_physical",{
        "inch_cape_daily_power_from_weather":forecast,
        "inch_cape_half_hour_power_proxy":slot_power,
        "inch_cape_hourly_wind_speed_10m":speed,
        "inch_cape_future_minus_daily_mean":slot_power-forecast,
    },TRAIN,SLOTS.shape,physics+" 10-to-100 m factor is the teacher's 1/7 exponent. Daily labels treat the daily level as flat.")

    # Fit a wind-speed calibration to historical farm output, one origin per day.
    # Generalization checks leave the validation and both tests untouched.
    ix=(ORIGINS%86400==0)&(np.arange(len(ORIGINS))<TRAIN)
    historical=jma.forecast(d[ix,:]+3600*np.arange(24)[None,:],orig[ix,:])
    actual=measured.reindex(d[ix,0]).to_numpy()
    candidates=[]
    for exponent in (.10,.12,1/7,.16,.18,.20,.22):
        for bias in (-1.25,-.75,-.25,0,.25,.75,1.25):
            expected=power(historical*10**exponent+bias).mean(1)
            candidates.append((float(np.nanmean((expected-actual)**2)),exponent,bias))
    error,exponent,bias=min(candidates)
    learned=choice(daily(jma,d,orig,exponent,bias),daily(jma,d+86400,orig,exponent,bias),d)
    save_block("farm_weather_calibrated",{
       "inch_cape_calibrated_daily_power":learned,
       "inch_cape_calibrated_vs_physics":learned-forecast,
    },TRAIN,SLOTS.shape,physics+f" Fitted on train-day origins only: exponent {exponent}, bias {bias} m/s.")

    gt=daily(gfs,d,orig)
    gn=daily(gfs,d+86400,orig)
    direct=choice(gt,gn,d)
    save_block("farm_weather_hub",{
        "inch_cape_GFS_hub_daily_power":np.where(np.isfinite(direct),direct,learned),
        "inch_cape_GFS_hub_observed":np.isfinite(direct),
        "inch_cape_JMA_GFS_disagreement":direct-learned,
    },TRAIN,SLOTS.shape,physics+" GFS 80m operates only when archived; clipped daily fallback to calibrated JMA.")
    months = pd.to_datetime(d[:,0],unit="s",utc=True).month
    observations = measured.reindex(d[ix,0]).to_numpy()
    historical_month = pd.Series(observations,index=months[ix]).groupby(level=0).mean()
    seasonal = historical_month.reindex(months).to_numpy()[:,None]
    lagged = measured.reindex(d[:,0]-2*86400).to_numpy()[:,None]
    out={}
    for name,v in (("train_month_mean",seasonal),("two_day_persistence",lagged),("physical_JMA",forecast),
                   ("calibrated_JMA",learned),("GFS_plus_JMA",np.where(np.isfinite(direct),direct,learned))):
        residual=v[:,0]-measured.reindex(d[:,0]).to_numpy()
        out[name]=[float(np.sqrt(np.nanmean(s[(index%86400)==0]**2))) for s,index in zip(np.split(residual,CUTS),np.split(ORIGINS,CUTS))]
    (HERE/"farm_weather_audit.json").write_text(json.dumps({
        "rmse_of_daily_farm_forecast_MW_for_train_val_test25_test26":out,
        "training_only_speed_calibration":{"exponent":exponent,"bias_m_per_s":bias},
        "link":{"JMA":jma.source,"GFS":gfs.source},
    },indent=2))
    print(out,flush=True)


if __name__=="__main__":
    main()
