"""As-of UK gas trading price features from official publication timestamps."""
import gzip
import json

import numpy as np
import pandas as pd

from build_features import HERE, ORIGINS, SLOTS, TRAIN, load_baseline, save_block

GAS = HERE / "sources"


def lookup(records, dates):
    # Each gas day has its own set of revisions. The latest visible revision is chosen
    # independently of when records covering other gas days become available.
    data = records[["day", "published", "observation", "price"]].copy()
    data.sort_values(["day", "published", "observation"], inplace=True)
    data.drop_duplicates(["day", "published"], keep="last", inplace=True)
    day = data.day.to_numpy("int64")
    published = data.published.to_numpy("int64")
    value = data.price.to_numpy("float32")
    epoch = 1609459200
    scale = 1_000_000_000
    key = day // 86400 * scale + published - epoch
    assert (day % 86400 == 0).all() and (published - epoch < scale).all()

    def select(period):
        i = np.searchsorted(key, period // 86400 * scale + ORIGINS - epoch, side="right") - 1
        match = (i >= 0) & (day[i] == period) & (published[i] <= ORIGINS)
        return np.where(match, value[i], np.nan)

    return np.column_stack([select(dates - lag * 86400) for lag in range(10)])


def moving_mean(values):
    present = np.isfinite(values)
    return np.where(present.any(1), np.nansum(values, axis=1) / np.maximum(1, present.sum(1)), np.nan)


def latest_valid(values):
    indices = np.argmax(np.isfinite(values), axis=1)
    value = values[np.arange(len(values)), indices]
    return value[:, None], np.where(np.isfinite(value), indices, np.nan)[:, None]


def main():
    files = sorted(GAS.glob("gas-tape-*.gz"))
    raw = pd.DataFrame([r for path in files for r in json.load(gzip.open(path, "rt"))["data"]])
    raw = raw[raw["UnitOfMeasure"].eq("p/kWh")].copy()
    raw["day"] = pd.to_datetime(raw.applicableFor, dayfirst=True, utc=True, errors="coerce")
    applied = pd.to_datetime(raw.applicableAt, dayfirst=True, utc=True, errors="coerce")
    generated = pd.to_datetime(raw.generatedTimeStamp, dayfirst=True, utc=True, errors="coerce")
    raw["observation"] = applied
    # The site does not attach a UTC offset. Treat times as UTC and add one hour.
    raw["published"] = pd.concat([applied, generated], axis=1).max(axis=1) + pd.Timedelta(hours=1)
    raw["price"] = 10 * pd.to_numeric(raw.value, errors="coerce")  # p/kWh to GBP/MWh
    raw = raw.dropna(subset=["day", "observation", "published", "price"])
    for name in ("day", "observation", "published"):
        raw[name] = raw[name].dt.as_unit("s").astype("int64")
    # Gas day starts at 05:00 local. Search back conservatively from the UTC date.
    dates = ORIGINS // 86400 * 86400
    outcomes = {name: lookup(group, dates) for name, group in raw.groupby("itemName")}
    suite = outcomes["SAP, Actual Day"]
    actual, age = latest_valid(suite)
    seven_day = moving_mean(suite[:, 2:9])[:, None]
    hourly, age_hourly = latest_valid(outcomes["SAP, hourly actual"])
    buy, _ = latest_valid(outcomes["SMP Buy, Actual Day"])
    sell, _ = latest_valid(outcomes["SMP Sell, Actual Day"])
    source = "National Gas Data Portal OCM trade prices PUBOB603/47 and system marginal prices PUBOB604/605. Publication guard is max(applicableAt, generatedTimeStamp)+1h, then latest visible gas day/revision. Units GBP/MWh thermal."
    save_block("gas_prices", {
        "gas_SAP_recent": actual,
        "gas_SAP_log1p": np.log1p(np.maximum(0, actual)),
        "gas_SAP_moving_week": seven_day,
        "gas_SAP_vs_week": actual-seven_day,
        "gas_SAP_age_days": age,
    }, TRAIN, SLOTS.shape, source)
    save_block("gas_balancing", {
        "gas_hourly_SAP_age": age_hourly,
        "gas_hourly_SAP_minus_daily": hourly-actual,
        "gas_buy_premium": buy-actual,
        "gas_sell_discount": actual-sell,
    }, TRAIN, SLOTS.shape, source)
    native = load_baseline()
    approximation = native("PRICES_forward")
    demand = native("NDF_forward")
    wind = native("WINDFOR_forward")
    save_block("gas_market_spread", {
        "auction_minus_fuel_cost_at_50pct_efficiency": approximation - 2*actual,
        "fuel_cost_times_net_load": 2*actual*(demand-wind),
        "gas_volatility_of_seven_day_quotes": moving_mean((suite[:, 2:9]-seven_day)**2)[:, None]**.5,
    }, TRAIN, SLOTS.shape, source + " A 50% heat-rate proxy is a modelling feature, not a forecast of any plant's true gross margin.")
    print(len(files),len(raw),raw["itemName"].value_counts().to_dict(),flush=True)


if __name__ == "__main__":
    main()
