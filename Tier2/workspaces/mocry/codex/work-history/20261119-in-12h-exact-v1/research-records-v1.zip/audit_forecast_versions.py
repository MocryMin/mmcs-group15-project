"""Check whether multiple rows with identical delivery and publication disagree."""
import json

import pandas as pd

from build_features import HERE


def main():
    results={}
    for dataset in ("indgen","tsdf","inddem","imbalngc","lolpdrm"):
        files=sorted((HERE/"sources").glob(f"{dataset}-*.gz"))
        rows=pd.concat([pd.read_csv(f) for f in files],ignore_index=True)
        multiple=rows.duplicated(["obs","pub"],keep=False)
        duplicates=rows.loc[multiple]
        groups=duplicates.groupby(["obs","pub"],sort=False)
        conflicts=groups[["value","probability"]].nunique().gt(1).any(axis=1)
        elapsed=(rows.obs-rows.pub)/3600
        results[dataset]=dict(records=len(rows),files=len(files),
            duplicate_keys=int(len(conflicts)),different_values_at_same_key=int(conflicts.sum()),
            publish_to_delivery_hour_quantiles=elapsed.quantile([.01,.25,.5,.95,.99]).to_dict())
        print(dataset,results[dataset],flush=True)
    (HERE/"published_forecast_audit.json").write_text(json.dumps(results,indent=2))


if __name__=="__main__":
    main()
