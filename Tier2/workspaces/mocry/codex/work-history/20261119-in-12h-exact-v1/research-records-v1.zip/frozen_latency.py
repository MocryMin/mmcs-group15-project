"""Stress published feed latency in already-trained matched models."""
import argparse
import csv
import json
import time

import numpy as np
import torch

from build_features import BASE, CUTS, FEATURES, HERE
from experiment import Model, predict, recipe_features, scores


def details(name):
    arr = np.load(FEATURES/f"{name}.npy",mmap_mode="r")
    records = json.loads((FEATURES/f"{name}.json").read_text())["columns"]
    return {r["name"]:(arr[:,:,i],r) for i,r in enumerate(v for v in records if "mean" in v)}


def replacements(x,names,kind,delay):
    original=details(kind)
    actual=details(f"{kind}_delay{delay}")
    for key,(_,dest) in original.items():
        position=names.index(key)
        if key not in actual:
            continue
        norm,prior=actual[key]
        physical=norm*prior["std"]+prior["mean"]
        x[:,:,position]=(physical-dest["mean"])/dest["std"]


def run(cases, deadline):
    old=np.concatenate([np.load(BASE/"inputs.npy",mmap_mode="r"),
                        np.load(BASE/"summer-2026/inputs.npy",mmap_mode="r")])
    names=json.loads((BASE/"features.json").read_text())["names"]
    with np.load(BASE/"targets.npz") as a, np.load(BASE/"summer-2026/targets.npz") as b:
        y = {s:torch.as_tensor(v,device="cuda")
             for s,v in (("val",a["y"][CUTS[0]:CUTS[1]]),("test25",a["y"][CUTS[1]:]),("test26",b["y"]))}
    result=[]
    for case in cases:
        root=HERE/"runs"/case
        checkpoints=sorted(root.glob("seed-*/result.json"))
        cfg=json.loads((checkpoints[0].parent/"config.json").read_text())["case"]
        cases_sources=[k for k in ("tsdf","indgen") if k in cfg.get("blocks",[])]
        if not cases_sources or cfg.get("transform") or cfg.get("anchor") or cfg.get("ridge_offset"):
            raise ValueError(f"Need raw forecast inputs and an untransformed checkpoint: {case}")
        x,cols=recipe_features(old,names,cfg,int(CUTS[0]))
        x=x.numpy()
        for condition in ("original","delay30","delay120","delay360","missing"):
            if time.time()>=deadline:
                return result
            sp=x.copy()
            for kind in cases_sources:
                if condition=="missing":
                    for key in details(kind):
                        sp[:,:,cols.index(key)]=0
                elif condition.startswith("delay"):
                    replacements(sp,cols,kind,int(condition[5:]))
            xs={s:torch.as_tensor(out,device="cuda") for s,out in zip(y,np.split(sp,CUTS)[1:])}
            for ck in checkpoints:
                saved=json.loads(ck.read_text())
                current=torch.load(ck.parent/"model.pt",weights_only=True,map_location="cuda")
                m=Model(cols,cfg.get("width",344),cfg.get("layers",1),
                        cfg.get("projection","linear"),cfg.get("head","mean")).cuda()
                m.load_state_dict(current["weights"])
                for split,v in xs.items():
                    row=scores(predict(m,v,deadline),y[split])
                    if condition=="original":
                        np.testing.assert_allclose(row["12h"],saved[split]["12h"],rtol=8e-5,atol=2e-7)
                    result.append({"case":case,"seed":saved["seed"],"condition":condition,"split":split,**row})
            del xs,sp
            print(case,condition,flush=True)
    return result


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("cases",nargs="+")
    p.add_argument("--deadline",type=float,required=True)
    p.add_argument("--output",default="frozen_feed_latency.csv")
    a=p.parse_args()
    torch.set_float32_matmul_precision("high")
    rows=run(a.cases,a.deadline)
    if rows:
        with (HERE/a.output).open("w",newline="") as f:
            w=csv.DictWriter(f,rows[0].keys());w.writeheader();w.writerows(rows)
