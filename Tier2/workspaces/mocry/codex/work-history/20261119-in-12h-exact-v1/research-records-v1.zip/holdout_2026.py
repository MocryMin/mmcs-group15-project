"""Reconstruct and evaluate the predeclared Jan–May 2026 holdout."""
import argparse
import csv
import importlib.util
import json
from pathlib import Path
import shutil
import time

import numpy as np
import pandas as pd

from build_features import BASE, FEATURES, HERE, P, SIZES, forecast_shape_columns
from build_forward_features import generation_columns

FOLDER=HERE/"jan_may_2026"
DATA=FOLDER/"sources"
PLAN=json.loads((HERE/"holdout_2026_plan.json").read_text())
SCHEMA=json.loads((BASE/"features.json").read_text())
LEGACY=("AGPT","FUELINST","INDO","ITSDO","NDF","WINDFOR")


def import_file(label,path):
    spec=importlib.util.spec_from_file_location(label,path)
    m=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def prepare():
    DATA.mkdir(parents=True,exist_ok=True)
    raw=HERE/"sources"
    for f in raw.glob("extra26-*.gz"):
        _,feed,date=f.stem.split("-",2)
        if feed.upper() in LEGACY:
            shutil.copyfile(f,DATA/f"{feed.upper()}-{date}.csv.gz")
    for name in LEGACY:
        learned=list(DATA.glob(f"{name}-2026-*.csv.gz"))
        if len(learned)!=22:
            raise FileNotFoundError(f"{name}: only {len(learned)} of the expected 22 weekly releases")
        for f in (BASE/"sources").glob(f"{name}-2025-12-*.csv.gz"):
            shutil.copyfile(f,DATA/f.name)
    for f in (BASE/"summer-2026/sources").glob("PRICES-*.csv.gz"):
        shutil.copyfile(f,DATA/f.name)
    v7=import_file("holdout_labels_v7",P/"tier1-halfhour-20261113-v7/prepare_data.py")
    asof=import_file("holdout_point_in_time",BASE/"prepare_data.py")
    inputs=P/"tier1-multiproduct-20261110-v6/inputs"
    day=pd.read_csv(inputs/"daily_market_index_price.csv",index_col="date").iloc[:,0]
    cpi=pd.read_csv(inputs/"CPI.csv",dtype=str).set_index("Title").iloc[:,0]
    cpi=cpi[cpi.index.str.fullmatch(r"\d{4} [A-Z]{3}",na=False)]
    months=pd.to_datetime(day.index).strftime("%Y %b").str.upper()
    target_price=day*108.7/cpi.reindex(months).to_numpy(dtype=float)
    days=pd.date_range(PLAN["start"],PLAN["end_exclusive"],inclusive="left")
    label,quality=v7.reconstruct(days.strftime("%Y-%m-%d").tolist(),target_price)
    assert len(label)==len(days)*48
    label.to_csv(FOLDER/"labels.csv.gz",index=False,compression="gzip")
    quality.to_csv(FOLDER/"quality.csv",index=False)
    asof.main(FOLDER,frame=label,splits={"test":(PLAN["start"],PLAN["end_exclusive"])},
              source_dir=DATA,frozen=SCHEMA)
    assert json.loads((FOLDER/"features.json").read_text())["names"]==SCHEMA["names"]
    with np.load(FOLDER/"targets.npz") as a:
        assert len(a["utc"])==len(days)*48-23
        assert np.all(np.diff(a["utc"])==1800)
    print(len(days),"days rebuilt and input schema checked",flush=True)


def source_values(dataset,origin,slot):
    root=HERE/"sources"
    recent=list(root.glob(f"extra26-{dataset}-*.gz"))
    if len(recent)!=22:
        raise FileNotFoundError(f"{dataset}: only {len(recent)} weekly datasets")
    archived=[f for f in root.glob(f"{dataset}-2025-12-*.gz") if f.stem[-2:] >= "13"]
    v=pd.concat([pd.read_csv(f) for f in sorted(archived+recent)],ignore_index=True)
    v.sort_values(["obs","pub"],kind="stable",inplace=True)
    v.drop_duplicates(["obs","pub"],keep="last",inplace=True)
    pub,obs=v.pub.to_numpy("int64"),v.obs.to_numpy("int64")
    tzero=1609459200
    stride=1_000_000_000
    key=obs//1800*stride+pub-tzero
    ix=np.searchsorted(key,slot//1800*stride+origin[:,None]-tzero,side="right")-1
    keep=(ix>=0)&(obs[ix]==slot)&(pub[ix]<=origin[:,None])
    return {
        f"{dataset}_forward":np.where(keep,v.value.to_numpy("float32")[ix],np.nan),
        f"{dataset}_forecast_age":np.where(keep,np.log1p(np.maximum(0,origin[:,None]-pub[ix])/60),np.nan),
        f"{dataset}_known":keep,
    }


def columns(feature_block,x,origin):
    slot=origin[:,None]+np.arange(24)*1800
    names=SCHEMA["names"]

    def native(name):
        j=names.index(name)
        raw=x[:,:,j]*SCHEMA["std"][j]+SCHEMA["mean"][j]
        for ir in (name+"_observed",name+"_known"):
            if ir in names:
                pos=names.index(ir)
                keep=x[:,:,pos]*SCHEMA["std"][pos]+SCHEMA["mean"][pos]>.5
                return np.where(keep,raw,np.nan)
        return raw

    if feature_block=="forecast_shape":
        return forecast_shape_columns(native)
    if feature_block=="generation_schedule":
        g=source_values("indgen",origin,slot)["indgen_forward"]
        d=source_values("inddem",origin,slot)["inddem_forward"]
        t=source_values("tsdf",origin,slot)["tsdf_forward"]
        return generation_columns(g,d,t,native)
    if feature_block in {"indgen","tsdf"}:
        return source_values(feature_block,origin,slot)
    raise ValueError(feature_block)


def block(name,x,origin):
    definition=json.loads((FEATURES/f"{name}.json").read_text())
    series=columns(name,x,origin)
    out=[]
    labels=[]
    coverage={}
    for row in definition["columns"]:
        if "mean" not in row:
            continue
        label=row["name"]
        raw=np.broadcast_to(np.asarray(series[label],dtype="float32"),x.shape[:2])
        finite=np.isfinite(raw)
        out.append(np.where(finite,(raw-row["mean"])/row["std"],0).astype("float32"))
        coverage[label]=float(finite.mean())
        labels.append(label)
    return np.stack(out,axis=-1),labels,coverage


def evaluate(deadline,supplement,replicas=False):
    import torch
    from experiment import Model, predict, recipe_features, scores, zca_parameters
    torch.set_float32_matmul_precision("high")
    x=np.load(FOLDER/"inputs.npy")
    with np.load(FOLDER/"targets.npz") as a:
        origin=a["utc"]
        y=torch.tensor(a["y"],device="cuda")
    cache={}
    output=[]
    result_predictions={}
    planned=PLAN["models_frozen_before_calculating_errors"]
    suffix=""
    if supplement:
        planned=json.loads((HERE/"holdout_2026_preprocessing_plan.json").read_text())["models"]
        suffix="_preprocessing"
    if replicas:
        planned=json.loads((HERE/"holdout_2026_replicas_plan.json").read_text())["models"]
        suffix="_replicas"
    for name in planned:
        if time.time()>=deadline:
            break
        root=HERE/"runs"/name
        configs=sorted(c for c in root.glob("seed-*/config.json") if (c.parent/"result.json").exists())
        expected=6 if replicas else 3
        if len(configs)!=expected:
            raise ValueError(f"Expected {expected} completed seeds for {name}")
        case=json.loads(configs[0].read_text())["case"]
        keep=[i for i,k in enumerate(SCHEMA["names"]) if not any(k.startswith(p) for p in case.get("drop",[]))]
        blocks=[x[:,:,keep]]
        columns=[SCHEMA["names"][i] for i in keep]
        for b in case.get("blocks",[]):
            if b not in cache:
                cache[b]=block(b,x,origin)
            matrix,labels,_=cache[b]
            blocks.append(matrix)
            columns.extend(labels)
        values=np.concatenate(blocks,axis=-1)
        if case.get("transform")=="zca":
            train=np.concatenate([np.load(BASE/"inputs.npy",mmap_mode="r"),
                                  np.load(BASE/"summer-2026/inputs.npy",mmap_mode="r")])
            recipe={**case,"transform":"identity"}
            r,_=recipe_features(train,SCHEMA["names"],recipe,int(SIZES[0]))
            mean,white=zca_parameters(r.numpy(),int(SIZES[0]),case.get("zca_floor",.15))
            values=(values-mean)@white
            fname=name.replace("/","-")+"_train_preprocessing.npz"
            np.savez_compressed(FOLDER/fname,center=mean,projection=white)
        values=torch.tensor(values,device="cuda")
        for c in configs:
            info=json.loads(c.read_text())
            assert info["features"]==columns
            saved=torch.load(c.parent/"model.pt",weights_only=True,map_location="cuda")
            model=Model(columns,case.get("width",344),case.get("layers",1),
                        case.get("projection","linear"),case.get("head","mean")).cuda()
            model.load_state_dict(saved["weights"])
            prediction=predict(model,values,deadline)
            result_predictions[f"{name}:{info['seed']}"]=prediction.cpu().numpy()
            output.append({"model":name,"seed":info["seed"],"step":saved["step"],**scores(prediction,y)})
        print(name,"evaluated",flush=True)
    if output:
        with (FOLDER/f"scores{suffix}.csv").open("w",newline="") as f:
            w=csv.DictWriter(f,output[0].keys());w.writeheader();w.writerows(output)
        np.savez_compressed(FOLDER/f"predictions{suffix}.npz",**result_predictions)
    fname=f"feature_coverage{suffix}.json"
    (FOLDER/fname).write_text(json.dumps({k:v[2] for k,v in cache.items()},indent=2))


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("mode",choices=["prepare","evaluate"])
    p.add_argument("--deadline",required=True,type=float)
    evaluation=p.add_mutually_exclusive_group()
    evaluation.add_argument("--supplement",action="store_true")
    evaluation.add_argument("--replicas",action="store_true")
    a=p.parse_args()
    if a.mode=="prepare":
        if time.time()<a.deadline:
            prepare()
    else:
        evaluate(a.deadline,a.supplement,a.replicas)
