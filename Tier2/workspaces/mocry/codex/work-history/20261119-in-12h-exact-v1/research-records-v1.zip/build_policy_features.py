"""Features from publicly announced policy dates and monthly UKA market averages."""
import gzip
import json
import re

import numpy as np
import pandas as pd

from build_features import HERE, ORIGINS, SLOTS, TRAIN, load_baseline, save_block


def timestamp(text):
    return int(pd.Timestamp(text,tz="UTC").timestamp())


def main():
    root = json.load(gzip.open(HERE/"sources/carbon-monthly-gov.gz","rt",encoding="utf-8"))
    table = root["ccm"]["tables"]
    last = np.full(len(ORIGINS),np.nan)
    past = np.full(len(ORIGINS),np.nan)
    triggers = np.full(len(ORIGINS),np.nan)
    min_pub = int(pd.Timestamp(root["ccm"]["first"]).timestamp())+3600
    observations = []
    for group in table:
        for row in group["rows"]:
            if len(row)<8 or not re.match(r"^[a-zA-Z]{3}-\d\d$",row[0]):
                continue
            values = [float(re.sub(r"[^\d.]", "", v)) if re.search(r"\d",v) else np.nan for v in [row[2],row[-2]]]
            if not np.isfinite(values[1]):
                continue
            release = pd.to_datetime(row[0],format="%b-%y").tz_localize("UTC")+pd.DateOffset(months=1)
            observations.append((max(int(release.timestamp()),min_pub),values))
    for release,(trigger,price) in sorted(observations):
        current = ORIGINS >= release
        past[current] = last[current]
        last[current] = price
        triggers[current] = trigger
    source = "DESNZ official Cost Containment Mechanism monitoring tables, latest reported monthly UKA average used only after the end of its monitoring-label month. Individual row publication times and revisions are not given."
    save_block("carbon_market",{
        "UKA_monthly_average_lagged":last[:,None],
        "UKA_change_since_last_month":(last-past)[:,None],
        "UKA_gap_to_CCM_trigger":(last-triggers)[:,None],
        "UKA_observed":np.isfinite(last)[:,None],
    },TRAIN,SLOTS.shape,source)
    save_block("policy_regime",{
        "non_domestic_energy_bill_relief":(SLOTS>=timestamp("2022-10-01"))&
                                            (SLOTS<timestamp("2023-04-01"))&
                                            (ORIGINS[:,None]>=timestamp("2022-09-22")),
        "UK_ETS_tighter_cap_since_2024":(SLOTS>=timestamp("2024-01-01"))&
                                          (ORIGINS[:,None]>=timestamp("2023-07-04")),
        "UK_ETS_future_markets_consult_open":(ORIGINS[:,None]>=timestamp("2023-12-19")),
    },TRAIN,SLOTS.shape,
       "GOV.UK Energy Bill Relief Scheme publication on 2022-09-21 and 2023-07-03 UK ETS Authority response to the development consultation. The final indicator marks a publicly announced consultation, not policy implementation. These features may proxy shifts and do not identify causal effects.")
    gas = np.load(HERE/"blocks/gas_prices.npy",mmap_mode="r")[:,:,0]
    row = json.loads((HERE/"blocks/gas_prices.json").read_text())["columns"][0]
    nominal_gas = gas*row["std"]+row["mean"]
    nominal_fuel_and_CO2 = 2*(nominal_gas+.183*last[:,None])
    native = load_baseline()
    price = native("PRICES_forward")
    save_block("gas_carbon_cost",{
        "carbon_adjusted_gas_cost":nominal_fuel_and_CO2,
        "auction_minus_carbon_adjusted_gas_cost":price-nominal_fuel_and_CO2,
    },TRAIN,SLOTS.shape,source+" Illustrative heat rate using 50% efficiency and 0.183 tonnes CO2 per MWh thermal. It is not an observed plant marginal cost.")
    print("UKA monthly observations",len(observations),flush=True)


if __name__=="__main__":
    main()
