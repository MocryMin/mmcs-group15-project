"""Validation-only output combination of finalists and the direct ridge."""
import argparse
import csv
import json

import numpy as np

from build_features import BASE, CUTS, HERE, TARGETS


def loads(path):
    if path.startswith("ridge/"):
        paths=[HERE/path/"predictions.npz"]
    else:
        paths=sorted((HERE/"runs"/path).glob("seed-*/predictions.npz"))
    if not paths:
        raise FileNotFoundError(path)
    sums={}
    for p in paths:
        with np.load(p) as z:
            for k in ("val","test25","test26"):
                sums[k]=sums.get(k,0)+z[k]/len(paths)
    return sums


def fit(left,right,truth):
    diff=right["val"]-left["val"]
    e=truth["val"]-left["val"]
    weights=np.clip(np.sum(e*diff,axis=(0,1))/np.maximum(1e-8,np.sum(diff**2,axis=(0,1))),0,1)
    avg={s:left[s]+weights* (right[s]-left[s]) for s in left}
    return avg,weights


def outcomes(name,forecasts,truth):
    outputs=[]
    for s in truth:
        e=(forecasts[s]-truth[s])**2
        for label,domain in [("12h",24),("4h",8),("30min",1)]:
            m=e[:,:domain].mean((0,1))
            outputs.append({"method":name,"split":s,"scope":label,"normalized_MSE":float(m.mean()),
                **{nm:float(x) for nm,x in zip(TARGETS,m)}})
    return outputs


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("pairs",nargs="+")
    args=p.parse_args()
    with np.load(BASE/"targets.npz") as a, np.load(BASE/"summer-2026/targets.npz") as b:
        truth={"val":a["y"][CUTS[0]:CUTS[1]],"test25":a["y"][CUTS[1]:],"test26":b["y"]}
    results=[]
    by_model={}
    for pair in args.pairs:
        left,right=pair.split("=")
        for item in (left,right):
            if item not in by_model:
                by_model[item]=loads(item)
                results.extend(outcomes(item,by_model[item],truth))
        combined,weights=fit(by_model[left],by_model[right],truth)
        name=left+" + "+right
        results.extend(outcomes(name,combined,truth))
        for row in results[-9:]:
            row.update({f"right_weight_{name}":float(x) for name,x in zip(TARGETS,weights)})
    labels=list(results[0])+[f"right_weight_{s}" for s in TARGETS]
    with (HERE/"forecast_blends.csv").open("w",newline="") as f:
        writer=csv.DictWriter(f,labels)
        writer.writeheader()
        writer.writerows(results)


if __name__=="__main__":
    main()
