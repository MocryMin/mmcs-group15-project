"""Translate weather and market inputs into delivery-aligned physical quantities."""
import json

import numpy as np
import pandas as pd

from build_features import FEATURES, ORIGINS, SLOTS, TRAIN, load_baseline, save_block


def read(name):
    array = np.load(FEATURES / f"{name}.npy", mmap_mode="r")
    meta = json.loads((FEATURES / f"{name}.json").read_text())
    valid = [row for row in meta["columns"] if "mean" in row]
    return {row["name"]: array[:, :, j] * row["std"] + row["mean"]
            for j, row in enumerate(valid)}


def older(values, lags, leads):
    result = np.full((len(ORIGINS), len(lags)), np.nan, dtype="float32")
    for j, (lag, lead) in enumerate(zip(lags, leads)):
        i = np.searchsorted(ORIGINS, ORIGINS - lag * 1800)
        i = np.minimum(i, len(ORIGINS)-1)
        valid = ORIGINS[i] == ORIGINS - lag * 1800
        result[valid, j] = values[i[valid], lead]
    return result


def average(x):
    count = np.isfinite(x).sum(1, keepdims=True)
    return np.where(count > 0, np.nansum(x, axis=1, keepdims=True) / np.maximum(count, 1), np.nan)


def features():
    native = load_baseline()
    clock = np.arange(24)[None, :] * .5
    supply_curve = native("AGPT_seasonal_mean")
    demand_curve = native("FUELINST_seasonal_mean")
    wind = native("WINDFOR_forward")
    demand = native("NDF_forward")
    live_5min = native("five_minute_demand_lag_0")[:, :1]
    live_indo = native("INDO_history_0")[:, -1:]
    live_itsdo = native("ITSDO_history_0")[:, -1:]

    # Correct future demand using only errors observed in earlier delivery intervals.
    near_demand = native("FUELINST_history_0")[:, -8:][:, ::-1]
    forecast_ago = older(demand, np.arange(1, 9), np.zeros(8, dtype=int))
    # FUELINST sampling closes near the origin. Two or more intervals provide a robust reference.
    latest_delta = average(near_demand[:, 1:5] - forecast_ago[:, 1:5])
    recent_delta = average(near_demand[:, 1:] - forecast_ago[:, 1:])
    live_offset = live_5min - live_indo
    corrected_demand = {
        "recent_demand_minus_NDF_2h": latest_delta,
        "recent_demand_minus_NDF_4h": recent_delta,
        "load_curve_corrected_2h": demand + latest_delta * np.exp(-clock / 2),
        "load_curve_corrected_6h": demand + recent_delta * np.exp(-clock / 6),
        "latest_demand_from_five_min": live_5min,
        "current_transmission_to_national_gap": live_itsdo - live_indo,
        "cross_scope_demand_offset": live_offset,
        "latest_vs_season_demand": live_5min - demand_curve,
        "forecast_demand_change_since_recent": demand - live_5min,
    }
    save_block("demand_physics", corrected_demand, TRAIN, SLOTS.shape,
               "Contemporaneous public demand series and earlier forecast revisions. Additive forecast-error features use earlier origins only, with half-hour group alignment approximate for 5-minute FUELINST.")

    mix = read("mix_level")
    mix_hist = read("mix_history")
    actual_wind = mix["wind_mix_latest"][:, :1]
    past_wind = mix_hist["wind_mix_history"][:, -8:][:, ::-1]
    wind_ago = older(wind, np.arange(1, 9), np.zeros(8, dtype=int))
    wind_delta = average(past_wind[:, 1:5] - wind_ago[:, 1:5])
    current_domestic = mix["total_domestic_mix"][:, :1]
    current_nonwind = current_domestic - actual_wind
    a = native("AGPT_history_0")
    # Correct MW using a recent published wind vintage and a live estimate of non-wind generation.
    corrected_wind = wind + wind_delta * np.exp(-clock / 3)
    supply = {
        "wind_proxy_bias": wind_delta,
        "wind_forecast_corrected": corrected_wind,
        "wind_change_since_recent": wind - actual_wind,
        "combined_lately_domestic_plus_wind": current_nonwind + corrected_wind,
        "nonwind_generation_recent_vs_season": current_nonwind + corrected_wind - supply_curve,
        "short_horizon_generation_proxy": current_nonwind + corrected_wind + (a[:, -1:] - current_domestic) * np.exp(-clock / 2),
        "generation_proxy_minus_demand": current_nonwind + corrected_wind - corrected_demand["load_curve_corrected_6h"],
        "nuclear_recent": mix["nuclear_mix_latest"][:, :1],
        "gas_recent": mix["gas_mix_latest"][:, :1],
    }
    save_block("generation_physics", supply, TRAIN, SLOTS.shape,
               "Elexon WINDFOR, FUELINST by fuel and AGPT. Uses only published observations and forecasts. Proxy scope differs from the target, which includes the scenario wind farm.")

    raw = read("temp-hourly")
    direction = read("wind-hourly")
    cloud = read("cloud-hourly")
    print(list(raw),list(direction)[:14],list(cloud)[:7],flush=True)
    local = pd.to_datetime(SLOTS.ravel(),unit="s",utc=True).tz_convert("Europe/London")
    time = (local.hour.to_numpy() + local.minute.to_numpy()/60).reshape(SLOTS.shape)
    day_year = local.dayofyear.to_numpy().reshape(SLOTS.shape)
    declination = .409 * np.sin(2*np.pi*day_year/365.2425 - 1.39)
    sun = np.maximum(0, np.sin(np.deg2rad(53.5))*np.sin(declination)
                     + np.cos(np.deg2rad(53.5))*np.cos(declination)*np.cos(np.pi*(time-12)/12))
    temperatures = [v for key, v in raw.items() if "temp" in key and "day1" in key]
    wind_speeds = [v for key, v in direction.items() if "speed" in key and "day1" in key]
    cloud_cover = [v for key, v in cloud.items() if "cloud" in key and "day1" in key]
    if not temperatures or not wind_speeds or not cloud_cover:
        return
    temp = np.mean(temperatures, axis=0)
    speeds = np.stack(wind_speeds)/3.6  # Open-Meteo default km/h, turbine proxy expects m/s
    wind_proxy = np.maximum(0, np.minimum(speeds, 12)**3 - 3**3).mean(0)
    c = np.mean(cloud_cover, axis=0)
    save_block("weather_physics_ms", {
        "heating_degree": np.maximum(0, 16-temp),
        "cooling_degree": np.maximum(0, temp-21),
        "mean_regional_temp": temp,
        "pseudo_wind_turbine_curve": wind_proxy,
        "daylight_weighted_cloudiness": sun * (1-np.clip(c,0,100)/100),
        "solar_elevation": sun,
    }, TRAIN, SLOTS.shape,
        "Public archived 24h-old forecasts, regional average; temperature hinge, clipped cubic wind proxy and estimated daylight. Approximate signals, no calibrated wind turbine or PV model.")


if __name__ == "__main__":
    features()
