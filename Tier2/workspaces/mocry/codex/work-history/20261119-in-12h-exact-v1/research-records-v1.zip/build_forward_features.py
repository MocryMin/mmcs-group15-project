"""Lead-aligned national generation schedules and forecast scope comparisons."""
import numpy as np

from build_features import SLOTS, TRAIN, load_baseline, save_block
from build_system_features import outlook


def generation_columns(generation, demand_schedule, transmission, native):
    return {
        "indicated_generation_vs_course_season":generation-native("AGPT_seasonal_mean"),
        "latest_indicated_generation_vs_transmission_demand":generation-transmission,
        "indicated_generation_net_of_wind_forecast":generation-native("WINDFOR_forward"),
        "indicated_generation_minus_demand_schedule":generation-demand_schedule,
        "indicated_generation_vs_published_last_actual":generation-native("AGPT_history_0")[:,-1:],
    }


def main():
    generation = outlook("indgen")
    demand_schedule = outlook("inddem")
    transmission = outlook("tsdf")
    native = load_baseline()
    system = native("NDF_forward")
    wind = native("WINDFOR_forward")
    observed_load = native("five_minute_demand_lag_0")[:, :1]
    scope = "Elexon national-boundary INDGEN, INDDEM and TSDF matched by delivery and publication time. Schedules and system forecasts represent different accounting scopes from coursework targets."
    save_block("generation_schedule",generation_columns(generation,demand_schedule,transmission,native),
               TRAIN,SLOTS.shape,scope)
    save_block("transmission_scope", {
        "tsdf_minus_ndf":transmission-system,
        "tsdf_delta_since_latest_five_min_actual":transmission-observed_load,
        "tsdf_delta_from_24h_seasonal":transmission-native("FUELINST_seasonal_mean"),
        "indicated_demand_minus_tsdf":demand_schedule-transmission,
        "tsdf_excluding_forecast_wind":transmission-wind,
    },TRAIN,SLOTS.shape,scope)
    print("MW medians",
          [float(np.nanmedian(x)) for x in (generation,demand_schedule,transmission,system)],flush=True)


if __name__=="__main__":
    main()
