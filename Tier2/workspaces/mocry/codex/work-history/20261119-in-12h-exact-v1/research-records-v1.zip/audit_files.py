"""Fingerprint the frozen point data and all feature archive files."""
import hashlib
import json
import platform

import numpy as np
import pandas as pd

from build_features import BASE, FEATURES, HERE, ORIGINS, SIZES


def identity(path):
    with path.open("rb") as f:
        return hashlib.file_digest(f,"sha256").hexdigest()


paths = [BASE/p for p in ["features.json","inputs.npy","targets.npz",
                         "summer-2026/inputs.npy","summer-2026/targets.npz"]]
holdout = HERE/"jan_may_2026"
paths.extend(holdout/name for name in ("inputs.npy","targets.npz","features.json","labels.csv.gz","quality.csv")
             if (holdout/name).is_file())
offsets = HERE/"farm_decomposition_offsets.npz"
if offsets.exists():
    paths.append(offsets)
files = [*sorted((HERE/"sources").glob("*")),*sorted(FEATURES.glob("*")),*sorted((holdout/"sources").glob("*"))]
paths.extend(f for f in files if f.is_file())
split=[pd.to_datetime(a,unit="s",utc=True) for a in np.split(ORIGINS,np.cumsum(SIZES)[:-1])]
data={"environment":{"python":platform.python_version(),"numpy":np.__version__,"pandas":pd.__version__},
      "main_splits":[dict(count=len(v),first=v[0].isoformat(),last=v[-1].isoformat()) for v in split],
      "files":{str(p.relative_to(HERE.parent)):{"bytes":p.stat().st_size,"sha256":identity(p)} for p in paths}}
(HERE/"feature_input_hashes.json").write_text(json.dumps(data,indent=2))
print(len(paths),"input files hashed",flush=True)
