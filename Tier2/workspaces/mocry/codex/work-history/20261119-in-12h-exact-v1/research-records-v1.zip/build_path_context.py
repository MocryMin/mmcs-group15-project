"""Causal local lead summaries of prices and physically feasible surplus."""
import numpy as np

from build_features import SLOTS, TRAIN, load_baseline, save_block
from build_physical_features import read


def summarize(x, length, method):
    z=np.pad(x,((0,0),(0,length-1)),constant_values=np.nan)
    local=np.lib.stride_tricks.sliding_window_view(z,length,axis=1)
    known=np.isfinite(local).any(-1)
    if method=="mean":
        v=np.nansum(local,axis=-1)/np.maximum(1,np.isfinite(local).sum(-1))
    elif method=="min":
        v=np.where(np.isfinite(local),local,np.inf).min(-1)
    elif method=="max":
        v=np.where(np.isfinite(local),local,-np.inf).max(-1)
    elif method=="argmax":
        v=np.where(np.isfinite(local),local,-np.inf).argmax(-1)
    else:
        raise ValueError(method)
    return np.where(known,v,np.nan)


def main():
    native=load_baseline()
    margin=read("indgen")["indgen_forward"]-read("tsdf")["tsdf_forward"]
    deficit=np.maximum(0,-margin)
    p=native("PRICES_forward")
    width=12
    lo=summarize(p,width,"min")
    hi=summarize(p,width,"max")
    columns={
        "next_six_hours_auction_price_over_current":hi-p,
        "next_six_hours_auction_price_under_current":p-lo,
        "within_six_hours_auction_price_range":hi-lo,
        "time_to_auction_local_max":summarize(p,width,"argmax"),
        "next_three_hours_mean_auction_price":summarize(p,6,"mean"),
        "next_six_hours_capped_positive_shortfall":summarize(np.clip(deficit,0,100),width,"mean"),
        "expected_very_near_margin_zero":np.abs(margin)<1000,
        "next_six_hours_oversupply_share":summarize((margin>=0).astype("float32"),width,"mean"),
        "next_three_hours_average_margin":summarize(margin,6,"mean"),
        "next_six_hours_margin_fall":margin-summarize(margin,width,"min"),
    }
    save_block("delivery_path_context",columns,TRAIN,SLOTS.shape,
        "Lead-local summaries within the available 12h path. Every underlying value is a previously published auction, INDGEN, or TSDF. No realised forward price or meter enters.")


if __name__=="__main__":
    main()
