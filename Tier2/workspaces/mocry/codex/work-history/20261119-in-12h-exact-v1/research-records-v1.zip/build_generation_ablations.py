"""Named, ordered subsets of the five selected operating-plan features."""
from build_feature_subsets import subset

TERMS = {
    "seasonal":"indicated_generation_vs_course_season",
    "transmission":"latest_indicated_generation_vs_transmission_demand",
    "wind":"indicated_generation_net_of_wind_forecast",
    "inddem":"indicated_generation_minus_demand_schedule",
    "recent":"indicated_generation_vs_published_last_actual",
}

if __name__=="__main__":
    for key,feature in TERMS.items():
        subset(f"gen_without_{key}","generation_schedule",lambda name:name!=feature)
        subset(f"gen_only_{key}","generation_schedule",lambda name:name==feature)
    subset("gen_recent_and_transmission","generation_schedule",
           lambda name:name in {TERMS["recent"],TERMS["transmission"]})
    subset("gen_seasonal_and_transmission","generation_schedule",
           lambda name:name in {TERMS["seasonal"],TERMS["transmission"]})
