"""Direct per-delivery linear and piecewise-linear forecasts."""
import json
import os
import time

for key in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS"):
    os.environ[key]="6"

import numpy as np
from scipy.linalg import eigh

from build_features import BASE, CUTS, FEATURES, HERE, SIZES, TARGETS

ALPHAS=(.01,.1,1.,10.,100.,1000.,10000.)
SPLITS=("train","val","test25","test26")


def with_hinges(x,names,train):
    family=("PRICES_forward","tsdf_forward","indgen_forward","indicated_generation",
            "NDF_forward","WINDFOR_forward")
    extra=[]
    for j,name in enumerate(names):
        if not name.startswith(family) or name.endswith(("_known","_observed","_age")):
            continue
        knots=np.quantile(x[:train,:,j],[.2,.5,.8])
        z=np.maximum(0,x[:,:,j,None]-knots.astype("float32"))
        extra.append(z)
    return np.concatenate([x,*extra],axis=-1)


def metric(e):
    loss=np.square(e,dtype="float64")
    result={name:float(loss[:,:cut].mean()) for name,cut in (("12h",24),("4h",8),("30min",1))}
    result.update({f"12h_{name}":float(v) for name,v in zip(TARGETS,loss.mean((0,1)))})
    return result


def fit(case,x0,y0,names,blocks,hinge,deadline):
    inputs=[x0]
    extended=names.copy()
    train=int(SIZES[0])
    for tag in blocks:
        inputs.append(np.load(FEATURES/f"{tag}.npy",mmap_mode="r"))
        j=json.loads((FEATURES/f"{tag}.json").read_text())
        extended.extend(c["name"] for c in j["columns"] if "mean" in c)
    x=np.concatenate(inputs,axis=-1)
    if hinge:
        x=with_hinges(x,extended,train)
    y=np.concatenate(y0,axis=0)
    scores=np.empty((len(ALPHAS),len(y)-train,24,3),dtype="float32")
    coefficients, offsets=[],[]
    for lead in range(24):
        if time.time()>=deadline:
            return
        inputs=x[:train,lead].astype("float64")
        target=y[:train,lead].astype("float64")
        m=inputs.mean(0)
        k=target.mean(0)
        inputs-=m
        target-=k
        eigen,basis=eigh(inputs.T@inputs)
        numerator=basis.T@(inputs.T@target)
        projection=(x[train:,lead]-m)@basis
        by_alpha=[numerator/(np.maximum(0,eigen[:,None])+a) for a in ALPHAS]
        scores[:,:,lead]=np.stack([projection@q+k for q in by_alpha])
        w=np.stack([basis@q for q in by_alpha])
        coefficients.append(w)
        offsets.append(k-m@w)
    counts=np.cumsum(SIZES[1:-1])
    validation=scores[:,:int(SIZES[1])]
    cut=int(SIZES[1])
    selection=[]
    for span,label in ((24,"12h"),(8,"4h"),(1,"30min")):
        estimate=(validation[:,:,:span]-y0[1][None,:,:span])**2
        best=int(np.argmin(estimate.mean((1,2,3))))
        selection.append((best,label))
    output={}
    dst=HERE/"lead_regression"/case
    dst.mkdir(parents=True,exist_ok=True)
    for best,label in selection:
        prediction=np.split(scores[best],counts)
        output[label]=dict(alpha=ALPHAS[best],results={s:metric(p-gt) for s,p,gt in zip(SPLITS[1:],prediction,y0[1:])})
        np.savez_compressed(dst/f"model_{label}.npz",
                            weight=np.stack(coefficients)[:,best],bias=np.stack(offsets)[:,best],
                            alpha=ALPHAS[best])
        if label=="12h":
            np.savez_compressed(dst/"predictions.npz",**dict(zip(SPLITS[1:],prediction)))
    report={"features":int(x.shape[-1]),"parameters":int(24*3*(x.shape[-1]+1)),
            "hinges":hinge,"blocks":blocks,"selections":output}
    (dst/"result.json").write_text(json.dumps(report,indent=2))
    print(case,output["12h"]["alpha"],[output["12h"]["results"][s]["12h"] for s in SPLITS[1:]],flush=True)


if __name__=="__main__":
    import sys
    deadline=float(sys.argv[1])
    names=json.loads((BASE/"features.json").read_text())["names"]
    x=np.concatenate([np.load(BASE/"inputs.npy"),np.load(BASE/"summer-2026/inputs.npy")])
    with np.load(BASE/"targets.npz") as a,np.load(BASE/"summer-2026/targets.npz") as b:
        y=[*np.split(a["y"],CUTS[:2]),b["y"]]
    for case,blocks,hinge in (
        ("original",[],False),
        ("plans",["generation_schedule"],False),
        ("raw_plans",["tsdf","indgen"],False),
        ("plans_recent",["generation_schedule","recent"],False),
        ("plans_hinges",["generation_schedule","recent"],True),
        ("plans_shapes_hinges",["generation_schedule","recent","delivery_path_context"],True),
        ("national_hinges",["tsdf","indgen","forecast_shape","recent"],True),
    ):
        if time.time()<deadline:
            fit(case,x,y,names,blocks,hinge,deadline)
