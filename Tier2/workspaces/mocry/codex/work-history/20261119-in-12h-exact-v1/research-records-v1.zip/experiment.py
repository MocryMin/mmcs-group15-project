"""Budgeted feature and input-representation comparisons on the Tier 2B splits."""
import argparse
import csv
import json
import math
import os
import sys
import time
from pathlib import Path

for variable in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[variable] = '4'

import numpy as np
import torch
from torch import nn

from build_features import BASE, FEATURES, HERE, P, CUTS, ORIGINS, SIZES, TARGETS

sys.path.insert(0, str(P/'tier2b-8x768'))
from base_training import DEFAULTS, epoch_batches

SPLITS = ('train','val','test25','test26')
SCOPES = {'12h':24, '4h':8, '30min':1}


class BudgetExpired(Exception):
    pass


def check_time(deadline):
    if time.time() >= deadline:
        raise BudgetExpired


def groups(names):
    historical, forward, calendar = [], [], []
    for i, name in enumerate(names):
        if any(x in name for x in ('history','recent','lag','past_','age_hours','five_min','change_')) and '_forecast_age' not in name:
            historical.append(i)
        elif any(x in name for x in ('time_','weekday','season_sin','season_cos','relative_day','christmas_week')):
            calendar.append(i)
        else:
            forward.append(i)
    return [v for v in (historical,forward,calendar) if v]


class InputProjection(nn.Module):
    def __init__(self, names, width, method):
        super().__init__()
        self.method = method
        if method == 'stochastic':
            # Each raw channel distributes its value across d nonnegative weights.
            self.logits = nn.Parameter(torch.randn(len(names), width))
            self.norm = nn.LayerNorm(width)
        elif method == 'stochastic_signed':
            self.positive = nn.Parameter(torch.randn(len(names), width)*.25)
            self.negative = nn.Parameter(torch.randn(len(names), width)*.25)
            self.norm = nn.LayerNorm(width)
        elif method in {'stochastic_centered','stochastic_signed_l1','convex_channels_norm'}:
            self.logits = nn.Parameter(torch.randn(len(names),width)*.25)
            self.norm = nn.LayerNorm(width)
            if method == 'stochastic_centered':
                self.channel_gain = nn.Parameter(torch.ones(len(names),1))
        elif method == 'linear_norm':
            self.linear = nn.Sequential(nn.Linear(len(names),width),nn.LayerNorm(width))
        elif method == 'convex_channels':
            self.logits = nn.Parameter(torch.randn(len(names),width)*.25)
            self.amplitude = nn.Parameter(torch.ones(width))
            self.bias = nn.Parameter(torch.zeros(width))
        elif method == 'hinges':
            self.register_buffer('knots', torch.tensor([-1., 0., 1.]))
            self.linear = nn.Linear(4 * len(names),width)
        elif method == 'periodic':
            self.frequency = nn.Parameter(torch.full((len(names),), .5))
            self.linear = nn.Linear(3 * len(names),width)
        elif method == 'factorized':
            self.linear = nn.Sequential(nn.Linear(len(names),32,bias=False),nn.Linear(32,width))
        elif method == 'vintage_gate':
            self.forward_groups = [
                [i for i,name in enumerate(names) if name.startswith(prefix)]
                for prefix in ('PRICES_forward','NDF_forward','WINDFOR_forward','lolpdrm_','tsdf_','indgen_')
            ]
            self.forward_groups = [group for group in self.forward_groups if group]
            self.other = [i for i in range(len(names)) if all(i not in g for g in self.forward_groups)]
            self.linear = nn.Linear(len(self.other),width)
            self.signal = nn.ModuleList([nn.Linear(len(g),width,bias=False) for g in self.forward_groups])
            self.confidence = nn.ModuleList([nn.Linear(len(g),1) for g in self.forward_groups])
            for layer in self.confidence:
                nn.init.zeros_(layer.weight)
                nn.init.zeros_(layer.bias)
        elif method == 'grouped':
            self.indices = groups(names)
            self.paths = nn.ModuleList([nn.Sequential(nn.Linear(len(group),width),nn.LayerNorm(width))
                                        for group in self.indices])
        else:
            self.linear = nn.Linear(len(names),width)
            if method == 'gate':
                self.gate = nn.Linear(len(names),width)
            elif method == 'mlp':
                middle = min(2*len(names),192)
                self.linear = nn.Sequential(nn.Linear(len(names),middle),nn.GELU(),nn.Linear(middle,width))

    def forward(self, x):
        if self.method == 'stochastic':
            return self.norm(x @ self.logits.softmax(dim=-1))
        if self.method == 'stochastic_signed':
            return self.norm(x @ (self.positive.softmax(dim=-1)-self.negative.softmax(dim=-1)))
        if self.method == 'stochastic_centered':
            p = self.logits.softmax(dim=-1)-1/self.logits.shape[-1]
            return self.norm(x @ (self.channel_gain*p))
        if self.method == 'stochastic_signed_l1':
            p = self.logits / self.logits.abs().sum(dim=-1,keepdim=True).clamp_min(1e-6)
            return self.norm(x @ p)
        if self.method == 'convex_channels_norm':
            return self.norm(x @ self.logits.softmax(dim=0))
        if self.method == 'convex_channels':
            return x @ self.logits.softmax(dim=0) * self.amplitude + self.bias
        if self.method == 'hinges':
            return self.linear(torch.cat([x, (x[...,None]-self.knots).relu().flatten(-2)],dim=-1))
        if self.method == 'periodic':
            phase = x*self.frequency
            return self.linear(torch.cat([x, phase.sin(), phase.cos()],dim=-1))
        if self.method == 'vintage_gate':
            y = self.linear(x[:,:,self.other])
            for group, feature, confidence in zip(self.forward_groups,self.signal,self.confidence):
                signal = x[:,:,group]
                y = y + feature(signal) * (2 * confidence(signal).sigmoid())
            return y
        if self.method == 'grouped':
            return sum(path(x[:,:,indices]) for path,indices in zip(self.paths,self.indices))/math.sqrt(len(self.paths))
        y = self.linear(x)
        if self.method == 'gate':
            return y * (2 * self.gate(x).sigmoid())
        return y


class Model(nn.Module):
    def __init__(self, names, width, layers, projection, head, anchor=None, ridge=None, backbone='transformer'):
        super().__init__()
        self.projection = projection
        self.backbone = backbone
        if projection in {'separate_tokens','cross_history'}:
            history, *remaining = groups(names)
            self.history_columns = history
            self.forecast_columns = sum(remaining, [])
            self.history_emb = nn.Linear(len(history),width)
            self.emb = nn.Linear(len(self.forecast_columns),width)
            self.role = nn.Parameter(torch.zeros(2,width))
            if projection == 'cross_history':
                self.cross = nn.MultiheadAttention(width,4,dropout=.1,batch_first=True)
                self.cross_norm = nn.LayerNorm(width)
        elif projection == 'linear':
            self.emb = nn.Linear(len(names), width)
        else:
            self.emb = InputProjection(names,width,projection)
        pos = torch.arange(24,dtype=torch.float32)[:,None]*torch.exp(
            torch.arange(0,width,2)*(-math.log(10000.)/width))
        self.register_buffer('pos',torch.stack([pos.sin(),pos.cos()],dim=-1).flatten(1))
        if backbone == 'rnn':
            first = nn.RNN(width,width,batch_first=True)
        elif backbone in {'lstm','bilstm'}:
            bidirectional = backbone == 'bilstm'
            first = nn.LSTM(width,width//2 if bidirectional else width,
                            batch_first=True,bidirectional=bidirectional)
        else:
            first = nn.TransformerEncoderLayer(width,4,2*width,.1,'gelu',batch_first=True,norm_first=True)
        self.norm = nn.LayerNorm(width)
        self.drop = nn.Dropout(.1)
        self.head = head
        self.out = nn.Linear(width,72)
        if backbone == 'transformer':
            self.seq = nn.Sequential(first,*[nn.TransformerEncoderLayer(
                width,4,2*width,.1,'gelu',batch_first=True,norm_first=True) for _ in range(layers-1)])
        else:
            assert layers == 1 and projection not in {'separate_tokens','cross_history'}
            self.seq = first
        if head in {'local','local_only','affine_local'}:
            self.local = nn.Linear(width,3)
        if head == 'affine_local':
            self.direct = nn.Linear(len(names),3)
        if anchor is not None:
            indices, coefficients, offset = anchor
            self.register_buffer('anchor_indices', torch.tensor(indices))
            self.register_buffer('anchor_coefficients', torch.from_numpy(coefficients))
            self.register_buffer('anchor_offset', torch.from_numpy(offset))
        if ridge is not None:
            indices, center, scale, active, factor = ridge
            self.register_buffer('ridge_indices', torch.tensor(indices))
            self.register_buffer('ridge_center', torch.tensor(center))
            self.register_buffer('ridge_scale', torch.tensor(scale))
            self.register_buffer('ridge_indicator', torch.tensor(active))
            self.ridge_factor = factor

    def forward(self, x):
        if self.projection in {'separate_tokens','cross_history'}:
            history = self.history_emb(x[:,:,self.history_columns])+self.pos+self.role[0]
            future = self.emb(x[:,:,self.forecast_columns])+self.pos+self.role[1]
            if self.projection == 'cross_history':
                context,_ = self.cross(future,history,history,need_weights=False)
                z = self.norm(self.seq(self.cross_norm(future+context)))
            else:
                z = self.norm(self.seq(torch.cat([history,future],dim=1)))[:,24:]
        else:
            encoded = self.seq(self.emb(x)+self.pos)
            z = self.norm(encoded if self.backbone=='transformer' else encoded[0])
        y = self.out(self.drop(z.mean(1))).reshape(-1,24,3)
        if self.head == 'local_only':
            y = self.local(self.drop(z))
        elif self.head in {'local','affine_local'}:
            y = y + self.local(self.drop(z))
        if self.head == 'affine_local':
            y = y + self.direct(x)
        if hasattr(self, 'anchor_indices'):
            y = y + torch.einsum('bhi,hij->bhj', x[:, :, self.anchor_indices],
                                 self.anchor_coefficients) + self.anchor_offset
        if hasattr(self, 'ridge_indices'):
            prior = x[:,:,self.ridge_indices]*self.ridge_scale+self.ridge_center
            y = y + self.ridge_factor*prior*(x[:,:,self.ridge_indicator,None]>0)
        return y


def refit_feature_scales(matrix, names, base_schema, block_rows, train_count):
    indicators = {}
    for j,name in enumerate(names):
        if name.endswith(('_observed','_known')) and name in base_schema['names']:
            ref = base_schema['names'].index(name)
            indicators[name] = matrix[:,:,j]*base_schema['std'][ref]+base_schema['mean'][ref]>.5
    for j,name in enumerate(names):
        col = matrix[:,:,j]
        present = np.ones(col.shape,dtype=bool)
        for suffix in ('_observed','_known'):
            mask_name = name+suffix
            if mask_name in indicators:
                present = indicators[mask_name]
                break
        if name in block_rows and block_rows[name]['coverage'][0]<1.:
            present = col!=0
        values = col[:train_count][present[:train_count]]
        if not len(values):
            col[:]=0
            continue
        shift = values.mean(dtype='float64')
        scale = values.std(dtype='float64')
        matrix[:,:,j] = np.where(present,(col-shift)/scale,0) if scale>1e-5 else 0


def zca_parameters(matrix,train_count,floor=.15):
    cells = matrix[:train_count].reshape(-1,matrix.shape[-1]).astype('float64')
    center = cells.mean(0)
    cells -= center
    covariance = cells.T@cells/len(cells)
    eig,z = np.linalg.eigh(covariance)
    zca = (z*np.maximum(eig,floor)**(-.5))@z.T
    return center.astype('float32'),zca.astype('float32')


def recipe_features(x0, names, item, train_count, rows=None):
    keep = [i for i,name in enumerate(names)
            if not any(name.startswith(prefix) for prefix in item.get('drop',[]))]
    if item.get('drop_all_base'):
        keep = []
    names = [names[i] for i in keep]
    blocks = [x0[:,:,keep]]
    block_rows = {}
    for group in item.get('blocks',[]):
        blocks.append(np.load(FEATURES/f'{group}.npy',mmap_mode='r'))
        provenance = json.loads((FEATURES/f'{group}.json').read_text())
        new_columns = {c['name']:c for c in provenance['columns'] if 'mean' in c}
        names.extend(new_columns)
        block_rows.update(new_columns)
    x = np.concatenate(blocks,axis=-1)
    if rows is not None:
        x = x[rows]
        original_schema = json.loads((BASE/'features.json').read_text())
        refit_feature_scales(x,names,original_schema,block_rows,train_count)
    if item.get('align_latest_first'):
        histories = [j for j,name in enumerate(names) if '_history_' in name or name.startswith('past_auction')]
        x[:,:,histories] = x[:,::-1,histories].copy()
    transform = item.get('transform','identity')
    if transform == 'zca':
        subset = item.get('zca_prefixes')
        floor = item.get('zca_floor',.15)
        if subset:
            ids = [j for j,name in enumerate(names) if name.startswith(tuple(subset))]
            selected = x[:,:,ids]
            center,zca = zca_parameters(selected,train_count,floor)
            x[:,:,ids] = (selected-center)@zca
        else:
            center,zca = zca_parameters(x,train_count,floor)
            x = ((x-center)@zca).astype('float32')
    elif transform != 'identity':
        if transform in {'price_asinh','price_rank'}:
            ids = [j for j,name in enumerate(names) if 'price' in name.lower() or 'auction' in name.lower()]
        else:
            ids = list(range(len(names)))
        for j in ids:
            col = x[:,:,j]
            if len(np.unique(col[:800])) <= 3:
                continue
            if transform == 'robust':
                q1, median, q3 = np.quantile(col[:train_count],[.25,.50,.75])
                if q3-q1 < 1e-7:
                    continue
                mapped = np.clip((col-median)/(q3-q1),-5,5)
            elif 'rank' in transform:
                from scipy.special import ndtri
                percent = np.linspace(.001,.999,513)
                boundaries = np.quantile(col[:train_count],percent)
                values, index, counts = np.unique(boundaries,return_index=True,return_counts=True)
                mid = .5*(percent[index]+percent[index+counts-1])
                mapped = ndtri(np.interp(col,values,mid))
            else:
                mapped = np.arcsinh(col) if 'asinh' in transform else np.clip(col,-4,4)
            mu, sd = mapped[:train_count].mean(dtype='float64'), mapped[:train_count].std(dtype='float64')
            x[:,:,j] = (mapped-mu)/max(sd,1e-7)
    assert x.shape[-1] == len(names) and np.isfinite(x).all()
    return torch.from_numpy(x), names


def fit_linear_anchor(x, y, names, mode):
    # The anchor is fit on training labels only, once for each delivery lead.
    # Exclude trajectory coordinates so it stays a small delivery-aligned calibration.
    indicators = ('_forward', '_seasonal_mean', '_forecast_age', '_known',
                  'latest', 'recent_1', 'recent_4', 'step_change', 'vs_season',
                  'from_start', 'wind_share', 'modelled_gap', 'demand_lag_0')
    indices = [index for index, name in enumerate(names) if any(k in name for k in indicators)]
    a = x[:len(y), :, indices].numpy()
    if mode == 'context':
        indices = list(range(len(names)))
        a = x[:len(y)].numpy()
    strength = .05 if mode == 'context' else .012
    weights = []
    offsets = []
    for lead in range(y.shape[1]):
        inputs = np.array(a[:, lead], dtype='float64', copy=True)
        targets = y[:, lead].astype('float64')
        inputs_mean = inputs.mean(0)
        targets_mean = targets.mean(0)
        inputs -= inputs_mean
        targets -= targets_mean
        gram = inputs.T @ inputs
        gram.flat[::len(indices)+1] += len(inputs)*strength
        w = np.linalg.solve(gram, inputs.T @ targets)
        offsets.append(targets_mean-inputs_mean@w)
        weights.append(w)
    return indices, np.asarray(weights,dtype='float32'), np.asarray(offsets,dtype='float32')


def ridge_offset(names, item):
    if 'ridge_offset' not in item:
        return None
    case, weight = item['ridge_offset']
    labels = [f'{case}_residual_{t}' for t in TARGETS]
    recipe = json.loads((FEATURES/f'{case}.json').read_text())
    rows = {c['name']:c for c in recipe['columns']}
    return ([names.index(name) for name in labels], [rows[name]['mean'] for name in labels],
            [rows[name]['std'] for name in labels], names.index(case+'_known'), weight)


def delayed_training_channels(names, item, rows, train_count):
    setup = item.get('delay_augmentation')
    if setup is None:
        return [],None,0
    assert rows is None and item.get('transform','identity')=='identity'
    groups,delay,rate = setup
    indexes,arrays = [],[]
    for group in groups:
        reference = {c['name']:c for c in json.loads((FEATURES/f'{group}.json').read_text())['columns']
                     if 'mean' in c}
        variant = f'{group}_delay{delay}'
        matrix = np.load(FEATURES/f'{variant}.npy',mmap_mode='r')
        info = [c for c in json.loads((FEATURES/f'{variant}.json').read_text())['columns'] if 'mean' in c]
        for j,updated in enumerate(info):
            name = updated['name']
            if name not in reference:
                continue
            old = reference[name]
            raw = matrix[:train_count,:,j]*updated['std']+updated['mean']
            arrays.append(((raw-old['mean'])/old['std']).astype('float32'))
            indexes.append(names.index(name))
    return indexes,torch.as_tensor(np.stack(arrays,axis=-1),device='cuda'),rate


@torch.inference_mode()
def predict(model, x, deadline):
    model.eval()
    result = []
    for batch in x.split(256):
        check_time(deadline)
        result.append(model(batch))
    return torch.cat(result)


def farm_decomposition(item, splits, targets):
    method = item.get('farm_decomposition')
    if method is None:
        return targets, None
    with np.load(HERE/'farm_decomposition_offsets.npz') as data:
        forecast = torch.tensor(data['forecast'],device='cuda').split(splits)
        if method == 'measured_training_farm':
            correction = torch.tensor(data['training_actual'],device='cuda')
        else:
            assert method == 'forecast_anchor'
            correction = forecast[0]
    remaining = targets.clone()
    remaining[:,:,1] -= correction
    return remaining, forecast


def scores(prediction, y):
    errors = (prediction-y).square()
    parts = {name: errors[:,:count].mean().item() for name,count in SCOPES.items()}
    parts.update({f'12h_{name}': x for name,x in zip(TARGETS,errors.mean((0,1)).tolist())})
    return parts


def fit(item, seed, x0, y_cpu, names, settings):
    check_time(settings.deadline)
    folder = HERE/'runs'/settings.group/item['id']/f'seed-{seed}'
    if (folder/'result.json').exists():
        return
    folder.mkdir(exist_ok=True,parents=True)
    x,names = recipe_features(x0,names,item,len(y_cpu[0]),settings.rows)
    anchor = fit_linear_anchor(x,y_cpu[0],names,item['anchor']) if item.get('anchor') else None
    x = x.cuda().split([len(v) for v in y_cpu])
    y = [torch.from_numpy(v).cuda() for v in y_cpu[:2 if settings.search else len(x)]]
    assert not (settings.early_2024 and item.get('farm_decomposition'))
    train_targets, forecast_farm = farm_decomposition(item, [len(v) for v in x], y[0])
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    model = Model(names,item.get('width',344),item.get('layers',1),
                  item.get('projection','linear'),item.get('head','mean'),
                  anchor,ridge_offset(names,item),item.get('backbone','transformer')).cuda()
    n_params = sum(v.numel() for v in model.parameters())
    config = json.loads(DEFAULTS.read_text())
    config.update(seed=seed, epochs=settings.epochs, checkpoint_every_updates=settings.evaluate_every)
    lr = config['learning_rate']
    optimizer = torch.optim.AdamW(model.parameters(),lr=lr['peak'],weight_decay=config['weight_decay'])
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer,mode='min',factor=lr['plateau_factor'],patience=lr['plateau_patience_evaluations'],
        threshold=lr['min_relative_improvement'],threshold_mode='rel',min_lr=lr['minimum'])
    generator = torch.Generator().manual_seed(seed)
    batch_sizes = epoch_batches(len(x[0]),config)
    total = config['epochs']*len(batch_sizes)
    best = float('inf')
    selected = 0
    step = 0
    config['case'] = item
    config['features'] = names
    config['parameters'] = n_params
    config['splits'] = dict(zip(('train',*settings.splits),[len(v) for v in y_cpu]))
    config['early_2024'] = settings.early_2024
    (folder/'config.json').write_text(json.dumps(config,indent=2))
    print('start',settings.group,item['id'],seed,n_params,flush=True)
    began = time.monotonic()
    source_dropout = item.get('source_dropout',{})
    drop_groups = []
    for group,rate in source_dropout.items():
        definition = json.loads((FEATURES/f'{group}.json').read_text())['columns']
        column_ids = [names.index(c['name']) for c in definition if 'mean' in c]
        drop_groups.append((torch.tensor(column_ids,device='cuda'),rate))
    feature_rng = torch.Generator(device='cuda').manual_seed(seed+193)
    delayed_indices, delayed_values, delayed_rate = delayed_training_channels(names,item,settings.rows,len(y_cpu[0]))

    @torch.inference_mode()
    def predict_split(index):
        value = predict(model, x[index], settings.deadline)
        if forecast_farm is not None:
            value[:,:,1] += forecast_farm[index]
        return value

    with (folder/'trajectory.csv').open('w',newline='') as f:
        writer = None

        def checkpoint(batch_loss):
            nonlocal best,selected,writer
            val = scores(predict_split(1),y[1])
            current_lr = optimizer.param_groups[0]['lr']
            if step >= lr['warmup_updates']:
                scheduler.step(val['12h'])
            if val['12h'] < best:
                best = val['12h']
                selected = step
                temp = folder/'model.tmp'
                torch.save({'weights':model.state_dict(),'features':names,'step':step},temp)
                temp.replace(folder/'model.pt')
            row = {'step':step, 'batch_loss':batch_loss,'lr':current_lr,**val}
            if writer is None:
                writer = csv.DictWriter(f,row.keys())
                writer.writeheader()
            writer.writerow(row)
            f.flush()

        checkpoint(None)
        for _ in range(config['epochs']):
            for batch in torch.randperm(len(x[0]),generator=generator).cuda().split(batch_sizes):
                check_time(settings.deadline)
                step += 1
                if step <= lr['warmup_updates']:
                    optimizer.param_groups[0]['lr'] = lr['peak']*step/lr['warmup_updates']
                model.train()
                optimizer.zero_grad(set_to_none=True)
                inputs = x[0][batch]
                if delayed_values is not None:
                    delayed = torch.rand((len(inputs),1,1),device='cuda',generator=feature_rng)<delayed_rate
                    inputs[:,:,delayed_indices] = torch.where(
                        delayed,delayed_values[batch],inputs[:,:,delayed_indices])
                for channel_ids,rate in drop_groups:
                    kept = torch.rand((len(inputs),1,1),device='cuda',generator=feature_rng)>=rate
                    inputs[:,:,channel_ids] *= kept
                loss = (model(inputs)-train_targets[batch]).square().mean()
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(),config['gradient_clip_norm'])
                optimizer.step()
                if step % config['checkpoint_every_updates'] == 0 or step == total:
                    checkpoint(loss.item())

    checkpoint_state = torch.load(folder/'model.pt',weights_only=True,map_location='cuda')
    assert checkpoint_state['step']==selected
    model.load_state_dict(checkpoint_state['weights'])
    results = {'parameters':n_params,'step':selected,'seed':seed,'seconds':time.monotonic()-began}
    saved = {}
    for index, split in enumerate(settings.splits[:1] if settings.search else settings.splits,start=1):
        pred = predict_split(index)
        results[split] = scores(pred,y[index])
        if not settings.search:
            saved[split] = pred.cpu().numpy()
    assert math.isclose(results['val']['12h'],best,rel_tol=1e-6)
    if saved:
        np.savez_compressed(folder/'predictions.npz',**saved)
    (folder/'result.json').write_text(json.dumps(results,indent=2))
    print('done',settings.group,item['id'],seed,selected,best,flush=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('manifest',type=Path)
    parser.add_argument('--group',required=True)
    parser.add_argument('--seeds',type=int,nargs='+',default=[17])
    parser.add_argument('--epochs',type=int,default=5)
    parser.add_argument('--evaluate-every',type=int,default=20)
    parser.add_argument('--search',action='store_true')
    parser.add_argument('--early-2024',action='store_true')
    parser.add_argument('--deadline',type=float,required=True)
    options=parser.parse_args()
    torch.set_num_threads(2)
    torch.set_float32_matmul_precision('high')
    torch.backends.cudnn.benchmark=False
    options.splits = SPLITS[1:]
    options.rows = None
    with np.load(BASE/'targets.npz') as a, np.load(BASE/'summer-2026/targets.npz') as b:
        y = [*np.split(a['y'],CUTS[:2]),b['y']]
        if options.early_2024:
            ends = np.datetime64('2022-01-01') + np.array([0,730,974,1096],dtype='timedelta64[D]')
            starts = np.searchsorted(ORIGINS,ends.astype('datetime64[s]').astype('int64'))
            rows = [np.arange(start,end-(0 if end==SIZES[0] else 23)) for start,end in zip(starts,starts[1:])]
            assert ORIGINS[rows[0][-1]]+23*1800<ORIGINS[rows[1][0]]
            assert ORIGINS[rows[1][-1]]+23*1800<ORIGINS[rows[2][0]]
            assert rows[-1][-1]<SIZES[0]
            physical = a['baseline'][rows[0],0]+a['y'][rows[0],0]*a['target_sd']
            normalization = a['target_sd']/physical.std(0)
            y = [(a['y'][indices]*normalization).astype('float32') for indices in rows]
            options.rows = np.concatenate(rows)
            options.splits = ('val','test24')
    x0 = np.concatenate([np.load(BASE/'inputs.npy',mmap_mode='r'),np.load(BASE/'summer-2026/inputs.npy',mmap_mode='r')])
    names = json.loads((BASE/'features.json').read_text())['names']
    try:
        for item in json.loads(options.manifest.read_text()):
            for seed in options.seeds:
                fit(item,seed,x0,y,names,options)
                torch.cuda.empty_cache()
    except BudgetExpired:
        print('Wall-clock budget expired. Completed experiments are retained.',flush=True)


if __name__=='__main__':
    main()
