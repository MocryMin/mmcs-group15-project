"""Apply selected forecasts to the existing Tier 2B control logic."""
import argparse
import csv
import json
import sys
import time

import numpy as np

from build_features import BASE, CUTS, HERE, P, load_baseline
from holdout_2026 import FOLDER, SCHEMA

sys.path.insert(0,str(P/"tier2b-halfhour-mpc-20261118"))
import rolling

p = rolling.p


def references():
    results = {}
    with np.load(BASE/"targets.npz") as a, np.load(BASE/"summer-2026/targets.npz") as b:
        for split,path,sel in (("test25",a,slice(CUTS[1],None)),("test26",b,slice(None))):
            length = len(path["utc"][sel])//24*24
            reference = path["baseline"][sel][:length]
            stamps = path["utc"][sel][:length]
            scale = path["target_sd"]
            target = path["y"][sel][:length]*scale+reference
            results[split] = stamps,reference,scale,target
    with np.load(FOLDER/"targets.npz") as extra:
        length = len(extra["utc"])//24*24
        reference=extra["baseline"][:length]
        scale=extra["target_sd"]
        results["jan_may26"]=(extra["utc"][:length],reference,scale,extra["y"][:length]*scale+reference)
    return results


def chosen(model,how):
    directory = HERE/"runs"/model
    runs = sorted(directory.glob("seed-*/result.json"))
    if how=="single":
        runs = [min(runs,key=lambda q:json.loads(q.read_text())["val"]["12h"])]
    predictions = {}
    for candidate in runs:
        with np.load(candidate.parent/"predictions.npz") as r:
            for split in ("test25","test26"):
                predictions.setdefault(split,[]).append(r[split])
    with np.load(FOLDER/"predictions.npz") as r:
        for candidate in runs:
            seed=json.loads(candidate.read_text())["seed"]
            name=f"{model}:{seed}"
            if name in r:
                predictions.setdefault("jan_may26",[]).append(r[name])
    return {split:np.mean(v,axis=0) for split,v in predictions.items()}


def prediction_metrics(path,target):
    expected_gap=target[:,:,1]-target[:,:,2]
    prediction_gap=path[:,:,1]-path[:,:,2]
    near=np.abs(expected_gap)<500  # 500 MWh per half hour = 1 GW
    correct=(prediction_gap>=0)==(expected_gap>=0)
    return {
        "gap_mae_MWh":float(np.mean(np.abs(prediction_gap-expected_gap))),
        "gap_sign_acc":float(correct.mean()),
        "gap_sign_acc_within_1GW":float(correct[near].mean()),
        "high_price_MAE_GBP":float(np.mean(np.abs(path[:,:,0].max(1)-target[:,:,0].max(1)))),
        "low_price_MAE_GBP":float(np.mean(np.abs(path[:,:,0].min(1)-target[:,:,0].min(1)))),
    }


def settle(policy, actual, prices_known, scores, trace=None):
    stock = used = gross = 0.
    capacity_budget = 400 * (len(actual)/48)
    cash = np.empty(len(actual))
    for i,(price,generation,demand) in enumerate(actual):
        low=min(int(stock/p.step),len(p.S)-2)
        k=stock/p.step-low
        selected=p.best((1-k)*scores[i,:,low]+k*scores[i,:,low+1],0)
        if policy=="B":
            free=max(0.,generation-demand-min(362*5.031*.5,p.cfg["cap_kg_day"]*.0559/48))
            if free>0:
                selected=min(selected,-min(50.,free))
        if len(actual)-i<=48:
            selected=50.
        change,after,c,u,sale,hydrogen=p.flows(
            policy,generation,demand,price,prices_known[i],stock,selected,max(0.,capacity_budget-used)/p.E)
        assert abs(after-stock-p.E*c+u/p.E)<1e-6
        assert sale<=demand+1e-6 and sale+hydrogen+c<=generation+u+1e-6
        if trace is not None:
            trace.append((stock, selected, c, u, after, sale, hydrogen, change))
        gross+=change
        cash[i]=change
        used+=p.E*c
        stock=after
    # For a fair finite test, remaining energy receives zero terminal revenue.
    return dict(gross=float(gross),cycle=float(used/400),terminal_stock_MWh=float(stock)),cash


def run(models, deadline, suffix=""):
    rows, metrics, timeline = [], [], {}
    known_auction = np.split(load_baseline()("PRICES_forward")[:,0],
                            [CUTS[0],CUTS[1],CUTS[2]])[2:]
    auction = dict(zip(("test25","test26"),known_auction))
    x=np.load(FOLDER/"inputs.npy",mmap_mode="r")
    price=SCHEMA["names"].index("PRICES_forward")
    mark=SCHEMA["names"].index("PRICES_forward_known")
    visible=x[:,0,mark]*SCHEMA["std"][mark]+SCHEMA["mean"][mark]>.5
    auction["jan_may26"]=np.where(visible,x[:,0,price]*SCHEMA["std"][price]+SCHEMA["mean"][price],np.nan)
    for model in models:
        saved = chosen(model,"ensemble") if model!="weekday_reference" else {}
        for split,(stamps,baseline,sd,target) in references().items():
            if time.time()>=deadline:
                break
            if model!="weekday_reference" and split not in saved:
                continue
            np.testing.assert_array_equal(np.diff(stamps),1800)
            actual = target[:,0]
            pricing_signal = auction[split][:len(stamps)]
            pricing_signal = np.where(np.isfinite(pricing_signal),pricing_signal,baseline[:,0,0])
            values = baseline if model=="weekday_reference" else baseline + saved[split][:len(stamps)]*sd
            values = values.copy()
            values[:,:,1:] = np.maximum(values[:,:,1:],0)
            months = len(stamps)/48/365
            metrics.append(dict(model=model,split=split,**prediction_metrics(values,target)))
            for policy in ("A","B"):
                if time.time() >= deadline:
                    break
                scores = rolling.first_scores(policy,values,np.full(len(stamps),24))
                result,cash = settle(policy,actual,pricing_signal,scores)
                timeline[model,split,policy]=(stamps,cash)
                rows.append(dict(model=model,split=split,policy=policy,days=len(stamps)/48,
                    gross_GBP=result["gross"],equivalent_full_cycles=result["cycle"],
                    terminal_stock_MWh=result["terminal_stock_MWh"],
                    annual_cost_assumption_low_GBP=rolling.replay.FIXED_LOW,
                    pro_rata_net_low_GBP=result["gross"]-rolling.replay.FIXED_LOW*months))
            print(model,split,"completed",flush=True)
    for name, records in [(f"dispatch_diagnostics{suffix}.csv",rows),(f"dispatch_prediction_metrics{suffix}.csv",metrics)]:
        if records:
            with (HERE/name).open("w",newline="") as f:
                c=csv.DictWriter(f,records[0].keys());c.writeheader();c.writerows(records)
    write_intervals(timeline,suffix)


def write_intervals(timeline,suffix=""):
    rows=[]
    for (model,split,policy),(stamps,profit) in timeline.items():
        base="scale1/original_1x864" if model.endswith("_1x864") else "scale1/original_3x448"
        if base==model or not model.startswith("scale3/"):
            continue
        if (base,split,policy) not in timeline:
            continue
        t,p=timeline[base,split,policy]
        np.testing.assert_array_equal(stamps,t)
        _,d=np.unique(t//86400,return_inverse=True)
        gain=np.bincount(d,weights=profit-p)
        count=len(gain)
        r=np.random.default_rng(404).integers(0,count-7+1,size=(6000,int(np.ceil(count/7))))
        selection=(r[:,:,None]+np.arange(7)).reshape(6000,-1)[:,:count]
        low,high=np.quantile(gain[selection].sum(1),[.025,.975])
        rows.append(dict(model=model,base=base,split=split,policy=policy,
            cash_delta_GBP=gain.sum(),lo_7day_GBP=low,hi_7day_GBP=high,days=count))
    if rows:
        with (HERE/f"dispatch_gain_intervals{suffix}.csv").open("w",newline="") as f:
            w=csv.DictWriter(f,rows[0].keys());w.writeheader();w.writerows(rows)


if __name__=="__main__":
    arg=argparse.ArgumentParser(description=__doc__)
    arg.add_argument("candidates",nargs="+")
    arg.add_argument("--deadline",required=True,type=float)
    arg.add_argument("--suffix",choices=("", "_architecture"),default="")
    args=arg.parse_args()
    run(["weekday_reference",*args.candidates],args.deadline,args.suffix)
