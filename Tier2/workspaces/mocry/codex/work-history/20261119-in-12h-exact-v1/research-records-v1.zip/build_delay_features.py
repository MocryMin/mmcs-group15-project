"""Compare realistic publication and ingestion delays of the strongest data feeds."""
from build_system_features import outlook


if __name__=="__main__":
    import sys
    for tag in sys.argv[1:]:
        name, delay=tag.split(":")
        outlook(name,int(delay))
