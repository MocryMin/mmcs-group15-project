"""Test the information value of delayed metering from the scenario's own wind farm."""
import numpy as np
import pandas as pd

from build_features import P, ORIGINS, SLOTS, TRAIN, load_baseline, save_block


def main():
    root=P/"tier1-multiproduct-20261110-v6/inputs"
    wind=pd.read_csv(root/"wind_farm_generation.csv")
    lookup=pd.Series(wind.wind_farm_MW.to_numpy(),
                     index=pd.to_datetime(wind.date,utc=True).dt.as_unit("s").astype("int64"))
    day=ORIGINS//86400*86400
    native=load_baseline()

    def histories(lag):
        return lookup.reindex(day-lag*86400).to_numpy()[:,None]

    daily=np.concatenate([histories(lag) for lag in range(2,9)],axis=1)
    with np.errstate(invalid="ignore"):
        average=np.nanmean(daily,axis=1,keepdims=True)
        spread=np.nanstd(daily,axis=1,keepdims=True)
    source = "Scenario sensitivity. The project's independent-farm daily average is assumed visible from midnight two dates later. Its past values would come from the client's meter. No historical publication snapshots are supplied; the archive is never added to the primary as-of comparison."
    save_block("farm_meter_lag2",{
        "farm_last_complete_daily_lag_2":histories(2),
        "farm_previous_daily_change":histories(2)-histories(3),
        "farm_seven_day_average_from_lag_2":average,
        "farm_seven_day_sd_from_lag_2":spread,
    },TRAIN,SLOTS.shape,source)
    save_block("farm_meter_wind",{
        "farm_meter_vs_current_gb_wind_forecast":histories(2)-native("WINDFOR_forward"),
        "farm_meter_recent_to_week_ratio":histories(2)/np.maximum(25,average),
        "farm_wind_generation_proxy":histories(2)+native("AGPT_seasonal_mean"),
        "farm_gap_between_lag2_and_lag7":histories(2)-histories(7),
    },TRAIN,SLOTS.shape,source)


if __name__=="__main__":
    main()
