"""Per-origin temporal centering using values available at that origin."""
import numpy as np

from build_features import SLOTS, TRAIN, load_baseline, save_block


def describe(a):
    valid = np.isfinite(a)
    n = valid.sum(1,keepdims=True)
    center = np.nansum(a,axis=1,keepdims=True)/np.maximum(1,n)
    sd = np.sqrt(np.nansum((a-center)**2,axis=1,keepdims=True)/np.maximum(1,n))
    return np.where(n>0,center,np.nan),np.where(n>0,sd,np.nan)


def main():
    x = load_baseline()
    shape = {}
    for name in ("PRICES","NDF","WINDFOR"):
        curve=x(name+"_forward")
        m,s=describe(curve)
        floor=10 if name=="PRICES" else 250
        shape[name+"_centered_delivery_curve"]=(curve-m)/np.maximum(floor,s)
        shape[name+"_origin_curve_mean"]=m
        shape[name+"_origin_curve_scale"]=np.log1p(s)
    save_block("origin_path_norm",shape,TRAIN,SLOTS.shape,
        "Per-origin mean/scale of already-published price, demand and wind forecasts, with floor for constant windows. A known future forecast is treated as an input available at the decision timestamp.")
    historical = {}
    for tag in ("FUELINST","AGPT","INDO","ITSDO"):
        curve=x(tag+"_history_0")
        m,s=describe(curve)
        historical[tag+"_history_recent_centered"] = (curve-m)/np.maximum(250,s)
        historical[tag+"_latest_minus_recent_mean"] = curve[:,-1:]-m
        historical[tag+"_recent_scale"] = np.log1p(s)
    save_block("origin_history_norm",historical,TRAIN,SLOTS.shape,
        "Per-origin mean/scale calculated over previously published observations; historical values kept as extra channels.")


if __name__=="__main__":
    main()
