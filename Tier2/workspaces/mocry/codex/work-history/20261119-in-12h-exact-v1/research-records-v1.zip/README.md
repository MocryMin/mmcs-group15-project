# Tier 2B 特征工程实验

实验沿用项目半小时模型的标签、验证尺度和初始 59 列输入。输出是未来 24 个半小时的电价、系统发电量和需求。输入的每一行按交付时段对齐，在该次作出预测时全部已经可读。输入按已发布版本关联，天气按历史预报而非再分析关联。来源、覆盖和会受发布时间假设影响的情景见 [SOURCES.md](SOURCES.md)。

主划分为 2022–2024 训练、2025 年 1–8 月验证、2025 年 9–12 月及 2026 年 6–8 月两个测试期。起点数依次为 52,585、11,641、5,833、4,393。评估的 12 小时均方误差先按既有的每目标训练尺度标准化，再对预测起点、24 个提前期和三个目标取均值。前 4 小时、首半小时和各单独目标另有记录。三种子通常为 17、29 和 43。测试期误差首次读取于验证筛选之后，同期资料也在之前的项目研究中用过。

## 工件

| 文件 | 内容 |
|:--|:--|
| `screen*.json` | 小模型输入和表示筛选。单种子、四轮，验证每 24 步 |
| `confirm*.json` | 小模型验证入选与三种子复核 |
| `scale*.json` | 1×864 和 3×448。五轮，每十步按验证损失选权重 |
| `early_2024.json` | 额外的时间顺序复训。2022–23 训练和重新定标，2024 年 1–8 月验证及 9–12 月测试 |
| `blocks/*.npy`、`blocks/*.json` | 按冻结顺序对齐的新增输入及来源、列名、训练定标、覆盖率 |
| `runs/<阶段>/<配方>/seed-<种子>/` | 配置、验证学习轨迹、最佳权重、锁定权重时的评估，以及复核阶段的逐起点预测 |
| `run_scores.csv`、`mean_scores.csv` | 实际完成的训练记录，各拆分和目标误差 |
| `feature_catalogue.csv` | 全部构造列、来源、训练定标和各时期的数据覆盖 |
| `paired_block_intervals.csv`、`paired_block14_intervals.csv`、`paired_block28_intervals.csv` | 同种子、同日期对照。重采样 7、14 或 28 日的连续块，以免把高度重叠的半小时目标当作独立样本 |
| `heldout_regimes.csv` | 分月、只含原生标签的起点、最高电价前 10% 等复核口径 |
| `dispatch_diagnostics.csv` | 固定 100 MW／400 MWh 电池及旧氢侧配置的运营复算。半年或季度内首个实际动作和现有分配规则 |
| `holdout_2026_plan.json`、`jan_may_2026/` | 预先锁定的 2026 年 1–5 月测试模型、到期输入、标签与成对区块区间 |
| `model_replay_audit.json`、`feature_input_hashes.json` | 冻结权重回读、发布时间与交付时间重复键的冲突排除、输入档案完整性摘要 |

本目录依赖相邻 `tier2b-asof-20261119` 的已核对输入、尺度和标签，以及 `tier2b-8x768/base_training.json` 的优化器配置。运行环境是项目已有的 CUDA Python 环境。用 `experiment.py <配方 JSON> --group <阶段> --seeds 17 29 43 --epochs 5 --evaluate-every 10 --deadline <Unix UTC 时间>` 重训主配方。筛选传入 `--search`；它只计算验证误差。2024 时间复核传入 `--early-2024`。生成的权重和误差都留在该次阶段目录。可用 `summarize_results.py` 重建汇总。

各新增特征的数据期和可用率见 `blocks/*.json`。市场、气象和政策的额外输入是否有预测贡献，分别从对照与时间稳定性判断。整周重采样区间度量历史日期的差异，随机种子离散度、特征探索次数和标签重建是另三项影响。

## 固定规模的检查点

主表用三个种子的均值。单份权重按相同的 12 小时验证标准，从种子 17、29、43 中取验证误差最低的检查点。

| 模型 | 历史回放入口 | 输入处理 |
|:--|:--|:--|
| 1×864（种子 29） | [权重](runs/scale3/generation_1x864/seed-29/model.pt) · [配置](runs/scale3/generation_1x864/seed-29/config.json) | 原 59 列加 [发电计划五列](blocks/generation_schedule.json)，共 64 列 |
| 3×448（种子 29，计划原值） | [权重](runs/scale3/national_3x448/seed-29/model.pt) · [配置](runs/scale3/national_3x448/seed-29/config.json) | 加 [INDGEN](blocks/indgen.json)、[TSDF](blocks/tsdf.json) 和由原输入构造的 [路径形状](blocks/forecast_shape.json) |
| 3×448（种子 43） | [权重](runs/scale_processed/generation_zca_3x448/seed-43/model.pt) · [配置](runs/scale_processed/generation_zca_3x448/seed-43/config.json) | 同一 64 列先按训练集标准化，再使用 [训练集白化矩阵](jan_may_2026/scale_processed-generation_zca_3x448_train_preprocessing.npz) |
| 1×864（种子 17，原输入后备） | [权重](runs/scale1/original_1x864/seed-17/model.pt) · [配置](runs/scale1/original_1x864/seed-17/config.json) | 保持原 59 列。新增预报整体中断时，可继续用已有数据运行 |

模型输出是 24 槽乘三个目标的标准化残差。以原 `targets.npz` 中的三项 `target_sd` 乘回各列，再加预测时刻可算出的同槽季节基准。发电和需求按交付半小时 MWh 保存，换成 GW 时除以 500。
