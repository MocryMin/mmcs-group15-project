"""Compress known historical trajectories and expose short-horizon price statistics."""
import gzip
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.fft import dct

from build_features import BASE, ORIGINS, SLOTS, TRAIN, load_baseline, save_block


def history():
    native = load_baseline()
    result = {}
    for source in ('AGPT','FUELINST','INDO','ITSDO'):
        trajectory = np.concatenate([native(source+'_history_1'),native(source+'_history_0')],axis=1)
        valid = np.isfinite(trajectory)
        mean = np.nansum(trajectory,axis=1,keepdims=True)/np.maximum(valid.sum(1,keepdims=True),1)
        filled = np.where(valid,trajectory,mean)
        coefficients = dct(filled,axis=1,norm='ortho')
        for k in range(8):
            result[f'{source}_history_dct_{k}']=coefficients[:,k:k+1]
        result[f'{source}_trajectory_coverage']=valid.mean(1,keepdims=True)
    save_block('history_dct',result,TRAIN,SLOTS.shape,
               'First eight orthogonal cosine coefficients of each 48-sample past trajectory, with per-origin coverage.')


def price():
    native = load_baseline()
    result = {}
    forward = native('PRICES_forward')
    weekday = native('PRICES_seasonal_mean')
    past = np.concatenate([native('past_auction_1'),native('past_auction_0')],axis=1)
    # Scale and distribution terms use only a known auction path or past observations.
    for name, sample in [('forward',forward),('past',past)]:
        cnt = np.isfinite(sample).sum(1,keepdims=True)
        avg = np.nansum(sample,axis=1,keepdims=True)/np.maximum(cnt,1)
        stdev = np.sqrt(np.nansum(np.square(sample-avg),axis=1,keepdims=True)/np.maximum(cnt,1))
        result[name+'_price_mean']=np.where(cnt>0,avg,np.nan)
        result[name+'_price_volatility']=np.where(cnt>2,stdev,np.nan)
        result[name+'_price_max']=np.where(cnt>0,np.max(np.where(np.isfinite(sample),sample,-1e4),axis=1,keepdims=True),np.nan)
        result[name+'_price_min']=np.where(cnt>0,np.min(np.where(np.isfinite(sample),sample,1e4),axis=1,keepdims=True),np.nan)
        if name=='forward':
            result['price_demeaned']=forward-avg
            result['price_spread_asinh']=np.arcsinh((forward-weekday)/30)
            result['price_position_in_path']=(forward-result[name+'_price_min'])/np.maximum(1,result[name+'_price_max']-result[name+'_price_min'])
    save_block('price_stats',result,TRAIN,SLOTS.shape,'Known auction relative shape and recent price distribution; no realised future MID.')


def auction_schedule():
    files = list((BASE/'sources').glob('PRICES-*.csv.gz'))
    quotes = pd.concat([pd.read_csv(x) for x in files]).drop_duplicates(['obs'],keep=False).set_index('obs')
    hours = SLOTS//3600*3600
    native = load_baseline()
    original = native('PRICES_forward')
    expanded=[]
    for cutoff in (12,18,22):
        availability_time = hours//86400*86400-86400+cutoff*3600
        valid = availability_time<=ORIGINS[:,None]
        quote = quotes.value.reindex(hours.ravel()).to_numpy('float32').reshape(hours.shape)
        signal = np.where(valid,quote,np.nan)
        # Fill only slots for which the frozen midnight-cutoff input did not contain a quote.
        new = np.isfinite(signal)&~np.isfinite(original)
        columns = {'n2ex_earlier_nominal_price': np.where(new,signal,np.nan),
                   'n2ex_available_earlier':new,
                   'n2ex_earlier_spread':np.where(new,signal-native('PRICES_seasonal_mean'),np.nan)}
        save_block(f'auction{cutoff}',columns,TRAIN,SLOTS.shape,
                   f'Next delivery-day N2EX at {cutoff:02}:00 UTC on the prior day under normal auction schedule. Retrospective auction values lack vintage proof; sensitivity only.')
        expanded.append(float(new.mean()))
    print('New N2EX schedule coverage',expanded,flush=True)


if __name__=='__main__':
    history()
    price()
    auction_schedule()
