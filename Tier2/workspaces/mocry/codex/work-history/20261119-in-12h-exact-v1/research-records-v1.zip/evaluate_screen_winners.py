"""Evaluate a validation-ranked shortlist without changing its saved weights."""
import argparse
import csv
import json
import time

import numpy as np
import torch

from build_features import BASE, CUTS, HERE, SIZES
from experiment import Model, predict, recipe_features, scores


def group_results(group, baseline, count, deadline):
    path=HERE/"runs"/group
    rankings=[]
    for case in sorted(path.iterdir()):
        files=sorted(case.glob("seed-*/result.json"))
        if len(files)!=3:
            continue
        val=np.mean([json.loads(f.read_text())["val"]["12h"] for f in files])
        rankings.append((val,case.name))
    candidates=[case for _,case in sorted(rankings) if case!=baseline][:count]
    plans=[baseline,*candidates]
    D=np.concatenate([np.load(BASE/"inputs.npy",mmap_mode="r"),
                      np.load(BASE/"summer-2026/inputs.npy",mmap_mode="r")])
    original=json.loads((BASE/"features.json").read_text())["names"]
    with np.load(BASE/"targets.npz") as a,np.load(BASE/"summer-2026/targets.npz") as b:
        labels=[torch.tensor(y,device="cuda") for y in [*np.split(a["y"],CUTS[:2])[1:],b["y"]]]
    torch.set_float32_matmul_precision("high")
    all_rows=[]
    for item in plans:
        if time.time()>=deadline:
            break
        configs=sorted((path/item).glob("seed-*/config.json"))
        config=json.loads(configs[0].read_text())["case"]
        if "ridge_offset" in config or config.get("anchor"):
            raise ValueError("This screen replay expects a model without a fitted external offset")
        x,features=recipe_features(D,original,config,int(SIZES[0]))
        parts=[part.cuda() for part in x.split(SIZES.tolist())[1:]]
        for model_config in configs:
            receipt=json.loads((model_config.parent/"result.json").read_text())
            loaded=torch.load(model_config.parent/"model.pt",weights_only=True,map_location="cuda")
            m=Model(features,config.get("width",344),config.get("layers",1),
                    config.get("projection","linear"),config.get("head","mean"),
                    backbone=config.get("backbone","transformer")).cuda()
            m.load_state_dict(loaded["weights"])
            for s,t,y in zip(("val","test25","test26"),parts,labels):
                record=scores(predict(m,t,deadline),y)
                if s=="val":
                    np.testing.assert_allclose(record["12h"],receipt["val"]["12h"],rtol=1e-4)
                all_rows.append(dict(case=item,split=s,seed=receipt["seed"],**record))
        print(group,item,"replayed",flush=True)
    if all_rows:
        p=HERE/f"screen_winners_{group}.csv"
        with p.open("w",newline="") as f:
            w=csv.DictWriter(f,all_rows[0].keys())
            w.writeheader();w.writerows(all_rows)


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("group")
    p.add_argument("baseline")
    p.add_argument("--count",default=2,type=int)
    p.add_argument("--deadline",required=True,type=float)
    a=p.parse_args()
    group_results(a.group,a.baseline,a.count,a.deadline)
