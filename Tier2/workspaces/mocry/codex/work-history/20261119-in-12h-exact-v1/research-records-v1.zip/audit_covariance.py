"""Inspect the train-only covariance used by ZCA on the selected inputs."""
import json

import numpy as np

from build_features import BASE, FEATURES, HERE, TRAIN


x0=np.load(BASE/"inputs.npy",mmap_mode="r")[:TRAIN]
a=np.load(FEATURES/"generation_schedule.npy",mmap_mode="r")[:TRAIN]
columns=json.loads((BASE/"features.json").read_text())["names"]
columns.extend(c["name"] for c in json.loads((FEATURES/"generation_schedule.json").read_text())["columns"] if "mean" in c)
matrix=np.concatenate([x0,a],axis=-1)
z=matrix.reshape(-1,matrix.shape[-1]).astype("float64")
z-=z.mean(0)
C=z.T@z/len(z)
eig=np.linalg.eigvalsh(C)
d=np.sqrt(np.maximum(np.diag(C),1e-20))
correlation=C/d[:,None]/d[None,:]
original_count=x0.shape[-1]
links=[{"source":columns[j],"other":columns[i],"correlation":float(correlation[i,j])}
       for j in range(original_count,len(columns)) for i in range(j)]
links=sorted(links,key=lambda row:-abs(row["correlation"]))[:24]
output={"observations":int(len(z)),"columns":len(columns),
        "eigenvalues":eig.tolist(),"count_below_0_15":int((eig<.15).sum()),
        "correlated_pairs_involving_generation_features":links}
(HERE/"input_covariance_audit.json").write_text(json.dumps(output,indent=2))
print(output["observations"],output["columns"],eig[-1],output["count_below_0_15"],links[:5],flush=True)
