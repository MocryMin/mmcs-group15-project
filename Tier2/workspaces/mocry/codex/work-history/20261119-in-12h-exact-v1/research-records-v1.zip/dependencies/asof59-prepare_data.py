"""Point-in-time feature reconstruction for the three joint 12h forecasters."""
from pathlib import Path
import gzip
import json
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parent
SOURCE = ROOT / 'sources'
EPOCH = 1609459200
STRIDE = 1_000_000_000
SPLITS = {'train': ('2022-01-01','2025-01-01'), 'val': ('2025-01-01','2025-09-01'),
          'test': ('2025-09-01','2026-01-01')}
audit = {}


class Archive:
    """Find the last version of one delivery interval published by the decision."""
    def __init__(self, name, key, duration=0, source_dir=SOURCE):
        chunks = sorted(source_dir.glob(name+'-*.csv.gz'))
        rows = pd.concat([pd.read_csv(f) for f in chunks], ignore_index=True)
        rows = rows[rows.key.eq(key)].dropna().copy()
        if name in ('FUELINST','INDO','ITSDO'):
            rows = rows[rows.value.between(4000,90000)]
        rows['pub'] = np.maximum(rows.pub, rows.obs+duration) if duration else rows.pub
        rows = rows.drop_duplicates(['obs','pub','value'])
        ambiguous = rows.duplicated(['obs','pub'],keep=False)
        audit[name] = {'weekly_files':len(chunks),'rows':len(rows),'conflicting_rows_excluded':int(ambiguous.sum())}
        rows = rows.loc[~ambiguous].sort_values(['obs','pub'])
        self.obs = rows.obs.to_numpy(np.int64)
        self.pub = rows.pub.to_numpy(np.int64)
        self.keys = (self.obs//300)*STRIDE + self.pub-EPOCH
        assert np.all(np.diff(self.keys)>0) and np.max(self.pub-EPOCH)<STRIDE
        self.values = rows.value.to_numpy(np.float32)
        order = self.pub.argsort(kind='stable')
        self.times = self.pub[order]
        self.newest = np.maximum.accumulate(self.obs[order])

    def find(self, obs, asof):
        ix = np.searchsorted(self.keys,(obs//300)*STRIDE+(asof-EPOCH),side='right')-1
        good = (ix>=0)&(self.obs[ix]==obs)&(self.pub[ix]<=asof)
        return np.where(good,self.values[ix],np.nan), np.where(good,self.pub[ix],0)

    def latest(self, asof):
        i = np.searchsorted(self.times,asof,side='right')-1
        if np.any(i<0):
            raise ValueError('Missing warm-up archive')
        return self.newest[i]


def read_daily(name):
    records = json.loads((PROJECT/'tier2b-feature-engineering-20261110'/'research'/
                          ('neso_'+name+'_day_ahead.json')).read_text())['records']
    frame = pd.DataFrame([r for r in records if r['n']>0]).set_index('date')
    frame['pub'] = pd.to_datetime(frame.latest_issue,utc=True).to_numpy(dtype='datetime64[s]').astype('int64')
    return frame


def main(output=ROOT, physical_delay_hours=0, *, frame=None, splits=SPLITS, source_dir=SOURCE, frozen=None):
    df = pd.read_csv(PROJECT/'tier1-halfhour-20261113-v7/inputs/halfhour.csv.gz') if frame is None else frame
    idx = pd.DatetimeIndex(pd.to_datetime(df.utc,utc=True))
    seconds = idx.to_numpy(dtype='datetime64[s]').astype('int64')
    targets = np.column_stack([df.price,.5*(df.background_MW+df.farm_flat_MW),.5*df.demand_MW])
    split_rows = [np.flatnonzero((idx>=a)&(idx<b))[:-23] for a,b in splits.values()]
    origins = np.concatenate(split_rows)
    now = seconds[origins,None]
    lead = np.arange(24)*1800
    dest = now+lead
    columns = {}

    def add(name, x):
        columns[name] = np.broadcast_to(x, dest.shape).astype(np.float32)

    sources = {k:Archive(k,key,duration,source_dir) for k,key,duration in [
        ('AGPT','AGPT',1800),('FUELINST','positive',300),('INDO','INDO',1800),
        ('ITSDO','ITSDO',1800),('NDF','NDF',0),('WINDFOR','WINDFOR',0),('PRICES','auction',0)]}
    recent = {}
    for k in ('AGPT','FUELINST','INDO','ITSDO'):
        s = sources[k]
        knowledge = now-3600*physical_delay_hours
        last = s.latest(knowledge)
        age = (now-last)/60
        audit[k]['latest_start_age_minutes_q50_q95_q99_max'] = np.percentile(age,[50,95,99,100]).tolist()
        add(k+'_age_hours',np.log1p(age/60))
        for block in (0,1):
            # Consecutive rows hold the older-to-newer observations, ending at the latest available.
            obs = last+lead-(23+24*block)*1800
            v,_ = s.find(obs,knowledge)
            add(k+'_history_'+str(block),v)
            if block==0:
                recent[k]=v[:,-1:]
        if k=='FUELINST':
            for lag in (0,1,2,3,4,5):
                v,_ = s.find(last-lag*300,knowledge)
                add('five_minute_demand_lag_'+str(lag),v)

    for k,resolution in [('NDF',1800),('WINDFOR',3600),('PRICES',3600)]:
        v,issue = sources[k].find(dest//resolution*resolution,now)
        add(k+'_forward',v)
        add(k+'_forward_known',issue>0)
        if k!='PRICES':
            add(k+'_forecast_age_hours',np.where(issue>0,np.log1p((now-np.minimum(now,issue))/3600),np.nan))
        audit[k]['forward_coverage'] = float((issue>0).mean())
    for block in (0,1):
        obs = now+lead-(24+24*block)*1800
        add('past_auction_'+str(block),sources['PRICES'].find(obs//3600*3600,now)[0])
    for k,field in [('demand','mean'),('wind','mean')]:
        daily = read_daily(k)
        days, inverse = np.unique(dest//86400,return_inverse=True)
        pick = daily.reindex(pd.to_datetime(days,unit='D',utc=True).strftime('%Y-%m-%d'))
        ids = inverse.reshape(dest.shape)
        pub = pick.pub.to_numpy()[ids]
        visible = pub<=now
        add('daily_'+k,np.where(visible,pick[field].to_numpy()[ids],np.nan))
        add('daily_'+k+'_count',np.where(visible,pick.n.to_numpy()[ids],0))
    t = dest//1800
    for name,phase in [('time',t%48/48),('weekday',((dest//86400+3)%7)/7),
                       ('season',(dest/86400-10_957)/365.2425)]:
        add(name+'_sin',np.sin(2*np.pi*phase))
        add(name+'_cos',np.cos(2*np.pi*phase))
    # Use only archived inputs to form the residual reference. Its physical units
    # need not match the labels exactly; the model learns the systematic offset.
    baseline = []
    for k,unit in [('PRICES',1),('AGPT',.5),('FUELINST',.5)]:
        vals=[]
        for lag in (7,14,21,28):
            obs = dest-86400*lag
            if k=='PRICES':
                obs=obs//3600*3600
            vals.append(sources[k].find(obs,now)[0])
        vals = np.stack(vals)
        n = np.isfinite(vals).sum(0)
        avg = np.nansum(vals,axis=0)/np.maximum(n,1)
        add(k+'_seasonal_count',n)
        fallback = recent.get(k,columns['past_auction_0'][:,-1:])
        avg = np.where(n>0,avg,np.nan_to_num(fallback))
        add(k+'_seasonal_mean',avg)
        baseline.append(avg*unit)
    baseline = np.stack(baseline,axis=-1)
    scale = np.array(json.loads((PROJECT/'tier2b-gpu-overfit-5m-1b/protocol.json').read_text())['meta']['target_std'])
    y = (targets[origins[:,None]+np.arange(24)]-baseline)/scale
    train_n = len(split_rows[0])
    names=list(columns)
    for name in list(names):
        use_indicator = (name+'_observed' in frozen['names'] if frozen is not None
                         else np.isnan(columns[name][:train_n]).any() and not name.endswith('_forward'))
        if use_indicator:
            names.append(name+'_observed')
            columns[names[-1]] = np.isfinite(columns[name]).astype(np.float32)
    x = np.empty((*dest.shape,len(names)),dtype='float32')
    if frozen is not None:
        assert names==frozen['names']
    averages,scales=[],[]
    for j,name in enumerate(names):
        a=columns.pop(name)
        mu=np.float64(frozen['mean'][j]) if frozen is not None else np.nanmean(a[:train_n],dtype=np.float64)
        sd=np.float64(frozen['std'][j]) if frozen is not None else np.nanstd(a[:train_n],dtype=np.float64)
        assert np.isfinite(mu+sd),name
        sd=sd if sd>1e-6 else 1.
        x[:,:,j]=np.where(np.isfinite(a),(a-mu)/sd,0.)
        averages.append(mu);scales.append(sd)
    assert np.isfinite(x).all() and np.isfinite(y).all()
    output.mkdir(exist_ok=True)
    np.save(output/'inputs.npy',x)
    np.savez(output/'targets.npz',y=y.astype('float32'),baseline=baseline.astype('float32'),
             utc=now[:,0],target_sd=scale,split_sizes=list(map(len,split_rows)))
    (output/'features.json').write_text(json.dumps(dict(names=names,mean=averages,std=scales,audit=audit),indent=2))
    print('Prepared',x.shape,list(map(len,split_rows)),audit,flush=True)


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser()
    parser.add_argument('--delay-control',action='store_true')
    delayed=parser.parse_args().delay_control
    main(ROOT/'delay-control' if delayed else ROOT,48 if delayed else 0)
