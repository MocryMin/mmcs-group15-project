# Tier 2B 半小时预测的信息来源

采集日为 2026-11-19。所有时刻用 UTC。六个 Elexon 接口按**发布时间**每七天取一份，从 2021-12-01 起到 2026-01-01 截止，共 214 个区间。预测从 2022-01-01 开始，最初一个月用于准备历史特征。逐文件摘要在 [source_sha256.txt](source_sha256.txt)。

| 来源 | 进入预测的量 | 如何判断当时可见 |
|---|---|---|
| [Elexon AGPT](https://data.elexon.co.uk/bmrs/api/v1/datasets/AGPT/stream?publishDateTimeFrom=2025-11-16T00:00Z&publishDateTimeTo=2025-11-17T00:00Z) | 课程所用 11 类燃料的半小时背景发电功率合计 | 该版本发布且计量时段已结束。只接纳 11 项齐全且前八项至少一项为正的记录 |
| [Elexon FUELINST](https://data.elexon.co.uk/bmrs/api/v1/datasets/FUELINST/stream?publishDateTimeFrom=2025-11-16T00:00Z&publishDateTimeTo=2025-11-17T00:00Z) | 五分钟需求实绩。按同一版本的燃料和互联通道记录累加正功率 | 查每个五分钟区间的发布版本，输入限 4,000–90,000 MW。与既有 Elexon demand/outturn/summary 实绩交集逐行核过 |
| [Elexon INDO](https://data.elexon.co.uk/bmrs/api/v1/datasets/INDO?publishDateTimeFrom=2025-11-16T00:00Z&publishDateTimeTo=2025-11-17T00:00Z)、[ITSDO](https://data.elexon.co.uk/bmrs/api/v1/datasets/ITSDO?publishDateTimeFrom=2025-11-16T00:00Z&publishDateTimeTo=2025-11-17T00:00Z) | 国民需求和输电系统需求的初报，两个独立半小时特征 | 初报已发布且交付时段已结束；同用上述功率筛查范围 |
| [Elexon NDF](https://data.elexon.co.uk/bmrs/api/v1/datasets/NDF/stream?publishDateTimeFrom=2025-11-16T00:00Z&publishDateTimeTo=2025-11-17T00:00Z)、[WINDFOR](https://data.elexon.co.uk/bmrs/api/v1/datasets/WINDFOR/stream?publishDateTimeFrom=2025-11-16T00:00Z&publishDateTimeTo=2025-11-17T00:00Z) | 各未来交付时段的全国需求预报与风电预报 | 针对每个交付时段选择决策时刻已经发布的最新版本。风电采用对应小时的预报 |
| NESO 日前需求和风电日摘要 | 日均值和点数 | 采用项目已归档的两份 NESO 数据，以合成日摘要所用各点中最晚的发布时间为准 |
| [NESO 转发的 Nord Pool N2EX 英国日前拍卖价](https://api.neso.energy/api/3/action/package_show?id=day-ahead-power-exchange-prices-nordpool) | 每小时名义英镑报价，及其可见标记 | 原交易所在前一日发布。归档仅含交付日期、GMT 小时和价格。依正常日前发布机制，在交付日 00:00 UTC 才使用该日全套价。对特殊延误和修订无法逐笔验真 |
| [Elexon 短期市场指数](https://bmrs.elexon.co.uk/market-index-prices)及项目 V7 处理 | 项目实际结算电价目标，按 2020 年英镑计价 | 最终价作标签。原始接口只有交付时间；规则规定提交时限，也允许延误及更正。[BSC 第 T 节 1.6.2、1.6.4 和 1.6.6](https://bscdocs.elexon.co.uk/bsc-module/bsc/bsc-section-t-settlement-and-trading-charges) |

季节基准取目标时段分别向前 7、14、21、28 天的已发布价格、背景发电或五分钟需求，附有效个数。价格历史用日前拍卖价。发电和需求的季节基准以半小时电量计。项目独立风场的逐日平铺发电及 V7 缺口修复只用于定义结果标签。缺失特征用训练集均值填补，随特征保存可用标记；均值和标准差见 [features.json](features.json)。需求历史及各预报的覆盖和抽查见 [audit.json](audit.json)。

## 复现

1. 已落盘的紧凑发布历史位于 `sources/`。如需重新采集，`save_sources.py` 启动本机接收端，`collect_events.js` 接受 Playwright 页面和形如 `[dataset, start_date, end_date]` 的任务列表。`collect_auction.js` 收集日前拍卖价。原库可能继续修订或滚动淘汰旧日期，复核本轮数值以已保存文件和校验表为准。
2. 在课程 GPU Python 环境执行 `prepare_data.py` 生成共用输入，`audit.py` 核实来源和划分，`fit.py ridge` 和 `fit.py nets` 分别训练岭回归和两个 Transformer。神经网络依赖同级原项目中的模型及五轮基础训练配置，训练目录已存在时会保护已有权重，可复制至新的实验目录复跑。
3. `prepare_data.py --delay-control` 和 `fit.py delay-control` 生成物理实绩额外滞后 48 小时的岭回归对照。`summarize.py` 合并误差、生成训练曲线并核对模型文件。
