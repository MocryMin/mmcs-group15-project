"""Delayed-final-market-index sensitivity where exact release versions are unavailable."""
import numpy as np
import pandas as pd

from build_features import ORIGINS, P, SLOTS, TRAIN, load_baseline, save_block


def main():
    raw=pd.read_csv(P/"gb-price-stress-20261112/halfhour-market-index.csv")
    raw["seconds"]=pd.to_datetime(raw.utc,utc=True).dt.as_unit("s").astype("int64")
    raw=raw.drop_duplicates("seconds",keep="last").set_index("seconds")
    fields=["mid_GBP_per_MWh","volume","active_providers"]
    raw=raw[fields].where(raw.active_providers>0,axis=0)

    def get(indices, field):
        values=raw[field].reindex(indices.ravel()).to_numpy().reshape(indices.shape)
        return values

    def group(day, cutoff):
        sampled=SLOTS-day*86400
        prev=ORIGINS[:,None]-cutoff*3600
        trail=prev-np.arange(23,-1,-1)[None,:]*1800
        assert (sampled+1800<=ORIGINS[:,None]-24*3600).all()
        price=get(sampled,"mid_GBP_per_MWh")
        trades=np.log1p(np.maximum(0,get(sampled,"volume")))
        hist=get(trail,"mid_GBP_per_MWh")
        v=get(trail,"volume")
        norm=np.maximum(1,np.nansum(v,axis=1,keepdims=True))
        local=np.nansum(v*hist,axis=1,keepdims=True)/norm
        finite=np.isfinite(hist)
        nohistory = finite.sum(1,keepdims=True)==0
        local=np.where(nohistory,np.nan,local)
        return {
            "lagged_final_mid_same_delivery":price,
            "lagged_final_mid_same_delivery_known":np.isfinite(price),
            "log_lagged_final_volume_same_delivery":trades,
            "lagged_final_mid_12h_vwap":local,
            "lagged_final_mid_vs_forecast_auction":price-load_baseline()("PRICES_seasonal_mean"),
            "lagged_final_mid_flat_vs_shape":price-local,
            "latest_consumed_final_mid_before_guard":hist[:,-1:],
            "lagged_final_mid_negative_share":np.where(nohistory,np.nan,((hist<0)&finite).mean(1,keepdims=True)),
        }

    source="Sensitivity only. Elexon Market Index Data final tape; nominal prices and volumes, timestamped by half-hour delivery. Retimed to old dates with no current or future delivery values. Exact historical first-publication and revision snapshots unavailable."
    save_block("mid_final_lag48",group(2,49),TRAIN,SLOTS.shape,source+" Same delivery 48h earlier, and 12h trailing history ending 49h before origin.")
    save_block("mid_final_lag168",group(7,169),TRAIN,SLOTS.shape,source+" Same delivery 168h earlier and 12h trailing history ending 169h before origin.")


if __name__=="__main__":
    main()
