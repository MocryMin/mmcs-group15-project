"""Compare new public forecasts as levels, changes, or margins."""
import numpy as np

from build_features import SLOTS, TRAIN, load_baseline, save_block
from build_physical_features import read


def main():
    source = "Elexon national boundary N. Latest forecast version published by the actual model origin, matched to each half-hour delivery."
    generation=read("indgen")["indgen_forward"]
    transmission=read("tsdf")["tsdf_forward"]
    demand_signed=read("inddem")["inddem_forward"]
    native=load_baseline()
    d0=native("FUELINST_seasonal_mean")
    g0=native("AGPT_seasonal_mean")
    signals={
        "indgen_deviation_from_seasonal":generation-g0,
        "tsdf_deviation_from_seasonal":transmission-d0,
        "indgen_minus_tsdf":generation-transmission,
        "indgen_plus_signed_inddem":generation+demand_signed,
        "tsdf_plus_signed_inddem":transmission+demand_signed,
    }
    for name,x in (("indgen",generation),("tsdf",transmission)):
        signals[f"{name}_ramp_from_first_slot"]=x-x[:,:1]
        prev=np.concatenate([x[:,:1],x[:,:-1]],axis=1)
        signals[f"{name}_ramp_since_previous_slot"]=x-prev
    save_block("operating_shapes",signals,TRAIN,SLOTS.shape,source)
    margin = generation-transmission
    save_block("dispatch_context",{
        "forecast_generation_minus_transmission":margin,
        "forecast_deficit_positive_part":np.maximum(0,-margin),
        "forecast_surplus_positive_part":np.maximum(0,margin),
        "forecast_deficit_share":(margin<0).mean(1,keepdims=True),
        "forecast_margin_minimum":margin.min(1,keepdims=True),
        "forecast_margin_maximum":margin.max(1,keepdims=True),
    },TRAIN,SLOTS.shape,source+" The physical balance proxy need not match the course labels exactly.")


if __name__=="__main__":
    main()
