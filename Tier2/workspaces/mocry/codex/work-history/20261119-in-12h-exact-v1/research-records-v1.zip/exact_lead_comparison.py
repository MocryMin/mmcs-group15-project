"""Evaluate individual half-hour slots against the frozen point-in-time labels."""
import csv
import json

import numpy as np

from build_features import BASE, CUTS, FEATURES, HERE, ORIGINS, TARGETS


SPLITS = ("test25", "test26")
LEAD_HOURS = (0.5, 4, 12)
SLOTS = np.array([int(2 * hours) - 1 for hours in LEAD_HOURS])
SEEDS = (17, 29, 43)
MODELS = {
    "Ridge": "ridge/forecast_shape+indgen+tsdf",
    "1x864": "runs/scale3/national_1x864",
    "1x1024": "runs/exact_lead/national_1x1024",
    "1x768": "runs/exact_lead/national_1x768",
    "3x448": "runs/scale3/national_3x448",
    "1x864_five": "runs/scale3/generation_1x864",
    "3x448_five_zca": "runs/scale_processed/generation_zca_3x448",
}
PHYSICAL_FACTORS = np.array([1.0, 0.002, 0.002])
UNITS = ("2020 GBP/MWh", "GW", "GW")


def external_errors(labels, baseline, scale):
    feeds = {}
    for name, target in (("indgen", 1), ("tsdf", 2)):
        metadata = json.loads((FEATURES / f"{name}.json").read_text())["columns"][0]
        assert metadata["name"] == f"{name}_forward" and min(metadata["coverage"][2:]) == 1
        values = np.load(FEATURES / f"{name}.npy", mmap_mode="r")
        encoded = dict(zip(SPLITS, np.split(values, CUTS)[2:]))
        for split in SPLITS:
            mw = (encoded[split][:, SLOTS, 0].astype("float64") * metadata["std"] + metadata["mean"])
            actual = labels[split][:, SLOTS, target] * scale[target] + baseline[split][:, SLOTS, target]
            feeds.setdefault(split, np.full((1, len(actual), len(SLOTS), len(TARGETS)), np.nan))
            feeds[split][0, :, :, target] = (mw * 0.5 - actual) / scale[target]
    return feeds


def model_errors(path, labels):
    folder = HERE / path
    checkpoints = [folder / f"seed-{seed}" for seed in SEEDS] if path.startswith("runs/") else [folder]
    errors = {split: [] for split in SPLITS}
    for checkpoint in checkpoints:
        with np.load(checkpoint / "predictions.npz") as prediction:
            for split in SPLITS:
                assert prediction[split].shape == labels[split].shape
                errors[split].append(prediction[split][:, SLOTS].astype("float64") - labels[split][:, SLOTS])
    return {split: np.stack(errors[split]) for split in SPLITS}


def resample_days(origins, seed=209):
    days, indices = np.unique(origins // 86400, return_inverse=True)
    assert np.all(np.diff(days) == 1)
    count = len(days)
    rng = np.random.default_rng(seed)
    blocks = rng.integers(0, count - 6, size=(6000, int(np.ceil(count / 7))))
    resampled = (blocks[:, :, None] + np.arange(7)).reshape(6000, -1)[:, :count]
    weights = np.bincount(indices)[resampled].sum(1)
    return indices, resampled, weights


def resampled_means(delta, index, resampled, weights):
    per_day = np.bincount(index, weights=delta)
    return per_day[resampled].sum(1) / weights


def paired_intervals(delta, index, resampled, weights):
    return np.quantile(resampled_means(delta, index, resampled, weights), (0.025, 0.975))


def write_csv(filename, rows):
    with (HERE / filename).open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)


def main():
    with np.load(BASE / "targets.npz") as original, np.load(BASE / "summer-2026/targets.npz") as summer:
        labels = dict(zip(SPLITS, [original["y"][CUTS[1]:], summer["y"]]))
        baseline = dict(zip(SPLITS, [original["baseline"][CUTS[1]:], summer["baseline"]]))
        scale = original["target_sd"]
        np.testing.assert_array_equal(scale, summer["target_sd"])
    errors = {name: model_errors(path, labels) for name, path in MODELS.items()}
    errors["Elexon"] = external_errors(labels, baseline, scale)
    scores = []
    differences = []
    origins = dict(zip(SPLITS, np.split(ORIGINS, CUTS)[2:]))
    units_per_sd = scale * PHYSICAL_FACTORS
    for split in SPLITS:
        bootstraps = resample_days(origins[split])
        for model, results in errors.items():
            for horizon, hours in enumerate(LEAD_HOURS):
                # Retain the same seed averaging as the matched training comparisons.
                normalized = results[split][:, :, horizon]
                for col, target in enumerate(TARGETS):
                    residual = normalized[:, :, col]
                    if np.isnan(residual).all():
                        continue
                    assert np.isfinite(residual).all()
                    physical = residual * units_per_sd[col]
                    absolute = np.abs(physical).mean(0)
                    scores.append(dict(model=model, period=split, lead_h=hours, target=target,
                                       n_origins=len(absolute), n_runs=len(residual), unit=UNITS[col],
                                       mae=absolute.mean(), rmse=np.sqrt(np.square(physical).mean()),
                                       standardized_mse=np.square(residual).mean()))
                    for reference in ("Ridge", "1x864", "Elexon"):
                        if reference == model:
                            continue
                        other = errors[reference][split][:, :, horizon, col]
                        if np.isnan(other).all():
                            continue
                        delta = absolute - np.abs(other * units_per_sd[col]).mean(0)
                        low, high = paired_intervals(delta, *bootstraps)
                        differences.append(dict(model=model, reference=reference, period=split, lead_h=hours,
                                                target=target, unit=UNITS[col], mae_change=delta.mean(),
                                                low95=low, high95=high))
                if model != "Elexon":
                    scores.append(dict(model=model, period=split, lead_h=hours, target="composite",
                                       n_origins=normalized.shape[1], n_runs=len(normalized), unit="standardized",
                                       mae="", rmse="", standardized_mse=np.square(normalized).mean()))
    write_csv("exact_lead_scores.csv", scores)
    write_csv("exact_lead_differences.csv", differences)
    print(f"{len(scores)} scores and {len(differences)} paired comparisons saved.")


if __name__ == "__main__":
    main()
