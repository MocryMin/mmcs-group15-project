"""Feature groups from versioned public British generation fuel and flow reports."""
from pathlib import Path
import json

import numpy as np
import pandas as pd
from build_features import HERE, ORIGINS, SLOTS, TRAIN, save_block, load_baseline

FILES = sorted((HERE/'sources').glob('mix-*.gz'))
STANDARD = ['gas','wind','nuclear','biomass','hydro','pumps','coal','other','import',
            'import_count','samples']
EPOCH = 1609459200
STRIDE = 1_000_000_000


def main():
    cols = pd.concat([pd.read_csv(x) for x in FILES], ignore_index=True)
    assert len(FILES) >= 224 and set(STANDARD) <= set(cols)
    obs = cols['obs'].to_numpy('int64')
    pub = np.maximum(cols['pub'].to_numpy('int64'),obs+300)
    cols['pub'] = pub
    cols.sort_values(['obs','pub'],inplace=True)
    cols.drop_duplicates(['obs','pub'],keep='last',inplace=True)
    obs = cols['obs'].to_numpy('int64')
    pub = cols['pub'].to_numpy('int64')
    keys = (obs//300)*STRIDE+pub-EPOCH
    values = cols[STANDARD].to_numpy('float32')
    by_pub = np.argsort(pub,kind='stable')
    cut = np.searchsorted(pub[by_pub],ORIGINS,side='right')-1
    assert cut.min()>=0
    latest = np.maximum.accumulate(obs[by_pub])[cut,None]
    lag = ORIGINS[:,None]-latest
    assert lag.min()>=300

    def find(delivery):
        ids = np.searchsorted(keys,(delivery//300)*STRIDE+ORIGINS[:,None]-EPOCH,side='right')-1
        known = (ids>=0)&(delivery==obs[ids])&(pub[ids]<=ORIGINS[:,None])
        return np.where(known[:,:,None],values[ids],np.nan)

    level = find(latest)
    levels = {f'{name}_mix_latest':level[:,:,i] for i,name in enumerate(STANDARD)}
    levels['mix_age'] = np.log1p(lag/60)
    levels['total_domestic_mix'] = np.sum(level[:,:,:8],axis=-1)
    levels['gas_share_in_mix'] = level[:,:,0]/np.maximum(1000,levels['total_domestic_mix'])
    levels['wind_share_in_mix'] = level[:,:,1]/np.maximum(1000,levels['total_domestic_mix'])
    shape = SLOTS.shape
    save_block('mix_level',levels,TRAIN,shape,'Elexon FUELINST vintage by publication and completed 5-min observation.')

    previous = [find(latest - delay*1800) for delay in (1,4,12,24)]
    changes = {f'{name}_mix_change_{delay}':(level[:,:,j]-raw[:,:,j])
               for j,name in enumerate(STANDARD[:9]) for delay,raw in zip((1,4,12,24),previous)}
    save_block('mix_changes',changes,TRAIN,shape,'Change since a completed and published historical FUELINST record.')

    history = find(latest + np.arange(-23,1)[None,:]*1800)
    summarized = {f'{name}_mix_history':history[:,:,i] for i,name in enumerate(STANDARD[:9])}
    save_block('mix_history',summarized,TRAIN,shape,'Latest available half-hour-spaced FUELINST trajectory.')

    native = load_baseline()
    projected_non_wind = np.sum(level[:,:,[0,2,3,4,5,6,7]],axis=-1)
    wind_forecast = native('WINDFOR_forward')
    ndf = native('NDF_forward')
    forecast = {
        'forecast_minus_observed_wind':wind_forecast-level[:,:,1],
        'half_hour_supply_proxy':wind_forecast+projected_non_wind,
        'gap_to_ndf_excluding_crossborder':wind_forecast+projected_non_wind-ndf,
        'gap_to_ndf_including_crossborder':wind_forecast+projected_non_wind+level[:,:,8]-ndf,
    }
    save_block('mix_forward',forecast,TRAIN,shape,'Forecasts anchored by actual recently published generation; proxies across dataset scopes.')
    print(json.dumps({'weekly_chunks':len(FILES),'observations':len(obs),
                      'age_minutes_quantiles':np.quantile(lag/60,[0,.5,.95,.99,1]).tolist()}),flush=True)


if __name__ == '__main__':
    main()
