"""Replay the frozen target-specific 12-hour path against existing comparators."""
import hashlib
import json
import sys

import numpy as np
import pandas as pd

from build_features import CUTS, FEATURES, HERE, P, load_baseline
from dispatch_diagnostics import p, references, rolling, settle
from exact_lead_comparison import resample_days, resampled_means

sys.path.insert(0, str(P / "tier2b-target-pilot-20261118"))
from detail_audit import cap, window_lookahead
from year_bound import upper_bound


OUTPUT = HERE / "in-12h-exact-v1"
CONFIG = json.loads((OUTPUT / "config.json").read_text(encoding="utf-8"))
SPLITS = tuple(CONFIG["windows"])
SEEDS = CONFIG["seeds"]
HORIZON = CONFIG["horizon_slots"]
FIXED_LOW = rolling.replay.FIXED_LOW
FIXED_HIGH = rolling.replay.FIXED_HIGH
FINANCING = json.loads((P / "operating-cost-review-20261117-v5/configuration.json").read_text())
RATE = FINANCING["r"]
LIFE = FINANCING["batteries"][0]["life"]
CRF = RATE / (1 - (1 + RATE) ** -LIFE)
COMMISSION_ANNUAL = FIXED_LOW - cap * (CRF + 0.025)


def feature_level(block, name):
    definition = json.loads((FEATURES / f"{block}.json").read_text())["columns"]
    columns = [column for column in definition if "mean" in column]
    position, entry = next((i, c) for i, c in enumerate(columns) if c["name"] == name)
    values = np.load(FEATURES / f"{block}.npy", mmap_mode="r")[:, :, position]
    return values.astype("float64") * entry["std"] + entry["mean"]


def test_split(values):
    return dict(zip(SPLITS, np.split(values, CUTS)[2:]))


def residuals(folder):
    root = HERE / folder
    if folder.startswith("runs/"):
        files = [root / f"seed-{seed}" / "predictions.npz" for seed in SEEDS]
    else:
        files = [root / "predictions.npz"]
    predictions = {split: [] for split in SPLITS}
    hashes = {}
    for path in files:
        with path.open("rb") as file:
            hashes[path.relative_to(HERE).as_posix()] = hashlib.file_digest(file, "sha256").hexdigest()
        with np.load(path) as file:
            for split in SPLITS:
                predictions[split].append(file[split].astype("float64"))
    return {split: np.mean(values, axis=0) for split, values in predictions.items()}, hashes


def break_even(gross, days):
    ceiling = gross * 365 / days
    return dict(annual_break_even_GBP=ceiling,
                net_at_2_5pct_GBP=gross - FIXED_LOW * days / 365,
                net_at_4pct_GBP=gross - FIXED_HIGH * days / 365,
                break_even_capex_2_5pct_GBP=max(0, (ceiling - COMMISSION_ANNUAL) / (CRF + 0.025)),
                break_even_capex_4pct_GBP=max(0, (ceiling - COMMISSION_ANNUAL) / (CRF + 0.04)))


def verify_trace(trace, actual, signal, policy, gross):
    before, request, charge, discharge, after, sale, hydrogen, cash = trace.T
    np.testing.assert_allclose(before[1:], after[:-1], atol=1e-7, rtol=0)
    np.testing.assert_allclose(after, before + p.E * charge - discharge/p.E, atol=1e-7, rtol=0)
    assert before[0] == 0 and after[-1] < 1e-7
    assert np.all((charge >= -1e-7) & (charge <= 50 + 1e-7))
    assert np.all((discharge >= -1e-7) & (discharge <= 50 + 1e-7))
    assert np.all(charge * discharge < 1e-7) and np.all(charge[-48:] < 1e-7)
    assert np.all((after >= -1e-7) & (after <= p.C + 1e-7))
    assert charge.sum() * p.E <= 400 * len(actual)/48 + 1e-6
    price, generation, demand = actual.T
    if policy == "B":
        forced = np.minimum(np.minimum(np.maximum(demand-generation, 0), before*p.E), 50)
        np.testing.assert_allclose(sale, np.minimum(generation, demand) + forced, atol=1e-7, rtol=0)
    _, _, _, _, sale0, hydrogen0 = p.flows(policy, generation, demand, price, signal, 0.0, 0.0)
    electricity_gain = np.dot(price, sale-sale0)
    hydrogen_gain = p.H * (hydrogen-hydrogen0).sum()
    np.testing.assert_allclose(cash.sum(), gross, rtol=0, atol=1e-5)
    np.testing.assert_allclose(electricity_gain + hydrogen_gain, gross, rtol=0, atol=1e-5)
    return dict(electricity_gain_GBP=electricity_gain, hydrogen_gain_GBP=hydrogen_gain)


def main():
    data, manifest = {}, {}
    for key in ("generation", "demand", "price_through_4h", "price_after_4h", "original_ridge", "original_1x864"):
        data[key], hashes = residuals(CONFIG[key])
        manifest.update(hashes)
    auction = load_baseline()("PRICES_forward")
    has_auction = test_split(np.isfinite(auction))
    factor = feature_level("real_price", "CPI_implied_discount_factor")
    real_factor = test_split(factor)
    real_auction = test_split(auction * factor)
    gen_external = test_split(feature_level("indgen", "indgen_forward") * 0.5)
    demand_external = test_split(feature_level("tsdf", "tsdf_forward") * 0.5)
    references_by_split = references()
    gross, traces, intervals, audit, issued = [], [], [], {}, {}
    pooled_changes = {}
    boundary = round(CONFIG["price_ridge_through_lead_h"] * 60 / CONFIG["slot_minutes"])
    for split, spec in CONFIG["windows"].items():
        stamps, base, sd, truth = references_by_split[split]
        n = len(stamps)
        assert n == spec["slots"] and pd.Timestamp(spec["start"]).timestamp() == stamps[0]
        assert np.all(np.diff(stamps) == CONFIG["slot_minutes"] * 60) and base.shape[1] == HORIZON
        np.testing.assert_allclose(truth[:-(HORIZON-1), -1], truth[HORIZON-1:, 0], atol=1e-6)
        mean = base.copy()
        mean[:, :, 0] *= real_factor[split][:n]
        external_price = np.where(has_auction[split][:n], real_auction[split][:n], mean[:, :, 0])
        external = np.stack([external_price, gen_external[split][:n], demand_external[split][:n]], axis=-1)
        signal = external_price[:, 0]
        price_residual = np.concatenate([data["price_through_4h"][split][:n, :boundary, 0],
                                         data["price_after_4h"][split][:n, boundary:, 0]], axis=1)
        hybrid = base + sd * np.stack([price_residual, data["generation"][split][:n, :, 1],
                                       data["demand"][split][:n, :, 2]], axis=-1)
        paths = {
            "in-12h-exact": hybrid,
            "mean": mean,
            "external_raw": external,
            "ridge_before_features": base + sd * data["original_ridge"][split][:n],
            "1x864_before_features": base + sd * data["original_1x864"][split][:n],
            "oracle_12h": truth,
        }
        actual = truth[:, 0]
        issue_horizon = np.minimum(HORIZON, n - np.arange(n))
        date = pd.to_datetime(stamps, unit="s", utc=True)
        days = n / 48
        issued[f"{split}_utc"] = stamps
        issued[f"{split}_common_current_price"] = signal
        audit[split] = dict(start=date[0].isoformat(), end_exclusive=(date[-1] + pd.Timedelta(minutes=30)).isoformat(),
                            slots=n, days=days, external_forward_price_coverage=has_auction[split][:n].mean(),
                            external_current_price_coverage=has_auction[split][:n, 0].mean())
        resampling = resample_days(stamps, seed=209 if split == "test25" else 421)
        for policy in ("A", "B"):
            comparisons = {}
            for method, path in paths.items():
                assert path.shape == truth.shape and np.isfinite(path).all()
                planned = path.copy()
                planned[:, :, 1:] = np.maximum(planned[:, :, 1:], 0.0)
                if method == "in-12h-exact":
                    issued[f"{split}_hybrid_path"] = planned
                scores = rolling.first_scores(policy, planned, issue_horizon, first_signal=signal)
                trace = []
                result, cash = settle(policy, actual, signal, scores, trace)
                earnings = result["gross"]
                trace = np.asarray(trace)
                attribution = verify_trace(trace, actual, signal, policy, earnings)
                gross.append(dict(split=split, policy=policy, method=method, days=days, gross_GBP=earnings,
                                  **break_even(earnings, days), cycles=result["cycle"], **attribution))
                comparisons[method] = cash
                table = pd.DataFrame(trace, columns=("stock_before_MWh", "request_MWh", "charge_AC_MWh",
                    "discharge_AC_MWh", "stock_after_MWh", "sales_MWh", "electrolyser_input_MWh", "gross_GBP"))
                table = table.assign(utc=date, split=split, policy=policy, method=method)
                traces.append(table)
            for method, baseline in comparisons.items():
                if method == "in-12h-exact":
                    continue
                delta = comparisons["in-12h-exact"] - baseline
                samples = resampled_means(delta, *resampling) * len(delta)
                low, high = np.quantile(samples, (0.025, 0.975))
                intervals.append(dict(split=split, policy=policy, reference=method, difference_GBP=delta.sum(),
                                      low95_GBP=low, high95_GBP=high))
                pooled_changes.setdefault((policy, method), []).append((delta.sum(), samples))
            full = window_lookahead(actual, signal, policy)
            upper, lp = upper_bound(actual, signal, policy)
            for method, value, cycles in (
                ("oracle_full_feasible", full["feasible_annual_lookahead"], full["equivalent_cycles"]),
                ("oracle_full_upper", upper, np.nan),
            ):
                gross.append(dict(split=split, policy=policy, method=method, days=days, gross_GBP=value,
                                  **break_even(value, days), cycles=cycles))
            assert upper + 0.02 >= max(full["feasible_annual_lookahead"], *(v.sum() for v in comparisons.values()))
            audit[split][f"full_oracle_{policy}"] = dict(**full, certified_outer_upper_GBP=upper, relaxation_lp_GBP=lp)
            print(split, policy, "replayed", flush=True)
    table = pd.DataFrame(gross)
    pooled = []
    for (policy, reference), results in pooled_changes.items():
        points, samples = zip(*results)
        low, high = np.quantile(np.sum(samples, axis=0), (0.025, 0.975))
        intervals.append(dict(split="pooled", policy=policy, reference=reference, difference_GBP=sum(points),
                              low95_GBP=low, high95_GBP=high))
    for (method, policy), group in table.groupby(["method", "policy"], sort=False):
        earnings = group.gross_GBP.sum()
        days = group.days.sum()
        pooled.append(dict(method=method, policy=policy, days=days, gross_GBP=earnings, **break_even(earnings, days)))
    table.to_csv(OUTPUT / "returns.csv", index=False)
    pd.DataFrame(pooled).to_csv(OUTPUT / "pooled_break_even.csv", index=False)
    pd.DataFrame(intervals).to_csv(OUTPUT / "paired_vs_hybrid.csv", index=False)
    pd.concat(traces, ignore_index=True).to_csv(OUTPUT / "dispatch.csv.gz", index=False, compression="gzip")
    np.savez_compressed(OUTPUT / "issued_hybrid.npz", **issued)
    audit["financing"] = dict(capex_GBP=cap, years=LIFE, discount_rate=RATE, capex_annuity=CRF,
                              annual_starting_inventory_GBP=COMMISSION_ANNUAL,
                              annual_fixed_cost_low_GBP=FIXED_LOW, annual_fixed_cost_high_GBP=FIXED_HIGH)
    audit["stored_prediction_sha256"] = manifest
    (OUTPUT / "audit.json").write_text(json.dumps(audit, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
