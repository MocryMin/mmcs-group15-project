"""Reproduce selected losses and test ambiguous-publication handling."""
import argparse
import json

import numpy as np
import pandas as pd
import torch

from build_features import BASE, CUTS, FEATURES, HERE, ORIGINS, SIZES, SLOTS, load_baseline
from build_forward_features import generation_columns
from experiment import Model, predict, recipe_features, scores


def strict(dataset):
    files=sorted((HERE/"sources").glob(f"{dataset}-*.gz"))
    data=pd.concat([pd.read_csv(f) for f in files],ignore_index=True)
    repeated=data[data.duplicated(["obs","pub"],keep=False)]
    ambiguity=repeated.groupby(["obs","pub"],sort=False).value.nunique()
    ambiguous=ambiguity.index[ambiguity>1]
    if len(ambiguous):
        data=data.loc[~pd.MultiIndex.from_frame(data[["obs","pub"]]).isin(ambiguous)]
    data=data.sort_values(["obs","pub"],kind="stable").drop_duplicates(["obs","pub"],keep="last")
    obs,pub=data.obs.to_numpy("int64"),data.pub.to_numpy("int64")
    key=obs//1800*1_000_000_000+pub-1609459200
    target=SLOTS//1800*1_000_000_000+ORIGINS[:,None]-1609459200
    ix=np.searchsorted(key,target,side="right")-1
    good=(ix>=0)&(obs[ix]==SLOTS)&(pub[ix]<=ORIGINS[:,None])
    return np.where(good,data.value.to_numpy("float32")[ix],np.nan),len(ambiguous)


def run(deadline):
    raw=np.concatenate([np.load(BASE/"inputs.npy",mmap_mode="r"),
                        np.load(BASE/"summer-2026/inputs.npy",mmap_mode="r")])
    names=json.loads((BASE/"features.json").read_text())["names"]
    with np.load(BASE/"targets.npz") as a,np.load(BASE/"summer-2026/targets.npz") as b:
        y=[torch.tensor(x,device="cuda") for x in [*np.split(a["y"],CUTS[:2]),b["y"]]]
    new={}
    changed={}
    for dataset in ("indgen","inddem","tsdf"):
        new[dataset],changed[dataset]=strict(dataset)
    engineering=generation_columns(new["indgen"],new["inddem"],new["tsdf"],load_baseline())
    meta=json.loads((FEATURES/"generation_schedule.json").read_text())["columns"]
    controls=np.load(FEATURES/"generation_schedule.npy",mmap_mode="r")
    encoded=[]
    for j,item in enumerate(v for v in meta if "mean" in v):
        raw_channel=np.asarray(engineering[item["name"]],dtype="float32")
        z=np.where(np.isfinite(raw_channel),(raw_channel-item["mean"])/item["std"],0).astype("float32")
        changed[item["name"]]=int((np.abs(controls[:,:,j]-z)>1e-6).sum())
        encoded.append(z)
    strict_features=np.stack(encoded,axis=-1)
    torch.set_float32_matmul_precision("high")
    output={"different_archive_keys_and_cells":changed,"runs":{}}
    for case in ("scale1/original_1x864","scale3/generation_1x864","scale3/national_3x448"):
        root=HERE/"runs"/case
        for base in sorted(root.glob("seed-*/result.json")):
            cfg=json.loads((base.parent/"config.json").read_text())
            rec=json.loads(base.read_text())
            recipe=cfg["case"]
            inputs,columns=recipe_features(raw,names,recipe,int(SIZES[0]))
            features=inputs.cuda().split(SIZES.tolist())
            model=Model(columns,recipe["width"],recipe.get("layers",1),
                        recipe.get("projection","linear"),recipe.get("head","mean")).cuda()
            checkpoint=torch.load(base.parent/"model.pt",weights_only=True,map_location="cuda")
            model.load_state_dict(checkpoint["weights"])
            assert checkpoint["step"]==rec["step"] and len(checkpoint["features"])==len(columns)
            reference={}
            for i,split in enumerate(("train","val","test25","test26")):
                reference[split]=scores(predict(model,features[i],deadline),y[i])
                if split!="train":
                    np.testing.assert_allclose(rec[split]["12h"],reference[split]["12h"],rtol=1e-4)
            output["runs"][f"{case}:{rec['seed']}"]={"exact_replay":reference}
            if case=="scale3/generation_1x864":
                changed_scores={}
                for i,(s,repaired) in enumerate(zip(("val","test25","test26"),np.split(strict_features,CUTS)[1:]),start=1):
                    changed_input=features[i].clone()
                    changed_input[:,:,-strict_features.shape[-1]:]=torch.tensor(repaired,device="cuda")
                    changed_scores[s]=scores(predict(model,changed_input,deadline),y[i])["12h"]
                output["runs"][f"{case}:{rec['seed']}"]["exclude_ambiguous_publication_keys"]=changed_scores
        print(case,"reproduced",flush=True)
    (HERE/"model_replay_audit.json").write_text(json.dumps(output,indent=2))


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--deadline",required=True,type=float)
    run(p.parse_args().deadline)
