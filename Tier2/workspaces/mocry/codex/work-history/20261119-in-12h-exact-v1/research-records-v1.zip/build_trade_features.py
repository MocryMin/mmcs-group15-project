"""Construct timing-bounded signals from NESO's public historical GTMA trades."""
import gzip
import json

import numpy as np
import pandas as pd

from build_features import HERE, ORIGINS, SLOTS, TRAIN, save_block


def main():
    files = sorted((HERE/"sources").glob("gtma-*.gz"))
    data = pd.DataFrame([r for f in files for r in json.load(gzip.open(f,"rt",encoding="utf-8"))["rows"]])
    for col in ("StartTime","EndTime","Last_Updated"):
        data[col] = pd.to_datetime(data[col],format="mixed",utc=True,errors="coerce")
    data = data.dropna(subset=["StartTime","EndTime","Last_Updated","Volume","Price","ID"])
    data = data.sort_values("Last_Updated").drop_duplicates("ID",keep="last")
    elapsed = (data.EndTime-data.StartTime).dt.total_seconds()/3600
    data = data.loc[(elapsed > 0)&(elapsed<=48)].copy()
    data["mwh"] = (data.Volume*elapsed).abs()
    data["up_mwh"] = data.mwh * (data.Volume > 0)
    data["down_mwh"] = data.mwh * (data.Volume < 0)
    data["cost"] = data.mwh*data.Price
    data["up_cost"] = data.up_mwh*data.Price
    data["down_cost"] = data.down_mwh*data.Price
    data["count"] = 1
    metrics = ["up_mwh","down_mwh","mwh","cost","up_cost","down_cost","count"]
    when = pd.to_datetime(ORIGINS,unit="s",utc=True)
    # Official historical snapshots are updated in the following month. Apply a further
    # full month of lag and require the archive's Last_Updated clock as well.
    fair_day = data.EndTime.dt.tz_localize(None).dt.to_period("M").dt.to_timestamp()+pd.DateOffset(months=2)
    fair = fair_day.dt.tz_localize("UTC")
    completed = pd.concat([data.Last_Updated,data.EndTime],axis=1).max(axis=1)
    eligible = pd.concat([fair,completed+pd.Timedelta(hours=1)],axis=1).max(axis=1)
    date_int = eligible.dt.as_unit("s").astype("int64")
    order = np.argsort(date_int,kind="stable")
    values = data[metrics].to_numpy("float64")[order]
    pub = date_int.to_numpy()[order]
    cumulative = np.r_[np.zeros((1,len(metrics))),np.cumsum(values,axis=0)]
    index = np.searchsorted(pub,ORIGINS,side="right")
    lo = np.searchsorted(pub,ORIGINS-92*86400,side="right")
    recent = cumulative[index]-cumulative[lo]
    save_block("gtma_lagged",{
        "GTMA_rolling_92d_up_mwh":np.log1p(recent[:,0,None]),
        "GTMA_rolling_92d_down_mwh":np.log1p(recent[:,1,None]),
        "GTMA_CB_market_vwap_lagged": (recent[:,3]/np.maximum(1,recent[:,2]))[:,None],
        "GTMA_up_minus_down_price_lagged": (recent[:,4]/np.maximum(1,recent[:,0])-recent[:,5]/np.maximum(1,recent[:,1]))[:,None],
        "GTMA_trade_count_92d":np.log1p(recent[:,6,None]),
    },TRAIN,SLOTS.shape,"NESO Grid Trade Master Agreement historical public archive. Completed trades with one calendar month after their normal next-month release plus a Last_Updated guard. Actual trades by the GB System Operator, not the coursework client.")

    # Sensitivity only: the source describes a daily public file, but exact historical
    # daily-file contents are unavailable. Keep at least two full days of delivery and data lag.
    delayed = (completed+pd.Timedelta(hours=49)).dt.as_unit("s").astype("int64").to_numpy()
    order = np.argsort(delayed,kind="stable")
    events = delayed[order]
    prefix = np.r_[np.zeros((1,len(metrics))),np.cumsum(data[metrics].to_numpy("float64")[order],axis=0)]
    positions = np.searchsorted(events,ORIGINS,side="right")
    rolling = {}
    for days in (7,28):
        previous = np.searchsorted(events,ORIGINS-days*86400,side="right")
        stats = prefix[positions]-prefix[previous]
        rolling[f"day_lag_GTMA_volume_{days}"] = np.log1p(stats[:,2,None])
        rolling[f"day_lag_GTMA_price_{days}"] = (stats[:,3]/np.maximum(1,stats[:,2]))[:,None]
        rolling[f"day_lag_GTMA_up_share_{days}"] = (stats[:,0]/np.maximum(1,stats[:,2]))[:,None]
    save_block("gtma_daily_sensitivity",rolling,TRAIN,SLOTS.shape,
               "NESO archived trades (same source). At least a 49h guard from both delivery end and Last_Updated, as a daily-file sensitivity. Historical daily publication vintages unavailable.")
    print("Trade records",len(data),"first",when[0],"last",when[-1],flush=True)


if __name__=="__main__":
    main()
