"""Plot matched feature ablations and lead-dependent forecast error."""
import argparse
from collections import defaultdict
import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from build_features import BASE, CUTS, HERE

SPLITS=("val","test25","jan_may26","test26")
TITLES={
    "val":"Jan–Aug 2025 validation",
    "test25":"Sep–Dec 2025 test",
    "jan_may26":"Jan–May 2026 test",
    "test26":"Jun–Aug 2026 test",
}


def case_scores(case):
    files=sorted((HERE/"runs"/case).glob("seed-*/result.json"))
    if not files:
        raise FileNotFoundError(case)
    return [json.loads(f.read_text()) for f in files]


def lead_errors(case):
    path=HERE/"runs"/case
    with np.load(BASE/"targets.npz") as a, np.load(BASE/"summer-2026/targets.npz") as b:
        y = {"test25":a["y"][CUTS[1]:],"test26":b["y"]}
    answer=defaultdict(list)
    for f in sorted(path.glob("seed-*/predictions.npz")):
        with np.load(f) as a:
            for key in ("test25","test26"):
                answer[key].append(np.mean((a[key]-y[key])**2,axis=0))
    return {key:np.mean(group,axis=0) for key,group in answer.items()}


def comparison(cases):
    import csv
    extra=[]
    for name in ("scores.csv","scores_preprocessing.csv"):
        with (HERE/"jan_may_2026"/name).open(newline="") as f:
            extra.extend(csv.DictReader(f))
    fig,axs=plt.subplots(1,4,figsize=(15.3,4.75),sharey=True,layout="constrained")
    colors=plt.get_cmap("tab10").colors
    labels=list(cases)
    values=[case_scores(cases[label]) for label in labels]
    observed=[r[s]["12h"] for data in values for r in data for s in ("val","test25","test26")]
    observed.extend(float(row["12h"]) for row in extra if row["model"] in cases.values())
    lo,hi=min(observed)-.005,max(observed)+.012
    for s,ax in zip(SPLITS,axs):
        for i,(label,data) in enumerate(zip(labels,values)):
            loss=([r[s]["12h"] for r in data] if s!="jan_may26" else
                  [float(row["12h"]) for row in extra if row["model"]==cases[label]])
            if not loss:
                continue
            color=colors[i%len(colors)]
            ax.plot([min(loss),max(loss)],[i,i],c=color,linewidth=2.6,alpha=.45)
            ax.scatter(np.mean(loss),i,c=[color],s=52,zorder=3)
            ax.text(max(loss)+.00065,i,f"{np.mean(loss):.4f}",va="center",fontsize=8)
        ax.set_yticks(range(len(labels)),labels)
        ax.set_title(TITLES[s],loc="left",fontsize=10.5)
        ax.set_xlabel("12 h forecast MSE")
        ax.grid(axis="x",alpha=.23)
        ax.spines[["right","top","left"]].set_visible(False)
        ax.set_xlim(lo,hi)
    axs[0].invert_yaxis()
    fig.suptitle("As-of half-hour forecasts · mean and range across matched seeds",fontsize=14)
    fig.savefig(HERE/"matched_forecast_mse.png",dpi=200)
    plt.close(fig)


def by_lead(base, selected):
    baseline=lead_errors(base)
    later=lead_errors(selected)
    fig,axes=plt.subplots(3,2,figsize=(10.3,7.2),sharex=True,layout="constrained")
    for j,key in enumerate(("test25","test26")):
        axes[0,j].set_title(TITLES[key],loc="left",fontsize=11)
        for t,label in enumerate(("Price","Generation","Demand")):
            ax=axes[t,j]
            lead=.5*np.arange(24)
            ax.plot(lead,baseline[key][:,t],label="Matched original",color="#526579",linewidth=1.85)
            ax.plot(lead,later[key][:,t],label="Selected features",color="#00715e",linewidth=2.1)
            ax.grid(alpha=.21)
            ax.spines[["top","right"]].set_visible(False)
            if j==0:
                ax.set_ylabel(label+" MSE")
            if t==2:
                ax.set_xlabel("Forecast lead (hours)")
    axes[0,0].legend(frameon=False,fontsize=9)
    fig.savefig(HERE/"forecast_mse_by_lead.png",dpi=200)
    plt.close(fig)


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("items",nargs="+",help="Display name=run path")
    p.add_argument("--lead",nargs=2,required=True)
    a=p.parse_args()
    comparison(dict(item.split("=",1) for item in a.items))
    by_lead(*a.lead)
