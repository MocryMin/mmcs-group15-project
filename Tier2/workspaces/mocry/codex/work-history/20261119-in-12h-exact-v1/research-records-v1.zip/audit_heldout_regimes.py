"""Cross-check feature gains by month, horizon and data reconstruction quality."""
import argparse
import csv
import json
from collections import defaultdict

import numpy as np
import pandas as pd

from build_features import BASE, CUTS, HERE, P, TARGETS


def references():
    with np.load(BASE/"targets.npz") as a, np.load(BASE/"summer-2026/targets.npz") as b:
        outputs = {
            "val": {k:a[k][CUTS[0]:CUTS[1]] for k in ("utc","y","baseline")},
            "test25": {k:a[k][CUTS[1]:] for k in ("utc","y","baseline")},
            "test26": {k:b[k] for k in ("utc","y","baseline")},
        }
        for choice in outputs.values():
            choice["sd"]=a["target_sd"]
    flags = pd.concat([pd.read_csv(P/"tier1-halfhour-20261113-v7/inputs/day_quality.csv"),
                       pd.read_csv(BASE/"summer-2026/label_quality.csv")])
    flags=flags.set_index("date")[["price_native","generation_native","demand_native"]].all(axis=1)
    for data in outputs.values():
        times=pd.to_datetime(data["utc"],unit="s",utc=True)
        first=flags.reindex(times.strftime("%Y-%m-%d"),fill_value=False).to_numpy()
        last=flags.reindex((times+pd.Timedelta(minutes=23*30)).strftime("%Y-%m-%d"),fill_value=False).to_numpy()
        data["native"]=first&last
        data["month"]=times.strftime("%Y-%m").to_numpy()
    return outputs


def collect(case):
    out=defaultdict(list)
    for path in sorted((HERE/"runs"/case).glob("seed-*/predictions.npz")):
        with np.load(path) as file:
            for k in ("val","test25","test26"):
                out[k].append(file[k])
    return out


def performance(case, data):
    predicted=collect(case)
    out=[]
    for s, parts in predicted.items():
        d=data[s]
        y=d["y"]
        forecast=np.stack(parts)
        actual=y*d["sd"]+d["baseline"]
        hit_price=actual[:,:,0]
        high = hit_price.max(1)
        by_case = {
            "all":np.ones(len(y),dtype=bool),
            "native_target_days":d["native"],
            "high_max_price_within_split":high >= np.quantile(high,.90),
            "excluding_high_max_price":high<np.quantile(high,.90),
        }
        by_case.update({month:d["month"]==month for month in np.unique(d["month"])})
        for name,sel in by_case.items():
            if not sel.any():continue
            err=(forecast[:,sel]-y[sel])**2
            e=(forecast.mean(0)[sel]-y[sel])**2
            for label,horizon in (("12h",24),("4h",8),("30min",1)):
                v=err[:,:,:horizon].mean((0,1,2))
                ensemble=e[:,:horizon].mean((0,1))
                row=dict(case=case,split=s,cohort=name,windows=int(sel.sum()),seeds=len(parts),
                         scope=label,mean_seed_MSE=float(v.mean()),ensemble_MSE=float(ensemble.mean()))
                row.update({target:float(x) for target,x in zip(TARGETS,v)})
                out.append(row)
    return out


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("cases",nargs="+")
    args=p.parse_args()
    data=references()
    everything=[row for case in args.cases for row in performance(case,data)]
    if everything:
        with (HERE/"heldout_regimes.csv").open("w",newline="") as f:
            w=csv.DictWriter(f,everything[0].keys());w.writeheader();w.writerows(everything)


if __name__=="__main__":
    main()
