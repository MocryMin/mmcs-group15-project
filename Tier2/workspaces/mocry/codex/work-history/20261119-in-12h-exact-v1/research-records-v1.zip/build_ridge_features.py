"""Create train-only, forward-chaining multi-output ridge forecasts as input features."""
import argparse
import os
import time

for v in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS"):
    os.environ[v]="8"

import numpy as np
import pandas as pd
from scipy.linalg import cho_factor,cho_solve

from build_features import BASE, FEATURES, ORIGINS, SLOTS, TRAIN, TARGETS, save_block


def make(case, blocks, deadline):
    base = np.concatenate([np.load(BASE/"inputs.npy",mmap_mode="r"),
                           np.load(BASE/"summer-2026/inputs.npy",mmap_mode="r")])
    added = [np.load(FEATURES/f"{name}.npy",mmap_mode="r") for name in blocks]
    x = np.concatenate([base,*added],axis=-1).reshape(len(base),-1).astype("float64")
    y = np.load(BASE/"targets.npz")["y"][:TRAIN].reshape(TRAIN,72).astype("float64")
    del base,added
    out = np.zeros((len(x),72),dtype="float32")
    present = np.zeros(len(x),dtype=bool)
    boundaries = [int(pd.Timestamp(v,tz="UTC").timestamp()) for v in
                  ("2022-07-01","2023-01-01","2023-07-01","2024-01-01","2024-07-01","2025-01-01")]
    earliest = TRAIN
    for lo,hi in zip(boundaries,[*boundaries[1:],int(ORIGINS[-1])+1800]):
        if time.time() >= deadline:
            return
        # In earlier blocks, a seven-day purge leaves room for the complete outcome
        # window and for actuals to arrive before the modelling cut.
        n = np.searchsorted(ORIGINS,lo-7*86400) if lo<boundaries[-1] else TRAIN
        if n>TRAIN:
            raise ValueError("An evaluation outcome would enter the ridge fit")
        earliest = min(earliest,np.searchsorted(ORIGINS,lo))
        fit_x = x[:n]
        mx,my = fit_x.mean(0),y[:n].mean(0)
        sd = fit_x.std(0)
        sd[sd<1e-8]=1
        z=(fit_x-mx)/sd
        gram=z.T@z
        gram.flat[::len(mx)+1] += .02*n
        w=cho_solve(cho_factor(gram,check_finite=False),z.T@(y[:n]-my),check_finite=False)
        indexes=(ORIGINS>=lo)&(ORIGINS<hi)
        out[indexes]=((x[indexes]-mx)/sd@w+my).astype("float32")
        present[indexes]=True
        print(case,pd.Timestamp(lo,unit="s"),n,int(indexes.sum()),flush=True)
    n = TRAIN
    np.savez_compressed(FEATURES/f"{case}_last_fit.npz",weights=w,mean_x=mx,scale_x=sd,mean_y=my)
    shaped=out.reshape(len(out),24,3)
    source = "Target-scaled residual predictions from direct 12h ridge. Forward-chaining six-month folds within train, with 7-day gap. Validation and tests use a model fit entirely on the original train split. First training half-year has no ridge feature."
    save_block(case,{
        **{f"{case}_residual_{k}":np.where(present[:,None],shaped[:,:,j],np.nan)
           for j,k in enumerate(TARGETS)},
        f"{case}_known":present[:,None],
    },TRAIN,SLOTS.shape,source)
    print(case,"earliest forward-chaining row",earliest,flush=True)


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--deadline",required=True,type=float)
    a = p.parse_args()
    make("ridge_prior",["forecast_shape","lolpdrm","embedded_solar","embedded_wind"],a.deadline)
    make("ridge_plain_prior",[],a.deadline)
