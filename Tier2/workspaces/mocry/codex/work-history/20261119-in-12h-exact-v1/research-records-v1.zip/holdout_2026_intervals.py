"""Paired error intervals for the third, predeclared test block."""
import argparse
from contextlib import ExitStack
import csv

import numpy as np
import pandas as pd

from build_features import TARGETS
from holdout_2026 import FOLDER


def main(supplement,replicas=False):
    pairs=[
        ("confirmation_system/baseline","confirmation_forward/generation_schedule"),
        ("scale1/original_1x864","scale3/generation_1x864"),
        ("scale1/original_1x864","scale3/national_1x864"),
        ("scale1/original_3x448","scale3/generation_3x448"),
        ("scale1/original_3x448","scale3/national_3x448"),
    ]
    if supplement:
        pairs=[
            ("scale3/generation_1x864","scale_processed/generation_zca_1x864"),
            ("scale3/generation_3x448","scale_processed/generation_zca_3x448"),
            ("scale1/original_3x448","scale_processed/generation_zca_3x448"),
            ("scale3/generation_1x864","scale_processed/generation_no_daily_1x864"),
        ]
    seeds=(17,29,43)
    if replicas:
        pairs=[
            ("extended_zca/generation_raw_3x448","extended_zca/generation_zca_3x448"),
            ("extended_seeds/original_1x864","extended_seeds/generation_1x864"),
            ("extended_seeds/original_3x448","extended_seeds/national_3x448"),
        ]
        seeds=(5,11,61,79,103,137)
    with np.load(FOLDER/"targets.npz") as a:
        y,times=a["y"],a["utc"]
    _, day=np.unique(times//86400,return_inverse=True)
    n=int(day.max()+1)
    rng=np.random.default_rng(209)
    group=(rng.integers(0,n-7+1,size=(6000,int(np.ceil(n/7))))[:,:,None]+np.arange(7))
    relevant=group.reshape(6000,-1)[:,:n]
    q=pd.read_csv(FOLDER/"quality.csv").set_index("date")
    quality=q[["generation_native","price_native","demand_native"]].all(axis=1)
    first=quality.reindex(pd.to_datetime(times,unit="s",utc=True).strftime("%Y-%m-%d")).to_numpy()
    last=quality.reindex(pd.to_datetime(times+23*1800,unit="s",utc=True).strftime("%Y-%m-%d")).to_numpy()
    native=first & last
    rows=[]
    with ExitStack() as context:
        primary="predictions_replicas.npz" if replicas else "predictions.npz"
        p=context.enter_context(np.load(FOLDER/primary))
        a=context.enter_context(np.load(FOLDER/"predictions_preprocessing.npz")) if supplement else p
        def forecast(model,seed):
            key=f"{model}:{seed}"
            return (p if key in p else a)[key]
        for base,new in pairs:
            for split,length in (("12h",24),("4h",8),("30min",1)):
                stack = [np.stack([forecast(model,seed)[:,:length]-y[:,:length] for seed in seeds])
                         for model in (base,new)]
                errors=[np.square(x,dtype="float64").mean((0,2)) for x in stack]
                for field,index in [("overall",None),*list(zip(TARGETS,range(3)))]:
                    b,c=[v.mean(1) if index is None else v[:,index] for v in errors]
                    denominator=np.bincount(day,weights=b)[relevant].sum(1)
                    numerator=np.bincount(day,weights=c)[relevant].sum(1)
                    low,high=np.quantile(100*(1-numerator/denominator),[.025,.975])
                    rows.append(dict(base=base,model=new,scope=split,target=field,
                        original_MSE=b.mean(),candidate_MSE=c.mean(),improvement_pct=100*(1-c.mean()/b.mean()),
                        low_pct=low,high_pct=high,native_origins=int(native.sum()),
                        native_improvement_pct=100*(1-c[native].mean()/b[native].mean())))
    filename="paired_intervals.csv"
    if supplement:
        filename="paired_preprocessing.csv"
    if replicas:
        filename="paired_replicas.csv"
    with (FOLDER/filename).open("w",newline="") as f:
        w=csv.DictWriter(f,rows[0].keys())
        w.writeheader();w.writerows(rows)


if __name__=="__main__":
    cli=argparse.ArgumentParser(description=__doc__)
    mode=cli.add_mutually_exclusive_group()
    mode.add_argument("--preprocessing",action="store_true")
    mode.add_argument("--replicas",action="store_true")
    flags=cli.parse_args()
    main(flags.preprocessing,flags.replicas)
