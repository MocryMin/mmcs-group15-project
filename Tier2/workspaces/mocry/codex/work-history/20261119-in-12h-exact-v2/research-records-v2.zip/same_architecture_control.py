"""Compare a new cohort of the v1 generation architecture at the same mixing weight."""
import argparse
import hashlib
import json

import numpy as np
import torch

from evaluate import PERIODS, jan_may, score_rows
from run import HERE, PROTOCOL, archived_transformer, datasets


COHORT = (5, 11, 61, 79, 103, 137)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--deadline", type=float, required=True)
    parser.add_argument("--cadence",type=int,choices=(10,24),default=10)
    parser.add_argument("--matched-width",action="store_true")
    args = parser.parse_args()
    plan = json.loads((HERE/"final_lock.json").read_text())
    alpha = plan["generation_blend"][0]["weight"]
    control_name = "native_control" if args.cadence==10 else "native_control_c24"
    model_id = "national_1x768"
    cohort = COHORT
    if args.matched_width:
        assert args.cadence==24
        control_name,model_id,cohort = "native_control_small","native_1x360_matched",tuple(PROTOCOL["seeds"])
    root = (HERE/control_name/model_id).resolve()
    original = HERE.parent/PROTOCOL["generation"]/"seed-17"/"config.json"
    original = json.loads(original.read_text())
    expected_case = json.loads((HERE/"native_control_small.json").read_text())[0] if args.matched_width else original["case"]
    available, hashes, parameters = [], [], None
    for seed in cohort:
        folder = root/f"seed-{seed}"
        if not (folder/"result.json").exists():
            continue
        config = json.loads((folder/"config.json").read_text())
        assert config["checkpoint_every_updates"]==args.cadence
        assert config["case"]==expected_case
        parameters = config["parameters"] if parameters is None else parameters
        assert config["parameters"]==parameters
        for key in ("features","epochs","learning_rate"):
            assert config[key]==original[key]
        available.append(seed)
        with (folder/"model.pt").open("rb") as f:
            hashes.append(hashlib.file_digest(f,"sha256").hexdigest())
    assert len(available)>=3
    torch.set_float32_matmul_precision("high")
    torch.set_num_threads(2)
    inputs, _, names = datasets()
    xj, _, _, _, _, names_jan = jan_may()
    assert original["features"]==names==names_jan
    cohorts = [("native-three",available[:3])]
    if len(available)==6:
        cohorts.append(("native-six",available))
    truth,times,paths = {},{},{}
    with np.load(HERE/"final_lock_paths.npz") as original_paths:
        scales = original_paths["target_sd"]
        for split,x in zip(PERIODS,(inputs[2],inputs[3],xj)):
            truth[split],times[split] = (original_paths[f"{split}:{v}"] for v in ("truth","utc"))
            base = original_paths[f"{split}:v1"]
            paths[split] = {name:original_paths[f"{split}:{name}"] for name in ("v1","generation_blend")}
            for name,seeds in cohorts:
                added = archived_transformer(root,x,args.deadline,seeds)[:,:,1]
                control = base.copy()
                control[:,:,1] = (1-alpha)*base[:,:,1] + alpha*added
                paths[split][name] = control
    result = {"seeds":available,"weight":alpha,"neural_parameters_per_seed":parameters,
              "checkpoint_every_updates":args.cadence,
              "source":PROTOCOL["generation"],"sha256":hashes}
    outfile = "same_architecture_control" if args.cadence==10 else "same_architecture_control_c24"
    if args.matched_width:
        outfile = "same_architecture_control_matched"
    (HERE/f"{outfile}.json").write_text(json.dumps(result,indent=2))
    score_rows(truth,paths,scales,times,f"{outfile}_scores.csv")
    print(result,flush=True)


if __name__=="__main__":
    main()
