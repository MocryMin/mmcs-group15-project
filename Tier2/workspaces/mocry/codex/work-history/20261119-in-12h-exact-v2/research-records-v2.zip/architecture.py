"""Transformer variants for the fixed 24-slot electricity forecasting task."""
import math

import torch
from torch import nn
from torch.nn import functional as F


SLOTS = 24
TARGETS = 3


def position_sinusoid(width, slots=SLOTS, offset=0):
    phase = (torch.arange(slots, dtype=torch.float32)+offset)[:, None] * torch.exp(
        torch.arange(0, width, 2) * (-math.log(10000.0) / width))
    return torch.stack((phase.sin(), phase.cos()), dim=-1).flatten(1)[:, :width]


def normalizer(width, name):
    return nn.RMSNorm(width, eps=1e-6) if name == "rms" else nn.LayerNorm(width)


class SlotAttention(nn.Module):
    def __init__(self, width, heads, kv_heads, encoding, radius, qk_norm, dropout, length=SLOTS,
                 local_heads=None, direction=None):
        super().__init__()
        assert width % heads == 0 and heads % kv_heads == 0
        self.heads, self.kv_heads = heads, kv_heads
        self.dim = width // heads
        self.kv_width = kv_heads * self.dim
        self.encoding = encoding
        self.radius = radius
        self.dropout = dropout
        self.local_heads = local_heads
        self.direction = direction
        self.qkv = nn.Linear(width, width + 2*self.kv_width)
        self.out = nn.Linear(width, width)
        distance = torch.arange(length)[:, None] - torch.arange(length)
        self.register_buffer("distance", distance, persistent=False)
        if encoding == "relative":
            self.relative = nn.Parameter(torch.zeros(heads, 2*length-1))
        elif encoding == "alibi":
            self.register_buffer("slopes", 2.0**(-torch.arange(1, heads+1)*8.0/heads), persistent=False)
        elif encoding == "rope":
            assert self.dim % 2 == 0
            freqs = torch.exp(torch.arange(0, self.dim, 2) * (-math.log(10000.0)/self.dim))
            phase = torch.arange(length)[:, None] * freqs
            self.register_buffer("rotary_cos", phase.cos(), persistent=False)
            self.register_buffer("rotary_sin", phase.sin(), persistent=False)
        elif encoding == "differential":
            assert self.dim % 2 == 0 and not qk_norm
            self.subtract = nn.Parameter(torch.full((heads,), -1.39))
        self.qk_norm = qk_norm
        if qk_norm:
            self.temperature = nn.Parameter(torch.full((heads,), math.log(self.dim**0.5)))

    def rotate(self, tensor):
        a, b = tensor[..., 0::2], tensor[..., 1::2]
        c, s = self.rotary_cos.to(tensor.dtype), self.rotary_sin.to(tensor.dtype)
        return torch.stack((a*c - b*s, a*s + b*c), dim=-1).flatten(-2)

    def mask(self, dtype):
        bias = None
        visible = None
        if self.encoding == "relative":
            bias = self.relative[:, self.distance + (self.distance.shape[-1]-1)]
        if self.encoding == "alibi":
            bias = -self.slopes[:, None, None] * self.distance.abs()
        if self.radius:
            visible = self.distance.abs() <= self.radius
            if self.local_heads is not None:
                is_global = torch.arange(self.heads, device=visible.device) >= self.local_heads
                visible = visible[None] | is_global[:, None, None]
        if self.direction is not None:
            if self.direction == "prefix":
                directional = self.distance >= 0
            elif self.direction == "suffix":
                directional = self.distance <= 0
            else:
                prefix = torch.arange(self.heads, device=self.distance.device) < self.heads//2
                directional = torch.where(prefix[:, None, None], self.distance >= 0, self.distance <= 0)
            visible = directional if visible is None else visible & directional
        if visible is not None:
            if bias is None:
                return visible
            bias = bias.masked_fill(~visible, float("-inf"))
        return bias.to(dtype) if bias is not None else None

    def forward(self, x):
        batch, length, width = x.shape
        q, k, v = self.qkv(x).split((width, self.kv_width, self.kv_width), dim=-1)
        q = q.reshape(batch, length, self.heads, self.dim).transpose(1, 2)
        k = k.reshape(batch, length, self.kv_heads, self.dim).transpose(1, 2)
        v = v.reshape(batch, length, self.kv_heads, self.dim).transpose(1, 2)
        if self.encoding == "rope":
            q, k = self.rotate(q), self.rotate(k)
        if self.kv_heads != self.heads:
            repeat = self.heads // self.kv_heads
            k, v = k.repeat_interleave(repeat, dim=1), v.repeat_interleave(repeat, dim=1)
        if self.qk_norm:
            q = F.normalize(q, dim=-1) * self.temperature.clamp(-2, 4).exp()[None, :, None, None]
            k = F.normalize(k, dim=-1)
        mask = self.mask(q.dtype)
        dropout = self.dropout if self.training else 0.0
        if self.encoding == "differential":
            qa, qb = q.chunk(2, dim=-1)
            ka, kb = k.chunk(2, dim=-1)
            first = F.scaled_dot_product_attention(qa, ka, v, attn_mask=mask, dropout_p=dropout)
            second = F.scaled_dot_product_attention(qb, kb, v, attn_mask=mask, dropout_p=dropout)
            value = first - self.subtract.sigmoid()[None, :, None, None] * second
        else:
            value = F.scaled_dot_product_attention(q, k, v, attn_mask=mask, dropout_p=dropout,
                                                  scale=1.0 if self.qk_norm else None)
        return self.out(value.transpose(1, 2).reshape(batch, length, width))


class FeedForward(nn.Module):
    def __init__(self, width, kind, ratio, dropout, kernel=0):
        super().__init__()
        self.kind = kind
        self.gated = kind in ("swiglu", "geglu")
        inner = max(16, 16*round(width*ratio/16))
        self.up = nn.Linear(width, inner * (2 if self.gated else 1))
        self.down = nn.Linear(inner, width)
        self.drop = nn.Dropout(dropout)
        self.conv = nn.Conv1d(inner, inner, kernel, padding=kernel//2, groups=inner) if kernel else None

    def forward(self, x):
        x = self.up(x)
        if self.gated:
            value, gate = x.chunk(2, dim=-1)
            x = value * (F.silu(gate) if self.kind == "swiglu" else F.gelu(gate))
        elif self.kind == "silu":
            x = F.silu(x)
        else:
            x = F.gelu(x)
        if self.conv is not None:
            x = x + self.conv(x.transpose(1, 2)).transpose(1, 2)
        return self.down(self.drop(x))


class StaticSlotMixing(nn.Module):
    def __init__(self, width, heads, length, mode, dropout):
        super().__init__()
        self.heads = heads
        self.mode = mode
        self.lift = nn.Linear(width, width)
        self.out = nn.Linear(width, width)
        self.drop = nn.Dropout(dropout)
        if mode == "spectral":
            slot = torch.arange(length, dtype=torch.float32)[:, None]
            harmonic = torch.arange(length, dtype=torch.float32)
            basis = torch.cos((slot+0.5) * harmonic * math.pi / length) * math.sqrt(2/length)
            basis[:, 0] /= math.sqrt(2)
            self.register_buffer("basis", basis, persistent=False)
            self.kernel = nn.Parameter(torch.zeros(heads, length))
        else:
            distance = torch.arange(length)[:, None] - torch.arange(length)
            scales = torch.linspace(1, length/2, heads)
            self.kernel = nn.Parameter(-distance.abs() / scales[:, None, None])

    def forward(self, x):
        batch, length, width = x.shape
        values = self.lift(x).reshape(batch, length, self.heads, -1)
        if self.mode == "spectral":
            basis = self.basis.to(values.dtype)
            coeff = torch.einsum("lf,blhd->bfhd", basis, values)
            amplitudes = coeff * self.kernel.tanh().T[..., None].to(values.dtype)
            mixed = torch.einsum("lf,bfhd->blhd", basis, amplitudes)
        else:
            mixed = torch.einsum("hij,bjhd->bihd", self.kernel.softmax(-1).to(values.dtype), values)
        return self.out(self.drop(mixed.reshape(batch, length, width)))


class RoutedFeedForward(nn.Module):
    def __init__(self, width, config):
        super().__init__()
        count = config["experts"]
        kind = config.get("ff", "gelu")
        total_ratio = config.get("ff_ratio", 4/3 if kind.endswith("glu") else 2)
        self.experts = nn.ModuleList(FeedForward(width, kind, total_ratio/count,
                                                config.get("dropout", 0.1))
                                     for _ in range(count))
        self.route = nn.Linear(width, count)

    def forward(self, x):
        route = self.route(x).softmax(dim=-1)
        return (torch.stack([m(x) for m in self.experts], dim=-1) * route.unsqueeze(-2)).sum(-1)


class Block(nn.Module):
    def __init__(self, width, cfg, *, radius=0, length=SLOTS):
        super().__init__()
        self.style = cfg.get("residual", "pre")
        norm = cfg.get("norm", "layer")
        self.attn_norm = normalizer(width, norm)
        self.ff_norm = normalizer(width, norm)
        self.drop = nn.Dropout(cfg.get("dropout", 0.1))
        heads = cfg.get("heads", 4)
        mixing = cfg.get("mixing", "attention")
        dropout = cfg.get("attention_dropout", cfg.get("dropout", 0.1))
        if mixing == "attention":
            self.attn = SlotAttention(width, heads, cfg.get("kv_heads", heads),
                cfg.get("attn", "absolute"), radius, cfg.get("qk_norm", False),
                dropout, length, cfg.get("local_heads"), cfg.get("direction"))
        elif mixing == "none":
            self.attn = None
        else:
            self.attn = StaticSlotMixing(width, heads, length, mixing, dropout)
        ff = cfg.get("ff", "gelu")
        self.ff = FeedForward(width, ff, cfg.get("ff_ratio", 4/3 if ff.endswith("glu") else 2),
                              cfg.get("dropout", 0.1), cfg.get("ff_kernel", 0))
        if cfg.get("experts"):
            self.ff = RoutedFeedForward(width, cfg)
        scale = cfg.get("res_scale")
        if scale is None:
            self.register_buffer("attention_gain", torch.tensor(1.0), persistent=False)
            self.register_buffer("ff_gain", torch.tensor(1.0), persistent=False)
        else:
            self.attention_gain = nn.Parameter(torch.full((width,), scale))
            self.ff_gain = nn.Parameter(torch.full((width,), scale))

    def forward(self, x):
        if self.attn is None:
            return x + self.drop(self.ff(self.ff_norm(x)))*self.ff_gain
        if self.style == "post":
            x = self.attn_norm(x + self.drop(self.attn(x))*self.attention_gain)
            return self.ff_norm(x + self.drop(self.ff(x))*self.ff_gain)
        if self.style == "parallel":
            return (x + self.drop(self.attn(self.attn_norm(x)))*self.attention_gain
                    + self.drop(self.ff(self.ff_norm(x)))*self.ff_gain)
        x = x + self.drop(self.attn(self.attn_norm(x)))*self.attention_gain
        return x + self.drop(self.ff(self.ff_norm(x)))*self.ff_gain


class TargetReadout(nn.Module):
    def __init__(self, width, hidden, exchange, dropout):
        super().__init__()
        self.projections = nn.ModuleList(nn.Linear(width, hidden) for _ in range(TARGETS))
        self.heads = nn.ModuleList(nn.Linear(hidden, 1) for _ in range(TARGETS))
        self.exchange = nn.MultiheadAttention(hidden, 4, batch_first=True, dropout=dropout) if exchange else None
        self.norm = nn.LayerNorm(hidden) if exchange else None
        if self.exchange is not None:
            self.gain = nn.Parameter(torch.tensor(0.2))
        for output in self.heads:
            nn.init.normal_(output.weight, std=0.002)
            nn.init.zeros_(output.bias)

    def forward(self, x):
        hidden = torch.stack([F.gelu(project(x)) for project in self.projections], dim=2)
        if self.exchange is not None:
            tokens = self.norm(hidden.flatten(0, 1))
            response, _ = self.exchange(tokens, tokens, tokens, need_weights=False)
            hidden = hidden + self.gain * response.reshape_as(hidden)
        return torch.cat([head(hidden[:, :, i]) for i, head in enumerate(self.heads)], dim=-1)


class ForecastTransformer(nn.Module):
    def __init__(self, features, config):
        super().__init__()
        width = config.get("width", 320)
        self.feature_count = features
        self.history_mode = config.get("history_mode")
        if self.history_mode:
            recent, previous = config["history_indices"]
            self.recent_cols, self.previous_cols = recent, previous
            use = set(recent + previous)
            self.forecast_cols = list(range(features)) if self.history_mode=="parallel" else [i for i in range(features) if i not in use]
            self.hist_recent = nn.Linear(len(recent),width)
            self.hist_previous = nn.Linear(len(previous),width)
            self.register_buffer("history_pos",position_sinusoid(width,2*SLOTS,-2*SLOTS),persistent=False)
            self.history_norm = normalizer(width,config.get("norm","layer"))
            self.history_query = normalizer(width,config.get("norm","layer"))
            self.history_cross = nn.MultiheadAttention(width,config.get("heads",4),batch_first=True,
                dropout=config.get("dropout",0.1))
            self.history_scale = nn.Parameter(torch.tensor(0.3))
            self.history_encoder = Block(width,config,length=2*SLOTS) if config.get("history_encoder") else None
        self.input = nn.Linear(len(self.forecast_cols) if self.history_mode else features, width)
        self.ridge_embed = nn.Linear(TARGETS, width) if config.get("ridge_condition") else None
        self.ridge_gain = nn.Parameter(torch.tensor(0.1)) if self.ridge_embed is not None else None
        residual_gate = config.get("residual_gate")
        self.decode_gate = (nn.Parameter(torch.full((SLOTS, TARGETS), float(residual_gate)))
                            if residual_gate is not None else None)
        protected = config.get("protect_demand_slots", 0)
        if protected:
            output_mask = torch.ones(SLOTS, TARGETS)
            output_mask[:protected, 2] = 0
            self.register_buffer("output_mask", output_mask, persistent=False)
        else:
            self.output_mask = None
        self.use_pos = config.get("pos", "sinusoid" if config.get("attn", "absolute") == "absolute" else "none")
        if self.use_pos == "learned":
            self.pos = nn.Parameter(torch.randn(SLOTS, width)*0.02)
        elif self.use_pos == "sinusoid":
            self.register_buffer("pos", position_sinusoid(width), persistent=False)
        self.local_conv = None
        if config.get("temporal_kernel"):
            kernel = config["temporal_kernel"]
            self.local_conv = nn.Conv1d(width, width, kernel, padding=kernel//2, groups=width)
        self.lead_scale = nn.Parameter(torch.zeros(SLOTS, width)) if config.get("lead_film") else None
        self.channel_depth = config.get("channel_depth", 0)
        if self.channel_depth:
            self.channel_embed = nn.Linear(SLOTS, width)
            self.channel_identity = nn.Parameter(torch.randn(features, width)*0.02)
            self.channel_layers = nn.Sequential(*(Block(width, config, length=features)
                                                  for _ in range(self.channel_depth)))
            self.cross_norm = normalizer(width, config.get("norm", "layer"))
            self.channel_cross = nn.MultiheadAttention(width, config.get("heads", 4),
                dropout=config.get("dropout", 0.1), batch_first=True)
            self.channel_blend = nn.Parameter(torch.tensor(0.3))
        self.price_regime = config.get("price_regime")
        if self.price_regime:
            self.known_price_channel = config["known_price_channel"]
            price_width = config.get("price_expert_width", 0)
            count = 4 if config.get("price_horizon_experts") else 2
            self.price_experts = (nn.Sequential(nn.Linear(width, price_width),nn.GELU(),nn.Linear(price_width,count))
                                  if price_width else nn.Linear(width, count))
            groups = 2*(torch.arange(SLOTS)>=8) if count==4 else torch.zeros(SLOTS,dtype=torch.long)
            self.register_buffer("price_horizon_groups", groups, persistent=False)
        task_width = config.get("task_width", 0)
        self.task_heads = nn.ModuleList(nn.Sequential(nn.Linear(width,task_width),nn.GELU(),nn.Linear(task_width,1))
                                        for _ in range(TARGETS)) if task_width else None
        exchange_width = config.get("target_readout_width", 0)
        self.target_readout = (TargetReadout(width, exchange_width, config.get("target_exchange", False),
                                             config.get("dropout", 0.1)) if exchange_width else None)
        self.patch_size = config.get("patch", 0)
        if self.patch_size:
            assert SLOTS % self.patch_size == 0
            self.patch_in = nn.Linear(self.patch_size*width, width)
            self.patch_block = Block(width, config, length=SLOTS//self.patch_size)
            self.patch_out = nn.Linear(width, width)
        self.tied = config.get("tied", False)
        self.depth = config.get("depth", 1)
        depth_mix = config.get("depth_mix")
        if depth_mix is None:
            self.layer_logits = None
        else:
            self.layer_logits = nn.Parameter(torch.zeros(self.depth))
            with torch.no_grad():
                self.layer_logits[-1] = float(depth_mix)
        radius = config.get("radius", 0)
        self.layers = nn.ModuleList(
            Block(width, config, radius=radius if (i % 2 == 0 or not config.get("alternate_global")) else 0)
            for i in range(1 if self.tied else self.depth))
        self.norm = normalizer(width, config.get("norm", "layer"))
        self.drop = nn.Dropout(config.get("dropout", 0.1))
        contextual_gate = config.get("contextual_gate")
        self.correction_gate = nn.Linear(width, TARGETS) if contextual_gate is not None else None
        if self.correction_gate is not None:
            nn.init.zeros_(self.correction_gate.weight)
            nn.init.constant_(self.correction_gate.bias, float(contextual_gate))
        self.readout = config.get("readout", "local_global")
        self.balance_decode = config.get("balance_decode", 0.0)
        if self.readout != "flat":
            self.local = nn.Linear(width, TARGETS)
        if self.readout == "local_global":
            self.global_head = nn.Linear(width, SLOTS*TARGETS)
        elif self.readout in ("lead_specific", "lead_global"):
            self.lead_weight = nn.Parameter(torch.empty(SLOTS, width, TARGETS))
            nn.init.uniform_(self.lead_weight, -width**-0.5, width**-0.5)
            self.lead_bias = nn.Parameter(torch.zeros(SLOTS, TARGETS))
            if self.readout == "lead_global":
                self.global_head = nn.Linear(width, SLOTS*TARGETS)
        elif self.readout in ("dense_time", "target_queries"):
            self.compress = nn.Linear(width, 24)
            if self.readout == "dense_time":
                self.trajectory = nn.Linear(SLOTS*24, SLOTS*TARGETS)
            else:
                self.target_query = nn.Parameter(torch.randn(TARGETS, 24)*0.1)
                self.target_value = nn.Linear(width, 3*SLOTS)
        elif self.readout == "flat":
            self.compress = nn.Linear(width, 48)
            self.trajectory = nn.Linear(SLOTS*48, SLOTS*TARGETS)
        elif self.readout == "horizon_attention":
            self.context_query = nn.Linear(width, 3*24)
            self.context_key = nn.Linear(width, 24)
            self.context_value = nn.Linear(width, 3*24)
            self.context_weights = nn.Parameter(torch.empty(SLOTS, 3, 24))
            nn.init.uniform_(self.context_weights, -24**-0.5, 24**-0.5)
            self.relative_head = nn.Parameter(torch.zeros(3, 2*SLOTS-1))
            delta = torch.arange(SLOTS)[:, None] - torch.arange(SLOTS)
            self.register_buffer("lead_distance", delta + SLOTS-1, persistent=False)
        elif self.readout in ("knots", "increments"):
            self.knots = config.get("knots", 8)
            out = self.knots if self.readout=="knots" else 1
            self.coarse_head = nn.Linear(width, out*TARGETS)
        elif self.readout == "fourier":
            frequencies = config.get("harmonics", 4)
            if config.get("basis_kind") == "dct":
                phase = (torch.arange(SLOTS)[:,None]+0.5)*torch.arange(frequencies+1)*math.pi/SLOTS
                basis = phase.cos()
            else:
                theta = torch.arange(SLOTS)[:,None]*torch.arange(1,frequencies+1)*2*math.pi/SLOTS
                basis = torch.cat((torch.ones(SLOTS,1), theta.cos(), theta.sin()),dim=-1)
            self.register_buffer("output_basis", basis, persistent=False)
            self.fourier_head = nn.Linear(width, basis.shape[1]*TARGETS)
        self.direct = nn.Linear(features, TARGETS) if config.get("direct") else None
        skip = config.get("global_skip", 0)
        self.global_skip = (nn.Sequential(nn.Linear(SLOTS*features, skip), nn.LayerNorm(skip), nn.GELU(),
            nn.Dropout(config.get("dropout", 0.1)), nn.Linear(skip, SLOTS*TARGETS)) if skip else None)
        self.anchor = config.get("ridge_anchor", 0.0)
        if self.anchor:
            head = self.global_head if self.readout == "local_global" else getattr(self, "local", self.trajectory if self.readout=="flat" else None)
            nn.init.normal_(head.weight, std=0.002)
            nn.init.zeros_(head.bias)
        if config.get("zero_readout"):
            for method in ("local", "global_head", "trajectory", "target_value", "direct", "price_experts"):
                head = getattr(self, method, None)
                if head is not None:
                    head = head[-1] if isinstance(head,nn.Sequential) else head
                    nn.init.zeros_(head.weight)
                    nn.init.zeros_(head.bias)
            if self.global_skip is not None:
                nn.init.zeros_(self.global_skip[-1].weight)
                nn.init.zeros_(self.global_skip[-1].bias)

    def forward(self, x):
        if self.ridge_embed is not None:
            x, ridge = x.split((self.feature_count, TARGETS), dim=-1)
        z = self.input(x[:,:,self.forecast_cols] if self.history_mode else x)
        if self.ridge_embed is not None:
            z = z + self.ridge_gain * self.ridge_embed(ridge)
        if self.use_pos != "none":
            z = z + self.pos
        if self.lead_scale is not None:
            z = z * (1 + self.lead_scale)
        if self.local_conv is not None:
            z = z + self.local_conv(z.transpose(1, 2)).transpose(1, 2)
        if self.history_mode:
            memory = torch.cat((self.hist_previous(x[:,:,self.previous_cols]),
                                self.hist_recent(x[:,:,self.recent_cols])),dim=1) + self.history_pos
            if self.history_encoder is not None:
                memory = self.history_encoder(memory)
            memory = self.history_norm(memory)
            context,_ = self.history_cross(self.history_query(z),memory,memory,need_weights=False)
            z = z + self.history_scale*context
        if self.patch_size:
            patches = z.reshape(len(z), SLOTS//self.patch_size, -1)
            patches = self.patch_out(self.patch_block(self.patch_in(patches)))
            z = z + patches.repeat_interleave(self.patch_size, dim=1)
        if self.channel_depth:
            tokens = self.channel_embed(x.transpose(1, 2)) + self.channel_identity
            tokens = self.channel_layers(tokens)
            response, _ = self.channel_cross(self.cross_norm(z), tokens, tokens, need_weights=False)
            z = z + self.channel_blend * response
        states = []
        for i in range(self.depth):
            z = self.layers[0 if self.tied else i](z)
            if self.layer_logits is not None:
                states.append(z)
        if self.layer_logits is not None:
            weights = self.layer_logits.softmax(0).to(z.dtype)
            z = torch.einsum("l,lbhi->bhi", weights, torch.stack(states))
        z = self.drop(self.norm(z))
        if self.readout == "flat":
            y = self.trajectory(self.compress(z).flatten(1)).reshape(-1, SLOTS, TARGETS)
        else:
            y = self.local(z)
        if self.readout in ("local_global", "lead_global"):
            y = y + self.global_head(z.mean(1)).reshape(-1, SLOTS, TARGETS)
        if self.readout in ("lead_specific", "lead_global"):
            y = y + torch.einsum("bhd,hdk->bhk", z, self.lead_weight) + self.lead_bias
        if self.readout == "dense_time":
            y = y + self.trajectory(self.compress(z).flatten(1)).reshape(-1, SLOTS, TARGETS)
        if self.readout == "target_queries":
            weights = (self.compress(z) @ self.target_query.T).softmax(dim=1)
            values = self.target_value(z).reshape(-1, SLOTS, SLOTS, TARGETS)
            y = y + (values * weights[:, :, None]).sum(1)
        if self.readout == "knots":
            coarse = self.coarse_head(z.mean(1)).reshape(-1, TARGETS, self.knots)
            y = y + F.interpolate(coarse, size=SLOTS, mode="linear", align_corners=False).transpose(1, 2)
        if self.readout == "increments":
            y = y.cumsum(1)/math.sqrt(SLOTS) + self.coarse_head(z.mean(1))[:,None]
        if self.readout == "fourier":
            amplitudes = self.fourier_head(z.mean(1)).reshape(-1, self.output_basis.shape[1], TARGETS)
            y = y + torch.einsum("hk,bkt->bht", self.output_basis, amplitudes)
        if self.readout == "horizon_attention":
            q = self.context_query(z).reshape(-1, SLOTS, 3, 24).transpose(1, 2)
            k = self.context_key(z)[:, None].expand(-1, 3, -1, -1)
            v = self.context_value(z).reshape(-1, SLOTS, 3, 24).transpose(1, 2)
            context = F.scaled_dot_product_attention(q, k, v, attn_mask=self.relative_head[:, self.lead_distance])
            y = y + torch.einsum("bthd,htd->bht", context, self.context_weights)
        if self.direct is not None:
            y = y + self.direct(x)
        if self.task_heads is not None:
            y = y + torch.cat([head(z) for head in self.task_heads],dim=-1)
        if self.target_readout is not None:
            y = y + self.target_readout(z)
        if self.global_skip is not None:
            y = y + self.global_skip(x.flatten(1)).reshape(-1, SLOTS, TARGETS)
        if self.price_regime:
            known = x[:, :, self.known_price_channel] > 0
            correction = self.price_experts(z)
            idx = self.price_horizon_groups + (~known).long()
            price = y[:, :, 0] + correction.gather(-1,idx[...,None]).squeeze(-1)
            y = torch.cat((price[:, :, None], y[:, :, 1:]), dim=-1)
        if self.balance_decode:
            y = torch.stack((y[:, :, 0], y[:, :, 1] + self.balance_decode*y[:, :, 2], y[:, :, 2]), dim=-1)
        if self.decode_gate is not None:
            y = y * self.decode_gate.sigmoid()
        if self.correction_gate is not None:
            y = y * self.correction_gate(z).sigmoid()
        if self.output_mask is not None:
            y = y * self.output_mask
        return y


class TargetStreams(nn.Module):
    """Separate encoders for target groups, all using the same available data."""
    def __init__(self, features, config):
        super().__init__()
        specifications = config["streams"]
        self.groups = [spec["targets"] for spec in specifications]
        assert sorted(i for group in self.groups for i in group) == list(range(TARGETS))
        self.encoders = nn.ModuleList(ForecastTransformer(features, {**config, **spec})
                                      for spec in specifications)

    def forward(self, x):
        pieces = {}
        for encoder, group in zip(self.encoders, self.groups):
            path = encoder(x)
            pieces.update({i: path[:, :, i] for i in group})
        return torch.stack([pieces[i] for i in range(TARGETS)], dim=-1)


def make_network(features, config, names):
    history = [[i for i,name in enumerate(names)
                if f"_history_{k}" in name or name.startswith(f"past_auction_{k}")] for k in range(2)]
    configured = dict(config, known_price_channel=names.index("PRICES_forward_known"),history_indices=history)
    kind = TargetStreams if config.get("streams") else ForecastTransformer
    return kind(features, configured)
