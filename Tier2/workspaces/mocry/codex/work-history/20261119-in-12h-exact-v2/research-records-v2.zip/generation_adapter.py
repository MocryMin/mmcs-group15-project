"""Export and audit the frozen generation-only extension to v1."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

import numpy as np
import torch

from evaluate import PERIODS, jan_may, score_rows
from run import HERE, PROTOCOL, datasets, make_network, predict, ridge_anchor

try:
    from safetensors.torch import load_file, save_file
except ModuleNotFoundError:
    sys.path.insert(0, str(HERE.parents[1]/"publication-20261119"/"dependencies"))
    from safetensors.torch import load_file, save_file


def projection(config):
    streams = config["streams"]
    branch = next(i for i,spec in enumerate(streams) if spec["targets"]==[1])
    return branch, {**{key:value for key,value in config.items() if key!="streams"}, **streams[branch]}


def export_state(folder, sha256, prefix, output):
    file = folder/"model.pt"
    with file.open("rb") as f:
        assert hashlib.file_digest(f,"sha256").hexdigest()==sha256
    full = torch.load(file, weights_only=True, map_location="cpu")["weights"]
    state = {key.removeprefix(prefix):value.contiguous()
             for key,value in full.items() if key.startswith(prefix)}
    save_file(state, output)
    return len(state)


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--manifest",type=Path,required=True)
    cli.add_argument("--deadline",type=float,required=True)
    args = cli.parse_args()
    plan = json.loads(args.manifest.read_text())
    rule, = plan["generation_blend"]
    assert rule["target"]==1 and rule["start"]==0 and rule["end"]==24
    checkpoint = plan["models"][rule["model"]]
    branch, case = projection(checkpoint["case"])
    torch.set_float32_matmul_precision("high")
    x, _, names = datasets()
    train_ridges = ridge_anchor(x)
    inputs = dict(zip(PERIODS[:2],x[2:]))
    anchors = dict(zip(PERIODS[:2],(a[:,:,1].cpu().numpy() for a in train_ridges[2:])))
    xj, _, _, _, _, jan_names = jan_may()
    assert names==jan_names
    inputs[PERIODS[2]] = xj
    ridge_file = HERE.parent/PROTOCOL["demand"]/"weights.npz"
    with np.load(ridge_file) as f:
        w = f["weight"][:,1::3].astype("float32")
        b = f["bias"][1::3].astype("float32")
    torch.set_float32_matmul_precision("highest")
    anchors[PERIODS[2]] = (xj.flatten(1)@torch.from_numpy(w).cuda()+torch.from_numpy(b).cuda()).cpu().numpy()
    torch.set_float32_matmul_precision("high")
    dest = HERE/"generation_adapter"
    dest.mkdir(exist_ok=True)
    np.savez_compressed(dest/"ridge_generation.npz",weight=w,bias=b)
    by_seed = {}
    metadata = {"source_manifest":args.manifest.name, "architecture":case, "features":names,
                "delivery_slots":24, "slot_minutes":30,"target":"generation","adapter_blend_weight":rule["weight"],
                "last_layer_output_column":1, "weight_files":[], "audit_max_delta": {}}
    network = make_network(len(names),case,names).cuda()
    metadata["neural_parameters_per_seed"] = sum(p.numel() for p in network.parameters())
    for folder, sha256 in zip(checkpoint["folders"],checkpoint["sha256"]):
        location = HERE/folder
        name = location.name
        output = dest/(name+".safetensors")
        assert export_state(location,sha256,f"encoders.{branch}.",output)>0
        network.load_state_dict(load_file(output))
        by_seed[name] = {split: predict(network,values,args.deadline).cpu().numpy()[:,:,1]
                         + case["ridge_anchor"]*anchors[split] for split,values in inputs.items()}
        with output.open("rb") as f:
            metadata["weight_files"].append({"file":output.name,"sha256":hashlib.file_digest(f,"sha256").hexdigest()})
    truth, times, paths = {}, {}, {}
    alpha = rule["weight"]
    with np.load(args.manifest.with_name(args.manifest.stem+"_paths.npz")) as archived:
        scales = archived["target_sd"]
        for split in PERIODS:
            truth[split],times[split]=(archived[f"{split}:{v}"] for v in ("truth","utc"))
            base = archived[f"{split}:v1"]
            paths[split] = {"v1":base}
            for name, outputs in by_seed.items():
                outcome = base.astype("float64")
                outcome[:,:,1] = (1-alpha)*base[:,:,1] + alpha*outputs[split]
                paths[split][name] = outcome
            ensemble = base.astype("float64")
            ensemble[:,:,1] = (1-alpha)*base[:,:,1]+alpha*np.mean(
                [output[split] for output in by_seed.values()],axis=0,dtype="float64")
            expected = archived[f"{split}:generation_blend"]
            np.testing.assert_allclose(ensemble,expected,rtol=1e-4,atol=1e-5)
            paths[split]["all-three"] = ensemble
            metadata["audit_max_delta"][split] = float(np.abs(ensemble-expected).max())
    (dest/"config.json").write_text(json.dumps(metadata,indent=2))
    score_rows(truth, paths, scales, times,"generation_adapter_single_seed_scores.csv")
    print(metadata["neural_parameters_per_seed"],metadata["audit_max_delta"],flush=True)


if __name__ == "__main__":
    main()
