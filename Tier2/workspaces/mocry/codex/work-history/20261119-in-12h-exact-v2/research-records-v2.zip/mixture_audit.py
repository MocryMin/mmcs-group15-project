"""Stress-test the locked generation mixture without reselecting on test data."""
import json

import numpy as np

from evaluate import PERIODS, csv_write, score_rows, validation_targets
from run import BASE, CUTS, HERE, reference


def sample_intervals(truth, estimate, baseline, utc, days):
    unique, index = np.unique(utc//86400,return_inverse=True)
    n = len(unique)
    rng = np.random.default_rng(209)
    starts = rng.integers(0,n-days+1,(6000,(n+days-1)//days))
    selected = (starts[:,:,None] + np.arange(days)).reshape(len(starts),-1)[:,:n]
    base_error = np.square(baseline-truth).reshape(len(truth),-1).mean(1)
    model_error = np.square(estimate-truth).reshape(len(truth),-1).mean(1)
    loss = np.bincount(index,weights=base_error)
    difference = np.bincount(index,weights=base_error-model_error)
    relative = 100*difference[selected].sum(1)/loss[selected].sum(1)
    return np.quantile(relative,(0.025,0.975))


def validation(plan):
    choice, = plan["generation_blend"]
    checkpoint = plan["models"][choice["model"]]
    members = []
    for folder in checkpoint["folders"]:
        with np.load(HERE/folder/"predictions.npz") as f:
            members.append(f["val"][:,:,1])
    new = np.mean(members,axis=0,dtype="float64")
    with np.load(BASE/"targets.npz") as data:
        actual = data["y"][CUTS[0]:CUTS[1],:,1]
        month = data["utc"][CUTS[0]:CUTS[1]].astype("datetime64[s]").astype("datetime64[M]").astype(int)
    blocks = [(month >= month.min()+2*i) & (month < month.min()+2*i+2) for i in range(4)]
    return actual, reference("val")[:,:,1].astype("float64"), new, blocks


def pooled_year():
    ordered = ("test25","jan_may26","test26")
    with np.load(HERE/"final_lock_paths.npz") as main, np.load(HERE/"replication_lock_paths.npz") as replica:
        truth = np.concatenate([main[f"{split}:truth"] for split in ordered]).astype("float64")
        time = np.concatenate([main[f"{split}:utc"] for split in ordered])
        assert np.all(np.diff(time)>0)
        forecasts = {name:np.concatenate([main[f"{split}:{name}"] for split in ordered]).astype("float64")
                     for name in ("v1","standalone","stable_blend","generation_blend")}
        forecasts["generation_blend_new_seeds"] = np.concatenate(
            [replica[f"{split}:generation_blend"] for split in ordered]).astype("float64")
        scales = main["target_sd"]
    for title, filename in (("component_extension","component_lock_paths.npz"),
                            ("component_extension_new_seeds","component_replication_paths.npz")):
        location = HERE/filename
        if location.exists():
            with np.load(location) as extra:
                forecasts[title] = np.concatenate(
                    [extra[f"{split}:component_extension"] for split in ordered]).astype("float64")
    score_rows({"year":truth},{"year":forecasts},scales,{"year":time},"pooled_year_scores.csv")
    checks, monthly, cadence = [], [], []
    month = time.astype("datetime64[s]").astype("datetime64[M]")
    baseline_error = np.square(forecasts["v1"]-truth).mean((1,2))
    for name in forecasts:
        if not name.startswith(("generation_blend","component_extension")):
            continue
        for span in (7,14,28):
            lo,hi = sample_intervals(truth,forecasts[name],forecasts["v1"],time,span)
            checks.append(dict(model=name,block_days=span,low95_pct=lo,high95_pct=hi))
        error = np.square(forecasts[name]-truth).mean((1,2))
        for key in np.unique(month):
            here = month==key
            monthly.append(dict(model=name,month=str(key),
                                relative_gain_pct=100*(1-error[here].mean()/baseline_error[here].mean()),
                                exclude_month_gain_pct=100*(1-error[~here].mean()/baseline_error[~here].mean())))
        for slots in (2,4,12,24,48):
            phase = (time//1800)%slots
            gains = [100*(1-error[phase==j].mean()/baseline_error[phase==j].mean())
                     for j in range(slots)]
            cadence.append(dict(model=name,interval_hours=slots/2,min_phase_gain_pct=min(gains),
                                max_phase_gain_pct=max(gains),n_positive=sum(x>0 for x in gains),n_phases=slots))
    csv_write("pooled_year_bootstrap_sensitivity.csv",checks)
    csv_write("pooled_year_month_diagnostics.csv",monthly)
    csv_write("pooled_year_cadence_checks.csv",cadence)


def price_specialization():
    archive = HERE/"component_lock_paths.npz"
    if not archive.exists():
        return
    truth, paths, time = {}, {}, {}
    with np.load(archive) as data:
        scales = data["target_sd"]
        for split in PERIODS:
            truth[split],time[split],base = (data[f"{split}:{tag}"] for tag in ("truth","utc","v1"))
            trained_together, trained_alone = base.copy(),base.copy()
            trained_together[:,:,0] = (base[:,:,0]+data[f"{split}:standalone"][:,:,0])/2
            trained_alone[:,:,0] = data[f"{split}:component_extension"][:,:,0]
            paths[split] = {"v1":base,"joint_4x320":trained_together,"price_only_4x320":trained_alone}
    score_rows(truth,paths,scales,time,"price_specialization_scores.csv")


def component_weight_sensitivity():
    plan = json.loads((HERE/"component_lock.json").read_text())
    truth, months = validation_targets()
    v1 = reference("val").astype("float64")
    weights = np.full((24,3),.5)
    choices = (0.,.25,.5,.75,1.)
    grid = []
    for part in plan["component_extension"]:
        target,lo,hi,name,locked = (part[k] for k in ("target","start","end","model","weight"))
        assert locked==0.5
        predictions = []
        for folder in plan["models"][name]["folders"]:
            with np.load(HERE/folder/"predictions.npz") as file:
                predictions.append(file["val"][:,lo:hi,target])
        model = np.mean(predictions,axis=0,dtype="float64")
        base, actual = v1[:,lo:hi,target],truth[:,lo:hi,target]
        matched = np.square((base+model)/2-actual)
        divisor = np.array([matched[month].mean() for month in months])
        best = (0.,.5)
        for value in choices:
            error = np.square((1-value)*base+value*model-actual)
            improvements = 1-np.array([error[month].mean() for month in months])/divisor
            grid.append(dict(target=target,first_slot=lo+1,last_slot=hi,weight=value,
                             MSE=error.mean(),min_gain=improvements.min(),mean_gain=improvements.mean()))
            if improvements.min()>0 and improvements.mean()>best[0]:
                best = float(improvements.mean()),value
        weights[lo:hi,target] = best[1]
    csv_write("component_weight_validation.csv",grid)
    results = {}
    true,times = {},{}
    for file_name, tag in (("component_lock_paths","first"),("component_replication_paths","new-seeds")):
        with np.load(HERE/f"{file_name}.npz") as data:
            scales = data["target_sd"]
            for split in PERIODS:
                label = f"{split}-{tag}"
                true[label],times[label],base,locked = (
                    data[f"{split}:{x}"].astype("float64") if x!="utc" else data[f"{split}:{x}"]
                    for x in ("truth","utc","v1","component_extension"))
                shift = 2*(locked-base)
                results[label] = {"v1":base,**{f"{a:g}": base + a*shift for a in choices[1:]},
                                  "selected-by-validation":base + weights*shift}
    score_rows(true,results,scales,times,"component_weight_scores.csv")
    print("Component weight sensitivity confirmed",[(weights[:8,i].mean(),weights[8:,i].mean())
          for i in range(3)],flush=True)


def main():
    grid = (0.,.25,.5,.75,1.)
    plan = json.loads((HERE/"final_lock.json").read_text())
    rule, = plan["generation_blend"]
    assert rule["weight"]==0.5
    actual, base, new, months = validation(plan)
    by_weight = []
    selected = []
    for start,end in ((0,8),(8,24)):
        best = (0.,0.5)
        reference_loss = np.square((base+new)/2-actual)[:,start:end]
        denominators = np.array([reference_loss[month].mean() for month in months])
        for alpha in grid:
            error = np.square((1-alpha)*base+alpha*new-actual)[:,start:end]
            block_losses = np.array([error[month].mean() for month in months])
            gains = 1-block_losses/denominators
            by_weight.append(dict(first_slot=start+1,last_slot=end,alpha=alpha,
                                  MSE=error.mean(),min_block_gain=gains.min(),mean_block_gain=gains.mean()))
            if gains.min()>0 and gains.mean()>best[0]:
                best = float(gains.mean()),alpha
        selected.append(best[1])
    csv_write("mix_weight_validation.csv",by_weight)
    alphas = {f"{a:g}":np.full(24,a) for a in grid}
    alphas["selected-by-lead"] = np.r_[np.full(8,selected[0]),np.full(16,selected[1])]
    report = []
    checks = []
    with np.load(HERE/"final_lock_paths.npz") as paths:
        for split in PERIODS:
            utc = paths[f"{split}:utc"]
            actual = paths[f"{split}:truth"][:,:,1].astype("float64")
            base = paths[f"{split}:v1"][:,:,1].astype("float64")
            new = 2*paths[f"{split}:generation_blend"][:,:,1].astype("float64")-base
            denominator = np.square(base-actual).mean()
            for label,alpha in alphas.items():
                estimate = (1-alpha)*base+alpha*new
                loss = np.square(estimate-actual).mean()
                report.append(dict(split=split,mixture=label,early=alpha[0],late=alpha[-1],
                                   generation_MSE=loss,reduction_pct=100*(1-loss/denominator)))
            for span in (3,7,14,28):
                lo,hi = sample_intervals(actual,(base+new)/2,base,utc,span)
                checks.append(dict(split=split,block_days=span,low95_pct=lo,high95_pct=hi))
    csv_write("mix_weight_test.csv",report)
    csv_write("generation_bootstrap_sensitivity.csv",checks)
    pooled_year()
    price_specialization()
    component_weight_sensitivity()
    print("Selected early/late validation weights",selected,flush=True)


if __name__=="__main__":
    main()
