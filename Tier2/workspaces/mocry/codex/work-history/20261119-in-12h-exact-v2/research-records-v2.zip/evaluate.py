"""Freeze candidate selection on validation, then evaluate the chosen predictors."""
import argparse
import csv
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

import numpy as np
import torch

from run import (
    BASE, CUTS, FEATURES, HERE, PROTOCOL, SIZES, SPLITS, TARGETS,
    additional_reference, check_time, datasets, make_network, predict, predictions, reference, ridge_anchor,
)
from exact_lead_comparison import resample_days, resampled_means
from holdout_2026 import FOLDER, SCHEMA, block


PERIODS = ("test25", "test26", "jan_may26")
PIECES = ((0,0,8), (0,8,24), (1,0,24), (2,0,8), (2,8,24))
UNIT_MULTIPLIER = np.array([1., .002, .002])
REFERENCE_NAMES = ("ridge", "generation", "price")


def stable_piece(candidates, actual, month_blocks, weights=(0.15, 0.25, 0.5, 0.75, 1.)):
    base = candidates["v1"]
    reference_block_loss = np.array(
        [np.square(base[mask]-actual[mask]).mean() for mask in month_blocks])
    best = (0., "v1", 0.)
    for name, path in candidates.items():
        if name == "v1":
            continue
        shift = path-base
        for weight in weights:
            error = np.square(base + weight*shift - actual)
            losses = np.array([error[mask].mean() for mask in month_blocks])
            relative_gains = 1-losses/reference_block_loss
            if relative_gains.min() > 0 and relative_gains.mean() > best[0]:
                best = (float(relative_gains.mean()), name, weight)
    return best


def validation_targets():
    with np.load(BASE/"targets.npz") as file:
        truth = file["y"][CUTS[0]:CUTS[1]]
        times = file["utc"][CUTS[0]:CUTS[1]].astype("datetime64[s]").astype("datetime64[M]").astype(int)
    month_blocks = [(times >= times.min()+2*i) & (times < times.min()+2*i+2) for i in range(4)]
    assert np.all(sum(month_blocks) == 1)
    return truth, month_blocks


def csv_write(filename, rows):
    with (HERE/filename).open("w", newline="", encoding="utf-8") as f:
        out = csv.DictWriter(f, rows[0].keys())
        out.writeheader()
        out.writerows(rows)


def records(stage):
    paths = sorted((HERE/"runs"/stage).glob("*/seed-*/result.json"))
    return [(p.parent, json.loads(p.read_text())) for p in paths]


def study_table():
    rows = []
    for stage in sorted((HERE/"runs").iterdir()):
        for path, result in records(stage.name):
            rows.append(dict(stage=stage.name, case=result["id"], seed=result["seed"],
                parameters=result["parameters"], selected=result["selected"], seconds=result["seconds"],
                **result["val"]))
    csv_write("validation_runs.csv", rows)


def bucket(stage, seeds):
    available = {}
    for folder, result in records(stage):
        if (folder/"model.pt").exists() and result["seed"] in seeds:
            available.setdefault(result["id"], {})[result["seed"]] = folder
    for name, checkpoints in available.items():
        if set(checkpoints) == set(seeds):
            yield name, [checkpoints[i] for i in seeds]


def checkpoint_spec(folders, case, score):
    hashes = []
    for folder in folders:
        with (folder/"model.pt").open("rb") as f:
            hashes.append(hashlib.file_digest(f,"sha256").hexdigest())
    return dict(folders=[str(folder.relative_to(HERE)) for folder in folders], sha256=hashes,
                case=case, validation_MSE=score)


def validate(stage, output, *, seeds, diagnostics=()):
    truth, month_blocks = validation_targets()
    baseline = reference("val")
    rows = {}
    configs = {}
    for name, folders in bucket(stage, seeds):
        arrays = []
        for folder in folders:
            with np.load(folder/"predictions.npz") as file:
                arrays.append(file["val"])
        rows[name] = np.mean(arrays, axis=0, dtype="float64")
        configs[name] = json.loads((folders[0]/"config.json").read_text())["case"]
    if not rows:
        raise ValueError("No complete three-seed checkpoints.")
    ranking = sorted((float(np.square(path-truth).mean()), name)
                     for name,path in rows.items() if min(configs[name].get("loss_targets",[1,1,1]))>0)
    csv_write(f"{output.stem}_validation_confirmed.csv", [
        dict(model=name, **{target: np.square(path[:, :, j]-truth[:, :, j]).mean()
                            for j,target in enumerate(TARGETS)}, joint=np.square(path-truth).mean(),
             joint_eligible=min(configs[name].get("loss_targets",[1,1,1]))>0)
        for name, path in sorted(rows.items(), key=lambda pair: np.square(pair[1]-truth).mean())
    ])
    source = {"v1": baseline, **rows}
    parts = []
    weights = []
    stable_weights = []
    selected = set()
    for target,start,end in PIECES:
        # Selecting from baseline and nonzero-loss heads is entirely within validation.
        actual = truth[:, start:end, target]
        on_piece = {name:path[:, start:end, target] for name,path in source.items()
                    if name=="v1" or configs[name].get("loss_targets",[1,1,1])[target]>0}
        win = min(on_piece, key=lambda k: np.square(on_piece[k]-actual).mean())
        parts.append(dict(target=target, start=start, end=end, model=win))
        if win != "v1":
            selected.add(win)
        diffs = [value-on_piece["v1"] for name,value in on_piece.items() if name!="v1"]
        options = [name for name in on_piece if name!="v1"]
        if diffs:
            # One candidate residual is blended into its fixed v1 component using only validation.
            shifts = np.stack(diffs)
            error = actual-on_piece["v1"]
            alpha = np.clip((shifts*error).sum((1,2)) / np.maximum(1e-9, (shifts*shifts).sum((1,2))), 0., 1.)
            loss = np.square(error-shifts*alpha[:, None, None]).mean((1,2))
            candidate = np.argmin(loss)
            amount = float(alpha[candidate])
            name = options[candidate] if amount >= 0.01 else "v1"
        else:
            name, amount = "v1", 0.
        weights.append(dict(target=target, start=start, end=end, model=name, weight=amount))
        if name!="v1":
            selected.add(name)
        score, stable_name, stable_amount = stable_piece(on_piece, actual, month_blocks)
        stable_weights.append(dict(target=target, start=start, end=end, model=stable_name,
                                   weight=stable_amount, mean_block_validation_gain=score))
        if stable_name!="v1":
            selected.add(stable_name)
    top = [name for score,name in ranking[:3]]
    best = top[0]
    eligible = [name for _,name in ranking]
    forward = [best]
    while len(forward) < min(3,len(eligible)):
        prior = np.sum([rows[name] for name in forward],axis=0)
        choices = [name for name in eligible if name not in forward]
        choice = min(choices,key=lambda name: np.square((prior + rows[name])/(len(forward)+1)-truth).mean())
        forward.append(choice)
    selected.update(top+forward)
    diagnostics = sorted(set(diagnostics).intersection(rows))
    selected.update(diagnostics)
    specs = {}
    for name, folders in bucket(stage, seeds):
        if name not in selected:
            continue
        specs[name] = checkpoint_spec(folders, configs[name], float(np.square(rows[name]-truth).mean()))
    result = {"registered_utc":datetime.now(timezone.utc).isoformat(),
              "checkpoint_stage":stage, "diagnostics":diagnostics,
              "v1_validation_MSE":float(np.square(baseline-truth).mean()),
              "best_standalone":best, "ensemble":top, "diverse_ensemble":forward,
              "replacement":parts, "blend":weights, "stable_blend":stable_weights,
              "generation_blend":[v for v in stable_weights if v["target"]==1], "models":specs}
    validation_paths = composed(result, {name:{"val": p} for name,p in source.items()})
    result["validation_comparison_MSE"] = {n:float(np.square(p-truth).mean())
                                               for n,p in validation_paths["val"].items()}
    output.write_text(json.dumps(result, indent=2))
    print("Locked", best, top, sorted(selected), flush=True)


def replicate(source, output, stage, seeds):
    plan = json.loads(source.read_text())
    with np.load(BASE/"targets.npz") as f:
        truth = f["y"][CUTS[0]:CUTS[1]]
    updated = []
    for name, folders in bucket(stage, seeds):
        if name not in plan["models"]:
            continue
        original = plan["models"][name]
        previous = json.loads((HERE/original["folders"][0]/"config.json").read_text())
        validation_paths = []
        for folder in folders:
            revised = json.loads((folder/"config.json").read_text())
            assert original["case"] == revised["case"]
            assert previous["training"] == revised["training"]
            with np.load(folder/"predictions.npz") as f:
                validation_paths.append(f["val"])
        mean = np.mean(validation_paths, axis=0, dtype="float64")
        plan["models"][name] = checkpoint_spec(folders, original["case"], float(np.square(mean-truth).mean()))
        updated.append(name)
    if not updated:
        raise ValueError("No complete independent seed cohort for the locked candidates.")
    plan["original_validation_comparison_MSE"] = plan.pop("validation_comparison_MSE")
    plan["replication"] = dict(source=source.name, seeds=seeds, models=sorted(updated), stage=stage,
                               registered_utc=datetime.now(timezone.utc).isoformat())
    output.write_text(json.dumps(plan, indent=2))
    print("Replicated with unchanged blend weights", sorted(updated), flush=True)


def refine_generation(source, output, stage, seeds):
    plan = json.loads(source.read_text())
    rule, = plan["generation_blend"]
    with np.load(BASE/"targets.npz") as f:
        y = f["y"][CUTS[0]:CUTS[1],:,1]
    v1 = reference("val")[:,:,1]
    alpha = rule["weight"]
    results = []
    for name, folders in bucket(stage, seeds):
        case = json.loads((folders[0]/"config.json").read_text())["case"]
        paths = []
        for folder in folders:
            with np.load(folder/"predictions.npz") as f:
                paths.append(f["val"][:,:,1])
        mean = np.mean(paths, axis=0, dtype="float64")
        blended = (1-alpha)*v1 + alpha*mean
        results.append((float(np.square(blended-y).mean()),name,folders,case,float(np.square(mean-y).mean())))
    if not results:
        raise ValueError("No complete generation-only candidate.")
    results.sort()
    score, name, folders, case, raw_score = results[0]
    plan["refined_generation"] = [{**rule,"model":name}]
    plan["models"][name] = checkpoint_spec(folders,case,raw_score)
    plan["refinement"] = {"registered_utc":datetime.now(timezone.utc).isoformat(),
                          "base":source.name, "stage":stage, "validation_generation_MSE":score,
                          "base_v1_generation_MSE":float(np.square(v1-y).mean())}
    csv_write(f"{output.stem}_candidates.csv",
              [dict(model=name, blended_generation_MSE=score, raw_generation_MSE=raw)
               for score,name,_,_,raw in results])
    output.write_text(json.dumps(plan,indent=2))
    print("Selected generation-only refinement",name,score,flush=True)


def extend_components(source, output, stage, seeds):
    plan = json.loads(source.read_text())
    truth, month_blocks = validation_targets()
    base = reference("val")
    candidates, by_name = {}, {}
    for name, folders in bucket(stage, seeds):
        case = json.loads((folders[0]/"config.json").read_text())["case"]
        target, = [j for j,weight in enumerate(case["loss_targets"]) if weight>0]
        folds = []
        for folder in folders:
            with np.load(folder/"predictions.npz") as file:
                folds.append(file["val"][:,:,target])
        mean = np.mean(folds,axis=0,dtype="float64")
        candidates.setdefault(target,{})[name] = mean
        by_name[name] = (folders,case,float(np.square(mean-truth[:,:,target]).mean()))
    selections = list(plan["generation_blend"])
    for target in (0,2):
        forecasts = {"v1":base[:,:,target],**candidates.get(target,{})}
        for lo,hi in ((0,8),(8,24)):
            part = {name:path[:,lo:hi] for name,path in forecasts.items()}
            gain,name,weight = stable_piece(part,truth[:,lo:hi,target],month_blocks,(0.15,0.25,0.5))
            selections.append(dict(target=target,start=lo,end=hi,model=name,weight=weight,
                                   mean_block_validation_gain=gain))
            if name!='v1':
                plan["models"][name] = checkpoint_spec(*by_name[name])
    plan["component_extension"] = selections
    plan["extension_registration"] = dict(base=source.name,stage=stage,
        registered_utc=datetime.now(timezone.utc).isoformat())
    output.write_text(json.dumps(plan,indent=2))
    print("Locked price and demand extension",selections,flush=True)


def jan_may():
    original = np.load(FOLDER/"inputs.npy")
    with np.load(FOLDER/"targets.npz") as file:
        times,y,base,sd = (file[k] for k in ("utc","y","baseline","target_sd"))
    added = [block(name, original, times) for name in FEATURES]
    names = SCHEMA["names"] + [n for _,labels,_ in added for n in labels]
    x = np.concatenate([original]+[v for v,_,_ in added], axis=-1)
    return torch.from_numpy(x).cuda(), y, base, sd, times, names


def stored_models(plan, names, features, ridges, baseline, deadline):
    rows={}
    seeds={}
    for name, config in plan["models"].items():
        fitted=[]
        for directory, expected in zip(config["folders"], config["sha256"]):
            check_time(deadline)
            path=HERE/directory/"model.pt"
            with path.open("rb") as model:
                assert hashlib.file_digest(model,"sha256").hexdigest()==expected
            case=config["case"]
            network=make_network(len(names),case,names).cuda()
            network.load_state_dict(torch.load(path,weights_only=True,map_location="cuda")["weights"])
            values = {}
            anchor = baseline if case.get("anchor_kind")=="v1" else ridges
            for split,x in features.items():
                if case.get("ridge_condition"):
                    x = torch.cat((x,torch.as_tensor(anchor[split],dtype=x.dtype,device=x.device)),dim=-1)
                values[split] = predict(network,x,deadline).cpu().numpy()+case.get("ridge_anchor",0)*anchor[split]
            fitted.append(values)
        seeds[name]=fitted
        rows[name]={split:np.mean([v[split] for v in fitted],axis=0,dtype="float64") for split in features}
        print("replayed",name,flush=True)
    return rows,seeds


def composed(plan, raw):
    built={}
    for split,base in raw["v1"].items():
        built[split]={"v1":base}
        for method in ("replacement","blend","stable_blend","generation_blend","refined_generation",
                       "component_extension","alternative_component"):
            if method not in plan:
                continue
            filled=base.copy()
            for part in plan[method]:
                tgt,lo,hi = part["target"],part["start"],part["end"]
                weight=part.get("weight",1.)
                source=raw[part["model"]][split][:,lo:hi,tgt]
                filled[:,lo:hi,tgt]=(1-weight)*filled[:,lo:hi,tgt]+weight*source
            built[split][method]=filled
        built[split]["standalone"]=raw[plan["best_standalone"]][split]
        built[split]["arch_ensemble"]=np.mean([raw[v][split] for v in plan["ensemble"]],axis=0)
        built[split]["diverse_ensemble"]=np.mean([raw[v][split] for v in plan.get("diverse_ensemble",plan["ensemble"])],axis=0)
        for name in plan["models"]:
            built[split][name]=raw[name][split]
    return built


def score_rows(truth, paths, scales, periods, filename):
    rows=[]
    for split,data in paths.items():
        actual=truth[split]
        benchmark=(data["v1"]-actual)**2
        resampling=resample_days(periods[split])
        for name,p in data.items():
            error=p-actual
            squared=error**2
            for title,lead in (("24-slot",slice(None)),("first-4h",slice(0,8)),("0.5h",slice(0,1)),
                               ("4h",slice(7,8)),("12h",slice(23,24))):
                for i,target in enumerate((*TARGETS,"joint")):
                    mask=i if i<3 else slice(None)
                    b=benchmark[:,lead,mask].reshape(len(actual),-1).mean(1)
                    v=squared[:,lead,mask].reshape(len(actual),-1).mean(1)
                    value=b.mean()-v.mean()
                    if i < 3 and not np.isfinite(v).all():
                        raise ValueError(f"{split} {name} produced non-finite scores.")
                    gains=100*resampled_means(b-v,*resampling) / np.maximum(1e-12,resampled_means(b,*resampling))
                    low,high=np.quantile(gains,(0.025,0.975))
                    error_units=(np.abs(error[:,lead,i]).mean()*scales[i]*UNIT_MULTIPLIER[i]) if i<3 else ""
                    rows.append(dict(split=split,model=name,horizon=title,target=target,n_origins=len(v),
                        v1_MSE=b.mean(),MSE=v.mean(),improvement_pct=100*value/b.mean(),
                        low95_pct=low,high95_pct=high,physical_MAE=error_units))
    csv_write(filename,rows)


def generation_ablation(plan, raw, truth, scales, times):
    rule, = plan["generation_blend"]
    names = plan["diagnostics"]
    val_y, _ = validation_targets()
    val_v1 = reference("val")[:,:,1].astype("float64")
    alpha = rule["weight"]
    validation = []
    for name in names:
        paths = []
        for folder in plan["models"][name]["folders"]:
            with np.load(HERE/folder/"predictions.npz") as f:
                paths.append(f["val"][:,:,1])
        mean = np.mean(paths,axis=0,dtype="float64")
        mixed = (1-alpha)*val_v1 + alpha*mean
        validation.append(dict(model=name, generation_MSE=np.square(mixed-val_y[:,:,1]).mean()))
    csv_write("matched_generation_ablation_validation.csv",validation)
    output = {}
    for split, base in raw["v1"].items():
        output[split] = {"v1":base}
        for name in names:
            mixed = base.copy()
            mixed[:,:,1] = (1-alpha)*base[:,:,1] + alpha*raw[name][split][:,:,1]
            output[split][name] = mixed
    score_rows(truth,output,scales,times,"matched_generation_ablation_scores.csv")


def replay(manifest,deadline,include_extra=True,report_ablation=False):
    plan=json.loads(manifest.read_text())
    torch.set_float32_matmul_precision("high")
    torch.set_num_threads(2)
    x,y,names=datasets()
    all_ridges=ridge_anchor(x)
    main = ("test25","test26")
    feat=dict(zip(main,(x[2],x[3])))
    ridges=dict(zip(main,(all_ridges[2].cpu().numpy(),all_ridges[3].cpu().numpy())))
    ground=dict(zip(main,(y[2].cpu().numpy(),y[3].cpu().numpy())))
    with np.load(BASE/"targets.npz") as old,np.load(BASE/"summer-2026/targets.npz") as summer:
        scales=old["target_sd"]
        times=dict(zip(main,(old["utc"][CUTS[1]:],summer["utc"])))
        baseline=dict(zip(main,(old["baseline"][CUTS[1]:],summer["baseline"])))
    v1={split:reference(split) for split in main}
    if include_extra:
        xj,yj,bj,sdj,tj,nj=jan_may()
        assert names==nj
        np.testing.assert_array_equal(scales,sdj)
        ridge_archive=HERE.parent/PROTOCOL["demand"]/"weights.npz"
        with np.load(ridge_archive) as file:
            w=torch.tensor(file["weight"],device="cuda",dtype=torch.float32)
            b=torch.tensor(file["bias"],device="cuda",dtype=torch.float32)
        torch.set_float32_matmul_precision("highest")
        ridgej=(xj.flatten(1)@w+b).reshape(-1,24,3).cpu().numpy()
        torch.set_float32_matmul_precision("high")
        feat["jan_may26"],ridges["jan_may26"],ground["jan_may26"]=xj,ridgej,yj
        times["jan_may26"],baseline["jan_may26"]=tj,bj
        v1["jan_may26"]=additional_reference(xj,ridgej,deadline)
    raw,seeds=stored_models(plan,names,feat,ridges,v1,deadline)
    raw["v1"] = v1
    paths=composed(plan,raw)
    for split in paths:
        paths[split]["ridge"] = ridges[split]
    stem=manifest.stem
    score_rows(ground,paths,scales,times,f"{stem}_scores.csv")
    if report_ablation:
        generation_ablation(plan,raw,ground,scales,times)
    robustness=[]
    for name,replicas in seeds.items():
        for i,replica in enumerate(replicas):
            for split,array in replica.items():
                error=(array-ground[split])**2
                base=(raw["v1"][split]-ground[split])**2
                robustness.append(dict(case=name,replica=i,split=split,MSE=error.mean(),
                    relative_gain_pct=100*(1-error.mean()/base.mean()),
                    **{v:error[:,:,j].mean() for j,v in enumerate(TARGETS)}))
    csv_write(f"{stem}_individual_seeds.csv",robustness)
    np.savez_compressed(HERE/f"{stem}_paths.npz",
        **{f"{split}:{name}": p for split,stage in paths.items() for name,p in stage.items()
           if name in ("v1","standalone","replacement","blend","stable_blend","generation_blend",
                       "refined_generation","component_extension","alternative_component",
                       "arch_ensemble","diverse_ensemble")},
        **{f"{split}:utc":v for split,v in times.items()},
        **{f"{split}:baseline":v for split,v in baseline.items()},
        **{f"{split}:truth":v for split,v in ground.items()}, target_sd=scales)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode",choices=("summarize","lock","replay","replicate","refine-generation",
                                       "extend-components"))
    parser.add_argument("--stage")
    parser.add_argument("--manifest",type=Path)
    parser.add_argument("--source",type=Path)
    parser.add_argument("--seeds",type=int,nargs="+",default=[17,29,43])
    parser.add_argument("--deadline",type=float)
    parser.add_argument("--main-only",action="store_true")
    parser.add_argument("--generation-ablation",action="store_true")
    parser.add_argument("--diagnostics",nargs="+",default=[])
    args=parser.parse_args()
    if args.mode=="summarize":
        study_table()
    elif args.mode=="lock":
        validate(args.stage,args.manifest,seeds=args.seeds,diagnostics=args.diagnostics)
    elif args.mode=="replicate":
        replicate(args.source,args.manifest,args.stage,args.seeds)
    elif args.mode=="refine-generation":
        refine_generation(args.source,args.manifest,args.stage,args.seeds)
    elif args.mode=="extend-components":
        extend_components(args.source,args.manifest,args.stage,args.seeds)
    else:
        replay(args.manifest,args.deadline,include_extra=not args.main_only,report_ablation=args.generation_ablation)


if __name__=="__main__":
    main()
