"""Plot the registered ensemble and report forecast errors by delivery lead."""
import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

from evaluate import HERE, TARGETS, csv_write


LABELS = {"test25":"Sep–Dec 2025","jan_may26":"Jan–May 2026","test26":"Jun–Aug 2026"}
COLORS = ("#626a75", "#0f72a7", "#ad561c", "#268455", "#8a4fa3", "#876322")
NAMES = {
    "v1": "in-12h-exact v1",
    "standalone": "Best validated architecture",
    "diverse_ensemble": "Validation-selected ensemble",
    "blend": "Blend with v1",
    "stable_blend": "Consistent-validation blend",
    "generation_blend": "Generation-only blend",
    "component_extension": "Target-specific Transformer blend",
}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path)
    parser.add_argument("--models", choices=tuple(NAMES), nargs="+",
                        default=["v1", "standalone", "stable_blend", "generation_blend"])
    parser.add_argument("--output-prefix", default="")
    args = parser.parse_args()
    leads = np.arange(1,25)*0.5
    rows, balance, monthly = [], [], []
    figure, axes = plt.subplots(3,3,figsize=(12,8.2),sharex=True,layout="constrained")
    with np.load(args.archive) as data:
        scale = data["target_sd"]
        for i,(period,label) in enumerate(LABELS.items()):
            actual = data[f"{period}:truth"]
            reference = data[f"{period}:baseline"]
            physical = actual*scale + reference
            true_gap = physical[:,:,1]-physical[:,:,2]
            near = np.abs(true_gap)<500
            months = data[f"{period}:utc"].astype("datetime64[s]").astype("datetime64[M]")
            for k,tag in enumerate(args.models):
                color = COLORS[k % len(COLORS)]
                values = data[f"{period}:{tag}"]
                e = values-actual
                squared = np.square(e,dtype="float64")
                forecast = values*scale + reference
                gap = forecast[:,:,1]-forecast[:,:,2]
                correct = (gap>=0)==(true_gap>=0)
                balance.append(dict(split=period,model=tag,gap_MAE_GW=np.mean(abs(gap-true_gap))*.002,
                                    gap_sign_accuracy=correct.mean(),within_1GW_sign_accuracy=correct[near].mean()))
                for month in np.unique(months):
                    by_target = squared[months==month].mean((0,1))
                    monthly.append(dict(split=period, month=str(month),model=tag,joint=by_target.mean(),
                                        **dict(zip(TARGETS,by_target))))
                for j,target in enumerate(TARGETS):
                    series = squared[:,:,j].mean(0)
                    axes[i,j].plot(leads,series,color=color,label=NAMES[tag],lw=1.65,
                                   linestyle="--" if tag=="v1" else "-",zorder=4 if tag=="v1" else 2)
                    for lead,mse in zip(leads,series):
                        rows.append(dict(split=period,model=tag,target=target,lead_hours=lead,MSE=mse))
                    axes[i,j].grid(alpha=.22)
            for j,target in enumerate(TARGETS):
                if i == 0:
                    axes[i,j].set_title(target.capitalize())
                if j==0:
                    axes[i,j].set_ylabel(label+"\nStandardized MSE")
                if i==2:
                    axes[i,j].set_xlabel("Delivery lead (hours)")
    axes[0,2].legend(frameon=False,fontsize=8,loc="best")
    figure.savefig(HERE/f"{args.output_prefix}forecast_error_profiles.png",dpi=170)
    plt.close(figure)
    csv_write(f"{args.output_prefix}lead_profiles.csv",rows)
    csv_write(f"{args.output_prefix}balance_accuracy.csv",balance)
    csv_write(f"{args.output_prefix}monthly_scores.csv",monthly)


if __name__ == "__main__":
    main()
