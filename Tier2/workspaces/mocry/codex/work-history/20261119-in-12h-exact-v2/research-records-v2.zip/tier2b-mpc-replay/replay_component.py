"""Replay the locked Transformer blend and four comparators with the v1 MPC."""
import hashlib
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parents[1]))

from build_features import BASE, CUTS, P, load_baseline
from dispatch_diagnostics import prediction_metrics
from exact_lead_comparison import resample_days, resampled_means
from holdout_2026 import FOLDER, SCHEMA
from in_12h_exact_replay import (
    CONFIG, FIXED_LOW, HORIZON, OUTPUT as V1_OUTPUT, references, residuals,
    rolling, settle, test_split, feature_level, verify_trace,
)


WINDOWS = ("test25", "jan_may26", "test26")
METHODS = ("component_blend", "v1", "ridge_before_features", "mean", "oracle_12h")
TRACE_FIELDS = ("stock_before_MWh", "request_MWh", "charge_AC_MWh", "discharge_AC_MWh",
                "stock_after_MWh", "sales_MWh", "electrolyser_input_MWh", "gross_GBP")
PRICE_INDEX = P / "tier1-multiproduct-20261110-v6/inputs/CPI.csv"
COMPONENT_PATHS = HERE.parent / "component_lock_paths.npz"


def as_of_factor(stamps):
    source = pd.read_csv(PRICE_INDEX, dtype=str)
    source = source[source.Title.str.fullmatch(r"\d{4} [A-Z]{3}", na=False)]
    months = pd.to_datetime(source.Title, format="%Y %b").dt.to_period("M")
    cpi = pd.Series(pd.to_numeric(source.iloc[:, 1]).to_numpy(), index=months)
    issue_month = pd.to_datetime(stamps, unit="s").to_period("M")
    factor = 108.7 / cpi.reindex(issue_month - 2).to_numpy()
    assert np.isfinite(factor).all()
    return factor


def original_ridge():
    stored, _ = residuals(CONFIG["original_ridge"])
    weights = HERE.parents[1] / CONFIG["original_ridge"] / "weights.npz"
    original = np.load(BASE / "inputs.npy", mmap_mode="r")
    summer = np.load(BASE / "summer-2026/inputs.npy", mmap_mode="r")
    extra = np.load(FOLDER / "inputs.npy", mmap_mode="r")
    original_schema = json.loads((BASE / "features.json").read_text())
    holdout_schema = json.loads((FOLDER / "features.json").read_text())
    for key in ("names", "mean", "std"):
        np.testing.assert_array_equal(original_schema[key], holdout_schema[key])
    with np.load(weights) as model:
        w, b = model["weight"], model["bias"]
        def predict(x):
            return (x.reshape(len(x), -1).astype("float64") @ w + b).reshape(-1, 24, 3).astype("float32")
        for split, x in (("test25", original[CUTS[1]:]), ("test26", summer)):
            np.testing.assert_allclose(predict(x[:64]), stored[split][:64], atol=1e-6, rtol=0)
        stored["jan_may26"] = predict(extra)
    return stored


def auction_at_issue():
    quote = load_baseline()("PRICES_forward")[:, 0]
    original = dict(zip(("test25", "test26"), np.split(quote, CUTS)[2:]))
    x = np.load(FOLDER / "inputs.npy", mmap_mode="r")[:, 0]
    index = SCHEMA["names"].index("PRICES_forward")
    flag = SCHEMA["names"].index("PRICES_forward_known")
    published = x[:, flag] * SCHEMA["std"][flag] + SCHEMA["mean"][flag] > 0.5
    values = x[:, index] * SCHEMA["std"][index] + SCHEMA["mean"][index]
    original["jan_may26"] = np.where(published, values, np.nan)
    return original


def replay_window(split, reference, auction, ridge, blend, prior, archive, prior_factors):
    stamps, seasonal, sd, truth = reference
    n = len(stamps)
    np.testing.assert_array_equal(stamps, blend[f"{split}:utc"][:n])
    np.testing.assert_array_equal(seasonal, blend[f"{split}:baseline"][:n])
    np.testing.assert_array_equal(sd, blend["target_sd"])
    np.testing.assert_allclose(truth, seasonal + sd * blend[f"{split}:truth"][:n], atol=1e-8, rtol=0)
    np.testing.assert_allclose(truth[:-(HORIZON-1), -1], truth[HORIZON-1:, 0], atol=1e-6, rtol=0)
    # Apply the same two-month-lag real-price conversion as the v1 replay.
    factor = as_of_factor(stamps)
    if split in prior_factors:
        np.testing.assert_allclose(prior_factors[split][:n], np.broadcast_to(factor[:, None], (n, HORIZON)),
                                   atol=1e-7, rtol=0)
        factor = prior_factors[split][:n, 0]
    mean = seasonal.copy()
    mean[:, :, 0] *= factor[:, None]
    signal = np.where(np.isfinite(auction[:n]), auction[:n] * factor, mean[:, 0, 0])
    v1 = seasonal + sd * blend[f"{split}:v1"][:n]
    v1[:, :, 1:] = np.maximum(v1[:, :, 1:], 0)
    if split in CONFIG["windows"]:
        np.testing.assert_array_equal(stamps, prior[f"{split}_utc"])
        np.testing.assert_allclose(signal, prior[f"{split}_common_current_price"], atol=2e-5, rtol=0)
        np.testing.assert_allclose((v1-prior[f"{split}_hybrid_path"])/sd, 0, atol=5e-7, rtol=0)
        # Use the exact archived arithmetic for the previously reported paths
        # and auction signal so any action-grid ties reproduce.
        v1 = prior[f"{split}_hybrid_path"]
        signal = prior[f"{split}_common_current_price"]
    paths = {
        "component_blend": seasonal + sd * blend[f"{split}:component_extension"][:n],
        "v1": v1,
        "ridge_before_features": seasonal + sd * ridge[:n],
        "mean": mean,
        "oracle_12h": truth,
    }
    horizon = np.minimum(HORIZON, n - np.arange(n))
    days = n / 48
    date = pd.to_datetime(stamps, unit="s", utc=True)
    start, end = date[0], date[-1] + pd.Timedelta(minutes=30)
    meta = dict(start=start.isoformat(), end_exclusive=end.isoformat(), slots=n, days=days,
                current_price_coverage=float(np.isfinite(auction[:n]).mean()))
    actual = truth[:, 0]
    capital = FIXED_LOW * days / 365
    returns, traces, metrics, cash = [], [], [], {}
    for method, path in paths.items():
        assert path.shape == truth.shape and np.isfinite(path).all()
        planned = path.copy()
        planned[:, :, 1:] = np.maximum(planned[:, :, 1:], 0)
        metrics.append(dict(split=split, method=method,
                            standard_MSE=np.square((planned-truth)/sd).mean(),
                            **prediction_metrics(planned, truth)))
        for policy in ("A", "B"):
            scores = rolling.first_scores(policy, planned, horizon, first_signal=signal)
            trace = []
            result, cash[policy, method] = settle(policy, actual, signal, scores, trace)
            gross = result["gross"]
            flows = verify_trace(np.asarray(trace), actual, signal, policy, gross)
            if split in CONFIG["windows"] and method != "component_blend":
                key = (split, policy, "in-12h-exact" if method=="v1" else method)
                np.testing.assert_allclose(gross, archive.loc[key, "gross_GBP"], atol=1e-4, rtol=0)
            returns.append(dict(split=split, method=method, policy=policy, days=days,
                                gross_GBP=gross, prorated_cost_GBP=capital, net_GBP=gross-capital,
                                cycles=result["cycle"], **flows))
            traces.append(pd.DataFrame(trace, columns=TRACE_FIELDS).assign(
                utc=date, split=split, policy=policy, method=method))
        print(split, method, "completed", flush=True)
    start_seed = {"test25":209, "test26":421, "jan_may26":719}[split]
    sampling = resample_days(stamps, seed=start_seed)
    changes = {}
    for policy in ("A", "B"):
        for method in METHODS[1:]:
            delta = cash[policy, "component_blend"] - cash[policy, method]
            changes[split, policy, method] = float(delta.sum()), resampled_means(delta, *sampling) * n
    return returns, traces, metrics, changes, meta


def intervals(changes):
    for policy in ("A", "B"):
        for method in METHODS[1:]:
            parts = [changes[split, policy, method] for split in WINDOWS]
            changes["pooled", policy, method] = sum(x for x, _ in parts), np.sum([v for _, v in parts], axis=0)
    rows = []
    for (split, policy, method), (delta, samples) in changes.items():
        low, high = np.quantile(samples, (0.025, 0.975))
        rows.append(dict(split=split, policy=policy, reference=method,
                         new_minus_reference_GBP=delta, low95_GBP=low, high95_GBP=high))
    return pd.DataFrame(rows)


def main():
    configured = json.loads((HERE.parent / "component_lock.json").read_text())
    assert all(part["weight"] == 0.5 for part in configured["component_extension"])
    ridge = original_ridge()
    auction = auction_at_issue()
    prior_factors = test_split(feature_level("real_price", "CPI_implied_discount_factor"))
    windows = references()
    archive = pd.read_csv(V1_OUTPUT / "returns.csv").set_index(["split", "policy", "method"])
    records, traces, forecasts, differences, metadata = [], [], [], {}, {}
    with np.load(COMPONENT_PATHS) as blend, np.load(V1_OUTPUT / "issued_hybrid.npz") as prior:
        for split in WINDOWS:
            rows, logs, quality, changes, receipt = replay_window(
                split, windows[split], auction[split], ridge[split], blend, prior, archive, prior_factors)
            records.extend(rows)
            traces.extend(logs)
            forecasts.extend(quality)
            differences.update(changes)
            metadata[split] = receipt
    table = pd.DataFrame(records)
    sums = ["days", "gross_GBP", "prorated_cost_GBP", "net_GBP", "cycles",
            "electricity_gain_GBP", "hydrogen_gain_GBP"]
    pooled = table.groupby(["method", "policy"], sort=False)[sums].sum().reset_index()
    pooled["annualized_gross_GBP"] = pooled["gross_GBP"] * 365 / pooled["days"]
    pooled["annualized_net_GBP"] = pooled["annualized_gross_GBP"] - FIXED_LOW
    assert len(table) == 30 and len(pooled) == 10
    table.to_csv(HERE / "returns.csv", index=False)
    pooled.to_csv(HERE / "pooled_returns.csv", index=False)
    intervals(differences).to_csv(HERE / "paired_differences.csv", index=False)
    pd.DataFrame(forecasts).to_csv(HERE / "forecast_metrics.csv", index=False)
    pd.concat(traces, ignore_index=True).to_csv(HERE / "dispatch.csv.gz", index=False, compression="gzip")
    with COMPONENT_PATHS.open("rb") as f:
        digest = hashlib.file_digest(f, "sha256").hexdigest()
    audit = dict(windows=metadata, fixed_annual_cost_GBP=FIXED_LOW, battery_MW=100, battery_MWh=400,
                 electrolyser_modules={"A":845,"B":362}, horizon_slots=HORIZON, slot_minutes=30,
                 component_plan_registered_utc=configured["extension_registration"]["registered_utc"],
                 forecast_archive=COMPONENT_PATHS.name, forecast_sha256=digest,
                 baseline_replays_verified=16)
    (HERE / "audit.json").write_text(json.dumps(audit, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
