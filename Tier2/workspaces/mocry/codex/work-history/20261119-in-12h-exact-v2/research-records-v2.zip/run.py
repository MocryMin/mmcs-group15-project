"""Run validation screens and frozen multi-seed confirmations."""
import argparse
import csv
import json
import math
import sys
import time
from pathlib import Path

import numpy as np
import torch

from architecture import make_network


HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from build_features import BASE, CUTS, SIZES, TARGETS
from experiment import BudgetExpired, DEFAULTS, Model, check_time, epoch_batches, predict, recipe_features


SPLITS = ("val", "test25", "test26")
FEATURES = ("forecast_shape", "indgen", "tsdf")
REFERENCE = HERE.parent / "in-12h-exact-v1"
PROTOCOL = json.loads((REFERENCE/"config.json").read_text(encoding="utf-8"))


def predictions(folder, split):
    root = HERE.parent/folder
    if folder.startswith("runs/"):
        locations = [root / f"seed-{seed}" / "predictions.npz" for seed in PROTOCOL["seeds"]]
    else:
        locations = [root / "predictions.npz"]
    paths = []
    for path in locations:
        with np.load(path) as source:
            paths.append(source[split])
    return np.mean(paths, axis=0, dtype="float64").astype("float32")


def reference(split):
    generation = predictions(PROTOCOL["generation"], split)
    short = predictions(PROTOCOL["demand"], split)
    price = predictions(PROTOCOL["price_after_4h"], split)
    edge = int(2*PROTOCOL["price_ridge_through_lead_h"])
    result = np.stack((price[:, :, 0], generation[:, :, 1], short[:, :, 2]), axis=-1)
    result[:, :edge, 0] = short[:, :edge, 0]
    return result


def datasets():
    initial = np.concatenate((np.load(BASE/"inputs.npy", mmap_mode="r"),
                              np.load(BASE/"summer-2026/inputs.npy", mmap_mode="r")))
    names = json.loads((BASE/"features.json").read_text())["names"]
    x, names = recipe_features(initial, names, {"blocks": FEATURES}, int(SIZES[0]))
    assert x.shape[1:] == (24, 76)
    del initial
    with np.load(BASE/"targets.npz") as a, np.load(BASE/"summer-2026/targets.npz") as b:
        y = [*np.split(a["y"], CUTS[:2]), b["y"]]
    return x.cuda().split(SIZES.tolist()), [torch.from_numpy(v).cuda() for v in y], names


def ridge_anchor(inputs):
    folder = HERE.parent/PROTOCOL["demand"]
    with np.load(folder/"weights.npz") as archive:
        weight = torch.as_tensor(archive["weight"], dtype=torch.float32, device="cuda")
        bias = torch.as_tensor(archive["bias"], dtype=torch.float32, device="cuda")
    torch.set_float32_matmul_precision("highest")
    values = [(x.flatten(1) @ weight + bias).reshape(-1,24,3) for x in inputs]
    torch.set_float32_matmul_precision("high")
    for split, v in zip(SPLITS, values[1:]):
        np.testing.assert_allclose(v.cpu().numpy(), predictions(PROTOCOL["demand"], split),
                                   rtol=1e-3, atol=1e-4)
    return values


def archived_transformer(folder, features, deadline, seeds=None):
    outputs = []
    for seed in (PROTOCOL["seeds"] if seeds is None else seeds):
        path = HERE.parent/folder/f"seed-{seed}"
        config = json.loads((path/"config.json").read_text())
        case = config["case"]
        model = Model(config["features"], case["width"], case.get("layers",1),
                      case.get("projection","linear"), case.get("head","mean")).cuda()
        old = torch.load(path/"model.pt", weights_only=True, map_location="cuda")
        model.load_state_dict(old["weights"])
        outputs.append(predict(model, features, deadline).cpu().numpy())
    return np.mean(outputs, axis=0, dtype="float64").astype("float32")


def additional_reference(features, ridge, deadline):
    generation = archived_transformer(PROTOCOL["generation"], features, deadline)
    price = archived_transformer(PROTOCOL["price_after_4h"], features, deadline)
    result = np.stack((price[:,:,0],generation[:,:,1],ridge[:,:,2]),axis=-1)
    edge = int(2*PROTOCOL["price_ridge_through_lead_h"])
    result[:,:edge,0] = ridge[:,:edge,0]
    return result


def v1_anchor(inputs, ridge, deadline):
    cache = HERE/"v1_train_paths.npy"
    if not cache.exists():
        train = additional_reference(inputs[0], ridge[0].cpu().numpy(), deadline)
        temp = HERE/"v1_train_paths.tmp.npy"
        np.save(temp, train)
        temp.replace(cache)
    else:
        train = np.load(cache)
    assert train.shape == (len(inputs[0]),24,3)
    return [torch.as_tensor(p,device="cuda") for p in [train,*[reference(s) for s in SPLITS]]]


def measures(prediction, y):
    errors = (prediction-y).square()
    row = {"joint": errors.mean().item()}
    for j, target in enumerate(TARGETS):
        row[target] = errors[:, :, j].mean().item()
        row[f"{target}_first"] = errors[:, 0, j].mean().item()
        row[f"{target}_early"] = errors[:, :8, j].mean().item()
        row[f"{target}_late"] = errors[:, 8:, j].mean().item()
    return row


def criterion(prediction, target, weights):
    return ((prediction-target).square()*weights).mean()


def write_reference(y):
    historical = {split: measures(torch.tensor(reference(split), device="cuda"), y[i])
                  for i,split in enumerate(SPLITS,1)}
    if not (HERE/"baseline_v1.json").exists():
        (HERE/"baseline_v1.json").write_text(json.dumps(historical, indent=2))


def fit(config, seed, settings, inputs, targets, names, anchor):
    check_time(settings.deadline)
    path = HERE/"runs"/settings.stage/config["id"]/f"seed-{seed}"
    if (path/"result.json").exists():
        return
    path.mkdir(parents=True, exist_ok=True)
    protocol = json.loads(DEFAULTS.read_text())
    lr = protocol["learning_rate"]
    peak = config.get("peak_lr", lr["peak"])
    training = dict(protocol, epochs=settings.epochs, checkpoint_every_updates=settings.every)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    model = make_network(len(names), config, names).cuda()
    learned = sum(t.numel() for t in model.parameters())
    opt = torch.optim.AdamW(model.parameters(), lr=peak, weight_decay=config.get("weight_decay", protocol["weight_decay"]))
    schedule = torch.optim.lr_scheduler.ReduceLROnPlateau(opt, mode="min", factor=lr["plateau_factor"],
        patience=config.get("plateau_patience", lr["plateau_patience_evaluations"]), threshold=lr["min_relative_improvement"],
        min_lr=lr["minimum"])
    rng = torch.Generator().manual_seed(seed)
    sizes = epoch_batches(len(inputs[0]), training)
    total = settings.epochs*len(sizes)
    scheduler_kind = config.get("scheduler", "plateau")
    step = 0
    best = float("inf")
    best_state = None
    weights = torch.as_tensor(config.get("loss_targets", [1, 1, 1]), dtype=torch.float32, device="cuda").expand(24,3).clone()
    weights[:8, 0] *= config.get("early_price_weight", 1)
    weights[8:, 0] *= config.get("late_price_weight", 1)
    weights /= weights.mean()
    factor = config.get("ridge_anchor", 0)
    correction = [v*torch.as_tensor(factor, device="cuda") for v in anchor] if factor else [0.0]*len(inputs)
    if config.get("ridge_condition"):
        inputs = tuple(torch.cat((x,v), dim=-1) for x,v in zip(inputs,anchor))
    (path/"config.json").write_text(json.dumps(dict(case=config, seed=seed, training=training, parameters=learned,
                                                   features=names), indent=2))
    print("start", settings.stage, config["id"], seed, learned, flush=True)
    started = time.monotonic()
    with (path/"trajectory.csv").open("w", newline="") as log:
        writer = None

        def check():
            nonlocal best, best_state, writer
            val = predict(model, inputs[1], settings.deadline) + correction[1]
            value = criterion(val, targets[1], weights).item()
            row = dict(step=step, criterion=value, lr=opt.param_groups[0]["lr"], **measures(val, targets[1]))
            if writer is None:
                writer = csv.DictWriter(log, row.keys())
                writer.writeheader()
            writer.writerow(row)
            log.flush()
            if step >= lr["warmup_updates"] and scheduler_kind == "plateau":
                schedule.step(value)
            if value < best:
                best = value
                best_state = (step, {k: v.detach().clone() for k,v in model.state_dict().items()})

        check()
        for _ in range(settings.epochs):
            for batch in torch.randperm(len(inputs[0]), generator=rng).cuda().split(sizes):
                check_time(settings.deadline)
                step += 1
                if step <= lr["warmup_updates"]:
                    opt.param_groups[0]["lr"] = peak*step/lr["warmup_updates"]
                elif scheduler_kind == "cosine":
                    fraction = (step-lr["warmup_updates"])/(total-lr["warmup_updates"])
                    opt.param_groups[0]["lr"] = lr["minimum"]+(peak-lr["minimum"])*(1+math.cos(math.pi*fraction))/2
                model.train()
                opt.zero_grad(set_to_none=True)
                emitted = model(inputs[0][batch])
                if factor:
                    emitted = emitted + correction[0][batch]
                loss = criterion(emitted, targets[0][batch], weights)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), protocol["gradient_clip_norm"])
                opt.step()
                if step % settings.every == 0 or step == total:
                    check()
    selected, state = best_state
    model.load_state_dict(state)
    result = dict(id=config["id"], seed=seed, parameters=learned, selected=selected, criterion=best,
                  seconds=time.monotonic()-started)
    outputs = {}
    for i,split in enumerate(SPLITS,1):
        if split != "val" and not settings.test:
            break
        value = predict(model, inputs[i], settings.deadline) + correction[i]
        result[split] = measures(value, targets[i])
        if settings.keep:
            outputs[split] = value.cpu().numpy()
    if settings.keep:
        torch.save(dict(weights={k:v.cpu() for k,v in state.items()}, step=selected), path/"model.pt")
        np.savez_compressed(path/"predictions.npz", **outputs)
    temporary = path/"result.tmp"
    temporary.write_text(json.dumps(result, indent=2))
    temporary.replace(path/"result.json")
    print("done", settings.stage, config["id"], seed, selected, f"{result['val']['joint']:.6f}", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("manifest", type=Path)
    parser.add_argument("--stage", required=True)
    parser.add_argument("--seeds", type=int, nargs="+", default=[17])
    parser.add_argument("--epochs", type=int, default=5)
    parser.add_argument("--every", type=int, default=20)
    parser.add_argument("--deadline", type=float, required=True)
    parser.add_argument("--keep", action="store_true")
    parser.add_argument("--test", action="store_true")
    settings = parser.parse_args()
    torch.set_num_threads(2)
    torch.set_float32_matmul_precision("high")
    torch.backends.cudnn.benchmark = False
    manifest = json.loads(settings.manifest.read_text(encoding="utf-8"))
    x,y,names = datasets()
    write_reference(y)
    try:
        anchor = ridge_anchor(x) if any(v.get("ridge_anchor", 0) or v.get("ridge_condition") for v in manifest) else None
        baseline = v1_anchor(x, anchor, settings.deadline) if any(v.get("anchor_kind")=="v1" for v in manifest) else None
        for case in manifest:
            for seed in settings.seeds:
                fit(case, seed, settings, x, y, names, baseline if case.get("anchor_kind")=="v1" else anchor)
                torch.cuda.empty_cache()
    except BudgetExpired:
        print("Budget elapsed; complete runs are preserved.", flush=True)


if __name__ == "__main__":
    main()
