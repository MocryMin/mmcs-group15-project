"""Choose a reproducible confirmation set using only validation losses."""
import argparse
import json
from pathlib import Path

from evaluate import HERE, records, study_table


SINGLE_SEED = 17
FAMILIES = ("operators","readouts","ridge_residual","token_architectures","learned_skips",
            "scale_sweep","structured_operators","matched_architectures","ridge_conditioned",
            "deeper_scale","target_heads","target_streams","shape_and_training","v1_residual",
            "history_attention","fixed_demand")
METRICS = ("price_early","price_late","generation","demand_first","demand_late")


def load_screen():
    candidates = []
    for stage in FAMILIES:
        for folder, result in records(stage):
            if result["seed"] == SINGLE_SEED:
                cfg = json.loads((folder/"config.json").read_text())["case"]
                if not all(v == v for v in result["val"].values()):
                    continue
                if cfg.get("anchor_kind")=="v1" and result["selected"]==0:
                    continue
                candidates.append(dict(case=cfg, validation=result["val"], family=stage))
    return candidates


def promotion(candidates, existing, limit):
    candidates = [r for r in candidates if r["case"]["id"] not in existing]
    nominated = {}
    def add(record, reason):
        tag = record["case"]["id"]
        if tag not in existing and tag not in nominated and len(nominated) < limit:
            nominated[tag] = {**record, "reason":reason}
    joint = [r for r in candidates if min(r["case"].get("loss_targets",[1,1,1]))>0]
    by_joint = sorted(joint,key=lambda r:r["validation"]["joint"])
    for record in by_joint[:8]:
        add(record, "overall validation")
    for metric in METRICS:
        index = ("price","generation","demand").index(metric.split("_")[0])
        eligible = [r for r in candidates if r["case"].get("loss_targets",[1,1,1])[index]>0]
        ranked = sorted(eligible,key=lambda r:r["validation"][metric])
        for record in ranked[:2]:
            add(record,metric)
    for name in FAMILIES:
        matches = [r for r in by_joint if r["family"]==name]
        if matches:
            add(matches[0],"best in "+name)
    return list(nominated.values())


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("output",type=Path)
    cli.add_argument("--limit",type=int,default=20)
    cli.add_argument("--skip",type=Path,nargs="*",default=[])
    args = cli.parse_args()
    excluded={r["id"] for file in args.skip for r in json.loads(file.read_text(encoding="utf-8"))}
    pool = load_screen()
    chosen = promotion(pool, excluded, args.limit)
    args.output.write_text(json.dumps([v["case"] for v in chosen],indent=2))
    args.output.with_suffix(".selection.json").write_text(json.dumps(chosen,indent=2))
    study_table()
    print("Promoted",len(chosen),"of",len(pool),[(v["case"]["id"],v["reason"]) for v in chosen],flush=True)


if __name__ == "__main__":
    main()
