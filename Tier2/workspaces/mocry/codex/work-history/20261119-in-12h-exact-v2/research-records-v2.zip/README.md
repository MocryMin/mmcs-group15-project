# 固定特征的 Transformer 架构实验

实验时段为 2026-11-19 17:58:04 至 19:58:04 UTC。输入沿用 `in-12h-exact v1` 的 76 列，按交付半小时组成 24 行。特征依次为原有 59 列、路径形状、INDGEN 和 TSDF 数据块。数据取值与标准化沿用原版本。发电、需求和电价的输出尺度和季节基准也与 v1 一致。

训练用 2022–2024，验证用 2025 年 1–8 月。候选依据验证误差筛查。历史回放使用 2025 年 9–12 月及 2026 年 6–8 月。2026 年 1–5 月单独重建 v1 的输出作额外复核。前两个历史窗此前用于确定 v1 的方案。比较以生成完整 24 槽的三目标标准化均方误差为主，并记录各目标和关键提前量。

主训练设置是 AdamW、五轮、18 更新步预热及按验证误差降低学习率。首批复训每 10 步评估一次，其余筛选、匹配对照及复训主要采用每 24 步评估。普通候选使用三目标等权标准化 MSE。显式设置了目标或提前量权重的变体按其训练权重选择检查点，只在被训练的目标上有资格单独替换 v1 输出。三个种子的平均路径和各单种子结果分别记录，便于区分架构收益和集成收益。

锁定时以验证数据比较单一架构、三个架构平均、分目标替换及与 v1 凸组合。稳健组合按目标和提前量，将 2025 年 1–8 月分成四个连续双月块并要求每块均改善。仅改发电的版本取同一组合的发电分支，保留 v1 的价格和需求输出。七天区块重采样按同一天配对，同一起点的三个目标和全部提前量一起重采样。

## 目录入口

| 文件 | 内容 |
|:--|:--|
| `architecture.py` | 注意力位置表示、头数、归一化、前馈算子、跨槽及跨变量结构、轨迹读出 |
| `ops.json`、`heads.json`、`tokens.json` | 第一批算子、读出及输入轴结构筛选 |
| `anchor.json`、`skips.json`、`scaling.json` | 官方 76 列特征上的岭回归残差连接、全路径跳连、宽度和深度 |
| `shape_operators.json`、`matched_architectures.json` | 形状解码、局部和全局注意力头、专家前馈、同规模残差对照 |
| `mixing.json`、`target_exchange.json` | 同规模静态／频域槽位混合及目标读出交互对照 |
| `specialized_components.json`、`directional_attention.json` | 专用电价与需求分支、发电注意力方向对照 |
| `validation_runs.csv` | 每次完成的训练、参数量、选中更新步、验证误差 |
| `runs/` | 训练配置和验证轨迹。复核阶段留存实际权重及验证预测 |
| `baseline_v1.json` | 从 v1 冻结组件重新拼接得到的对照损失 |
| `REPORT_ZH.md`、`component_lock.json` | 实验综述与改善跨三个测试窗的分目标组合 |

从相邻项目已有的 CUDA Python 环境运行 `run.py <manifest> --stage <name> --seeds 17 29 43 --epochs 5 --every 24 --keep --deadline <UTC Unix time>`。候选锁定和预测回读依次使用 `evaluate.py lock --stage <name> --manifest <file>` 和 `evaluate.py replay --manifest <file> --deadline <UTC Unix time>`。锁定时记录每个已完成权重的 SHA-256，回读时重新核对。逐槽误差图、逐月误差与余缺预测诊断可用 `accuracy_profiles.py <lock>_paths.npz` 生成。

已锁定的分目标组合直接回读 `component_lock.json`。同权重六种子复训回读 `component_replication.json`。预测矩阵中的 `component_extension` 为组合输出，`v1` 是基准。合并全年、不同区块长度及权重敏感性由 `mixture_audit.py` 生成。
