"""Rebuild the Tier 2B preview evidence from frozen historical replays."""

from dataclasses import replace
from functools import partial
from pathlib import Path
import sys

import numpy as np
import pandas as pd
from scipy.special import expit


HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent
A = PROJECT / "tier2b-commitment-20-20261124"
B = PROJECT / "tier2b-b-battery-only-20261124"
CV = PROJECT / "tier2b-six-fold-20261123"
SOURCE = PROJECT / "tier1-halfhour-20261113-v7"
XPRESS = PROJECT / "tier1-xpress-full-20261124"
sys.path[:0] = [str(p) for p in (A, B, CV, XPRESS)]
from commitment import check_path, load
import site_model
from run import school_licence
from halfhour import rounded_commitment
import solver_adapter
from continuous import replay_exact
from replay import ANNUAL, ETA, H_DAILY, H_RATE, P, SLOTS, THROUGHPUT, E, allocate, baseline, njit, read, report, settle
from data import folds, load_labels, read_label_panel, study_rows
sys.path.insert(0, str(PROJECT / "tier2b-b-site-ordinal-20261122"))
import site_replay as site

YEARS = tuple(range(2021, 2027))
CAP = 10_000
FUEL = ("Biomass", "Hydro Run-of-river and poundage", "Solar", "Wind Onshore", "Wind Offshore")
PLANT_ANNUAL = 756537.1657447455


def load_data():
    frame = read_label_panel()
    date = pd.to_datetime(frame.utc, utc=True).dt.strftime("%Y-%m-%d")
    farm = frame.groupby(date).farm_flat_MW.mean()
    fuel = pd.read_csv(SOURCE / "source_data/tier1-multiproduct-20261110-v6/inputs/daily_generation_by_fuel.csv")
    renewable = fuel[fuel.psrType.isin(FUEL)].groupby("date").MW.sum()
    return (renewable + farm) * 24


def renewable_share(utc, actual, renewable_mwh):
    days = pd.to_datetime(utc[::SLOTS], unit="s").strftime("%Y-%m-%d")
    renewable = renewable_mwh.reindex(days).to_numpy()
    assert np.isfinite(renewable).all(), (days[~np.isfinite(renewable)], renewable_mwh.index[-1])
    share = renewable / actual[:, 1].reshape(-1, SLOTS).sum(1)
    assert np.all((share >= 0) & (share <= 1)), share.max()
    return np.repeat(share, SLOTS)


def history_features(utc, actual, origins):
    scales = np.array([60., 1800., 1800.])
    history = actual[origins[:, None] - np.array([1, 2, 4, 48, 336])]
    seasonal = np.mean([actual[origins[:, None] + np.array([-1, 0]) - 336*j]
                        for j in range(1, 5)], axis=0)
    times = utc[origins]
    phase = np.column_stack((times / 1800 % 48 / 48, ((times // 86400 + 3) % 7)/7,
                            pd.to_datetime(times,unit="s").dayofyear.to_numpy()/365.25))
    calendar = np.column_stack((np.sin(2*np.pi*phase), np.cos(2*np.pi*phase)))
    previous = history[:,0]
    prior = previous[:,1]-previous[:,2]
    features = np.column_stack((previous/scales,prior/1500,calendar,
                                ((previous[:,None]-history[:,1:])/scales).reshape(len(origins),-1),
                                seasonal[:,1]/scales,(seasonal[:,1]-seasonal[:,0])/scales))
    return features, prior


def actual_reference(actual, signal):
    return np.minimum(actual[:, 1], actual[:, 2]) * (signal > 0)


def operations(actual, q, h, charge, discharge, share, direct):
    g, d = actual[:, 1:].T
    unused = g + discharge - q - h - charge
    assert unused.min() > -1e-6, unused.min()
    h_from_generation = h - np.maximum(0., discharge - q)
    assert h_from_generation.min() > -1e-6
    captured = np.minimum(np.maximum(g - d, 0.), charge + h_from_generation)
    return dict(delivered_MWh=q.sum(), demand_MWh=d.sum(),
                unused_MWh=unused.sum(), renewable_capture_MWh=np.dot(captured, share),
                renewable_surplus_MWh=np.dot(np.maximum(g-d, 0.), share),
                hydrogen_t=h.sum() / 55.9,
                incremental_cash_GBP=float(np.dot(actual[:, 0], q-direct) + H_RATE*h.sum()))


@njit(cache=True)
def reactive(actual, signal, online, unit, floor, base, previous, price_threshold):
    """One-step orders driven by the last observations and a trailing price median."""
    n = len(actual)
    trace = np.zeros((n, 8))
    stock, remaining, used = 0., H_DAILY, 0.
    cycle_budget = THROUGHPUT * n / SLOTS
    for i in range(n):
        day, slot = i // SLOTS, i % SLOTS
        if slot == 0:
            remaining = H_DAILY
        low = floor * unit * online[day]
        high = max(low, min(unit * online[day], remaining - (SLOTS-1-slot)*low))
        prev_price, prev_g, prev_d = previous[i]
        if n-i <= SLOTS:
            order = P
        elif prev_g > prev_d + low and prev_price <= price_threshold[i]:
            order = -P
        elif prev_price > price_threshold[i]:
            order = P
        else:
            order = 0.
        price, g, d = actual[i]
        closing, c, r, h, q = settle(stock, order, E, g, d, signal[i], low, high,
                                     max(0., cycle_budget-used)/ETA)
        h0, q0 = base[i]
        trace[i] = stock, order, c, r, closing, q, h, price*(q-q0) + H_RATE*(h-h0)
        stock, used, remaining = closing, used + ETA*c, remaining-h
    return trace


def a_row(year, key, blocks, data, base, trace, share):
    row = report(year, blocks, key, data, base, trace)
    _, _, c, r, _, q, h, _ = trace.T
    direct = actual_reference(data["actual"], data["signal"])
    op = operations(data["actual"], q, h, c, r, share, direct)
    plant_cost = float(data["fleet"]) * PLANT_ANNUAL * row["days"] / 365
    net = op["incremental_cash_GBP"] - plant_cost - row["battery_annual_equiv_cost_GBP"]
    np.testing.assert_allclose(net, row["portfolio_net_GBP"], rtol=0, atol=1e-5)
    return dict(policy="A", case=key, **row, plant_cost_GBP=plant_cost, **op)


def zero_oracle(year, template, data, share):
    actual = data["actual"]
    p, g, d = actual.T.reshape(3, -1, SLOTS)
    nd = len(p)
    dates = pd.to_datetime(data["utc"][::SLOTS], unit="s")
    plant = replace(template, G=g, D=d, p=p, dates=dates.strftime("%Y-%m-%d"),
                    year=dates.year.to_numpy(), years_equiv=nd/365)
    floor, fleet = float(data["load_floor"]), int(data["fleet"])
    val = site_model.value_table(plant, "A", floor, fleet, CAP)
    path, info = site_model.commit(val, 4, time_limit=30)
    assert not check_path(path, 4, np.isfinite(val))
    assert abs(info["gap"]) <= 0.05, info
    h = site_model.day_dispatch(plant, "A", floor, path, CAP)["h"].ravel()
    q = np.minimum(g.ravel()-h, d.ravel()) * (p.ravel() >= 0.)
    direct = actual_reference(actual, data["signal"])
    op = operations(actual, q, h, np.zeros(len(actual)), np.zeros(len(actual)), share, direct)
    plant_cost = fleet * PLANT_ANNUAL * nd/365
    np.testing.assert_allclose(site_model.reference(plant, "A")["receipts"] * plant.years_equiv +
                               info["objective"], np.dot(actual[:,0], q) + H_RATE*h.sum(), atol=.03, rtol=0)
    return dict(policy="A", case="plant_oracle", test_end_year=year, blocks=0, days=nd,
                electrolyser_units=fleet, gross_battery_GBP=0., battery_annual_equiv_cost_GBP=0.,
                net_battery_GBP=0., portfolio_net_GBP=op["incremental_cash_GBP"]-plant_cost,
                plant_cost_GBP=plant_cost, oracle_gap_GBP=info["gap"], **op)


def b_row(year, key, blocks, utc, actual, gate, share):
    window = site.Window(utc, actual, blocks, 0)
    cash, trace = site.run(window, np.where(gate, -window.power, window.power), audit=True, require_empty=False)
    _, _, c, sale, _, _, h, _ = trace.T
    direct = np.minimum(actual[:, 1], actual[:, 2])
    op = operations(actual, direct+sale, h, c, sale, share, direct)
    cost = ANNUAL * blocks * window.days / 365
    assert abs(cash.sum() - op["incremental_cash_GBP"]) < 1e-4
    return dict(policy="B", case=key, test_end_year=year, blocks=blocks, days=window.days,
                electrolyser_units=0, gross_battery_GBP=cash.sum(), battery_annual_equiv_cost_GBP=cost,
                net_battery_GBP=cash.sum()-cost, portfolio_net_GBP=cash.sum()-cost, plant_cost_GBP=0.,
                accuracy=np.mean(gate == (actual[:, 1]>=actual[:, 2])), **op), trace


def daily_trace(data, a, b, share):
    utc, actual, signal = (data[k] for k in ("utc", "actual", "signal"))
    p, g, d = actual.T
    a_increment = a[:, -1] - ANNUAL/(365*SLOTS)
    b_increment = b[:, -1] - ANNUAL/(365*SLOTS)
    _, _, _, _, _, sales, h, _ = a.T
    return pd.DataFrame(dict(day=pd.to_datetime(utc, unit="s").floor("D"),
                             price=p, renewable_MWh=g*share, demand_MWh=d,
                             physical_surplus_MWh=np.maximum(g-d,0.),
                             a_charge_MWh=a[:,2], a_discharge_MWh=a[:,3],
                             b_charge_MWh=b[:,2], b_discharge_MWh=b[:,3],
                             a_net_GBP=a_increment, b_net_GBP=b_increment,
                             a_portfolio_GBP=p*(sales-actual_reference(actual, signal))+
                                H_RATE*h-(ANNUAL+6*PLANT_ANNUAL)/(365*SLOTS)
                             )).groupby("day").agg({"price":"mean", **{k:"sum" for k in
                               ("renewable_MWh","demand_MWh","physical_surplus_MWh","a_charge_MWh","a_discharge_MWh",
                                "b_charge_MWh","b_discharge_MWh","a_net_GBP","b_net_GBP","a_portfolio_GBP")}})


def paths_from_panel(utc, data, panel, history):
    indices = np.searchsorted(panel["utc"], utc)
    np.testing.assert_array_equal(panel["utc"][indices], utc)
    book = panel["quotes"][indices]
    seasonal = np.maximum(panel["seasonal"][indices].astype(float), [-np.inf, 0., 0.])
    truth_indices = np.minimum(indices[:, None] + np.arange(24), indices[-1])
    truth = panel["truth"][indices].astype(float).copy()
    # Near the window end the controller requests discharge without using these paths.
    truth[-23:] = panel["truth"][truth_indices[-23:], 0]
    np.testing.assert_allclose(truth[:,0], data["actual"], rtol=1e-6, atol=1e-5)
    last = np.searchsorted(history.index.to_numpy(), utc)
    np.testing.assert_array_equal(history.index.to_numpy()[last], utc)
    previous = history.iloc[last-1][["p","g","d"]].to_numpy()
    threshold = history["trailing"].iloc[last-1].to_numpy()
    assert np.isfinite(threshold).all()
    return indices, book, seasonal, truth, previous, threshold


def run_replays():
    renewable = load_data()
    panel = dict(np.load(CV / "panels.npz"))
    history = pd.DataFrame(panel["history_actual"], columns=["p","g","d"], index=panel["history_utc"])
    history["trailing"] = history.p.rolling(7*SLOTS).median()
    full_utc, full_actual = load_labels()
    selection = study_rows(full_utc)
    features, prior = history_features(full_utc, full_actual, selection)
    b_folds = {fold.year:fold.test for fold in folds(full_utc[selection])}
    a_source = pd.read_csv(A/"six-fold-capacity-replay.csv").set_index(["policy","test_end_year","blocks"])
    a_rows, b_rows, daily, forecast = [], [], [], []
    for year in YEARS:
        data = read(year)
        utc, actual, signal, path = (data[k] for k in ("utc","actual","signal","path"))
        share = renewable_share(utc, actual, renewable)
        online, tomorrow = data["online"], data["planned_tomorrow"]
        unit, floor = float(data["module_slot_mwh"]), float(data["load_floor"])
        base = baseline(actual, signal, online, unit, floor)
        indices, book, seasonal, truth, previous, threshold = paths_from_panel(utc, data, panel, history)
        with np.load(CV/"folds"/str(year)/"paths.npz") as model:
            v2 = np.maximum(model["v2"][indices].astype(float), [-np.inf, 0., 0.])
        mix = v2.copy()
        known = np.isfinite(book[:,:8])
        mix[:,:8,0][known] = .75*mix[:,:8,0][known] + .25*book[:,:8][known]
        zero = np.zeros((len(actual), 8))
        zero[:,5:7] = base[:,::-1]
        a_rows.append(a_row(year, "forecast_plant", 0, data, base, zero, share))
        for blocks in (1, 11):
            ledger_path = A/f"ledger-{year}-{blocks}-continuous.npz"
            if ledger_path.exists():
                with np.load(ledger_path) as ledger:
                    np.testing.assert_array_equal(ledger["utc"], utc)
                    trace = ledger["trace"]
            else:
                trace = replay_exact(actual, signal, path, online, tomorrow, unit, floor, base, blocks)
            row = a_row(year,"selected",blocks,data,base,trace,share)
            np.testing.assert_allclose(row["portfolio_net_GBP"], a_source.loc[("A",year,blocks),"portfolio_net_GBP"],
                                       rtol=0,atol=1e-5)
            a_rows.append(row)
            if blocks == 1:
                a_selected, selected_row = trace, row
        for name, f in (("weekday",seasonal),("uncorrected",v2),("quote_mix",mix),("selected",path),
                        ("twelve_hour_truth",truth)):
            error = np.abs(f[:-23]-truth[:-23]).mean((0,1))
            if name == "selected":
                row = selected_row
            else:
                trace = replay_exact(actual, signal, f, online, tomorrow, unit, floor, base, 1)
                row = a_row(year,name,1,data,base,trace,share)
                a_rows.append(row)
            forecast.append(dict(policy="A", case=name, year=year, price_mae=error[0],
                                 generation_mae=error[1], demand_mae=error[2], net_GBP=row["net_battery_GBP"]))
        trace = reactive(actual,signal,online,unit,floor,base,previous,threshold)
        a_rows.append(a_row(year,"reactive",1,data,base,trace,share))
        ids = b_folds[year]
        np.testing.assert_array_equal(full_utc[selection][ids], utc)
        b_actual = full_actual[selection][ids]
        np.testing.assert_allclose(b_actual, actual, atol=1e-5, rtol=1e-6)
        with np.load(B/f"gate-b-{year}.npz") as model:
            design = np.c_[np.ones(len(ids)),np.clip((features[ids]-model["centre"])/model["spread"],-5,5)]
            gate = expit(prior[ids]/400 + design @ model["coefficients"]) >= .5
        past_gate, true_gate = prior[ids]>=0., b_actual[:,1]>=b_actual[:,2]
        for name, n, choice in (("direct",0,gate),("selected",1,gate),("previous_slot",1,past_gate),
                                ("truth_gate",1,true_gate),("selected",9,gate),("selected",11,gate)):
            row, trace = b_row(year,name,n,utc,b_actual,choice,share)
            if name == "selected":
                np.testing.assert_allclose(row["net_battery_GBP"],a_source.loc[("B",year,n),"net_battery_GBP"],
                                           rtol=0,atol=1e-5)
            if n == 1:
                forecast.append(dict(policy="B",case=name,year=year,accuracy=row["accuracy"],net_GBP=row["net_battery_GBP"]))
                if name == "selected":
                    b_selected=trace
            b_rows.append(row)
        daily.append(daily_trace(data,a_selected,b_selected,share))
        print(year, "replayed forecast variants and checked archival cash", flush=True)
    pd.DataFrame(a_rows+b_rows).to_csv(HERE/"evidence/replays.csv",index=False)
    pd.DataFrame(forecast).to_csv(HERE/"evidence/forecast-value.csv",index=False)
    pd.concat(daily).to_csv(HERE/"evidence/daily-operation.csv")


def run_oracle():
    renewable = load_data()
    template = load(SOURCE)
    site_model.milp = partial(rounded_commitment, solver_adapter)
    out = []
    with school_licence():
        for year in YEARS:
            data = read(year)
            out.append(zero_oracle(year, template, data, renewable_share(data["utc"],data["actual"],renewable)))
            print(year, "Xpress plant oracle", out[-1]["portfolio_net_GBP"],flush=True)
    pd.DataFrame(out).to_csv(HERE/"evidence/plant-oracle.csv",index=False)


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "oracle":
        run_oracle()
    else:
        run_replays()

