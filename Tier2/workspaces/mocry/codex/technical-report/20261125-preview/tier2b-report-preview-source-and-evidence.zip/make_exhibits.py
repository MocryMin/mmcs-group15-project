"""Generate figures and LaTeX tables from the verified Tier 2B evidence."""

from pathlib import Path
import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, Rectangle
import numpy as np
import pandas as pd


HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent
EV = HERE / "evidence"
FIG = HERE / "figures"
A = PROJECT / "tier2b-commitment-20-20261124"
B = PROJECT / "tier2b-b-battery-only-20261124"
YEARS = list(range(2021, 2027))
M = 1e6

rc = {"font.family":"DejaVu Serif","font.size":8.5,"axes.labelsize":8.5,"axes.titlesize":9,
      "axes.spines.top":False,"axes.spines.right":False,"axes.linewidth":.65,
      "xtick.major.width":.65,"ytick.major.width":.65,"pdf.fonttype":42}
plt.rcParams.update(rc)
BLUE, RED, GRAY = "#1c4558", "#8a422f", "#4e5458"


def write(name, body):
    (EV / f"{name}.tex").write_text(body+"\n", encoding="utf-8")


def table(name, cols, head, rows):
    end = r" \\"
    body = [rf"\begin{{tabularx}}{{\linewidth}}{{@{{}}{cols}@{{}}}}",r"\toprule",
            " & ".join(head)+end,r"\midrule"]
    for row in rows:
        if isinstance(row,str):
            body.append(row)
        else:
            body.append(" & ".join(row)+end)
    body += [r"\bottomrule", r"\end{tabularx}"]
    write(name,"\n".join(body))


def num(x, digits=2, signed=False):
    if not np.isfinite(x):
        return "--"
    f=f"{x:+,.{digits}f}" if signed else f"{x:,.{digits}f}"
    return f.replace("-",r"\ensuremath{-}")


def uk(year):
    return f"{year-1}/{str(year)[-2:]}"


def figures(sweep, daily):
    fig, ax = plt.subplots(figsize=(6.45,1.43))
    fig.subplots_adjust(left=.005,right=.996,bottom=.01,top=.98)
    ax.set(xlim=(0,632),ylim=(-7,136))
    ax.axis("off")
    layout = [
        (5, 185, "00:00 UTC", "A sets today's online count",
         ["4-day outlook", "12 h model + 84 h history"]),
        (224,185,"Start of half-hour t","Submit battery order",
         ["Stock and past observations", "A: 12 h paths; B: surplus sign"]),
        (442,185,"After the half-hour","Settle feasible delivery",
         ["Realised price, output, load", "Update stock and offtake"])
    ]
    for x,w,tag,name,details in layout:
        ax.add_patch(Rectangle((x,31),w,96,facecolor="#f5f6f6",edgecolor="#7b8388",lw=.65))
        ax.text(x+8,112,tag,fontsize=8.5,fontweight="bold",va="center")
        ax.text(x+8,88,name,fontsize=8.2,fontweight="bold",va="center")
        ax.text(x+8,62,"\n".join(details),fontsize=7.8,va="center",linespacing=1.45)
    for x in (191,410):
        ax.add_patch(FancyArrowPatch((x,79),(x+32,79),arrowstyle="-|>",mutation_scale=9,color=GRAY,lw=.8))
    ax.add_patch(FancyArrowPatch((529,30),(318,30),connectionstyle="arc3,rad=-.23",
                                 arrowstyle="-|>",mutation_scale=9,color=GRAY,lw=.7))
    ax.text(424,-5,"Next half-hour",ha="center",va="bottom",fontsize=7.5,
            bbox=dict(facecolor="white",edgecolor="none",pad=1.0))
    fig.savefig(FIG/"timing.pdf")
    plt.close(fig)

    fig, axes = plt.subplots(1,2,figsize=(6.45,2.45),sharex=True,sharey=True)
    fig.subplots_adjust(left=.095,right=.99,top=.90,bottom=.31,wspace=.13)
    for pol, ax, t1 in zip("AB",axes,(45,9)):
        z = sweep[sweep.policy.eq(pol)].pivot(index="blocks",columns="test_end_year",values="net_battery_GBP")/M
        for year in YEARS[:-1]:
            ax.plot(z.index,z[year],c="#aeb5ba",lw=.80,zorder=1)
        shock,=ax.plot(z.index,z[2022],c=RED,lw=1.18,ls=(0,(3,2)),label="2021/22")
        latest,=ax.plot(z.index,z[2026],c=BLUE,lw=1.35,label="2025/26")
        pooled,=ax.plot(z.index,z.mean(axis=1),c="#242424",lw=1.35,label="All-window mean")
        other,=ax.plot(z.index,z.drop(columns=2022).mean(axis=1),c=GRAY,lw=1.2,ls=":",label="Mean excluding 2021/22")
        ax.scatter([z[2026].idxmax(),11], [z[2026].max(), z.loc[11].mean()], c=[BLUE,"#242424"],s=18,zorder=8)
        ax.axvline(t1,color="#727374",lw=.6,ls="--")
        ax.text(t1 - (1 if t1==45 else 0),.69 if t1==45 else .94,f"Tier 1: {t1}",transform=ax.get_xaxis_transform(),
                fontsize=7,ha="right" if t1==45 else "center", va="top")
        ax.axhline(0,c="#999999",lw=.6)
        ax.set(xlim=(0,45),xticks=[0,10,20,30,40], title=f"Policy {pol}",ylim=(-150,160))
        ax.grid(axis="y",color="#dddddd",lw=.40)
        ax.set_axisbelow(True)
    axes[0].set_ylabel("Net battery gain (£m)")
    fig.supxlabel("Battery blocks installed",y=.177,fontsize=8.4)
    fig.legend(handles=[latest,pooled,shock,other],loc="lower center",bbox_to_anchor=(.52,-.001),
               ncol=2,frameon=False,fontsize=7.6,columnspacing=1.4)
    fig.savefig(FIG/"capacity.pdf")
    plt.close(fig)

    fig, axes = plt.subplots(1,2,figsize=(6.45,1.88),sharey=True)
    fig.subplots_adjust(left=.102,right=.99,top=.91,bottom=.32,wspace=.12)
    for name,ax in zip("ab",axes):
        values=[daily.loc[mask].groupby("season")[f"{name}_net_GBP"].mean()
                 .reindex(["Autumn","Winter","Spring","Summer"])/1000
                 for mask in (daily.window.ne(2022),daily.window.eq(2022))]
        x=np.arange(4)
        label1=ax.bar(x-.19,values[0],width=.37, color="#8a979c",label="Other five windows")
        label2=ax.bar(x+.19,values[1],width=.37, color=RED,label="2021/22")
        ax.axhline(0,c="#585858",lw=.65)
        ax.grid(axis="y",color="#ddd",lw=.5)
        ax.set_axisbelow(True)
        ax.set(xticks=x,xticklabels=values[0].index,title=f"Policy {name.upper()}")
    axes[0].set_ylabel("Net gain (£k/day)")
    fig.legend([label1,label2],["Other five windows","2021/22"],loc="lower center",
               bbox_to_anchor=(.53,.0),ncol=2,frameon=False,fontsize=7.6)
    fig.savefig(FIG/"seasonal.pdf")
    plt.close(fig)


def main():
    led=pd.read_csv(EV/"replays.csv")
    oracle=pd.read_csv(EV/"plant-oracle.csv")
    led=pd.concat([led,oracle],ignore_index=True)
    f=pd.read_csv(EV/"forecast-value.csv")
    s=pd.read_csv(EV/"six-fold-capacity-replay.csv")
    d=pd.read_csv(EV/"daily-operation.csv",parse_dates=["day"])
    d["window"]=d.day.dt.year + (d.day.dt.month>=9).astype(int)
    d["season"]=d.day.dt.month.map(dict.fromkeys([9,10,11],"Autumn") |
                                   dict.fromkeys([12,1,2],"Winter") |
                                   dict.fromkeys([3,4,5],"Spring") |
                                   dict.fromkeys([6,7,8],"Summer"))
    figures(s,d)
    plant=led[(led.policy=="A") & (led.case=="forecast_plant")]
    one=led[(led.policy=="A") & (led.case=="selected") & (led.blocks==1)]
    stats={"PlantNet":plant.portfolio_net_GBP.mean()/M,
           "PlantOracle":oracle.portfolio_net_GBP.mean()/M,
           "AOnePortfolio":one.portfolio_net_GBP.mean()/M,
           "AWorstZero":plant.portfolio_net_GBP.min()/M,
           "AWorstOne":one.portfolio_net_GBP.min()/M,
           "AShock":one.loc[one.test_end_year.eq(2022),"net_battery_GBP"].item()/M,
           "ALeaveLoss":-one.loc[one.test_end_year.ne(2022),"net_battery_GBP"].sum()/M,
           "RefA":s.loc[s.policy.eq("A") & s.test_end_year.eq(2026),"net_battery_GBP"].max()/M,
           "RefB":s.loc[s.policy.eq("B") & s.test_end_year.eq(2026),"net_battery_GBP"].max()/M}
    vals=[rf"\newcommand{{\{key}}}{{{num(v)}}}" for key,v in stats.items()]
    recs = [
        ("A","forecast_plant",0,"A: plant, forecast"),
        ("A","plant_oracle",0,"A: plant oracle"),
        ("A","reactive",1,"A: reactive rule"),
        ("A","selected",1,"A: rolling forecast"),
        ("A","twelve_hour_truth",1,"A: 12 h truth paths"),
        ("A","selected",11,"A: rolling forecast"),
        ("B","direct",0,"B: direct sales"),
        ("B","previous_slot",1,"B: prior-slot rule"),
        ("B","selected",1,"B: classifier"),
        ("B","truth_gate",1,"B: true surplus sign"),
        ("B","selected",9,"B: classifier"),
    ]
    rows=[]
    for p,case,blocks,label in recs:
        if case=="direct":
            rows.append(r"\midrule")
        g=led[(led.policy==p) & (led.case==case) & (led.blocks==blocks)]
        assert len(g)==6
        m=g.mean(numeric_only=True)
        supply=100*g.delivered_MWh.sum()/g.demand_MWh.sum()
        values=[m.incremental_cash_GBP/M,m.battery_annual_equiv_cost_GBP/M,m.portfolio_net_GBP/M,
                supply,m.unused_MWh/1000,m.renewable_capture_MWh/1000,m.hydrogen_t/1000]
        rows.append([label,str(blocks)]+[num(value,digits) for value,digits in zip(values,[2,2,2,3,1,1,2])])
    table("main-table","Yrrrrrrrr",
          ["Case and controller","Blocks","Gross","Batt. cost","Net",r"Served (\%)",
           r"Unused (GWh)",r"RE (GWh)",r"H$_2$ (kt)"], rows)

    rows=[]
    out=[]
    for yr in YEARS+[None]:
        oracle_mask=oracle.test_end_year.eq(yr) if yr is not None else oracle.test_end_year.ne(-1)
        oracle_value=oracle.loc[oracle_mask,"portfolio_net_GBP"].mean()/M
        mask=s.test_end_year.eq(yr) if yr is not None else s.test_end_year.ne(-1)
        p_mask=plant.test_end_year.eq(yr) if yr is not None else plant.test_end_year.ne(-1)
        a0=plant.loc[p_mask,"portfolio_net_GBP"].mean()/M
        values=[a0,oracle_value]+[s.loc[mask & s.policy.eq(p) & s.blocks.eq(n),"net_battery_GBP"].mean()/M
                     for p,n in (("A",1),("A",11),("B",1),("B",11))]
        out.append([yr]+values)
        if yr is None:
            rows.append(r"\midrule")
        rows.append([uk(yr) if yr else "Mean"]+[num(x) for x in values])
    table("windows-table","Yrrrrrr",
          ["Window","A: plant","A: plant oracle","A: +1 block","A: +11 blocks","B: 1 block","B: 11 blocks"],rows)

    stress=[]
    rows=[]
    choices=[("Low renewable output","renewable_MWh","min"),("High renewable output","renewable_MWh","max"),
             ("High demand","demand_MWh","max"),("High price","price","max")]
    for label,key,extreme in choices:
        roll=d.groupby("window")[key].transform(lambda x:x.rolling(7).mean())
        end=roll.idxmin() if extreme=="min" else roll.idxmax()
        week=d.iloc[end-6:end+1]
        assert week.window.nunique()==1 and len(week)==7
        first,last=week.day.iloc[[0,-1]]
        when=f"{first.day}--{last.day} {last:%b %Y}" if first.month==last.month else f"{first:%d %b}--{last:%d %b %Y}"
        raw=(label,first,last,week.renewable_MWh.mean()/1000,week.demand_MWh.mean()/1000,
             week.price.mean(),week.physical_surplus_MWh.mean()/1000,
             week.a_net_GBP.sum()/1000,week.b_net_GBP.sum()/1000)
        stress.append(raw)
        rows.append([label.replace("renewable output","renewables"),when,num(raw[3],0),num(raw[4],0),num(raw[5],0),num(raw[7],0),num(raw[8],0)])
    table("stress-table","YYrrrrr",["Condition","Week in UTC","RE (GWh)","Load (GWh)",
          r"Price (\gbp/MWh)",r"A (\gbp k)",r"B (\gbp k)"], rows)
    pd.DataFrame(stress,columns=["condition","from","to","renewable_GWh_day","demand_GWh_day",
                                 "mean_price","surplus_GWh_day","A_net_kGBP","B_net_kGBP"]).to_csv(EV/"stress-weeks.csv",index=False)
    vals.append(r"\newcommand{\StressReading}{The low-renewable week had no physical surplus and "
                r"both batteries lost money after ownership cost. High demand can coexist with surplus "
                r"at other times of the day, so its weekly mean does not determine battery value. "
                r"In the highest-price week A lost \gbp "+num(-stress[3][7],0)+r"k while B gained \gbp "+
                num(stress[3][8],0)+r"k. Under supply priority, charging uses otherwise unused energy. "
                r"Under economic dispatch, charging can displace a valuable sale or hydrogen output. "
                r"The net gain depends on the timing and opportunity cost of both actions.}")

    config=json.loads((PROJECT/"publication-20261119/tier1/tier2b-equipment.json").read_text(encoding="utf-8"))
    battery=config["battery"]
    annual=float(battery["cost_scenarios"][0]["annual_total_GBP"])
    installed=float(battery["capital_cost_low_GBP"])
    capital_rate=annual/installed
    data=[]
    for p in "AB":
        rows_one=led[(led.policy==p)&(led.case=="selected")&(led.blocks==1)]
        for label,g in (("All six windows",rows_one),("Without 2021/22",rows_one[rows_one.test_end_year.ne(2022)])):
            gross=g.gross_battery_GBP.sum()*365/g.days.sum()
            data.append((p,label,gross/M,gross/capital_rate/400_000))
    p0=plant
    h2_break=(p0.hydrogen_t.sum()*1000*7.7990270551508845-p0.portfolio_net_GBP.sum())/(p0.hydrogen_t.sum()*1000)
    pd.DataFrame(data,columns=["policy","sample","break_even_GBPm_year","break_even_GBP_kWh"]).to_csv(EV/"break-even.csv",index=False)
    a0,a5,b0,b5=[p[3] for p in data]
    rows=[
        ["First-block capital",r"At the \gbp "+num(installed/400_000,0)+
         r"/kWh base cost, the six-window break-even prices are \gbp "
         +num(a0,0)+r"/kWh in A and \gbp "+num(b0,0)+r"/kWh in B."],
        ["Without 2021/22",r"Break-even capital falls to \gbp "+num(a5,0)+r"/kWh in A and \gbp "+
         num(b5,0)+r"/kWh in B. All positive counts lose at the base cost."],
        ["Hydrogen receipt",r"The six-module fixed replay breaks even at \gbp "+num(h2_break)+
         r"/kg. Tier 1 reoptimisation at \gbp 2.50/kg selects no plant and at \gbp 9.50/kg selects seven modules."],
        ["Capacity commitment",r"The seven- and 22-block peaks use a single window. Eleven blocks under either policy use all six windows for selection. An investment decision should reflect the frequency of 2021/22-type conditions."],
    ]
    table("boundaries-table",r"P{34mm}Y",["Condition","Implication for the investment decision"],rows)

    rows=[]
    cases=[("A","weekday","A: four matching weekdays"),("A","uncorrected","A: uncorrected v2"),
           ("A","quote_mix","A: v2 plus auction mix"),("A","selected","A: mix plus Huber correction"),
           ("A","twelve_hour_truth","A: realised 12 h paths"),("B","previous_slot","B: previous-slot sign"),
           ("B","selected","B: weighted classifier"),("B","truth_gate","B: true surplus sign")]
    for p,case,label in cases:
        g=f[(f.policy==p)&(f.case==case)].mean(numeric_only=True)
        if case=="previous_slot":
            rows.append(r"\midrule")
        rows.append([label]+[num(g[k]*(100 if k=="accuracy" else 1),n) for k,n in
                             zip(["price_mae","generation_mae","demand_mae","accuracy"],[2,0,0,2])]
                    +[num(g.net_GBP/M)])
    table("forecast-table","Yrrrrr",["Input to controller",r"Price (\gbp/MWh)","Gen. (MWh)","Load (MWh)",
          r"Sign (\%)",r"Net (\gbp m)"],rows)
    p=f.pivot(index="year",columns=["policy","case"],values="net_GBP")
    deltas=p["B","previous_slot"]-p["B","selected"]
    assert (deltas>0).all()
    vals.append(r"\newcommand{\ForecastReading}{In A the price modifications improve both path accuracy "
                r"and realised value, with the Huber step adding only \gbp 0.02m per window over the auction mix. "
                r"In B the classifier has higher sign accuracy but earns \gbp "+num(deltas.mean()/M)+
                r"m less per window than the previous-slot rule. The simple rule earns more in all six one-block "
                r"replays. Classification accuracy gives each slot equal weight, whereas a wrong order at a high-value "
                r"shortfall can matter more than many correct orders.}")
    write("values","\n".join(vals))


if __name__ == "__main__":
    main()

