"""Send the frozen Tier 1 sparse models to Xpress without rebuilding their rows."""

from enum import Enum, IntEnum
from types import SimpleNamespace

import numpy as np
import xpress as xp


kHighsInf = np.inf


class HighsModelStatus(Enum):
    kOptimal = "Xpress optimal"
    kTimeLimit = "Xpress time limit"
    kInfeasible = "Xpress infeasible"
    kUnknown = "Xpress did not prove optimality"

    def __str__(self):
        return self.value


class HighsVarType(IntEnum):
    kContinuous = 0
    kInteger = 1


MatrixFormat = SimpleNamespace(kColwise="colwise")


class HighsLp(SimpleNamespace):
    def __init__(self):
        super().__init__(a_matrix_=SimpleNamespace(), offset_=0.)


HighsSolution = SimpleNamespace


def row_parameters(lower, upper):
    lower, upper = np.asarray(lower, float), np.asarray(upper, float)
    has_lower, has_upper = np.isfinite(lower), np.isfinite(upper)
    ranged = has_lower & has_upper & (lower != upper)
    kinds = np.select(
        [ranged, has_lower & has_upper, has_upper, has_lower],
        ["R", "E", "L", "G"], default="N",
    )
    rhs = np.where(has_upper, upper, np.where(has_lower, lower, 0.))
    width = np.zeros(len(rhs))
    width[ranged] = upper[ranged] - lower[ranged]
    return "".join(kinds), rhs, width if ranged.any() else None


class Highs:
    """Implement only the optimiser calls used by the archived model builders."""

    def __init__(self):
        self.problem = xp.problem()
        self.problem.controls.outputlog = 0
        self.options = {}
        self.integer_columns = set()
        self.last_mode = None
        self.total_counts = [0, 0]

    def setOptionValue(self, name, value):
        self.options[name] = value

    def passModel(self, lp):
        self.total_counts = [lp.num_col_, lp.num_row_]
        rowtype, rhs, rng = row_parameters(lp.row_lower_, lp.row_upper_)
        matrix = lp.a_matrix_
        self.problem.loadLP(
            rowtype=rowtype, rhs=rhs, rng=rng, objcoef=lp.col_cost_,
            start=matrix.start_, rowind=matrix.index_, rowcoef=matrix.value_,
            lb=np.maximum(lp.col_lower_, -xp.infinity), ub=np.minimum(lp.col_upper_, xp.infinity),
        )
        if lp.offset_:
            # Xpress stores the negative of OBJRHS in the objective constant.
            self.problem.chgObj([-1], [-lp.offset_])

    def changeColsIntegrality(self, count, columns, kinds):
        assert count == len(columns) == len(kinds)
        self.problem.chgColType(columns, "".join("I" if k else "C" for k in kinds))
        for c, k in zip(columns, kinds):
            if k:
                self.integer_columns.add(int(c))
            else:
                self.integer_columns.discard(int(c))

    def changeColIntegrality(self, column, kind):
        self.changeColsIntegrality(1, [column], [kind])

    def changeColsBounds(self, count, columns, lower, upper):
        assert count == len(columns) == len(lower) == len(upper)
        fixed = np.array_equal(lower, upper)
        ids = columns if fixed else np.tile(columns, 2)
        values = lower if fixed else np.r_[lower, upper]
        self.problem.chgBounds(ids, "B" * count if fixed else "L" * count + "U" * count,
                               np.clip(values, -xp.infinity, xp.infinity))

    def changeColBounds(self, column, lower, upper):
        self.changeColsBounds(1, [column], [lower], [upper])

    def changeColCost(self, column, cost):
        self.problem.chgObj([column], [cost])

    def addVars(self, count, lower, upper):
        assert count == len(lower) == len(upper)
        self.problem.addCols(objcoef=np.zeros(count), lb=lower, ub=upper)
        self.total_counts[0] += count

    def addVar(self, lower, upper):
        self.addVars(1, [lower], [upper])

    def addRows(self, count, lower, upper, nnz, starts, columns, coefficients):
        assert count == len(lower) == len(upper) and nnz == len(columns)
        kinds, rhs, width = row_parameters(lower, upper)
        self.problem.addRows(kinds, rhs, width, starts, columns, coefficients)
        self.total_counts[1] += count

    def addRow(self, lower, upper, nnz, columns, coefficients):
        self.addRows(1, [lower], [upper], nnz, [0, nnz], columns, coefficients)

    def run(self):
        controls = self.problem.controls
        controls.threads = self.options.get("threads", 1)
        controls.maxtime = -max(1, round(self.options.get("time_limit", 120.)))
        controls.feastol = 1e-8
        controls.optimalitytol = 1e-8
        controls.miptol = self.options.get("mip_feasibility_tolerance", 1e-7)
        controls.miprelstop = self.options.get("mip_rel_gap", 1e-8)
        controls.mipabsstop = self.options.get("mip_abs_gap", 1e-7)
        controls.mipaddcutoff = 0.
        controls.miprelcutoff = 0.
        if self.options.get("xpress_log"):
            controls.outputlog = 1
            self.problem.setLogFile(str(self.options["xpress_log"]))
        self.last_mode = "MIP" if self.integer_columns else "LP"
        if self.integer_columns:
            self.problem.mipOptimize()
        else:
            mode = self.options.get("solver", "choose")
            flags = self.options.get("xpress_lp_flags", {"ipm": "b", "simplex": "d"}.get(mode, ""))
            self.problem.lpOptimize(flags)
        status = self.problem.attributes.solstatus
        self.status = status
        self.value = None
        if status in (xp.SolStatus.OPTIMAL, xp.SolStatus.FEASIBLE):
            self.value = float(self.problem.attributes.mipobjval if self.integer_columns
                               else self.problem.attributes.lpobjval)
        self.best_bound = float(self.problem.attributes.bestbound) if self.integer_columns else (
            self.value if status == xp.SolStatus.OPTIMAL else None
        )

    def getModelStatus(self):
        if self.status == xp.SolStatus.OPTIMAL:
            return HighsModelStatus.kOptimal
        if self.status == xp.SolStatus.INFEASIBLE:
            return HighsModelStatus.kInfeasible
        if self.status == xp.SolStatus.FEASIBLE:
            return HighsModelStatus.kTimeLimit
        return HighsModelStatus.kUnknown

    def getSolution(self):
        valid = self.value is not None
        dual = self.problem.getDuals() if (
            valid and self.last_mode == "LP" and self.options.get("xpress_return_duals")
        ) else None
        return SimpleNamespace(value_valid=valid,
                               col_value=self.problem.getSolution() if valid else [],
                               row_dual=dual)

    def getInfo(self):
        return SimpleNamespace(objective_function_value=self.value, mip_dual_bound=self.best_bound)

    def getObjectiveValue(self):
        return self.value

    def getNumCol(self):
        return self.total_counts[0]

    def getNumRow(self):
        return self.total_counts[1]

