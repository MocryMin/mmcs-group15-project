# Group 15 Tier 2B report v1

25 November 2026. The five-page chapter is numbered 6–10. The integrated candidate combines the chapter with Tier 1 v7.1 and has ten body pages. Chapter I/II numerics are unchanged, except the Tier 2B references in the abstract, investment recommendation and appendix use the new four-day, 20% comparison. The manufacturer's 12.5% sensitivity stays in its own rows. The table of contents remains one page.

## Results and comparators

- A's zero-battery full-window Xpress comparison uses no-device sales with the same advance information. `evidence/plant-information.csv` contains all four commitment/allocation combinations and the separate market-information value. `evidence/daily-plant.csv` supports the seasonal utilisation result.
- The one-block B recommendation and its stress results use the previous-slot sign rule. The six-window 0–45 sweep compares fixed fitted controllers. Recomputed and archival net gains for all 552 sizes and windows are in `evidence/recomputed-capacity.csv`.
- The full-window zero-battery plant optimum and the rolling battery truth diagnostics use different information sets. All financial values are in 2020 GBP. Raw cash gain, plant and battery capital equivalents, incremental energy quantities, and captured renewable estimates are in `evidence/replays.csv`, with hedge and forecast comparisons in `forecast-value.csv`.
- `evidence/xpress-dispatch-audit.csv` has 192 24-slot comparisons. The acceptable DP objective sits between the Xpress feasible value and bound, allowing £0.025 for numerical variation. The longer retry resolves the two capped samples. `evidence/four-slot-enumeration.csv` records all 48 checks over 625 combinations each.

## Rebuild from the archive

Extract the entire source-and-evidence ZIP. No adjacent study directory is needed for replay, comparison or compilation. The compact `frozen` directory provides six timestamped evaluation slices with final outturn labels, matching day-ahead signals, the fitted and baseline forecast paths, the A commitment and B gate scores, and the renewable shares. It also provides the plant vector. The source of these inputs is the group's six-window refit, 20% commitment and fuel reconstruction. The package reproduces the operational comparisons from the frozen fitted inputs. Training the predictors again requires the training archives, as described in the Tier 2 public model catalogue.

The tested runtime is Python with NumPy, pandas, SciPy, Numba, Matplotlib and FICO Xpress 9.9.0. The Xpress commands use an available local licence. If it is not in the normal Xpress search path, set `MMCS_XPRESS_LICENCE_FILE` to the local licence file. The package does not contain a university licence.

Run from the extracted directory:

```text
python build_evidence.py
python build_evidence.py oracle
python build_evidence.py sweep
python audit_dispatch.py
python make_exhibits.py
tectonic tier2b-report-v1.tex
```

The `sweep` command recomputes the archived net gain at every size and window and verifies agreement to £0.01. The other evidence scripts are deterministic given the frozen inputs, within the reported Xpress solver tolerances. Use `SHA256SUMS.txt` to verify the archive files. Some runs write Numba caches next to the scripts.

For the integrated candidate, replace the copies of `integrated/evidence/*.tex` and `integrated/figures/{timing,capacity,seasonal}.pdf` with regenerated exhibits if inputs change. Run `tectonic report.tex` from `integrated/`.
