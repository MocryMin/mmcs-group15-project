"""Reproduce v1 from the frozen forecast and label slices."""

from contextlib import contextmanager
from functools import partial
import json
import os
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
from types import SimpleNamespace

import numpy as np
import pandas as pd
import xpress as xp

from continuous import replay_exact, sweep_exact
from replay import ANNUAL, ETA, H_DAILY, H_RATE, P, SLOTS, THROUGHPUT, E, baseline, njit, read, report, settle
import site_replay as site
import site_model
import solver_adapter
from numba import set_num_threads, get_num_threads

HERE = Path(__file__).resolve().parent
YEARS = tuple(range(2021, 2027))
CAP = 10_000
PLANT_ANNUAL = 756537.1657447455


@contextmanager
def school_licence():
    supplied = os.environ.get("MMCS_XPRESS_LICENCE_FILE")
    if supplied:
        with xp.init(supplied):
            yield
        return
    course = HERE.parent.parent.parent / "materials/sync-20261030/licence-instructions-extracted.txt"
    if not course.is_file():
        # Xpress uses its normal environment or installed licence.
        yield
        return
    directives = [line.strip() for line in course.read_text(encoding="utf-8-sig").splitlines()
                  if line.strip().lower().startswith("use_server")]
    assert len(directives) == 1
    with TemporaryDirectory(prefix="mmcs-tier2b-xpress-") as temp:
        licence = Path(temp) / "xpauth.xpr"
        licence.write_text(directives[0] + "\n", encoding="ascii")
        with xp.init(str(licence)):
            yield


def rounded_commitment(matrix_solver, c, *, constraints, bounds, integrality, options):
    """Pass the existing daily commitment subproblem to the selected solver."""
    lp = matrix_solver.HighsLp()
    sparse = constraints.A.tocsc()
    lp.num_row_, lp.num_col_ = sparse.shape
    lp.col_cost_, lp.col_lower_, lp.col_upper_ = c, bounds.lb, bounds.ub
    lp.row_lower_, lp.row_upper_ = constraints.lb, constraints.ub
    lp.a_matrix_.format_ = matrix_solver.MatrixFormat.kColwise
    lp.a_matrix_.start_, lp.a_matrix_.index_, lp.a_matrix_.value_ = (
        sparse.indptr, sparse.indices, sparse.data
    )
    solver = matrix_solver.Highs()
    solver.setOptionValue("output_flag", False)
    solver.setOptionValue("threads", 1)
    solver.setOptionValue("time_limit", options["time_limit"])
    solver.setOptionValue("mip_rel_gap", options["mip_rel_gap"])
    solver.passModel(lp)
    indices = np.flatnonzero(integrality).astype(np.int32)
    solver.changeColsIntegrality(len(indices), indices, np.ones(len(indices), dtype=np.uint8))
    solver.run()
    answer = solver.getSolution()
    return SimpleNamespace(x=np.asarray(answer.col_value) if answer.value_valid else None,
                           message=str(solver.getModelStatus()),
                           mip_dual_bound=solver.getInfo().mip_dual_bound)


def actual_reference(actual, signal):
    return np.minimum(actual[:, 1], actual[:, 2]) * (signal > 0)


def operations(actual, q, h, charge, discharge, share, direct):
    g, d = actual[:, 1:].T
    unused = g + discharge - q - h - charge
    assert unused.min() > -1e-6, unused.min()
    h_from_generation = h - np.maximum(0., discharge - q)
    assert h_from_generation.min() > -1e-6
    captured = np.minimum(np.maximum(g - d, 0.), charge + h_from_generation)
    return dict(delivered_MWh=q.sum(), demand_MWh=d.sum(),
                unused_MWh=unused.sum(), renewable_capture_MWh=np.dot(captured, share),
                renewable_surplus_MWh=np.dot(np.maximum(g-d, 0.), share),
                hydrogen_t=h.sum() / 55.9,
                incremental_cash_GBP=float(np.dot(actual[:, 0], q-direct) + H_RATE*h.sum()))


@njit(cache=True)
def reactive(actual, signal, online, unit, floor, base, previous, price_threshold):
    """One-step orders driven by the last observations and a trailing price median."""
    n = len(actual)
    trace = np.zeros((n, 8))
    stock, remaining, used = 0., H_DAILY, 0.
    cycle_budget = THROUGHPUT * n / SLOTS
    for i in range(n):
        day, slot = i // SLOTS, i % SLOTS
        if slot == 0:
            remaining = H_DAILY
        low = floor * unit * online[day]
        high = max(low, min(unit * online[day], remaining - (SLOTS-1-slot)*low))
        prev_price, prev_g, prev_d = previous[i]
        if n-i <= SLOTS:
            order = P
        elif prev_g > prev_d + low and prev_price <= price_threshold[i]:
            order = -P
        elif prev_price > price_threshold[i]:
            order = P
        else:
            order = 0.
        price, g, d = actual[i]
        closing, c, r, h, q = settle(stock, order, E, g, d, signal[i], low, high,
                                     max(0., cycle_budget-used)/ETA)
        h0, q0 = base[i]
        trace[i] = stock, order, c, r, closing, q, h, price*(q-q0) + H_RATE*(h-h0)
        stock, used, remaining = closing, used + ETA*c, remaining-h
    return trace


def a_row(year, key, blocks, data, base, trace, share):
    row = report(year, blocks, key, data, base, trace)
    _, _, c, r, _, q, h, _ = trace.T
    direct = actual_reference(data["actual"], data["signal"])
    op = operations(data["actual"], q, h, c, r, share, direct)
    plant_cost = float(data["fleet"]) * PLANT_ANNUAL * row["days"] / 365
    net = op["incremental_cash_GBP"] - plant_cost - row["battery_annual_equiv_cost_GBP"]
    np.testing.assert_allclose(net, row["portfolio_net_GBP"], rtol=0, atol=1e-5)
    return dict(policy="A", case=key, **row, plant_cost_GBP=plant_cost, **op)


def commitment_dispatch(year, data, share):
    actual = data["actual"]
    p, g, d = actual.T.reshape(3, -1, SLOTS)
    nd = len(p)
    dates = pd.to_datetime(data["utc"][::SLOTS], unit="s")
    static = json.loads((HERE/"frozen/plant.json").read_text(encoding="utf-8"))
    plant = site_model.Site(G=g, D=d, p=p, dates=dates.strftime("%Y-%m-%d"),
                            year=dates.year.to_numpy(), years_equiv=nd/365, **static)
    floor, fleet = float(data["load_floor"]), int(data["fleet"])
    val = site_model.value_table(plant, "A", floor, fleet, CAP)
    path, info = site_model.commit(val, 4, time_limit=30)
    assert not site_model.check_path(path, 4, np.isfinite(val))
    assert abs(info["gap"]) <= 0.05, info
    actual_baseline = actual_reference(actual,p.ravel())
    forecast_baseline = actual_reference(actual,data["signal"])
    sale_only = float(np.dot(actual[:,0], actual_baseline-forecast_baseline))
    assert sale_only >= 0.
    plant_cost = fleet * PLANT_ANNUAL * nd/365
    rows, daily = [], []
    for schedule, counts in (("forecast",data["online"]),("oracle",path)):
        assert not site_model.check_path(counts,4,np.isfinite(val))
        for dispatch in ("forecast","oracle"):
            if dispatch == "forecast":
                h,q = baseline(actual,data["signal"],counts,plant.e,floor).T
                direct = forecast_baseline
            else:
                h = site_model.day_dispatch(plant,"A",floor,counts,CAP)["h"].ravel()
                q = np.minimum(g.ravel()-h,d.ravel())*(p.ravel() >= 0.)
                direct = actual_baseline
            op = operations(actual,q,h,np.zeros(len(actual)),np.zeros(len(actual)),share,direct)
            assert np.max(h.reshape(-1,SLOTS).sum(1)) <= H_DAILY + 1e-6
            assert np.min(h.reshape(-1,SLOTS)-floor*plant.e*counts[:,None]) >= -1e-6
            row = dict(policy="A", case=f"plant_{schedule}_{dispatch}", test_end_year=year,
                       blocks=0,days=nd,electrolyser_units=fleet, gross_battery_GBP=0.,
                       battery_annual_equiv_cost_GBP=0.,net_battery_GBP=0.,plant_cost_GBP=plant_cost,
                       portfolio_net_GBP=op["incremental_cash_GBP"]-plant_cost,
                       schedule=schedule, allocation=dispatch,
                       mean_modules_online=float(np.mean(counts)), hydrogen_t_per_day=op["hydrogen_t"]/nd,
                       **op)
            if schedule == "oracle" and dispatch == "oracle":
                np.testing.assert_allclose(op["incremental_cash_GBP"],info["objective"],atol=.03,rtol=0.)
                row.update(case="plant_oracle", oracle_gap_GBP=max(0.,float(info["gap"])),
                           direct_sale_value_of_information_GBP=sale_only)
            if schedule == "forecast" and dispatch == "forecast":
                by_slot = actual[:,0]*(q-direct)+H_RATE*h-plant_cost/len(actual)
                daily = pd.DataFrame(dict(day=dates, online=counts,
                         plant_net_GBP=by_slot.reshape(-1,SLOTS).sum(1),
                         plant_hydrogen_t=h.reshape(-1,SLOTS).sum(1)/55.9))
            rows.append(row)
    return rows,daily



def b_row(year, key, blocks, utc, actual, gate, share):
    window = site.Window(utc, actual, blocks, 0)
    cash, trace = site.run(window, np.where(gate, -window.power, window.power), audit=True, require_empty=False)
    _, _, c, sale, _, _, h, _ = trace.T
    direct = np.minimum(actual[:, 1], actual[:, 2])
    op = operations(actual, direct+sale, h, c, sale, share, direct)
    cost = ANNUAL * blocks * window.days / 365
    assert abs(cash.sum() - op["incremental_cash_GBP"]) < 1e-4
    return dict(policy="B", case=key, test_end_year=year, blocks=blocks, days=window.days,
                electrolyser_units=0, gross_battery_GBP=cash.sum(), battery_annual_equiv_cost_GBP=cost,
                net_battery_GBP=cash.sum()-cost, portfolio_net_GBP=cash.sum()-cost, plant_cost_GBP=0.,
                accuracy=np.mean(gate == (actual[:, 1]>=actual[:, 2])), final_usable_stock_MWh=trace[-1,5], **op), trace


def daily_trace(data, a, b, share):
    utc, actual, signal = (data[k] for k in ("utc", "actual", "signal"))
    p, g, d = actual.T
    a_increment = a[:, -1] - ANNUAL/(365*SLOTS)
    b_increment = b[:, -1] - ANNUAL/(365*SLOTS)
    _, _, _, _, _, sales, h, _ = a.T
    return pd.DataFrame(dict(day=pd.to_datetime(utc, unit="s").floor("D"),
                             price=p, renewable_MWh=g*share, demand_MWh=d,
                             physical_surplus_MWh=np.maximum(g-d,0.),
                             a_charge_MWh=a[:,2], a_discharge_MWh=a[:,3],
                             b_charge_MWh=b[:,2], b_discharge_MWh=b[:,3],
                             a_net_GBP=a_increment, b_net_GBP=b_increment,
                             a_portfolio_GBP=p*(sales-actual_reference(actual, signal))+
                                H_RATE*h-(ANNUAL+6*PLANT_ANNUAL)/(365*SLOTS)
                             )).groupby("day").agg({"price":"mean", **{k:"sum" for k in
                               ("renewable_MWh","demand_MWh","physical_surplus_MWh","a_charge_MWh","a_discharge_MWh",
                                "b_charge_MWh","b_discharge_MWh","a_net_GBP","b_net_GBP","a_portfolio_GBP")}})





def variants(data):
    actual = data["actual"]
    indices = np.minimum(np.arange(len(actual))[:,None]+np.arange(24),len(actual)-1)
    truth = actual[indices].astype(float)
    v2 = np.maximum(data["v2"].astype(float),[-np.inf,0.,0.])
    mix = v2.copy()
    known = np.isfinite(data["auction"])
    mix[:,:8,0][known] = .75*mix[:,:8,0][known] + .25*data["auction"][known]
    return (("weekday",data["seasonal"].astype(float)),("uncorrected",v2),
            ("quote_mix",mix),("selected",data["path"]),("twelve_hour_truth",truth)), truth


def run_replays():
    a_source = pd.read_csv(HERE/"evidence/six-fold-capacity-replay.csv").set_index(["policy","test_end_year","blocks"])
    rows, daily, forecast = [], [], []
    for year in YEARS:
        data = read(year)
        utc, actual, signal = (data[k] for k in ("utc","actual","signal"))
        share = np.repeat(data["renewable_share"],SLOTS)
        online,tomorrow = data["online"],data["planned_tomorrow"]
        unit,floor = float(data["module_slot_mwh"]),float(data["load_floor"])
        base = baseline(actual,signal,online,unit,floor)
        zero = np.zeros((len(actual),8))
        zero[:,5:7] = base[:,::-1]
        rows.append(a_row(year,"forecast_plant",0,data,base,zero,share))
        paths, truth = variants(data)
        for name, path in paths:
            trace = replay_exact(actual,signal,path,online,tomorrow,unit,floor,base,1)
            row = a_row(year,name,1,data,base,trace,share)
            rows.append(row)
            error = np.abs(path[:-23]-truth[:-23]).mean((0,1))
            forecast.append(dict(policy="A",case=name,year=year,price_mae=error[0],
                                 generation_mae=error[1],demand_mae=error[2],net_GBP=row["net_battery_GBP"]))
            if name == "selected":
                np.testing.assert_allclose(row["portfolio_net_GBP"],a_source.loc[("A",year,1),"portfolio_net_GBP"],
                                           atol=1e-5,rtol=0)
                a_selected = trace
        trace = replay_exact(actual,signal,data["path"],online,tomorrow,unit,floor,base,11)
        row = a_row(year,"selected",11,data,base,trace,share)
        np.testing.assert_allclose(row["portfolio_net_GBP"],a_source.loc[("A",year,11),"portfolio_net_GBP"],
                                   atol=1e-5,rtol=0)
        rows.append(row)
        trace = reactive(actual,signal,online,unit,floor,base,data["prev"],data["price_threshold"])
        rows.append(a_row(year,"reactive",1,data,base,trace,share))
        b_actual = data["b_actual"]
        gate = data["b_score"] >= 0.
        prior = data["b_prior"]>=0.
        true = b_actual[:,1]>=b_actual[:,2]
        for name,n,choice in (("direct",0,gate),("selected",1,gate),("previous_slot",1,prior),
                              ("truth_gate",1,true),("selected",9,gate),("selected",11,gate)):
            row, trace = b_row(year,name,n,utc,b_actual,choice,share)
            if name == "selected":
                np.testing.assert_allclose(row["net_battery_GBP"],a_source.loc[("B",year,n),"net_battery_GBP"],
                                           atol=1e-5,rtol=0)
            if n == 1:
                forecast.append(dict(policy="B",case=name,year=year,accuracy=row["accuracy"],net_GBP=row["net_battery_GBP"]))
                if name == "previous_slot":
                    b_selected = trace
            rows.append(row)
        daily.append(daily_trace(data,a_selected,b_selected,share))
        print("Replayed",year,flush=True)
    pd.DataFrame(rows).to_csv(HERE/"evidence/replays.csv",index=False)
    pd.DataFrame(forecast).to_csv(HERE/"evidence/forecast-value.csv",index=False)
    pd.concat(daily).to_csv(HERE/"evidence/daily-operation.csv")


def run_oracle():
    site_model.milp = partial(rounded_commitment,solver_adapter)
    rows, plant_days = [], []
    with school_licence():
        for year in YEARS:
            data = read(year)
            outcomes,daily = commitment_dispatch(year,data,np.repeat(data["renewable_share"],SLOTS))
            rows.extend(outcomes)
            plant_days.append(daily)
            print("Xpress",year,[round(row["portfolio_net_GBP"]) for row in outcomes],flush=True)
    df=pd.DataFrame(rows)
    df.to_csv(HERE/"evidence/plant-information.csv",index=False)
    df[df.case.eq("plant_oracle")].to_csv(HERE/"evidence/plant-oracle.csv",index=False)
    pd.concat(plant_days,ignore_index=True).to_csv(HERE/"evidence/daily-plant.csv",index=False)



def run_sweep():
    """Recompute the 552 archived size sweep rows and compare cash outcomes."""
    set_num_threads(min(16,get_num_threads()))
    archive = pd.read_csv(HERE/"evidence/six-fold-capacity-replay.csv").set_index(["policy","test_end_year","blocks"])
    rows = []
    for year in YEARS:
        data = read(year)
        actual, signal, path = (data[key].astype(float) for key in ("actual","signal","path"))
        online, tomorrow = data["online"],data["planned_tomorrow"]
        unit,floor = float(data["module_slot_mwh"]),float(data["load_floor"])
        base = baseline(actual,signal,online,unit,floor)
        sizes = np.arange(1,46)
        traces = sweep_exact(actual,signal,path,online,tomorrow,unit,floor,base,sizes)
        for blocks in range(46):
            if blocks:
                a_net = traces[blocks-1,:,-1].sum() - ANNUAL*blocks*len(actual)/(SLOTS*365)
            else:
                a_net = 0.
            window = site.Window(data["utc"],data["b_actual"],blocks,0)
            order = np.where(data["b_score"]>=0.,-window.power,window.power)
            cash,_ = site.run(window,order,require_empty=False)
            b_net = cash.sum() - ANNUAL*blocks*window.days/365
            for policy,value in (("A",a_net),("B",b_net)):
                old = archive.loc[(policy,year,blocks),"net_battery_GBP"]
                np.testing.assert_allclose(value,old,rtol=0,atol=.01)
                rows.append(dict(policy=policy,test_end_year=year,blocks=blocks,
                                 net_battery_GBP=value,archived_net_battery_GBP=old))
        print("Verified 92 capacity results for",year,flush=True)
    pd.DataFrame(rows).to_csv(HERE/"evidence/recomputed-capacity.csv",index=False)


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "oracle":
        run_oracle()
    elif len(sys.argv)>1 and sys.argv[1]=="sweep":
        run_sweep()
    else:
        run_replays()

