"""Continuous-inventory Xpress check of selected five-order replays."""

import argparse
from pathlib import Path
from time import perf_counter

import numpy as np
from scipy.sparse import coo_matrix
import xpress as xp

from replay import (HERE, E, ETA, P, H_DAILY, H_RATE, LEADS, SLOTS, THROUGHPUT,
                    allocate, baseline, njit, path_limits, read, report, settle, write_rows)


@njit(cache=True)
def layers(prices, gen, demand, signals, lo, hi, stock, storage, power, budget):
    """All affine intervals for each of the five physical commands."""
    result = np.empty((len(prices) * 45, 8))
    count = 0
    for lead in range(len(prices)):
        p, g, d, sig, low, cap = (prices[lead], gen[lead], demand[lead], signals[lead], lo[lead], hi[lead])
        ref_h, ref_q = allocate(g, d, sig, low, cap)
        hold = budget if lead == 0 else np.inf
        discharge_limit = max(0., cap + (d if sig > 0. else 0.) - g)
        charge_limit = min(max(g - low, 0.), hold)
        for action in (0., -power / 2, power / 2, -power, power):
            if action < 0 and (charge_limit <= 1e-10 or
                               (action == -power and charge_limit <= power / 2)):
                continue
            if action > 0 and (discharge_limit <= 1e-10 or
                               (action == power and discharge_limit <= power / 2)):
                continue
            if lead == 0:
                knots = np.array((stock, stock))
            elif action == 0:
                knots = np.array((0., storage))
            else:
                thresholds = np.array((low, cap, d, d + low, d + cap))
                knots = np.empty(8)
                knots[0], knots[1] = 0., storage
                if action < 0:
                    knots[2] = storage - min(-action, charge_limit) * ETA
                    knots[3:] = storage - ETA * (g - thresholds)
                else:
                    knots[2] = min(action, discharge_limit) / ETA
                    knots[3:] = (thresholds - g) / ETA
                knots = np.sort(np.clip(knots, 0., storage))
            for idx in range(len(knots) - 1):
                left, right = knots[idx], knots[idx+1]
                if lead != 0 and right - left < 1e-10:
                    continue
                s0, _, _, h0, q0 = settle(left, action, storage, g, d, sig, low, cap, hold)
                s1, _, _, h1, q1 = settle(right, action, storage, g, d, sig, low, cap, hold)
                y0 = p * (q0 - ref_q) + H_RATE * (h0 - ref_h)
                y1 = p * (q1 - ref_q) + H_RATE * (h1 - ref_h)
                if lead == 0:
                    y0 -= 1e-7 * abs(action)
                    y1 = y0
                result[count] = (float(lead), action, left, right, s0, s1, y0, y1)
                count += 1
    return result[:count]


def solve_model(pieces, stock, storage, power, horizon, seconds, strict=False):
    layer, command, x0, x1, s0, s1, y0, y1 = pieces.T
    t = layer.astype(np.int32)
    n = len(t)
    scale = 100 * power
    objective = np.r_[y0, y1-y0] / scale
    i, stages = np.arange(n), np.arange(horizon)
    # A binary selects one affine segment per time, and a continuous
    # interpolation weight fixes both the inventory and its cash.
    rows = np.r_[i, i, n+t, n+horizon+t, n+horizon+t,
                 n+horizon+1+t[t < horizon-1], n+horizon+1+t[t < horizon-1]]
    before_final = t < horizon - 1
    columns = np.r_[i, n+i, i, i, n+i, i[before_final], n+i[before_final]]
    values = np.r_[-np.ones(n), np.ones(n), np.ones(n), x0/storage, (x1-x0)/storage,
                   -s0[before_final]/storage, -(s1-s0)[before_final]/storage]
    matrix = coo_matrix((values, (rows, columns)), shape=(n+2*horizon, 2*n)).tocsr()
    xp_model = xp.problem()
    ctl = xp_model.controls
    ctl.outputlog = 0
    ctl.threads = 1
    ctl.presolve = 0
    ctl.cutstrategy = 0
    ctl.timelimit = seconds
    ctl.feastol = 1e-9
    ctl.miptol = 1e-9 if strict else 1e-7
    ctl.optimalitytol = 1e-9
    ctl.miprelstop = 0.
    ctl.mipabsstop = 1e-5 / scale
    xp_model.addCols(objcoef=objective, lb=np.zeros(2*n), ub=np.r_[np.ones(n), (x1>x0).astype(float)])
    xp_model.addRows(rowtype="L"*n+"E"*(2*horizon),
                     rhs=np.r_[np.zeros(n), np.ones(horizon), stock/storage, np.zeros(horizon-1)],
                     start=matrix.indptr, colind=matrix.indices, rowcoef=matrix.data)
    xp_model.chgColType(i, "B"*n)
    xp_model.chgObjSense(xp.maximize)
    # The idle plan gives a feasible incumbent even with the time cap.
    idle = np.flatnonzero(command == 0.)
    assert len(idle) == horizon
    solution = np.zeros(2*n)
    solution[idle] = 1.
    solution[n+idle[1:]] = stock / storage
    xp_model.addMipSol(solution)
    xp_model.optimize()
    if not xp_model.attributes.mipsols:
        return None
    solution = np.asarray(xp_model.getSolution())
    selected = np.flatnonzero(solution[:n] > .5)
    if not np.array_equal(t[selected], stages):
        return None
    best = float(objective @ solution * scale)
    bound = float(xp_model.attributes.bestbound * scale)
    return command[selected], best, bound, int(xp_model.attributes.mipstatus)


@njit(cache=True)
def cash_for_orders(orders, path, signals, lo, hi, stock, storage, budget):
    cash = -1e-7 * abs(orders[0])
    for t, (price, gen, demand) in enumerate(path):
        ref_h, ref_q = allocate(gen, demand, signals[t], lo[t], hi[t])
        stock, _, _, h, q = settle(stock, orders[t], storage, gen, demand, signals[t], lo[t], hi[t],
                                    budget if t == 0 else np.inf)
        cash += price * (q - ref_q) + H_RATE * (h - ref_h)
    return cash


def solve(path, signals, lo, hi, stock, storage, power, budget, seconds):
    sample = layers(path[:, 0], path[:, 1], path[:, 2], signals, lo, hi, stock, storage, power, budget)
    for strict in (False, True):
        trial = solve_model(sample, stock, storage, power, len(path), max(1.5, seconds) if strict else seconds, strict)
        if trial is None:
            continue
        orders, earn, bound, status = trial
        cash = cash_for_orders(orders, path, signals, lo, hi, stock, storage, budget)
        if abs(cash - earn) <= .025 and bound >= cash - .025:
            return orders[0], cash, max(0., bound-cash), status
    raise ValueError(f"Xpress plan failed independent cash check at opening stock {stock}")


def replay(year, blocks, seconds, limit):
    data = read(year)
    actual, signals, path = (data[key].astype(float) for key in ("actual", "signal", "path"))
    online, tomorrow = data["online"], data["planned_tomorrow"]
    unit, alpha = (float(data[key]) for key in ("module_slot_mwh", "load_floor"))
    base = baseline(actual, signals, online, unit, alpha)
    n = len(actual) if limit is None else limit
    storage, power = E * blocks, P * blocks
    low, caps = np.empty(LEADS), np.empty(LEADS)
    trace, diagnostics = np.empty((n, 8)), np.zeros((n, 3))
    stock, remaining, used = 0., H_DAILY, 0.
    cycle_budget = THROUGHPUT * blocks * len(actual) / SLOTS
    start = 0
    partial = HERE / f"xp-{year}-{blocks}-resume.npz"
    if limit is None and partial.exists():
        with np.load(partial) as saved:
            assert saved["seconds"].item() == seconds
            start = saved["next_slot"].item()
            stock, remaining, used = saved["state"]
            trace[:start], diagnostics[:start] = saved["trace"], saved["diagnostics"]
    started = perf_counter()
    for i in range(start, n):
        day, slot = i // SLOTS, i % SLOTS
        if slot == 0:
            remaining = H_DAILY
        min_load = alpha * online[day] * unit
        high = max(min_load, min(online[day] * unit, remaining - (SLOTS - 1 - slot) * min_load))
        budget = max(0., cycle_budget - used) / ETA
        if len(actual) - i <= SLOTS:
            request = power
        else:
            path_limits(i, remaining, path, online, tomorrow, unit, alpha, low, caps, LEADS)
            projected_signals = path[i, :, 0].copy()
            projected_signals[0] = signals[i]
            request, cash, gap, status = solve(path[i], projected_signals, low, caps, stock, storage, power,
                                              budget, seconds)
            diagnostics[i] = cash, gap, status
        price, generation, demand = actual[i]
        end, charge, discharge, h, q = settle(stock, request, storage, generation, demand, signals[i],
                                               min_load, high, budget)
        h0, q0 = base[i]
        trace[i] = stock, request, charge, discharge, end, q, h, price * (q - q0) + H_RATE * (h - h0)
        remaining -= h
        used += ETA * charge
        stock = end
        if (i+1) % 480 == 0:
            if limit is None:
                temporary = partial.with_suffix(".tmp.npz")
                np.savez_compressed(temporary, next_slot=i+1, seconds=seconds, state=(stock, remaining, used),
                                    trace=trace[:i+1], diagnostics=diagnostics[:i+1])
                temporary.replace(partial)
            print(year, blocks, i+1, round(perf_counter()-started, 1), flush=True)
    print("Complete", year, blocks, n, "slots in", round(perf_counter()-started, 1),
          "seconds; limits", (diagnostics[:, 2] == 4).sum(), flush=True)
    if limit is not None:
        return
    row = report(year, blocks, "xpress", data, base, trace)
    row.update(time_limited_slots=int((diagnostics[:, 2] == 4).sum()),
               max_residual_gap_GBP=float(diagnostics[:, 1].max()))
    np.savez_compressed(HERE / f"ledger-{year}-{blocks}-xpress.npz", utc=data["utc"], trace=trace,
                        diagnostics=diagnostics, online=online, reference=base)
    write_rows(HERE / f"xpress-{year}-{blocks}.csv", [row])
    print(row, flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("year", type=int)
    parser.add_argument("blocks", type=int)
    parser.add_argument("--seconds", type=float, default=.25)
    parser.add_argument("--limit", type=int)
    args = parser.parse_args()
    replay(args.year, args.blocks, args.seconds, args.limit)


if __name__ == "__main__":
    main()
