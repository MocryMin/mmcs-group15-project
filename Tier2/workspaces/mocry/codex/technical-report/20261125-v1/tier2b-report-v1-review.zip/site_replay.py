"""Settle binding half-hour orders at the 10 tonne/day Policy B site."""
from dataclasses import dataclass
import json
from pathlib import Path

import numpy as np


EQUIPMENT = Path(__file__).resolve().with_name("tier2b-equipment.json")
CONFIG = json.loads(EQUIPMENT.read_text(encoding="utf-8"))
BATTERIES, ELECTROLYSERS = 9, 10
BATTERY = CONFIG["battery"]
HYDROGEN = CONFIG["electrolysers"]
SLOT_HOURS = CONFIG["settlement_hours"]
SLOTS_PER_DAY = round(24 / SLOT_HOURS)
BLOCK_POWER = BATTERY["ac_charge_MW"] * SLOT_HOURS
assert BATTERY["ac_charge_MW"] == BATTERY["ac_discharge_MW"]
POWER = BATTERIES * BLOCK_POWER
STORAGE = BATTERIES * BATTERY["usable_internal_MWh"]
EFFICIENCY = BATTERY["one_way_efficiency"]
THROUGHPUT = BATTERIES * BATTERY["max_internal_discharge_MWh_per_replay_day_equivalent"]
ANNUAL_COST = BATTERIES * BATTERY["cost_scenarios"][0]["annual_total_GBP"]
H_MODULE_MAX = HYDROGEN["ac_MW_per_module"] * SLOT_HOURS
H_MIN = H_MODULE_MAX * HYDROGEN["minimum_operating_load_fraction"]
H_MAX = ELECTROLYSERS * H_MODULE_MAX
H_DAILY = 10_000 * HYDROGEN["ac_kWh_per_kg"] / 1000
H_VALUE = HYDROGEN["netback_GBP_per_kg"] * 1000 / HYDROGEN["ac_kWh_per_kg"]
TRACE_FIELDS = (
    "opening_stock", "request", "charge", "discharge_to_sales", "discharge_to_hydrogen",
    "closing_stock", "hydrogen_input", "battery_cash",
)


@dataclass
class Window:
    utc: np.ndarray
    actual: np.ndarray
    blocks: int = BATTERIES
    electrolysers: int = ELECTROLYSERS

    def __post_init__(self):
        if not isinstance(self.blocks, (int, np.integer)) or self.blocks < 0:
            raise ValueError("blocks must be a non-negative integer")
        if not isinstance(self.electrolysers, (int, np.integer)) or self.electrolysers < 0:
            raise ValueError("electrolysers must be a non-negative integer")
        assert len(self.utc) == len(self.actual) and np.all(np.diff(self.utc) == 1800)
        assert np.isfinite(self.actual).all() and (self.actual[:, 1:] >= 0).all()
        self.price, generation, demand = self.actual.T
        self.gap = generation.astype(float) - demand.astype(float)
        self.surplus = np.maximum(self.gap, 0.)
        self.deficit = np.maximum(-self.gap, 0.)
        self.day = self.utc // 86400
        self.new_day = np.r_[True, self.day[1:] != self.day[:-1]]
        self.days = len(self.utc) / SLOTS_PER_DAY
        self.power = self.blocks * BLOCK_POWER
        self.storage = self.blocks * BATTERY["usable_internal_MWh"]
        self.budget = (self.blocks * BATTERY["max_internal_discharge_MWh_per_replay_day_equivalent"]
                       * self.days)
        self.hydrogen_slot_cap = self.electrolysers * H_MODULE_MAX
        self.base_hydrogen = np.empty(len(self.utc))
        remaining = 0.
        for i, (surplus, starts_day) in enumerate(zip(self.surplus, self.new_day)):
            if starts_day:
                remaining = H_DAILY
            use = min(surplus, self.hydrogen_slot_cap, remaining)
            self.base_hydrogen[i] = use if use >= H_MIN else 0.
            remaining -= self.base_hydrogen[i]


def run(window, orders, audit=False, require_empty=True):
    """Commit an order before observing the slot, then limit actual flows at settlement."""
    assert len(orders) == len(window.utc)
    orders = np.array(orders, dtype=float, copy=True)
    orders[-SLOTS_PER_DAY:] = window.power
    cash = np.empty(len(orders))
    trace = np.empty((len(orders), len(TRACE_FIELDS))) if audit else None
    stock = 0.
    used = 0.
    remaining = 0.
    slots = zip(window.price, window.surplus, window.deficit, window.new_day, window.base_hydrogen, orders)
    for i, (price, surplus, deficit, starts_day, reference, request) in enumerate(slots):
        if starts_day:
            remaining = H_DAILY
        cap = min(remaining, window.hydrogen_slot_cap)
        charge = min(max(-request, 0.), surplus, (window.storage - stock) / EFFICIENCY,
                     max(window.budget - used, 0.) / EFFICIENCY)
        available = min(max(request, 0.), stock * EFFICIENCY)
        sale = min(available, deficit)
        to_hydrogen = min(available - sale, max(cap - surplus, 0.))
        if surplus + to_hydrogen < H_MIN:
            to_hydrogen = 0.
        hydrogen = min(surplus - charge + to_hydrogen, cap)
        if hydrogen < H_MIN:
            hydrogen = 0.
        end = min(max(stock + EFFICIENCY * charge - (sale + to_hydrogen) / EFFICIENCY, 0.), window.storage)
        cash[i] = price * sale + H_VALUE * (hydrogen - reference)
        if audit:
            trace[i] = stock, request, charge, sale, to_hydrogen, end, hydrogen, cash[i]
        stock = end
        used += EFFICIENCY * charge
        remaining -= hydrogen
    if audit:
        verify(window, orders, trace, require_empty=require_empty)
    return cash, trace


def verify(window, orders, trace, require_empty=True):
    stock, requested, charge, sale, to_hydrogen, end, hydrogen, cash = trace.T
    discharge = sale + to_hydrogen
    tol = 1e-6
    assert np.isfinite(trace).all() and stock[0] == 0.
    if require_empty:
        assert end[-1] <= tol
    np.testing.assert_array_equal(requested, orders)
    np.testing.assert_allclose(abs(requested) % BLOCK_POWER, 0., atol=tol)
    assert np.all(abs(requested) <= window.power + tol)
    np.testing.assert_allclose(end[:-1], stock[1:], atol=tol, rtol=0.)
    np.testing.assert_allclose(end, stock + EFFICIENCY * charge - discharge / EFFICIENCY, atol=tol, rtol=0.)
    assert np.all((end >= -tol) & (end <= window.storage + tol))
    assert np.all(charge >= -tol) and np.all(discharge >= -tol) and np.all(to_hydrogen >= -tol)
    assert np.all(charge <= np.maximum(-orders, 0.) + tol)
    assert np.all(discharge <= np.maximum(orders, 0.) + tol)
    assert np.all(charge[-SLOTS_PER_DAY:] <= tol) and EFFICIENCY * charge.sum() <= window.budget + tol
    assert np.all(charge * discharge <= tol)
    np.testing.assert_allclose(sale, np.minimum(np.minimum(np.maximum(orders, 0.), stock * EFFICIENCY),
                                               window.deficit), atol=tol, rtol=0.)
    assert np.all(hydrogen + charge <= window.surplus + to_hydrogen + tol)
    assert np.all(hydrogen + tol >= to_hydrogen) and np.all(hydrogen <= window.hydrogen_slot_cap + tol)
    assert np.all((hydrogen == 0.) | (hydrogen >= H_MIN - tol))
    for use in (hydrogen, window.base_hydrogen):
        assert np.all(np.bincount(window.day - window.day[0], weights=use) <= H_DAILY + tol)
    expected = window.price * sale + H_VALUE * (hydrogen - window.base_hydrogen)
    np.testing.assert_allclose(cash, expected, atol=tol, rtol=0.)
