"""Replay the 20%-floor commitment with five storage orders and continuous settlement."""

import argparse
import csv
import json
from pathlib import Path
import sys
from time import perf_counter

import numpy as np

HERE = Path(__file__).resolve().parent
if (HERE / ".deps").exists():
    sys.path.append(str(HERE / ".deps"))
from numba import njit, prange, set_num_threads

PROJECT = HERE.parent
PARAMS = json.loads((HERE / "parameters.json").read_bytes())
ETA = PARAMS["eta"]
E = PARAMS["storage_per_block"]
P = PARAMS["power_per_block"]
H_RATE = PARAMS["hydrogen_price"]
H_DAILY = PARAMS["hydrogen_daily_cap"]
ANNUAL = PARAMS["cost_per_block"]
THROUGHPUT = PARAMS["throughput_per_day"]
SLOTS = 48
LEADS = 24


@njit(cache=True, inline="always")
def allocate(net, demand, signal, low, high):
    h = min(high, max(low, net if signal < H_RATE else net - demand))
    sales = min(net - h, demand) if signal > 0. else 0.
    return h, sales


@njit(cache=True, inline="always")
def settle(stock, action, storage, generation, demand, signal, low, high, budget):
    # Reserve enough electricity to serve mandatory hydrogen before charging.
    charge = min(max(-action, 0.), max(generation - low, 0.), budget, (storage - stock) / ETA)
    headroom = max(0., high + (demand if signal > 0. else 0.) - generation)
    sold_from_storage = min(max(action, 0.), stock * ETA, headroom)
    net = generation + sold_from_storage - charge
    h, sale = allocate(net, demand, signal, low, high)
    closing = min(storage, max(0., stock + ETA * charge - sold_from_storage / ETA))
    return closing, charge, sold_from_storage, h, sale


@njit(cache=True)
def path_limits(i, remaining, path, actual_count, tomorrow, unit, alpha, lower, caps, lead_count):
    day, position = i // SLOTS, i % SLOTS
    quota = remaining
    for j in range(lead_count):
        if position + j == SLOTS:
            quota = H_DAILY
        slots_left = SLOTS - 1 - (position + j) % SLOTS
        count = actual_count[day] if position + j < SLOTS else tomorrow[day]
        mandatory = alpha * unit * count
        lower[j] = mandatory
        caps[j] = max(mandatory, min(unit * count, quota - slots_left * mandatory))
        # Roll the predicted no-battery booking forward. Settlement later uses
        # the actual remaining allowance of the relevant battery policy.
        price, generation, demand = path[i, j]
        natural, _ = allocate(generation, demand, price, mandatory, caps[j])
        quota -= natural


@njit(cache=True, inline="always")
def continuation(next_values, point, inverse_step, intervals):
    scaled = point * inverse_step
    left = min(int(scaled), intervals - 1)
    fraction = min(1., max(0., scaled - left))
    return next_values[left] + fraction * (next_values[left + 1] - next_values[left])


@njit(cache=True)
def grid_order(i, stock, budget, storage, path, signals, low, cap, count, grid, side, other, power):
    side[:] = 0.
    intervals = len(grid) - 1
    inverse = intervals / storage
    for t in range(count - 1, 0, -1):
        price, generation, demand = path[i, t]
        mandatory, ceiling = low[t], cap[t]
        base_h, base_q = allocate(generation, demand, price, mandatory, ceiling)
        for k in range(intervals + 1):
            s = grid[k]
            best = -np.inf
            for a in range(-2, 3):
                new_s, _, _, h, q = settle(s, a * power / 2, storage,
                                           generation, demand, price, mandatory, ceiling, np.inf)
                val = price * (q - base_q) + H_RATE * (h - base_h) + continuation(side, new_s, inverse, intervals)
                if val > best:
                    best = val
            other[k] = best
        side, other = other, side
    price, generation, demand = path[i, 0]
    signal = signals[i]
    base_h, base_q = allocate(generation, demand, signal, low[0], cap[0])
    best, order = -np.inf, 0.
    for a in (0, -1, 1, -2, 2):
        request = a * power / 2
        new_s, _, _, h, q = settle(stock, request, storage, generation, demand, signal, low[0], cap[0], budget)
        val = price * (q - base_q) + H_RATE * (h - base_h) + continuation(side, new_s, inverse, intervals)
        val -= 1e-7 * abs(request)
        if val > best:
            best, order = val, request
    return order


@njit(cache=True)
def baseline(actual, signals, online, unit, alpha):
    n = len(actual)
    reference = np.zeros((n, 2))
    quota = H_DAILY
    for i in range(n):
        day, slot = i // SLOTS, i % SLOTS
        if slot == 0:
            quota = H_DAILY
        min_load = alpha * online[day] * unit
        cap = min(online[day] * unit, quota - (SLOTS - 1 - slot) * min_load)
        h, q = allocate(actual[i, 1], actual[i, 2], signals[i], min_load, max(min_load, cap))
        quota -= h
        reference[i, 0], reference[i, 1] = h, q
    return reference


@njit(cache=True)
def grid_replay(actual, signals, path, online, tomorrow, unit, alpha, base, blocks, intervals):
    n = len(actual)
    storage, power = E * blocks, P * blocks
    grid = np.linspace(0., storage, intervals + 1)
    side, other = np.empty_like(grid), np.empty_like(grid)
    low, caps = np.empty(LEADS), np.empty(LEADS)
    trace = np.empty((n, 8))
    stock, remaining, used = 0., H_DAILY, 0.
    cycle_budget = THROUGHPUT * blocks * n / SLOTS
    for i in range(n):
        day, slot = i // SLOTS, i % SLOTS
        if slot == 0:
            remaining = H_DAILY
        h0, q0 = base[i]
        min_load = alpha * unit * online[day]
        high = max(min_load, min(online[day] * unit, remaining - (SLOTS - 1 - slot) * min_load))
        budget = max(0., cycle_budget - used) / ETA
        if n - i <= SLOTS:
            request = power
        else:
            path_limits(i, remaining, path, online, tomorrow, unit, alpha, low, caps, LEADS)
            request = grid_order(i, stock, budget, storage, path, signals, low, caps, LEADS, grid, side, other, power)
        price, generation, demand = actual[i]
        end, charge, discharge, h, q = settle(stock, request, storage, generation, demand, signals[i],
                                               min_load, high, budget)
        gain = price * (q - q0) + H_RATE * (h - h0)
        trace[i] = (stock, request, charge, discharge, end, q, h, gain)
        remaining -= h
        used += ETA * charge
        stock = end
    return trace


@njit(cache=True, parallel=True)
def sweep(actual, signals, path, online, tomorrow, unit, alpha, base, sizes, intervals):
    traces = np.empty((len(sizes), len(actual), 8))
    for i in prange(len(sizes)):
        traces[i] = grid_replay(actual, signals, path, online, tomorrow, unit, alpha, base, sizes[i], intervals)
    return traces


def audit(trace, data, base, blocks):
    actual = data["actual"]
    before, order, c, r, after, q, h, gain = trace.T
    low = np.repeat(data["online"] * data["module_slot_mwh"] * data["load_floor"], SLOTS)
    high = np.repeat(data["online"] * data["module_slot_mwh"], SLOTS)
    tol = 2e-6
    assert np.isfinite(trace).all()
    assert abs(before[0]) < tol and np.max(np.abs(before[1:] - after[:-1])) < tol
    assert (np.abs(order[:, None] - np.linspace(-P * blocks, P * blocks, 5)) < tol).any(1).all()
    assert np.min(after) >= -tol and np.max(after) <= E * blocks + tol
    assert np.max(np.abs(after - before - ETA * c + r / ETA)) < tol
    assert np.min(c) >= -tol and np.min(r) >= -tol and np.min(q) >= -tol
    assert np.max(c - np.maximum(-order, 0.)) < tol and np.max(r - np.maximum(order, 0.)) < tol
    assert np.max(np.minimum(c, r)) < tol
    assert ETA * c.sum() <= THROUGHPUT * blocks * len(trace) / SLOTS + tol
    assert np.max(q - actual[:, 2]) < tol and np.max(c + h + q - r - actual[:, 1]) < tol
    assert np.max(low - h) < tol and np.max(h - high) < tol
    assert np.max(h.reshape(-1, SLOTS).sum(1)) <= H_DAILY + tol
    np.testing.assert_allclose(gain, actual[:, 0] * (q - base[:, 1]) + H_RATE * (h - base[:, 0]),
                               rtol=0, atol=tol)


def read(year):
    with np.load(HERE / "frozen" / f"inputs-{year}.npz") as frozen:
        return {key: frozen[key] for key in frozen.files}


def report(year, blocks, method, data, base, trace):
    audit(trace, data, base, blocks)
    n = len(trace)
    days = n / SLOTS
    days_before_jan = 122
    cost = ANNUAL * blocks * days / 365
    revenue = float(trace[:, -1].sum())
    base_portfolio = (data["actual"][:, 0] * (base[:, 1] -
                       np.minimum(data["actual"][:, 1], data["actual"][:, 2]) * (data["signal"] > 0))
                      + H_RATE * base[:, 0]).sum() - data["fleet"] * .7565371657447455e6 * days / 365
    return dict(test_end_year=year, blocks=blocks, method=method, electrolyser_units=int(data["fleet"]),
                days=days, gross_battery_GBP=revenue, battery_annual_equiv_cost_GBP=cost,
                net_battery_GBP=revenue - cost, portfolio_net_GBP=float(base_portfolio) + revenue - cost,
                net_sept_dec_GBP=float(trace[:days_before_jan*SLOTS, -1].sum()) - ANNUAL * blocks * days_before_jan / 365,
                electrolysis_tonnes=float(trace[:, 6].sum()) / .0559 / 1000,
                final_usable_stock_MWh=float(trace[-1, 4]))


def write_rows(file, rows):
    with file.open("w", newline="", encoding="utf-8") as out:
        writer = csv.DictWriter(out, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--years", nargs="+", type=int, default=[2026])
    parser.add_argument("--sizes", nargs="+", type=int, default=list(range(1, 46)))
    parser.add_argument("--intervals", type=int, default=240)
    parser.add_argument("--threads", type=int, default=20)
    parser.add_argument("--save-ledgers", action="store_true")
    args = parser.parse_args()
    set_num_threads(args.threads)
    for year in args.years:
        start = perf_counter()
        data = read(year)
        arguments = (data["actual"].astype(float), data["signal"].astype(float), data["path"].astype(float),
                     data["online"], data["planned_tomorrow"], float(data["module_slot_mwh"]), float(data["load_floor"]))
        actual, signal, _, online, _, unit, alpha = arguments
        base = baseline(actual, signal, online, unit, alpha)
        np.testing.assert_array_less(np.repeat(online * unit * alpha, SLOTS), actual[:, 1])
        sizes = np.array([n for n in args.sizes if n])
        traces = sweep(*arguments, base, sizes, args.intervals)
        rows = []
        for blocks, trace in zip(sizes, traces):
            method = f"grid_{args.intervals}"
            row = report(year, int(blocks), method, data, base, trace)
            rows.append(row)
            if args.save_ledgers:
                np.savez_compressed(HERE / f"ledger-{year}-{blocks}-{method}.npz", utc=data["utc"], trace=trace,
                                    online=online, starts=data["starts"], reference=base)
        if 0 in args.sizes:
            trace = np.zeros((len(actual), 8))
            trace[:, 5:7] = base[:, ::-1]
            rows.append(report(year, 0, f"grid_{args.intervals}", data, base, trace))
        desc = "_".join(map(str, args.sizes)) if len(args.sizes) < 9 else f"{min(args.sizes)}-{max(args.sizes)}"
        write_rows(HERE / f"results-{year}-grid-{args.intervals}-{desc}.csv", rows)
        print(year, "completed", len(rows), "capacities in", round(perf_counter() - start, 2), "s",
              "best net", max(rows, key=lambda row: row["net_battery_GBP"]), flush=True)


if __name__ == "__main__":
    main()
