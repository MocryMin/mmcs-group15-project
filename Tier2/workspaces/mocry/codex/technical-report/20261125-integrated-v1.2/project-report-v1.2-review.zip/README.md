# Integrated project report v1.2 review files

This review archive pairs with project-report-v1.2.pdf. Compile report.tex from
integrated/ with Tectonic. The result tables in evidence/ and the entries indexed
in model-evidence/README.md support checks of the printed figures. The course
brief is Project_Brief.pdf at the group repository root. The large frozen
half-hour input arrays and model weights are outside this review archive.
