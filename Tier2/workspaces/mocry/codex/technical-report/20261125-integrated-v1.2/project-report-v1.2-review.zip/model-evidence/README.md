# Tier 2B model evidence

These are copies of the experiment records used in Appendix D.3 to D.6.
Paths reproduce the local study layout. The main six-window replay starts
from the frozen predictions supplied separately under 'frozen/'.

| Report location | Records and row selection |
| --- | --- |
| D.3 Forecast inputs and branches | 'tier2b-six-fold-20261123/features.json' and fold notes. The catalogue gives the 76-column layout and v1/v2 configuration. In 'component_lock.json', use 'component_extension' for the locked weights. 'base_training.json' gives the optimisation settings. |
| Table D.2(a) | The 21-feature size screens in 'tier2b-gpu-overfit-5m-1b/comparison.csv' and 'tier2b-gpu-scale-100m-200m/comparison.csv'. Select 'family=Transformer'. The validation and test columns use each seed's lowest-validation checkpoint. The final training column fixes update 216. |
| Table D.2(b) | The 59-feature 'tier2b-asof-20261119' comparison and its per-architecture files. Use the 12-hour rows. Ridge, 4x768 and 8x768 also have a common first-slot comparison in the top-level and summer files. |
| Figure D.2 | In 'tier2b-asof-20261119', use 'training.csv', 'config.json' and 'best.json' from '1x128', '1x768', '1x864' and '1x1024'. The figure reads the three 12-hour MSE columns and selects the recorded validation minimum. |
| Table D.3 | 'matched_generation_ablation_scores.csv'. Select 'ablate_same_2x256_without_ridge', 'a_2deep_c24' and 'match_heads8', target 'generation', horizon '24-slot'. Pooled v1 and v2 are 'v1' and 'component_extension' in 'pooled_year_scores.csv', target 'joint', horizon '24-slot'. |
| Table D.4 and calibration | Use 'pooled' in 'tier2b-a-quote-residual-20261120/comparison.csv'. For the last three rows, sum 'net_GBP' in the three main test windows in 'tier2b-a-constrained-training-20261121/assessment.csv' and weight each MAE by its recorded pair count. See the lock and paired comparisons for the training cash floor and test intervals. The boundary study reports the spread error and taper diagnostic. |
| Table D.5 | 'tier2b-b-threshold-loss-20261122/comparison.csv'. Use 'test25', 'jan_may26' and 'test26'. Sum net gain and use slot counts for pooled accuracy and MAE. The gap threshold in 'model_lock.json' is for the earlier pilot. The final zero-electrolyser cases are recorded in 'tier2b-b-battery-only-20261124' and in the report-level evidence. |
| D.6 Direct policy and forecast horizon | Sum the three main-window cash values for the selected direct-policy ensemble in 'tier2b-direct-transformer-20261120/returns.csv'. Use the 25-block rows of 'tier2b-a-learned-24h-20261123/comparison.csv' for the horizon example. |

The model catalogue also identifies the public model profiles and trained
weights. The settings and tables here trace the reported comparisons.
