# Tier 2B six-window refit

The held-out periods run from 1 September to 1 September, with end years 2021–2026. All times are UTC. For each fold, a separate eight-month validation block is reserved before fitting. The other dates from September 2020–August 2026 make up the training set. Training and validation keep only origins whose full 24-slot target belongs to the same split. The final 23 origins of each annual window do not contribute to forecast error, but remain in the economic replay. This is a retrospective blocked experiment. Training periods for early folds include later years.

| Fold | Dates tested, inclusive | Validation |
| --- | --- | --- |
| 1 | Sep 2020–Aug 2021 | Jan–Aug 2022 |
| 2 | Sep 2021–Aug 2022 | Jan–Aug 2023 |
| 3 | Sep 2022–Aug 2023 | Jan–Aug 2022 |
| 4 | Sep 2023–Aug 2024 | Jan–Aug 2023 |
| 5 | Sep 2024–Aug 2025 | Jan–Aug 2024 |
| 6 | Sep 2025–Aug 2026 | Jan–Aug 2025 |

## Forecasts and dispatch

- **A** uses the existing v2 component architecture, Ridge penalty, neural seeds, training schedules and component blend. Each fold independently fits standardisation, Ridge and the six neural branches, using the validation loss to pick their checkpoints. The first four hours receive the same 75/25 v2 and auction mix where a quote exists and the existing Huber correction with a per-training-window cash floor. The learned residual and its three mixing coefficients are estimated afresh in each fold. The dispatch uses the frozen 45-battery, six-electrolyser site and five-action rolling 12-hour controller.
- **B** independently fits the existing weighted logistic classifier from historical observations, with the same features, offset, penalty and 0.5 threshold. The dispatch uses the frozen nine-battery, 10-electrolyser site and the same full-group charge or discharge request. Physical constraints determine the amount settled.
- **Data** preserve publication cutoffs in the A features and the previous completed slot convention in the B history. The early Elexon archives were extended to rebuild the original 76 A columns. The available N2EX archive starts in September 2021. Missing A features use fold training means after standardisation. When an A decision has neither a published current quote nor past matching auction quotes, its sale-order signal falls back to the four previously observed market-index prices for the same weekday and slot.
- **Comparison** is against the no-battery case for each policy's fixed hydrogen plant, with investment and maintenance annualised at the existing rate and apportioned by days. Figures are in real 2020 GBP. Each window starts at the minimum available stock and requests discharge during its final 48 half-hours. Remaining stock has zero terminal credit. The September–December cash in the annual replay carries its closing stock forward into January.
- **Truth diagnostics** keep the same controllers. A receives the realised 12-hour price, generation and demand paths. B receives the realised current classification label. These diagnostics measure the value of information for the specified controllers.

## Results

Net gains are in £m at 2020 prices. The weekday reference replaces all three A forecasts by the averages of the four previous matching weekdays and half-hours. The same sale signal and dispatch code apply in each A comparison.

| Test window | A refit | A weekday reference | A 12-hour truth | B refit | B truth gate | B gate accuracy |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Sep 2020–Aug 2021 | −139.63 | −50.73 | 44.77 | −5.76 | −4.13 | 95.55% |
| Sep 2021–Aug 2022 | 146.64 | 125.12 | 390.22 | 62.58 | 69.99 | 93.61% |
| Sep 2022–Aug 2023 | −20.38 | −1.90 | 117.00 | −5.07 | −0.69 | 95.86% |
| Sep 2023–Aug 2024 | −65.76 | −93.67 | −3.07 | −17.51 | −14.13 | 94.07% |
| Sep 2024–Aug 2025 | −28.13 | −62.54 | 22.39 | −9.97 | −9.05 | 96.54% |
| Sep 2025–Aug 2026 | −23.01 | −51.08 | 40.92 | 7.91 | 9.09 | 95.46% |

A covers its battery cost in one window and B in two. Across the six independent battery replays the respective totals are −£130.28m and +£32.18m. With September 2021–August 2022 removed, the totals are −£276.92m and −£30.39m. That window has the highest test price standard deviation at £98.22/MWh. The A rolling truth diagnostic covers cost in five windows. The B truth gate leaves the count at two.

The first A fold has no archived current-slot N2EX quote. The final price path has a £71.39/MWh MAE, compared with £14.72/MWh for the weekday reference. September 2022–August 2023 has the reverse forecast ranking, with £18.34/MWh against £44.06/MWh, while the weekday reference earns £18.48m more in the replay. In September 2024–August 2025 the final-day discharge requests leave 9,164 MWh of usable A stock and 2,004 MWh of B stock. Both receive zero terminal credit.

## Outputs and reproduction

The [fold summary](summary.csv) includes prices, the allocation of training and validation origins, prediction metrics, net gains and the two truth diagnostics. [Policy B](policy-b.csv) contains individual gate metrics and terminal stock. Each subfolder of `folds` holds its preprocessing statistics, validation trajectories, checkpoints, A prediction path, Huber coefficients, policy A results and B classifier coefficients. All 108 A selected checkpoints, six B fits and 105,168 exclusive test slots were checked. The CUDA graph validation trial failed checkpoint replay agreement. Affected fits were rerun with ordinary forward evaluation.

Run `prepare.py` after filling `early-sources` using the Elexon source ranges in `collect_early.js`. Use the established CUDA Python environment to run `train_a.py`, `policy_a.py`, `policy_b.py` and `summarize.py`. The training script accepts `--years`, and completed fold or seed checkpoints can be reused when restarting this experiment.
