# Integrated v1.3 review snapshot

Run tectonic report.tex in integrated/ to build the report. The evidence directory contains the result ledgers and the four new sensitivity and audit CSVs. The model-evidence directory contains the model and training records used in Appendix D.3-D.6. SHA256SUMS.txt lists the exact included files. The adjacent runnable ZIP contains the code and frozen inputs for the 2025/26 operational comparisons.
