"""Solve the five-action forecast problem by a continuous piecewise-linear Bellman recursion."""

import argparse
from time import perf_counter

import numpy as np
from replay import (HERE, E, ETA, P, H_DAILY, H_RATE, SLOTS, THROUGHPUT,
                    baseline, njit, path_limits, prange, read, report, set_num_threads, settle, write_rows)
from xpress_replay import layers

KNOT_LIMIT = 8192
VALUE_TOL = 1e-7
STOCK_TOL = 1e-9


@njit(cache=True, inline="always")
def put(xs, ys, size, x, y):
    if size and x - xs[size-1] < STOCK_TOL:
        ys[size-1] = max(ys[size-1], y)
        return size
    if size >= 2:
        between = (xs[size-1] - xs[size-2]) / (x - xs[size-2])
        expected = ys[size-2] + between * (y - ys[size-2])
        if abs(expected - ys[size-1]) <= VALUE_TOL:
            size -= 1
    if size >= len(xs):
        raise RuntimeError("The continuous envelope exceeded its knot work space.")
    xs[size], ys[size] = x, y
    return size + 1


@njit(cache=True, inline="always")
def lerp(x, a, b, ya, yb):
    return ya + (x-a) * (yb-ya) / (b-a)


@njit(cache=True, inline="always")
def value(xs, ys, size, point):
    i = min(size-2, max(0, np.searchsorted(xs[:size], point) - 1))
    return lerp(point, xs[i], xs[i+1], ys[i], ys[i+1])


@njit(cache=True)
def compose(pieces, v_x, v_y, v_len, out_x, out_y):
    length = 0
    for piece in pieces:
        _, _, x0, x1, s0, s1, y0, y1 = piece
        length = put(out_x, out_y, length, x0, y0 + value(v_x, v_y, v_len, s0))
        if s1 - s0 > STOCK_TOL:
            ix = np.searchsorted(v_x[:v_len], s0 + STOCK_TOL, side="right")
            while ix < v_len and v_x[ix] < s1 - STOCK_TOL:
                fraction = (v_x[ix] - s0) / (s1-s0)
                x = x0 + (x1-x0) * fraction
                y = y0 + (y1-y0) * fraction + v_y[ix]
                length = put(out_x, out_y, length, x, y)
                ix += 1
        length = put(out_x, out_y, length, x1, y1 + value(v_x, v_y, v_len, s1))
    return length


@njit(cache=True)
def envelope(ax, ay, alen, bx, by, blen, dx, dy):
    i, j = 0, 0
    prior_x, prior_a, prior_b = 0., ay[0], by[0]
    length = put(dx, dy, 0, 0., max(prior_a, prior_b))
    while i < alen - 1 and j < blen - 1:
        point = min(ax[i+1], bx[j+1])
        next_a = lerp(point, ax[i], ax[i+1], ay[i], ay[i+1])
        next_b = lerp(point, bx[j], bx[j+1], by[j], by[j+1])
        gap0, gap1 = prior_a-prior_b, next_a-next_b
        if gap0 * gap1 < 0 and point-prior_x > STOCK_TOL:
            fraction = gap0 / (gap0-gap1)
            cross = prior_x + (point-prior_x) * fraction
            if cross-prior_x > STOCK_TOL and point-cross > STOCK_TOL:
                cross_cash = prior_a + (next_a-prior_a) * fraction
                length = put(dx, dy, length, cross, cross_cash)
        length = put(dx, dy, length, point, max(next_a, next_b))
        i += int(ax[i+1] <= point + STOCK_TOL)
        j += int(bx[j+1] <= point + STOCK_TOL)
        prior_x, prior_a, prior_b = point, next_a, next_b
    return length


@njit(cache=True)
def optimal_order(path, signals, lo, cap, stock, storage, power, budget, ws):
    pieces = layers(path[:, 0], path[:, 1], path[:, 2], signals, lo, cap, stock, storage, power, budget)
    # Buffers hold the continuation, current upper envelope, one
    # candidate action and the union of the last two respectively.
    future, current, candidate, merged = 0, 1, 2, 3
    ws[future, 0, :2] = (0., storage)
    ws[future, 1, :2] = (0., 0.)
    vlen = 2
    end = len(pieces)
    for lead in range(len(path)-1, 0, -1):
        length = 0
        while end > 0 and pieces[end-1, 0] == lead:
            action = pieces[end-1, 1]
            start = end - 1
            while start > 0 and pieces[start-1, 0] == lead and pieces[start-1, 1] == action:
                start -= 1
            if length == 0:
                length = compose(pieces[start:end], ws[future, 0], ws[future, 1], vlen,
                                 ws[current, 0], ws[current, 1])
            else:
                clen = compose(pieces[start:end], ws[future, 0], ws[future, 1], vlen,
                               ws[candidate, 0], ws[candidate, 1])
                length = envelope(ws[current, 0], ws[current, 1], length, ws[candidate, 0], ws[candidate, 1],
                                  clen, ws[merged, 0], ws[merged, 1])
                current, merged = merged, current
            end = start
        future, current = current, future
        vlen = length
    best, request = -np.inf, 0.
    for row in pieces[:end]:
        cash = row[6] + value(ws[future, 0], ws[future, 1], vlen, row[4])
        if cash > best + VALUE_TOL or (abs(cash-best) <= VALUE_TOL and abs(row[1]) < abs(request)):
            request, best = row[1], cash
    return request, best


@njit(cache=True)
def replay_exact(actual, signals, path, online, tomorrow, unit, alpha, base, blocks):
    n = len(actual)
    storage, power = E * blocks, P * blocks
    lead_count = path.shape[1]
    low, caps, stage_signals = np.empty(lead_count), np.empty(lead_count), np.empty(lead_count)
    ws = np.empty((4, 2, KNOT_LIMIT))
    trace = np.empty((n, 8))
    stock, remaining, used = 0., H_DAILY, 0.
    cycle_budget = THROUGHPUT * blocks * n / SLOTS
    for i in range(n):
        day, slot = i // SLOTS, i % SLOTS
        if slot == 0:
            remaining = H_DAILY
        h0, q0 = base[i]
        min_load = alpha * unit * online[day]
        high = max(min_load, min(online[day] * unit, remaining - (SLOTS - 1 - slot) * min_load))
        budget = max(0., cycle_budget - used) / ETA
        if n - i <= SLOTS:
            order = power
        else:
            path_limits(i, remaining, path, online, tomorrow, unit, alpha, low, caps, lead_count)
            stage_signals[:] = path[i, :, 0]
            stage_signals[0] = signals[i]
            order, _ = optimal_order(path[i], stage_signals, low, caps, stock, storage, power, budget, ws)
        price, generation, demand = actual[i]
        end, charge, discharge, h, q = settle(stock, order, storage, generation, demand, signals[i],
                                               min_load, high, budget)
        trace[i] = stock, order, charge, discharge, end, q, h, price * (q-q0) + H_RATE * (h-h0)
        remaining -= h
        used += ETA * charge
        stock = end
    return trace


@njit(cache=True, parallel=True)
def sweep_exact(actual, signals, path, online, tomorrow, unit, alpha, base, sizes):
    traces = np.empty((len(sizes), len(actual), 8))
    for i in prange(len(sizes)):
        traces[i] = replay_exact(actual, signals, path, online, tomorrow, unit, alpha, base, sizes[i])
    return traces


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--years", nargs="+", type=int, default=[2026])
    parser.add_argument("--sizes", nargs="+", type=int, default=list(range(1, 46)))
    parser.add_argument("--threads", type=int, default=20)
    parser.add_argument("--keep", nargs="*", type=int, default=(1, 7, 12, 45))
    args = parser.parse_args()
    set_num_threads(args.threads)
    for year in args.years:
        start = perf_counter()
        data = read(year)
        actual, signal, path = (data[k].astype(float) for k in ("actual", "signal", "path"))
        online, tomorrow = data["online"], data["planned_tomorrow"]
        unit, alpha = (float(data[k]) for k in ("module_slot_mwh", "load_floor"))
        base = baseline(actual, signal, online, unit, alpha)
        np.testing.assert_array_less(unit * alpha * int(data["fleet"]), path[:, :, 1])
        sizes = np.array([n for n in args.sizes if n])
        traces = sweep_exact(actual, signal, path, online, tomorrow, unit, alpha, base, sizes)
        rows = []
        for blocks, trace in zip(sizes, traces):
            row = report(year, int(blocks), "continuous_dp", data, base, trace)
            rows.append(row)
            if blocks in args.keep:
                np.savez_compressed(HERE / f"ledger-{year}-{blocks}-continuous.npz", utc=data["utc"], trace=trace,
                                    online=online, starts=data["starts"], reference=base)
        if 0 in args.sizes:
            trace = np.zeros((len(actual), 8))
            trace[:, 5:7] = base[:, ::-1]
            rows.append(report(year, 0, "continuous_dp", data, base, trace))
        desc = "_".join(map(str, args.sizes)) if len(args.sizes) < 9 else f"{min(args.sizes)}-{max(args.sizes)}"
        write_rows(HERE / f"results-{year}-continuous-{desc}.csv", rows)
        print(year, "completed", len(rows), "capacities in", round(perf_counter()-start, 2), "s",
              "best net", max(rows, key=lambda row: row["net_battery_GBP"]), flush=True)


if __name__ == "__main__":
    main()
