"""Reproduce the report's horizon, budget and window-resampling checks."""

import argparse
from functools import partial
import json
from time import perf_counter

from numba import get_num_threads, set_num_threads
import numpy as np
import pandas as pd

from continuous import KNOT_LIMIT, optimal_order, sweep_exact
from replay import E, HERE, H_DAILY, P, SLOTS, baseline, path_limits, read, report

YEARS = range(2021, 2027)
SIZES = np.array([1, 11, 25, 45])
LOOKBACK = 28 * SLOTS


def extended_path(year, data, actual):
    if year == 2021:
        with np.load(HERE / "frozen/calendar-2020-25.npz") as january:
            first_day = january["dates"][0].astype("datetime64[s]").astype(np.int64)
            offset = (data["utc"][0] - first_day) // 1800
            prior = january["actual"][offset - LOOKBACK:offset]
    elif year == 2026 and (HERE / "frozen/2025-lookback.npz").exists():
        with np.load(HERE / "frozen/2025-lookback.npz") as lookback:
            assert lookback["utc"][-1] + 1800 == data["utc"][0]
            prior = lookback["actual"]
    else:
        previous = read(year - 1)
        assert previous["utc"][-1] + 1800 == data["utc"][0]
        prior = previous["actual"][-LOOKBACK:]
    assert len(prior) == LOOKBACK
    np.testing.assert_array_equal(np.diff(data["utc"]), 1800)
    origins = LOOKBACK + np.arange(len(actual))[:, None, None]
    leads = np.arange(24, SLOTS)[None, :, None]
    lags = (7 * SLOTS * np.arange(1, 5))[None, None, :]
    source = origins + leads - lags
    assert np.all(source < origins) and source.min() >= 0
    past = np.concatenate([prior, actual])
    return np.concatenate([data["path"], past[source].mean(axis=2)], axis=1)


def horizon(years, sizes, output):
    set_num_threads(min(4, get_num_threads()))
    archive = pd.read_csv(HERE / "evidence/recomputed-capacity.csv")
    archive = archive[archive.policy == "A"].set_index(["test_end_year", "blocks"])
    clean = []
    for year in years:
        start = perf_counter()
        data = read(year)
        actual, signals, path = (data[key].astype(float) for key in ("actual", "signal", "path"))
        online, tomorrow = data["online"], data["planned_tomorrow"]
        unit, alpha = (float(data[key]) for key in ("module_slot_mwh", "load_floor"))
        assert alpha == .2 and int(data["fleet"]) == 6
        base = baseline(actual, signals, online, unit, alpha)
        paths = {12: path, 24: extended_path(year, data, actual)}
        for hours, forecast in paths.items():
            np.testing.assert_array_less(unit * alpha * int(data["fleet"]), forecast[:, :, 1])
            traces = sweep_exact(actual, signals, forecast, online, tomorrow, unit, alpha, base, sizes)
            for blocks, trace in zip(sizes, traces):
                stat = report(year, int(blocks), f"continuous_{hours}h", data, base, trace)
                if hours == 12:
                    np.testing.assert_allclose(stat["net_battery_GBP"],
                                               archive.loc[(year, blocks), "net_battery_GBP"], atol=.01, rtol=0)
                clean.append(dict(hours=hours, **stat))
        pd.DataFrame(clean).to_csv(output, index=False)
        print(year, round(perf_counter() - start, 1), "seconds",
              [(x["blocks"], x["hours"], round(x["net_battery_GBP"])) for x in clean[-2 * len(sizes):]], flush=True)


def audit_horizon(output):
    from build_evidence import school_licence
    from xpress_replay import solve

    work = np.empty((4, 2, KNOT_LIMIT))
    rows = []
    with school_licence():
        for year in (2022, 2026):
            data = read(year)
            path = extended_path(year, data, data["actual"].astype(float))
            unit, alpha = (float(data[key]) for key in ("module_slot_mwh", "load_floor"))
            for blocks in (1, 45):
                for index in (SLOTS * 100, SLOTS * 100 + 36):
                    storage, power = E * blocks, P * blocks
                    stock, budget = storage * .35, power * 1.3
                    remaining = H_DAILY * (1 - .7 * (index % SLOTS) / SLOTS)
                    lo, hi = np.empty(SLOTS), np.empty(SLOTS)
                    path_limits(index, remaining, path, data["online"], data["planned_tomorrow"],
                                unit, alpha, lo, hi, SLOTS)
                    scenario = path[index]
                    signals = scenario[:, 0].copy()
                    signals[0] = data["signal"][index]
                    _, value = optimal_order(scenario, signals, lo, hi, stock, storage, power, budget, work)
                    _, feasible, gap, status = solve(scenario, signals, lo, hi, stock, storage, power, budget, 12.)
                    assert feasible - .025 <= value <= feasible + gap + .025
                    rows.append(dict(year=year, blocks=blocks, slot=index, dp_value_GBP=value,
                                     xpress_value_GBP=feasible, xpress_gap_GBP=gap, status=status))
    pd.DataFrame(rows).to_csv(output, index=False)
    print(pd.DataFrame(rows).to_string(index=False))


def budget(output):
    from build_evidence import CAP, rounded_commitment, school_licence
    import site_model
    import solver_adapter

    static = json.loads((HERE / "frozen/plant.json").read_text(encoding="utf-8"))
    with np.load(HERE / "frozen/calendar-2020-25.npz") as frozen:
        p, g, d = frozen["actual"].T.reshape(3, -1, SLOTS)
        dates = pd.DatetimeIndex(frozen["dates"])
    site = site_model.Site(G=g, D=d, p=p, dates=dates.strftime("%Y-%m-%d"),
                           year=dates.year.to_numpy(), years_equiv=6., **static)
    site_model.milp = partial(rounded_commitment, solver_adapter)
    values = site_model.value_table(site, "A", .2, 6, CAP)
    rows = [dict(modules=0, capital_GBP=0., annual_net_GBP=0., incumbent_to_bound_GBP=0.)]
    with school_licence():
        for modules in range(1, 7):
            feasible = values[:, :modules+1]
            counts, info = site_model.commit(feasible, 4, time_limit=45)
            assert not site_model.check_path(counts, 4, np.isfinite(feasible))
            assert abs(info["gap"]) < .1, info
            rows.append(dict(modules=modules, capital_GBP=site.capital * modules,
                             annual_net_GBP=info["objective"] / 6 - site.annual * modules,
                             incumbent_to_bound_GBP=max(0., info["gap"])))
            print(rows[-1], flush=True)
    np.testing.assert_allclose(rows[-1]["annual_net_GBP"], 13459603.221739565, atol=.1, rtol=0)
    pd.DataFrame(rows).to_csv(output, index=False)


def resample(output):
    replays = pd.read_csv(HERE / "evidence/replays.csv")
    scale = pd.read_csv(HERE / "evidence/recomputed-capacity.csv")
    view = pd.read_csv(HERE / "evidence/horizon-sensitivity.csv")
    samples = np.indices((6,) * 6, dtype=np.int8).reshape(6, -1)
    cases = [
        ("A plant, zero batteries", replays.query("policy == 'A' and case == 'forecast_plant'"), "portfolio_net_GBP"),
        ("A, first block", scale.query("policy == 'A' and blocks == 1"), "net_battery_GBP"),
        ("A, Tier 1 count (45), 12h", scale.query("policy == 'A' and blocks == 45"), "net_battery_GBP"),
        ("A, Tier 1 count (45), 24h", view.query("hours == 24 and blocks == 45"), "net_battery_GBP"),
        ("B, first block, previous gap", replays.query("policy == 'B' and case == 'previous_slot' and blocks == 1"), "net_battery_GBP"),
        ("B, Tier 1 count (9)", scale.query("policy == 'B' and blocks == 9"), "net_battery_GBP"),
    ]
    clean = []
    for label, frame, key in cases:
        frame = frame.sort_values("test_end_year")
        np.testing.assert_array_equal(frame["test_end_year"], list(YEARS))
        values = frame[key].to_numpy()
        lo, hi = np.quantile(values[samples].mean(axis=0), [.025, .975])
        clean.append(dict(case=label, mean_GBP=values.mean(), lower_GBP=lo, upper_GBP=hi,
                          total_excluding_2021_22_GBP=values[frame["test_end_year"] != 2022].sum()))
    pd.DataFrame(clean).to_csv(output, index=False)
    print(pd.DataFrame(clean).to_string(index=False))


def check_b(years, output):
    from build_evidence import b_row

    expected = pd.read_csv(HERE / "evidence/replays.csv")
    expected = expected[expected.policy == "B"].set_index(["test_end_year", "case", "blocks"])
    rows = []
    for year in years:
        data = read(year)
        share = np.repeat(data["renewable_share"], SLOTS)
        for name, blocks, score in (("previous_slot", 1, "b_prior"), ("selected", 9, "b_score")):
            row, _ = b_row(year, name, blocks, data["utc"], data["b_actual"], data[score] >= 0., share)
            want = expected.loc[(year, name, blocks), "net_battery_GBP"]
            np.testing.assert_allclose(row["net_battery_GBP"], want, atol=.01, rtol=0)
            rows.append(row)
    pd.DataFrame(rows).to_csv(output, index=False)
    print(pd.DataFrame(rows)[["test_end_year", "blocks", "case", "net_battery_GBP"]].to_string(index=False))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("check", choices=("horizon", "budget", "resample", "audit", "check-b"))
    parser.add_argument("--years", type=int, nargs="+", default=list(YEARS))
    parser.add_argument("--sizes", type=int, nargs="+", default=SIZES.tolist())
    parser.add_argument("--output")
    args = parser.parse_args()
    defaults = {"horizon": "horizon-sensitivity", "budget": "capital-budget", "resample": "window-uncertainty", "audit": "horizon-xpress-audit", "check-b": "one-window-b"}
    output = args.output or HERE / "evidence" / f"{defaults[args.check]}.csv"
    if args.check == "horizon":
        horizon(args.years, np.array(args.sizes), output)
    elif args.check == "budget":
        budget(output)
    elif args.check == "resample":
        resample(output)
    elif args.check == "audit":
        audit_horizon(output)
    else:
        check_b(args.years, output)


if __name__ == "__main__":
    main()
