# MMCS Group 15 | 2025/26 replay

This standalone package reruns the 1 September 2025 to 31 August 2026 test
with the report's frozen forecast and outturn inputs. Use Python with
NumPy, pandas, SciPy, Numba and FICO Xpress 9.9.0. The replay imports the
Xpress module. It uses the continuous-stock dynamic programme for A
and the fixed settlement rule for B, so it does not require a solver
licence checkout.

From the extracted directory, run:

    python report_sensitivity.py horizon --years 2026 --sizes 1 11 25 45 --output check-a.csv
    python report_sensitivity.py check-b --years 2026 --output check-b.csv

A covers both planning horizons and cross-checks the 12-hour results
to £0.01. The expected comparison for 24 hours is in
evidence/expected-a-2025-26.csv. B verifies the one-block previous-slot
strategy and the nine-block classifier. SHA256SUMS.txt covers the inputs.
