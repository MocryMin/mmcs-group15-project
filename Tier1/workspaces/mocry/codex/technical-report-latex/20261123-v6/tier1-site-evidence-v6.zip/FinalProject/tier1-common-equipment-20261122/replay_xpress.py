"""Xpress reoptimisation of the shared one-block case, with fixed interface states.

The archived plan supplies stock at the block interfaces and a throughput
allocation. Reoptimisation yields a full-horizon feasible witness, including
when the daily H2 allowance is split as in Tier 2B. It gives a lower bound
on unrestricted Oracle profit at these fixed equipment counts.
"""

import json
import os
from pathlib import Path
import sys
from time import perf_counter

import numpy as np
import pandas as pd
import xpress as xp

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parent
V7 = PROJECT / "tier1-halfhour-20261113-v7"
sys.path.insert(0, str(V7))
from model import Matrix, annual_costs, frame_for

CASE_A = PROJECT / "storage-exploration-20261116-v2/utility4h"
CASE_B = PROJECT / "storage-investment-20261116-v3/B_full_fixed100"
CASES = {
    "A": (CASE_A, "A_utility4h_100MW_lowcost_yearcycle1", 845),
    "B": (CASE_B, "fixed100", 362),
}
BLOCK_DAYS = 4


def solve_matrix(matrix):
    sparse = matrix.sparse()
    lower, upper = np.concatenate(matrix.rl), np.concatenate(matrix.ru)
    types = "".join(np.where(lower == upper, "E", np.where(np.isposinf(upper), "G", "L")))
    assert matrix.n + matrix.nr <= 5000
    problem = xp.problem()
    problem.controls.outputlog = 0
    problem.controls.threads = 1
    problem.controls.feastol = 1e-9
    problem.controls.optimalitytol = 1e-9
    args = dict(
        rowtype=types, rhs=np.where(np.isposinf(upper), lower, upper),
        objcoef=np.concatenate(matrix.cost), start=sparse.indptr, rowind=sparse.indices,
        rowcoef=sparse.data, lb=np.maximum(np.concatenate(matrix.lb), -xp.infinity),
        ub=np.minimum(np.concatenate(matrix.ub), xp.infinity),
    )
    if matrix.ints:
        problem.controls.mipabsstop = 1e-5
        problem.controls.miprelstop = 1e-12
        problem.loadMIP(**args, coltype="B" * len(matrix.ints), entind=matrix.ints)
        _, status = problem.optimize()
        if status != xp.SolStatus.OPTIMAL:
            raise RuntimeError(f"MIP status {status}")
    else:
        problem.loadLP(**args)
        problem.lpOptimize("d")
        if problem.attributes.lpstatus != xp.LPStatus.OPTIMAL:
            raise RuntimeError(f"LP status {problem.attributes.lpstatus}")
    return np.asarray(problem.getSolution())


def replay_block(frame, battery, hydrogen, count, netback, day_limit, policy,
                 split_h2, start, end, throughput):
    g, d, price = (frame[k].to_numpy(float) for k in ("g", "d", "price"))
    T = len(g)
    eta = battery["eta"]
    retention = battery["retention"]
    P, W = 0.5 * battery["P_MW"] / 1000, battery["usable"]
    direct = np.minimum(g, d)
    deficit = np.maximum(d - g, 0)
    hydrogen_max = count * hydrogen["unit_GWh"]
    per_day_energy = day_limit * hydrogen["kWh_kg"] / 1e6
    if split_h2:
        hydrogen_max = min(hydrogen_max, per_day_energy / 48)
    minimum = hydrogen["minimum"] * hydrogen["unit_GWh"]
    h2_value = netback * 1e6 / hydrogen["kWh_kg"]
    cuts = set()
    for _ in range(10):
        m = Matrix()
        q = m.variables(T, lo=direct if policy == "B" else 0, hi=direct, c=-price * 1000)
        c = m.variables(T, hi=np.minimum(P, g - direct if policy == "B" else g))
        r = m.variables(T, hi=np.minimum(P, deficit if policy == "B" else d), c=-price * 1000)
        u = m.variables(T, hi=P)
        s = m.variables(T, hi=W)
        h = m.variables(T, hi=hydrogen_max, c=-h2_value)
        m.rows(T, [(q, 1), (c, 1), (h, 1), (u, -1)], hi=g)
        m.rows(T, [(q, 1), (r, 1)], hi=d)
        m.rows(T, [(r, 1), (u, 1)], hi=P)
        m.rows(T, [(h, 1), (u, -1)], lo=0)
        m.rows(1, [(s[0], 1), (c[0], -eta), (r[0], 1 / eta), (u[0], 1 / eta)],
               lo=start * retention, hi=start * retention)
        m.rows(T - 1, [(s[1:], 1), (s[:-1], -retention), (c[1:], -eta),
                      (r[1:], 1 / eta), (u[1:], 1 / eta)], lo=0, hi=0)
        m.rows(1, [(s[-1], 1)], lo=end, hi=end)
        for day in h.reshape(-1, 48):
            m.rows(1, [(col, 1) for col in day], hi=per_day_energy)
        if throughput is not None:
            m.rows(1, [(col, 1 / eta) for col in np.r_[r, u]], hi=throughput)

        if policy == "B":
            limit = np.minimum(deficit, P)
            m.rows(1, [(r[0], 1)], lo=min(limit[0], start * retention * eta))
            for t in np.flatnonzero(limit[1:] > 0) + 1:
                m.rows(1, [(r[t], 1), (s[t - 1], -retention * eta)], hi=0)
                if limit[t] >= W * retention * eta:
                    m.rows(1, [(r[t], 1), (s[t - 1], -retention * eta)], lo=0)
                    continue
                stock_limited = m.variables(hi=1, integer=True)
                M = W * retention * eta
                m.rows(1, [(r[t], 1), (stock_limited, limit[t])], lo=limit[t])
                m.rows(1, [(r[t], 1), (s[t - 1], -retention * eta), (stock_limited, -M)], lo=-M)

        for t in sorted(cuts):
            on = m.variables(hi=1, integer=True)
            m.rows(1, [(h[t], 1), (on, -minimum)], lo=0)
            m.rows(1, [(h[t], 1), (on, -hydrogen_max)], hi=0)
        x = solve_matrix(m)
        h2 = x[h]
        violation = set(np.flatnonzero((h2 > 1e-8) & (h2 < minimum - 1e-8)))
        if not violation:
            out = np.array([x[q], x[c], x[r], x[u], x[s], h2])
            # Net simultaneous flows without changing stock, output or receipts.
            overlap = np.minimum(out[1] * eta ** 2, out[2] + out[3])
            from_h2 = np.minimum(out[3], overlap)
            from_sale = overlap - from_h2
            out[1] -= overlap / eta ** 2
            out[2] -= from_sale
            out[3] -= from_h2
            out[0] += from_sale
            return out
        if not violation - cuts:
            raise RuntimeError("Minimum load infeasible after integer repair")
        cuts.update(violation)
    raise RuntimeError("Minimum load repair exhausted")


def check_and_cash(frame, schedule, battery, hydrogen, count, netback, cap, policy, split):
    g, d, p = (frame[k].to_numpy(float) for k in ("g", "d", "price"))
    q, c, r, u, s, v = schedule
    eta, ret = battery["eta"], battery["retention"]
    prev = np.r_[0, s[:-1]] * ret
    P = 0.5 * battery["P_MW"] / 1000
    vol = v * 1e6 / hydrogen["kWh_kg"]
    active = v > 1e-8
    day = vol.reshape(-1, 48).sum(axis=1)
    err = [
        -schedule.min(), (q + c + v - u - g).max(), (q + r - d).max(),
        (c - P).max(), (r + u - P).max(), (s - battery["usable"]).max(),
        (u - v).max(), abs(s - prev - eta * c + (r + u) / eta).max(), abs(s[-1]),
        np.minimum(c, r + u).max(), (v - count * hydrogen["unit_GWh"]).max(),
        (hydrogen["minimum"] * hydrogen["unit_GWh"] - v[active]).max(),
    ]
    if policy == "B":
        err += [abs(q - np.minimum(g, d)).max(),
                abs(r - np.minimum(np.maximum(d - g, 0), np.minimum(P, prev * eta))).max()]
    assert max(err) < 2e-7, (policy, err)
    assert day.max() <= cap + 0.01
    if split:
        assert vol.max() <= cap / 48 + 0.01
    years = frame.index.year
    annual = []
    cash = (q + r) * p * 1000 + vol * netback
    for year in years.unique():
        mask = years == year
        days = mask.sum() / 48
        throughput = (r[mask] + u[mask]).sum() * 1000 / eta
        assert throughput <= days * battery["E_MWh"] + 0.002
        annual.append((year, cash[mask].sum(), throughput))
    return annual


def run(policy, frame, split):
    folder, stem, count = CASES[policy]
    config = json.loads((folder / "configuration.json").read_bytes())
    batteries, hydrogen = annual_costs(config)
    battery = batteries[0]
    product = next(h for h in hydrogen if h["id"] == "itm-neptune-v")
    assert battery["E_MWh"] == 400 and battery["P_MW"] == 100
    assert battery["retention"] == 1
    ref = pd.read_csv(folder / "results" / (stem + "_schedule.csv.gz"))
    stock, sale, h2 = (ref[battery["id"] + "__" + k].to_numpy() for k in ("stock", "sale", "hydrogen"))
    assert pd.DatetimeIndex(pd.to_datetime(ref.utc, utc=True)).equals(frame.index)
    cap, netback = config["cap_kg_day"], config["netback"]
    start_time = perf_counter()
    plans = {}
    for has_storage in (False, True):
        asset = battery if has_storage else dict(battery, P_MW=0, E_MWh=0, usable=0)
        blocks = []
        for start in range(0, len(frame), 48 * BLOCK_DAYS):
            stop = min(start + 48 * BLOCK_DAYS, len(frame))
            initial = stock[start - 1] if has_storage and start else 0.0
            terminal = stock[stop - 1] if has_storage and stop < len(frame) else 0.0
            # Split every throughput allowance by year so that every original
            # annual budget is respected, even across a block spanning New Year.
            if frame.index[start].year != frame.index[stop - 1].year:
                years = frame.index[start:stop].year
                breaks = [start, start + int(np.flatnonzero(years != years[0])[0]), stop]
            else:
                breaks = [start, stop]
            for left, right in zip(breaks, breaks[1:]):
                begin = initial if left == start else (stock[left - 1] if has_storage else 0)
                finish = terminal if right == stop else (stock[right - 1] if has_storage else 0)
                budget = ((sale[left:right] + h2[left:right]).sum() / battery["eta"] + 1e-10
                          if has_storage else None)
                blocks.append(replay_block(frame.iloc[left:right], asset, product, count,
                                           netback, cap, policy, split, begin, finish, budget))
        plans[has_storage] = np.concatenate(blocks, axis=1)
    annual_zero = check_and_cash(frame, plans[False], dict(battery, P_MW=0, E_MWh=0, usable=0),
                                 product, count, netback, cap, policy, split)
    annual_yes = check_and_cash(frame, plans[True], battery, product, count, netback, cap, policy, split)
    duration = perf_counter() - start_time
    annual_cost = battery["annual"] * 1e6
    records = []
    cap_treatment = "uniform_halfhour" if split else "daily_flexible"
    for (year, base, _), (_, rev, throughput) in zip(annual_zero, annual_yes):
        gain = rev - base
        records.append(dict(policy=policy, cap_treatment=cap_treatment, year=int(year),
                            gross_GBP=gain, annual_battery_cost_GBP=annual_cost,
                            net_GBP=gain - annual_cost, throughput_MWh=throughput))
    np.savez_compressed(ROOT / f"{policy}_{cap_treatment}_dispatch.npz",
                        cols=["direct", "charge", "battery_sale", "battery_h2", "stock", "h2_input"],
                        utc_ns=frame.index.as_unit("ns").asi8, with_battery=plans[True],
                        without_battery=plans[False])
    print(policy, cap_treatment, f"net GBP/yr {np.mean([row['net_GBP'] for row in records]):.2f}",
          f"wall {duration:.2f}s", flush=True)
    return records


if __name__ == "__main__":
    if os.environ.get("XPRESS_LICENSE_FILE"):
        xp.init(os.environ["XPRESS_LICENSE_FILE"])
    data = frame_for("2020-01-01", "2025-12-31")
    entries = run("A", data, False) + run("A", data, True) + run("B", data, False)
    pd.DataFrame(entries).to_csv(ROOT / "xpress_annual.csv", index=False, float_format="%.6f")
