"""Reproduce the frozen v7 results with FICO Xpress and its Community licence.

The electrolysis master is decomposed over complete UTC days. Its supporting
hyperplanes and the fixed-integer replay come from Xpress. For storage, local
Xpress duals are assembled into a bound evaluated on the full linked horizon.
"""

import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import sys
from time import perf_counter

import numpy as np
import pandas as pd
import xpress as xp

ROOT = Path(__file__).resolve().parent
V7 = ROOT.parent / "tier1-halfhour-20261113-v7"
sys.path.insert(0, str(V7))
from model import Matrix, annual_costs, frame_for
import verify

DAY_BLOCK = 14
STORAGE_CORE = 1008
STORAGE_OVERLAP = 96
MGBP = 1e6


def save_json(path, payload):
    path.write_text(json.dumps(payload, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def load_xpress(matrix, objective_scale=1.0):
    sparse = matrix.sparse()
    lower, upper = np.concatenate(matrix.rl), np.concatenate(matrix.ru)
    equal = lower == upper
    assert np.all(equal | np.isinf(lower) | np.isinf(upper))
    row_types = "".join(np.where(equal, "E", np.where(np.isposinf(upper), "G", "L")))
    problem = xp.problem()
    problem.controls.outputlog = 0
    problem.controls.threads = 1
    problem.controls.feastol = 1e-9
    problem.controls.optimalitytol = 1e-9
    params = dict(
        rowtype=row_types,
        rhs=np.where(np.isposinf(upper), lower, upper),
        objcoef=np.concatenate(matrix.cost) * objective_scale,
        start=sparse.indptr,
        rowind=sparse.indices,
        rowcoef=sparse.data,
        lb=np.maximum(np.concatenate(matrix.lb), -xp.infinity),
        ub=np.minimum(np.concatenate(matrix.ub), xp.infinity),
    )
    assert matrix.n + matrix.nr <= 5000
    problem.loadLP(**params)
    return problem


def optimise(problem):
    start = perf_counter()
    problem.lpOptimize("d")
    if problem.attributes.lpstatus != xp.LPStatus.OPTIMAL:
        raise RuntimeError(f"Xpress LP status: {problem.attributes.lpstatus}")
    return problem.attributes.lpobjval, perf_counter() - start


class DispatchBlock:
    def __init__(self, frame, product, config, policy, years):
        self.g, self.d, price = (frame[k].to_numpy(float) for k in ("g", "d", "price"))
        self.codes, dates = pd.factorize(frame.date, sort=False)
        self.periods = len(frame)
        self.days = len(dates)
        self.q_cost = -price / (1000 * years)
        self.h_cost = -(config["netback"] - product["variable_GBP_kg"]) / (product["kWh_kg"] * years)
        self.unit = product["unit_GWh"]
        self.minimum_energy = self.unit * product["minimum"]
        self.kwh = product["kWh_kg"]
        self.cap = config["cap_kg_day"] / MGBP
        self.policy = policy
        self.matrix, self.q, self.h = self.build_matrix(0)
        self.problem = load_xpress(self.matrix)
        self.capacity_rows = np.arange(3 * self.periods, 4 * self.periods, dtype=np.int32)

    def build_matrix(self, capacity):
        m = Matrix()
        T = self.periods
        direct = np.minimum(self.g, self.d)
        q = m.variables(
            T, lo=direct if self.policy == "B" else 0,
            hi=direct if self.policy == "B" else np.inf, c=self.q_cost,
        )
        h = m.variables(T, c=self.h_cost)
        m.rows(T, [(q, 1), (h, 1)], hi=self.g)
        m.rows(T, [(q, 1)], hi=self.d)
        m.rows(T, [(h, 1)], lo=0)
        m.rows(T, [(h, 1)], hi=capacity * self.unit)
        # Same GWh -> million kg coefficient and one cap per complete UTC day.
        m.rr.append((m.nr + self.codes).astype(np.int32))
        m.cc.append(h)
        m.val.append(np.full(T, 1 / self.kwh))
        m.nr += self.days
        m.rl.append(np.full(self.days, -np.inf))
        m.ru.append(np.full(self.days, self.cap))
        return m, q, h

    def set_capacity(self, capacity):
        self.problem.chgRHS(self.capacity_rows, np.full(self.periods, capacity * self.unit))

    def supporting_cut(self, capacity):
        self.set_capacity(capacity)
        cost, seconds = optimise(self.problem)
        dual = np.asarray(self.problem.getDuals())
        gradient = self.unit * dual[self.capacity_rows].sum()
        return cost, gradient, dual, seconds

    def replay(self, capacity):
        # Branch on the original off/on disjunction at any offending slot.
        # The two branches use actual bounds, avoiding large-M numerics.
        matrix, _, _ = self.build_matrix(capacity)
        problem = load_xpress(matrix, MGBP)
        best_cost = np.inf
        best_vector = None
        branched_slots = set()
        seconds = 0.0

        def branch():
            nonlocal seconds, best_cost, best_vector
            try:
                cost, elapsed = optimise(problem)
            except RuntimeError:
                if problem.attributes.lpstatus == xp.LPStatus.INFEAS:
                    return
                raise
            seconds += elapsed
            if cost >= best_cost:
                return
            vector = np.asarray(problem.getSolution())
            hydrogen = vector[self.h]
            violations = np.flatnonzero((hydrogen > 1e-8) & (hydrogen < self.minimum_energy - 1e-8))
            if not len(violations):
                best_cost, best_vector = cost, vector
                return
            slot = int(violations[0])
            branched_slots.add(slot)
            col = int(self.h[slot])
            problem.chgBounds([col], ["U"], [0.0])
            branch()
            problem.chgBounds([col], ["U"], [xp.infinity])
            problem.chgBounds([col], ["L"], [self.minimum_energy])
            branch()
            problem.chgBounds([col], ["L"], [0.0])

        branch()
        if best_vector is None:
            raise RuntimeError("No feasible fixed-capacity replay found")
        return best_cost / MGBP, best_vector[self.q], best_vector[self.h], seconds, len(branched_slots)


def capacity_master(blocks, annual_cost, maximum, revenue_ceiling, policy):
    """Single shared capacity and supporting cuts for total recourse cost."""
    m = Matrix()
    n = m.variables(hi=maximum, c=annual_cost)
    theta = m.variables(lo=-revenue_ceiling, c=1.0)
    m.rows(1, [(theta, 1)], lo=-revenue_ceiling)
    master = load_xpress(m)
    cuts = []
    trace = []
    solver_seconds = 0.0
    best_value = np.inf
    for iteration in range(40):
        lower, elapsed = optimise(master)
        solver_seconds += elapsed
        count = master.getSolution()[n]
        if cuts and (best_value - lower) * MGBP <= 0.05:
            weights = np.asarray(master.getDuals()[1:])
            if abs(weights.sum() - 1) > 1e-7 or weights.min() < -1e-8:
                raise RuntimeError(f"Invalid recourse cut weights: {weights}")
            weights = np.maximum(weights, 0)
            weights /= weights.sum()
            combined = [
                sum(weight * duals[index] for weight, duals in zip(weights, cuts) if weight > 0)
                for index in range(len(blocks))
            ]
            return count, combined, trace, solver_seconds

        evaluated = [block.supporting_cut(count) for block in blocks]
        cost = sum(result[0] for result in evaluated)
        gradient = sum(result[1] for result in evaluated)
        solver_seconds += sum(result[3] for result in evaluated)
        value = annual_cost * count + cost
        best_value = min(best_value, value)
        trace.append(dict(iteration=iteration, count=count, lower_cost=lower, evaluated_cost=value))
        print(f"{policy} continuous iteration {iteration}, {count:.9f} modules, "
              f"gap {(best_value-lower)*MGBP:,.4f} GBP/yr", flush=True)
        cuts.append([result[2] for result in evaluated])
        master.addRows("G", [cost - gradient * count], start=[0, 2],
                       colind=[n, theta], rowcoef=[-gradient, 1])
    raise RuntimeError("Xpress master did not converge")


def master_dual_bound(blocks, duals, product, maximum, reference):
    """Dual bound with explicit residual allowances, independent of master status."""
    capacity_reduced = product["annual"]
    dual_cost = 0.0
    gen_all, sale_all, source_all = [], [], []
    for block, dual in zip(blocks, duals):
        T = block.periods
        gen, sale, source, limit = np.split(dual[:4 * T], 4)
        gen, sale, limit = (np.minimum(a, 0) for a in (gen, sale, limit))
        source = np.maximum(source, 0)
        day_cap = np.minimum(dual[4 * T:], 0)
        q_reduced = block.q_cost - gen - sale
        h_reduced = block.h_cost - gen - source - limit - day_cap[block.codes] / block.kwh
        q_cap = np.minimum(block.g, block.d)
        # Bounds refer to the full master, where battery discharge can supply h.
        if block.policy == "B":
            dual_cost += np.dot(q_reduced, q_cap)
        else:
            dual_cost += np.dot(np.minimum(q_reduced, 0), q_cap)
        dual_cost += np.minimum(h_reduced, 0).sum() * maximum * block.unit
        dual_cost += np.dot(gen, block.g) + np.dot(sale, block.d) + day_cap.sum() * block.cap
        capacity_reduced += block.unit * limit.sum()
        gen_all.append(gen)
        sale_all.append(sale)
        source_all.append(source)
    dual_cost += min(0, capacity_reduced) * maximum
    return -dual_cost - reference, tuple(np.concatenate(a) for a in (gen_all, sale_all, source_all))


def storage_bound(product, charge_cost, discharge_value, charge_allowed, years, dt):
    """Lower-bound the full linked storage LP cost with Xpress row multipliers.

    A local LP's bookend inventory is zero. Only its centre multipliers are
    retained. Their validity follows from evaluating the Lagrangian on the
    original variable box, including every transition across a block boundary.
    """
    T = len(charge_cost)
    eta, retention = product["eta"], product["retention"]
    power = dt * product["P_MW"]
    window = product["usable"] * 1000
    charge_ub = np.where(charge_allowed, power, 0.0)
    c_cost = charge_cost * (1000 * years)
    d_cost = -discharge_value * (1000 * years)
    pi = np.empty(T + 1)
    seconds = 0.0
    largest_model = 0
    for start in range(0, T, STORAGE_CORE):
        end = min(T, start + STORAGE_CORE)
        left, right = max(0, start - STORAGE_OVERLAP), min(T, end + STORAGE_OVERLAP)
        periods = right - left
        m = Matrix()
        charge = m.variables(periods, hi=charge_ub[left:right], c=c_cost[left:right])
        discharge = m.variables(periods, hi=power, c=d_cost[left:right])
        stock = m.variables(periods, hi=window)
        m.rows(1, [(stock[0], 1), (charge[0], -eta), (discharge[0], 1 / eta)], 0, 0)
        m.rows(periods - 1, [(stock[1:], 1), (stock[:-1], -retention),
                             (charge[1:], -eta), (discharge[1:], 1 / eta)], 0, 0)
        m.rows(1, [(stock[-1], 1)], 0, 0)
        largest_model = max(largest_model, m.n + m.nr)
        model = load_xpress(m)
        _, elapsed = optimise(model)
        seconds += elapsed
        segment_duals = np.asarray(model.getDuals())
        pi[start:end] = segment_duals[start - left:end - left]
        if end == T:
            pi[-1] = segment_duals[-1]

    charge_reduced = c_cost + eta * pi[:T]
    discharge_reduced = d_cost - pi[:T] / eta
    stock_reduced = -pi[:T].copy()
    stock_reduced[:-1] += retention * pi[1:T]
    stock_reduced[-1] -= pi[-1]
    price_bound = (np.dot(charge_ub, np.minimum(charge_reduced, 0))
                   + power * np.minimum(discharge_reduced, 0).sum()
                   + window * np.minimum(stock_reduced, 0).sum()) / (MGBP * years)
    return product["annual"] + price_bound, pi, seconds, largest_model


def run_policy(frame, config, policy, output):
    started = perf_counter()
    bat, electrolyser = annual_costs(config)
    per_mw = [h["annual"] / h["MW"] for h in electrolyser]
    assert np.ptp(per_mw) < 1e-10
    assert all(h["variable_GBP_kg"] == 0 for h in electrolyser)
    assert all(h["minimum"] <= 0.5 for h in electrolyser)
    product = min(electrolyser, key=lambda h: h["kWh_kg"])
    cap = config["cap_kg_day"]
    dt = config["dt_hours"]
    dates = pd.to_datetime(frame.date.unique())
    years = float(np.sum(np.where(dates.is_leap_year, 1 / 366, 1 / 365)))
    g, d, price = (frame[k].to_numpy(float) for k in ("g", "d", "price"))
    reference = float(np.dot(price, np.minimum(g, d) * (price >= 0 if policy == "A" else 1)) / (1000 * years))
    ceiling = (np.dot(np.maximum(price, 0), d) / 1000 + len(dates) * cap * config["netback"] / MGBP) / years
    max_count = math.ceil(cap / (product["kg_hour"] * dt))
    block_size = DAY_BLOCK * 48
    blocks = [
        DispatchBlock(frame.iloc[start:start + block_size], product, config, policy, years)
        for start in range(0, len(frame), block_size)
    ]
    count, duals, trace, master_seconds = capacity_master(blocks, product["annual"], max_count, ceiling, policy)
    upper, (gen, sale, source) = master_dual_bound(blocks, duals, product, max_count, reference)
    cap_wall = perf_counter() - started

    sale_value = price / (1000 * years) + sale
    hydrogen_value = -gen - source
    allowed = np.ones(len(frame), dtype=bool)
    if policy == "B":
        sale_value = np.where(d > g, sale_value, -np.inf)
        allowed = g > d
    prices = dict(charge_cost=-gen, discharge_value=np.maximum(sale_value, hydrogen_value),
                  charge_allowed=allowed)
    storage_started = perf_counter()
    battery_duals, penalties, storage_seconds, storage_sizes = {}, {}, 0.0, {}
    for b in bat:
        bound, pi, elapsed, size = storage_bound(b, **prices, years=years, dt=dt)
        battery_duals[b["id"]] = pi
        penalties[b["id"]] = bound * MGBP
        storage_seconds += elapsed
        storage_sizes[b["id"]] = size
        print(f"{policy} {b['id']} per-unit penalty at least {bound*MGBP:,.2f} GBP/yr", flush=True)
    storage_wall = perf_counter() - storage_started

    replay_started = perf_counter()
    integer_count = math.ceil(count - 1e-8)
    solved = [block.replay(integer_count) for block in blocks]
    op_cost = sum(result[0] for result in solved)
    annual_cost = integer_count * product["annual"]
    profit = -op_cost - annual_cost
    increment = profit - reference
    gap = (upper - increment) * MGBP
    if not -0.05 <= gap < min(penalties.values()) - 10:
        raise RuntimeError(f"{policy} gap £{gap:,.4f} vs battery penalties {penalties}")
    name = f"xpress_{policy}"
    investments = {asset["id"]: 0 for asset in bat + electrolyser}
    investments[product["id"]] = integer_count
    schedule = frame[["date", "g", "d", "price"]].copy()
    schedule["direct"] = np.concatenate([block[1] for block in solved])
    h2_input = np.concatenate([block[2] for block in solved])
    for b in bat:
        for flow in ("charge", "sale", "hydrogen", "stock"):
            schedule[b["id"] + "__" + flow] = 0.0
    for h in electrolyser:
        schedule[h["id"] + "__input"] = h2_input if h["id"] == product["id"] else 0.0
    for key in ("charge", "battery_sale", "battery_h2"):
        schedule[key] = 0.0
    schedule["h2_input"] = schedule["generation_h2"] = h2_input
    schedule["h2_kg"] = h2_input * MGBP / product["kWh_kg"]
    schedule["sales"] = schedule.direct
    schedule["unused"] = g - schedule.direct - h2_input
    schedule["unserved"] = d - schedule.sales
    replay_wall = perf_counter() - replay_started
    total_before_export = perf_counter() - started
    hashes = {
        str(path.relative_to(V7)): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in (V7 / "inputs/halfhour.csv.gz", V7 / "configuration.json")
    }
    meta = dict(
        name=name, solver=f"FICO Xpress {xp.__version__}", policy=policy,
        dt_hours=dt, periods=len(frame), days=len(dates), years=years, cap_kg_day=cap,
        relaxation=False, zero_battery_certified=True, investment=investments,
        active_products={"batteries": bat, "electrolysers": electrolyser},
        battery_MWh=0.0, electrolyser_MW=integer_count * product["MW"],
        continuous_electrolyser_MW=count * product["MW"],
        annual_reference_mGBP=reference, annual_profit_mGBP=profit,
        annual_increment_mGBP=increment, upper_increment_mGBP=upper,
        global_profit_gap_GBP=gap, battery_dual_penalties_GBP=penalties,
        annual_electricity_mGBP=float(np.dot(price, schedule.sales) / (1000 * years)),
        annual_hydrogen_mGBP=float(schedule.h2_kg.sum() * config["netback"] / (MGBP * years)),
        annual_equipment_mGBP=annual_cost,
        annual_h2_tonnes=float(schedule.h2_kg.sum() / (1000 * years)),
        demand_coverage=float(schedule.sales.sum() / d.sum()),
        sizing_trace=trace, fixed_replay_minimum_load_branches=sum(result[4] for result in solved),
        storage_block_max_rows_plus_cols=storage_sizes, input_sha256=hashes,
        timing_seconds={
            "capacity_wall": cap_wall, "capacity_solver_calls": master_seconds,
            "storage_certificate_wall": storage_wall, "storage_solver_calls": storage_seconds,
            "fixed_integer_replay_wall": replay_wall, "fixed_integer_replay_solver_calls": sum(result[3] for result in solved),
            "total_wall_before_export": total_before_export,
        },
    )
    schedule.to_csv(output / (name + "_schedule.csv.gz"), index_label="utc", compression="gzip", float_format="%.12g")
    terms = dict(master_gen=gen, master_sale=sale, master_h_source=source,
                 master_limit=np.concatenate([a[3 * b.periods:4 * b.periods] for a, b in zip(duals, blocks)]),
                 master_daily_cap=np.concatenate([a[4 * b.periods:] for a, b in zip(duals, blocks)]))
    np.savez_compressed(output / (name + "_certificate.npz"), **terms, **battery_duals, **prices)
    meta["timing_seconds"]["wall_including_export"] = perf_counter() - started
    save_json(output / (name + ".json"), meta)
    # The original v7 independent schedule/cash audit reads only these copies.
    verify.ROOT = output.parent
    verify.verify(name)
    print(f"{policy} CERTIFIED: {integer_count} x {product['id']}, {increment:,.9f} mGBP/yr, "
          f"global gap {gap:.2f} GBP/yr; wall time {total_before_export:.2f}s", flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--policy", choices=("A", "B", "both"), default="both")
    args = parser.parse_args()
    license_file = os.environ.get("XPRESS_LICENSE_FILE")
    if license_file:
        xp.init(license_file)
    frame = frame_for("2020-01-01", "2025-12-31", "flat")
    assert len(frame) == 105216
    output = ROOT / "results"
    output.mkdir(exist_ok=True)
    configuration_path = V7 / "configuration.json"
    config = json.loads(configuration_path.read_bytes())
    (ROOT / "configuration.json").write_bytes(configuration_path.read_bytes())
    for policy in ("A", "B") if args.policy == "both" else (args.policy,):
        run_policy(frame, config, policy, output)


if __name__ == "__main__":
    main()
