"""Joint integer sizing at the 10 t/day site using the existing half-hour dispatch."""

import argparse
import json
from time import perf_counter

import numpy as np
import pandas as pd

from run_site import (
    GBP_PER_MILLION, HORIZON_YEARS, PROJECT, ROOT, SITE_CAP, Problem, annual_costs,
    check_and_cash, electrolysis_only, frame_for, investment_model, priority_dispatch,
    repair_economic_anchor,
)

OUTPUT = ROOT / "joint"
UPPER_ROUNDING_MGBP = 0.000002


def inputs():
    frame = frame_for("2020-01-01", "2025-12-31")
    source = PROJECT / "storage-exploration-20261116-v2/utility4h/configuration.json"
    config = json.loads(source.read_bytes())
    config["cap_kg_day"] = SITE_CAP
    config["electrolysers"] = [
        item for item in config["electrolysers"] if item["id"] == "itm-neptune-v"
    ]
    (battery,), (product,) = annual_costs(config)
    return frame, config, battery, product


def reference_revenue(frame, policy):
    price = frame.price.to_numpy()
    direct = np.minimum(frame.g, frame.d).to_numpy()
    if policy == "A":
        direct = direct * (price >= 0)
    return direct * price * 1000


def maximum_receipts(frame, config, policy):
    price = frame.price.to_numpy()
    ceiling = np.dot(np.maximum(price, 0), frame.d) * 1000
    h2 = frame.date.nunique() * SITE_CAP * config["netback"]
    return (ceiling + h2 - reference_revenue(frame, policy).sum()) / HORIZON_YEARS / GBP_PER_MILLION


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def scaled_battery(battery, blocks):
    return dict(battery, **{field: battery[field] * blocks for field in ("P_MW", "E_MWh", "usable", "annual")})


def record_candidate(frame, config, battery, product, policy, blocks, units, flows, upper_mGBP):
    asset = scaled_battery(battery, blocks)
    ref = reference_revenue(frame, policy)
    operating = check_and_cash(frame, flows, asset, product, units, config["netback"], SITE_CAP, policy, False)
    rows = []
    for year, amount, throughput in operating:
        mask = frame.index.year == year
        year_revenue = amount - ref[mask].sum()
        rows.append(dict(
            year=int(year), incremental_receipts_GBP=year_revenue, annual_internal_discharge_MWh=throughput,
            annual_net_gain_GBP=year_revenue - (asset["annual"] + units * product["annual"]) * GBP_PER_MILLION,
        ))
    annual = pd.DataFrame(rows)
    gain = float(annual.annual_net_gain_GBP.mean()) / GBP_PER_MILLION
    payload = dict(
        policy=policy, battery_blocks=int(blocks), battery_MW=asset["P_MW"], battery_MWh=asset["E_MWh"],
        electrolyser_units=int(units), electrolyser_MW=units * product["MW"],
        annual_net_gain_mGBP=gain, fixed_configuration_upper_mGBP=max(gain, upper_mGBP),
        annual_battery_cost_mGBP=asset["annual"], annual_electrolyser_cost_mGBP=units * product["annual"],
    )
    assert gain <= upper_mGBP + UPPER_ROUNDING_MGBP, (blocks, units, gain, upper_mGBP)
    stem = OUTPUT / f"{policy}_n{blocks}_h{units}"
    write_json(stem.with_suffix(".json"), payload)
    annual.to_csv(OUTPUT / f"{stem.name}_annual.csv", index=False, float_format="%.8f")
    np.savez_compressed(OUTPUT / f"{stem.name}_dispatch.npz", flows=flows, utc_ns=frame.index.as_unit("ns").asi8)
    return payload


def trial_a(frame, config, battery, product, blocks, units):
    investment_model.ROOT = OUTPUT
    name = f"A_relax_n{blocks}_h{units}"
    fixed = {battery["id"]: blocks, product["id"]: units}
    result = investment_model.solve(
        frame, config, "A", name, fixed=fixed, relaxation=True, dual_envelope=True,
        seconds=100, threads=3,
    )
    raw = pd.read_csv(OUTPUT / f"results/{name}_schedule.csv.gz")
    flows = raw[["direct", "charge", "battery_sale", "battery_h2",
                 battery["id"] + "__stock", "h2_input"]].to_numpy().T
    flows, repairs = repair_economic_anchor(frame, flows, scaled_battery(battery, blocks), product)
    upper = result["envelope_value_mGBP"] + UPPER_ROUNDING_MGBP
    row = record_candidate(frame, config, battery, product, "A", blocks, units, flows, upper)
    row["minimum_load_repairs"] = repairs
    row["supporting_plane_mGBP"] = {
        "at": [blocks, units], "value": upper,
        "gradient": [result["capacity_profit_supergradient_mGBP"][asset_id] for asset_id in fixed],
        "scope": "all capacities" if blocks and units else "capacity axes only",
    }
    return row


def trial_b(frame, config, battery, product, blocks, units):
    if blocks == 0:
        flows = electrolysis_only(frame, product, config, "B", units)
        gap = 0.0
    else:
        flows, proof = priority_dispatch(
            frame, config, scaled_battery(battery, blocks), product, units, blocks,
        )
        gap = proof["upper_gap_GBP_year"] / GBP_PER_MILLION
    cash = (flows[0] + flows[2]) * frame.price.to_numpy() * 1000
    cash += flows[5] * GBP_PER_MILLION / product["kWh_kg"] * config["netback"]
    net = (cash - reference_revenue(frame, "B")).sum() / (HORIZON_YEARS * GBP_PER_MILLION)
    net -= blocks * battery["annual"] + units * product["annual"]
    return record_candidate(frame, config, battery, product, "B", blocks, units, flows, net + gap)


def priority_lp(frame, config, battery, product, lower, upper, h_min, h_max):
    """Continuous upper bound with the convex hull of mandatory discharge at fixed capacity."""
    job = Problem(frame, config, OUTPUT, f"screen_{lower}_{upper}_{h_min}_{h_max}",
                  upper, h_max, nbmin=lower, nhmin=h_min, strict=False,
                  integer=False, quiet=True, years=HORIZON_YEARS, seconds=120)
    solver = job.solver
    solver.setOptionValue("solver", "simplex")
    solver.setOptionValue("simplex_strategy", 1)
    solver.setOptionValue("threads", 3)
    # The maximum reachable stock per installed block uses the most favourable
    # charge rate and lowest forced discharge across the capacity interval.
    reach = np.zeros(len(frame))
    stock = 0.0
    for t, gap in enumerate(job.g - job.d):
        if gap < 0:
            stock = max(0.0, stock - min(-gap / upper, job.P) / job.eta)
        else:
            charge = job.P if lower == 0 and gap > 0 else min(job.P, gap / max(lower, 1))
            stock = min(job.W, stock + job.eta * charge)
        reach[t] = stock

    def add_rows(cols, vals, lo, hi):
        count, width = cols.shape
        if count == 0:
            return
        inf = float(investment_model.highspy.kHighsInf)
        solver.addRows(count, np.full(count, lo if np.isfinite(lo) else -inf),
                       np.full(count, hi if np.isfinite(hi) else inf), count * width,
                       np.arange(0, count * width + 1, width, dtype=np.int32),
                       cols.astype(np.int32).ravel(), vals.astype(float).ravel())

    slots = np.flatnonzero(job.s != job.zero)
    add_rows(np.column_stack((job.s[slots], np.full(len(slots), job.n))),
             np.column_stack((np.ones(len(slots)), -reach[slots])), -np.inf, 0)
    slots = np.flatnonzero((job.deficit[1:] > 0) & (reach[:-1] > 0)) + 1
    ac = reach[slots - 1] * job.eta
    ratio = np.minimum(1, np.minimum(job.P / ac, job.deficit[slots] / (upper * ac)))
    add_rows(np.column_stack((job.r[slots], job.s[slots-1])),
             np.column_stack((np.ones(len(slots)), -ratio * job.eta)), 0, np.inf)
    job.run()
    assert job.upper is not None, job.status
    return dict(battery_interval=[lower, upper], h2_interval=[h_min, h_max],
                battery_blocks=float(job.x[job.n]), electrolyser_units=float(job.x[job.nh]),
                upper_mGBP=job.upper + UPPER_ROUNDING_MGBP, status=job.status)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("A", "B", "B-bound"))
    parser.add_argument("counts", nargs="+", type=int)
    args = parser.parse_args()
    OUTPUT.mkdir(exist_ok=True)
    start = perf_counter()
    data = inputs()
    if args.mode == "B-bound":
        result = priority_lp(*data, *args.counts)
        name = "B_bound_" + "_".join(map(str, args.counts))
    else:
        trial = trial_a if args.mode == "A" else trial_b
        result = trial(*data, *args.counts)
        name = f"{args.mode}_n{args.counts[0]}_h{args.counts[1]}"
    result["elapsed_seconds"] = perf_counter() - start
    write_json(OUTPUT / (name + ".json"), result)
    print(json.dumps(result), flush=True)
