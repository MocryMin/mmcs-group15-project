"""Strict-priority B sizing at half-hour resolution.

Direct supply is eliminated as a constant. A normalised reachable-stock upper
bound, valid for every capacity in the current interval, prunes empty periods.
Every remaining mandatory discharge min(deficit, power, preceding energy) is
enforced up front. Continuous efficient-electrolyser relaxation bounds all
eight original products at equal annual cost/MW; integer candidates use NeptuneV.
"""
from pathlib import Path
import sys,json,time,math,tempfile,shutil
import numpy as np
import pandas as pd
import highspy
ROOT=Path(__file__).resolve().parent;V7=ROOT.parent/'tier1-halfhour-20261113-v7'
sys.path.insert(0,str(V7))
from investment_model import Matrix,annual_costs

class Problem:
    def __init__(self,f,cfg,out,name,nbmax,nhmax,nbmin=0,nhmin=0,strict=False,integer=False,fixed=None,seconds=300,h_integer=True,cycles=True,years=None,quiet=False):
        self.f=f;self.cfg=cfg;self.out=out;self.name=name;self.strict=strict;self.integer=integer;self.fixed=fixed
        self.bs,self.hs=annual_costs(cfg);self.b=self.bs[0];self.h=min(self.hs,key=lambda h:h['kWh_kg'])
        b,h=self.b,self.h;T=len(f);self.T=T
        self.codes,days=pd.factorize(f.date,sort=False);self.days=days
        self.Y=years if years is not None else sum(1/(366 if pd.Timestamp(d).is_leap_year else 365) for d in days);self.quiet=quiet
        self.g,self.d,self.p=(f[k].to_numpy(float) for k in ('g','d','price'))
        self.surplus=np.maximum(self.g-self.d,0);self.deficit=np.maximum(self.d-self.g,0)
        self.P=.5*b['P_MW']/1000;self.W=b['usable'];eta=b['eta'];ret=b['retention'];self.eta=eta
        if fixed is not None:nbmin=nbmax=float(fixed[0]);nhmin=nhmax=float(fixed[1])
        self.nbmax,self.nhmax=nbmax,nhmax
        # Upper state per unit for ALL n <= nbmax: maximum charging, weakest
        # normalised mandatory depletion. n=0 follows from s <= n*bound.
        prev=0.;upper=np.zeros(T);prior=np.zeros(T)
        for t in range(T):
            prior[t]=prev*ret
            if self.deficit[t]>0:
                upper[t]=max(0,prior[t]-min(self.deficit[t]/nbmax,self.P)/eta) if nbmax>0 else 0
            else:upper[t]=min(self.W,prior[t]+eta*self.P) if nbmax>0 else 0
            prev=upper[t]
        self.state_upper,self.prior_upper=upper,prior
        m=Matrix();self.n=m.variables(lo=nbmin,hi=nbmax,c=b['annual'],integer=integer and fixed is None)
        self.nh=m.variables(lo=nhmin,hi=nhmax,c=h['annual'],integer=integer and h_integer and fixed is None)
        self.zero=m.variables(hi=0);zeros=np.full(T,self.zero,dtype=np.int32)
        def variable(up,cost=0):
            use=up>1e-12;ix=zeros.copy()
            if use.any():ix[use]=m.variables(int(use.sum()),hi=up[use],c=np.broadcast_to(cost,(T,))[use])
            return ix
        self.c=variable(np.minimum(self.surplus,nbmax*self.P))
        self.r=variable(np.minimum(self.deficit,np.minimum(nbmax*self.P,nbmax*prior*eta)), -self.p/(1000*self.Y))
        self.bh=variable(np.minimum(nbmax*self.P,nbmax*prior*eta))
        self.s=variable(nbmax*upper)
        self.v=variable(np.minimum(self.surplus+nbmax*prior*eta,nhmax*h['unit_GWh']),-(cfg['netback']-h['variable_GBP_kg'])/(h['kWh_kg']*self.Y))
        m.rows(1,[(self.s[0],1),(self.c[0],-eta),(self.r[0],1/eta),(self.bh[0],1/eta)],0,0)
        m.rows(T-1,[(self.s[1:],1),(self.s[:-1],-ret),(self.c[1:],-eta),(self.r[1:],1/eta),(self.bh[1:],1/eta)],0,0)
        m.rows(1,[(self.s[-1],1)],0,0)
        m.rows(T,[(self.s,1),(self.n,-upper)],hi=0)
        m.rows(T,[(self.c,1),(self.n,-self.P)],hi=0)
        m.rows(T,[(self.r,1),(self.bh,1),(self.n,-self.P)],hi=0)
        m.rows(T,[(self.v,1),(self.nh,-h['unit_GWh'])],hi=0)
        m.rows(T,[(self.c,1),(self.v,1),(self.bh,-1)],hi=self.surplus)
        m.rows(T,[(self.v,1),(self.bh,-1)],lo=0)
        for year in (sorted(set(f.date.str[:4])) if cycles else []):
            mask=f.date.str.startswith(year).to_numpy();length=int(mask.sum());nd=f.loc[mask,'date'].nunique()
            row=m.nr;m.nr+=1
            for ix in (self.r,self.bh):
                m.rr.append(np.full(length,row,dtype=np.int32));m.cc.append(ix[mask]);m.val.append(np.full(length,1/eta))
            m.rr.append(np.array([row],dtype=np.int32));m.cc.append(np.array([self.n],dtype=np.int32));m.val.append(np.array([-nd*b['E_MWh']/1000]))
            m.rl.append(np.array([-np.inf]));m.ru.append(np.array([0.]))
        rows=m.nr+self.codes;m.nr+=len(days);m.rr.append(rows.astype(np.int32));m.cc.append(self.v);m.val.append(np.full(T,1/h['kWh_kg']))
        m.rl.append(np.full(len(days),-np.inf));m.ru.append(np.full(len(days),cfg['cap_kg_day']/1e6))
        self.priority_binaries=[];linear=0
        if strict:
            for t in np.flatnonzero((self.deficit>0)&(prior>1e-12)):
                previous=self.s[t-1] if t else self.zero;D=self.deficit[t];su=prior[t]*eta
                # Valid lower convex envelope of mandatory min(D,P*n,eta*s).
                # Since s <= n*prior and n <= U, each argument of the min
                # is at least beta*eta*s. It cuts fractional on/off leakage.
                beta=min(1.,self.P/su,D/(nbmax*su))
                m.rows(1,[(self.r[t],1),(previous,-beta*ret*eta)],lo=0)
                if su<=self.P+1e-12 and nbmax*su<=D+1e-12:
                    m.rows(1,[(self.r[t],1),(previous,-ret*eta)],0,0);linear+=1
                elif D>=nbmax*self.P-1e-12:
                    z=m.variables(hi=1,integer=True)
                    m.rows(1,[(self.r[t],1),(self.n,-self.P),(z,nbmax*self.P)],lo=0)
                    m.rows(1,[(self.r[t],1),(previous,-ret*eta),(z,-nbmax*su)],lo=-nbmax*su)
                    self.priority_binaries.append((t,'power_stock',z))
                elif D<=nbmin*self.P+1e-12:
                    z=m.variables(hi=1,integer=True)
                    m.rows(1,[(self.r[t],1),(z,D)],lo=D)
                    m.rows(1,[(self.r[t],1),(previous,-ret*eta),(z,-nbmax*su)],lo=-nbmax*su)
                    self.priority_binaries.append((t,'deficit_stock',z))
                else:
                    served=m.variables(hi=1,integer=True);z=m.variables(hi=1,integer=True)
                    m.rows(1,[(self.r[t],1),(served,-D)],lo=0)
                    m.rows(1,[(self.r[t],1),(self.n,-self.P),(z,nbmax*self.P),(served,nbmax*self.P)],lo=0)
                    m.rows(1,[(self.r[t],1),(previous,-ret*eta),(z,-nbmax*su),(served,nbmax*su)],lo=-nbmax*su)
                    self.priority_binaries.append((t,'three',served,z))
        self.cost=np.concatenate(m.cost);A=m.sparse();A.eliminate_zeros()
        lower=np.concatenate(m.lb);upper_col=np.concatenate(m.ub);rl=np.concatenate(m.rl);ru=np.concatenate(m.ru)
        # Remove only rows already implied by the finite variable box. This
        # includes thousands of disabled-period identities and cannot remove
        # any feasible restriction or change the objective.
        pos=A.maximum(0);neg=A.minimum(0)
        box_min=pos@lower+neg@upper_col;box_max=pos@upper_col+neg@lower
        keep=~((box_min>=rl)&(box_max<=ru));A=A[keep].tocsc();rl=rl[keep];ru=ru[keep]
        lp=highspy.HighsLp();lp.num_col_=m.n;lp.num_row_=A.shape[0];lp.col_cost_=self.cost
        lp.col_lower_=lower;lp.col_upper_=upper_col;lp.row_lower_=rl;lp.row_upper_=ru
        lp.a_matrix_.format_=highspy.MatrixFormat.kColwise;lp.a_matrix_.start_=A.indptr;lp.a_matrix_.index_=A.indices;lp.a_matrix_.value_=A.data
        solver=highspy.Highs();self.solver=solver;solver.setOptionValue('output_flag',not quiet);solver.setOptionValue('threads',4);solver.setOptionValue('time_limit',seconds)
        solver.setOptionValue('mip_rel_gap',1e-6);solver.setOptionValue('mip_abs_gap',.0001);solver.setOptionValue('random_seed',0)
        solver.setOptionValue('mip_feasibility_tolerance',1e-7)
        solver.setOptionValue('log_to_console',False);solver.setOptionValue('output_flag',not quiet)
        self.log=Path(tempfile.gettempdir())/f'mmcs_Bv4_{out.name}_{name}.log';solver.setOptionValue('log_file',str(self.log))
        solver.passModel(lp);self.has_int=bool(m.ints)
        if m.ints:solver.changeColsIntegrality(len(m.ints),np.array(m.ints,dtype=np.int32),np.ones(len(m.ints),dtype=np.uint8))
        else:
            solver.setOptionValue('solver','ipm');solver.setOptionValue('run_crossover','off')
        if not quiet:print(name,'BUILD',T,m.n,A.shape[0],'priority',len(self.priority_binaries),'linear',linear,flush=True)
        self.nvars=m.n

    def run(self):
        self.solver.run();status=self.solver.getModelStatus();sol=self.solver.getSolution();info=self.solver.getInfo()
        if not sol.value_valid:raise RuntimeError((self.name,str(status)))
        self.x=np.array(sol.col_value);self.value=-float(info.objective_function_value)
        self.upper=-float(info.mip_dual_bound) if self.has_int else (self.value if status==highspy.HighsModelStatus.kOptimal else None)
        self.status=str(status)
        if not self.quiet:print(self.name,'SOLVED',self.status,'profit',self.value,'upper',self.upper,'n,h',self.x[self.n],self.x[self.nh],flush=True)
        return self.value

    def range_above(self,lower):
        assert not self.has_int
        nz=np.flatnonzero(self.cost);self.solver.addRow(-highspy.kHighsInf,-lower,len(nz),nz.astype(np.int32),self.cost[nz])
        ranges={}
        for label,col in [('battery',self.n),('electrolyser',self.nh)]:
            vals=[]
            for sign in [1,-1]:
                costs=np.zeros(self.nvars);costs[col]=sign
                self.solver.changeColsCost(self.nvars,np.arange(self.nvars,dtype=np.int32),costs);self.solver.run()
                assert self.solver.getModelStatus()==highspy.HighsModelStatus.kOptimal
                vals.append(float(self.solver.getSolution().col_value[col]))
            ranges[label]=vals
        return ranges

    def warm(self,meta,schedule):
        x=np.zeros(self.nvars);x[self.n]=meta['investment'].get(self.b['id'],0);x[self.nh]=meta['investment'].get(self.h['id'],0)
        if x[self.n]>self.nbmax+1e-6 or x[self.nh]>self.nhmax+1e-6:return
        for ix,col in [(self.c,'__charge'),(self.r,'__sale'),(self.bh,'__hydrogen'),(self.s,'__stock')]:
            use=ix!=self.zero;x[ix[use]]=schedule[self.b['id']+col].to_numpy()[use]
        use=self.v!=self.zero;x[self.v[use]]=schedule[self.h['id']+'__input'].to_numpy()[use]
        for item in self.priority_binaries:
            t,kind=item[:2];stock=x[self.s[t-1]]*self.b['retention']*self.eta if t else 0
            if kind=='power_stock':x[item[2]]=float(stock<x[self.n]*self.P-1e-9)
            elif kind=='deficit_stock':x[item[2]]=float(stock<self.deficit[t]-1e-9)
            else:
                x[item[2]]=float(self.deficit[t]<=min(stock,x[self.n]*self.P)+1e-9)
                x[item[3]]=float(stock<x[self.n]*self.P-1e-9)
        sol=highspy.HighsSolution();sol.col_value=x.tolist();sol.value_valid=True;self.solver.setSolution(sol)

    def finish(self,repair=True):
        initial_upper=self.upper;trace=[];seen=set()
        for k in range(12):
            x=self.x;bad=np.flatnonzero((x[self.v]>1e-8)&(x[self.v]<self.h['minimum']*self.h['unit_GWh']-1e-8))
            trace.append(dict(iteration=k,profit=self.value,upper=self.upper,subminimum_periods=len(bad)))
            if not len(bad):break
            assert repair
            new=set(map(int,bad))-seen;assert new
            for t in new:self.solver.changeColBounds(int(self.v[t]),0,0)
            seen.update(new);self.solver.setOptionValue('time_limit',120);self.run()
        else:raise RuntimeError('minimum-load repair did not close')
        x=self.x.copy();eta=self.eta
        overlap=np.minimum(x[self.c]*eta**2,x[self.bh]);
        # Arrays repeat the disabled zero index, so only write active positions.
        use=self.c!=self.zero;x[self.c[use]]-=overlap[use]/eta**2
        use=self.bh!=self.zero;x[self.bh[use]]-=overlap[use]
        s=self.f[['date','g','d','price']].copy();s['direct']=np.minimum(self.g,self.d)
        b,h=self.b,self.h
        for label,ix in [('charge',self.c),('sale',self.r),('hydrogen',self.bh),('stock',self.s)]:s[b['id']+'__'+label]=x[ix]
        for hh in self.hs:s[hh['id']+'__input']=x[self.v] if hh['id']==h['id'] else 0.
        s['charge']=x[self.c];s['battery_sale']=x[self.r];s['battery_h2']=x[self.bh];s['h2_input']=x[self.v]
        s['generation_h2']=s.h2_input-s.battery_h2;s['h2_kg']=s.h2_input*1e6/h['kWh_kg']
        s['sales']=s.direct+s.battery_sale;s['unused']=self.g-s.direct-s.charge-s.generation_h2;s['unserved']=self.d-s.sales
        counts={q['id']:0. for q in self.bs+self.hs};counts[b['id']]=float(x[self.n]);counts[h['id']]=float(x[self.nh])
        electricity=np.dot(self.p,s.sales)/(1000*self.Y);hydrogen=s.h2_kg.sum()*self.cfg['netback']/(1e6*self.Y)
        variable=s.h2_kg.sum()*h['variable_GBP_kg']/(1e6*self.Y);equipment=x[self.n]*b['annual']+x[self.nh]*h['annual']
        ref=np.dot(self.p,np.minimum(self.g,self.d))/(1000*self.Y);profit=float(electricity+hydrogen-variable-equipment)
        meta=dict(name=self.name,policy='B',dt_hours=.5,periods=self.T,days=len(self.days),years=self.Y,cap_kg_day=self.cfg['cap_kg_day'],
            relaxation=False,exact_operating_feasible=True,status=self.status,annual_profit_mGBP=profit,annual_increment_mGBP=profit-ref,
            upper_increment_mGBP=initial_upper,annual_reference_mGBP=float(ref),annual_electricity_mGBP=float(electricity),annual_hydrogen_mGBP=float(hydrogen),
            annual_equipment_mGBP=float(equipment),investment=counts,battery_MWh=float(x[self.n]*b['E_MWh']),electrolyser_MW=float(x[self.nh]*h['MW']),
            annual_h2_tonnes=float(s.h2_kg.sum()/1000/self.Y),demand_coverage=float(s.sales.sum()/s.d.sum()),annual_unserved_GWh=float(s.unserved.sum()/self.Y),
            annual_unused_GWh=float(s.unused.sum()/self.Y),active_products={'batteries':self.bs,'electrolysers':self.hs},repair_trace=trace,
            bound_scope='Global within capacity bounds and NeptuneV integer capacity, relaxed minimum-load. Separately retain all-product continuous upper bound.')
        out=self.out/'results';out.mkdir(exist_ok=True)
        (out/(self.name+'.json')).write_text(json.dumps(meta,indent=2))
        s.to_csv(out/(self.name+'_schedule.csv.gz'),index_label='utc',compression='gzip',float_format='%.12g')
        if self.log.exists():shutil.copy2(self.log,out/(self.name+'.log'))
        return meta,s
