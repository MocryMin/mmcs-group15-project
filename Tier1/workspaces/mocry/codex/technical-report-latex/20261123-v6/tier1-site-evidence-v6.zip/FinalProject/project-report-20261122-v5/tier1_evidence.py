"""Build numerical exhibits for the Tier 1 report from the frozen inputs."""
import json
import math
import os
from pathlib import Path
import sys
from contextlib import redirect_stdout
import io

import numpy as np
import pandas as pd
import xpress as xp

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parent
sys.path.insert(0, str(PROJECT / "tier1-xpress-reproduction-20261122"))
from reproduce import DispatchBlock, annual_costs, capacity_master, frame_for

V7 = PROJECT / "tier1-halfhour-20261113-v7"
COMMON = PROJECT / "tier1-common-equipment-20261122"
MODEL = json.loads((V7 / "configuration.json").read_bytes())
CONTRACT = json.loads((PROJECT / "publication-20261119/tier1/tier2b-equipment.json").read_bytes())
YEARS = 6


def greedy(frame, base, policy, battery):
    """Charge from unused generation and sell into an immediate shortfall."""
    generation, demand, price = (frame[k].to_numpy() for k in ("g", "d", "price"))
    q, _, _, _, _, h = base
    eta = battery["one_way_efficiency"]
    capacity = battery["usable_internal_MWh"] / 1000
    power = battery["ac_charge_MW"] / 2000
    nominal = battery["nominal_MWh"] / 1000
    stock = 0.0
    flows = base.copy()
    years = frame.index.year
    budgets = {y: np.count_nonzero(years == y) / 48 * nominal for y in set(years)}
    cum_out = 0.0
    previous_year = None
    for t in range(len(frame)):
        y = years[t]
        if y != previous_year:
            previous_year, cum_out = y, 0.0
        sale = min(power, stock * eta, max(0.0, demand[t] - q[t])) if policy == "B" or price[t] > 0 else 0.0
        charge = 0.0
        if sale == 0 and t < len(frame) - 48:
            # Keep sufficient discharge budget for all held stock, including
            # stock carried into this year, so priority can always be honoured.
            energy_room = min(capacity - stock, budgets[y] - cum_out - stock)
            charge = min(power, max(0.0, generation[t] - q[t] - h[t]), max(0.0, energy_room) / eta)
        stock += eta * charge - sale / eta
        cum_out += sale / eta
        flows[1:5, t] = charge, sale, 0, stock
    assert abs(stock) < 1e-8
    q, c, r, u, stock, h = flows
    assert np.max(q + c + h - generation) < 1e-8
    assert np.max(q + r - demand) < 1e-8
    if policy == "B":
        priority = np.minimum(demand - q, np.minimum(power, np.r_[0, stock[:-1]] * eta))
        np.testing.assert_allclose(r, priority, atol=1e-9)
    for y in set(years):
        assert r[years == y].sum() / eta <= budgets[y] + 1e-8
    return flows


def metrics(frame, flows, netback, kwh):
    g, d, p = (frame[k].to_numpy() for k in ("g", "d", "price"))
    q, c, r, u, stock, h = flows
    physical = np.maximum(g - d, 0)
    sales = q + r
    hydrogen_kg = h * 1e6 / kwh
    return dict(
        electricity_mGBP=float(np.dot(p, sales) / (1000 * YEARS)),
        hydrogen_mGBP=float(hydrogen_kg.sum() * netback / (1e6 * YEARS)),
        hydrogen_kt=float(hydrogen_kg.sum() / (1e6 * YEARS)),
        unmet_GWh=float((d - sales).sum() / YEARS),
        coverage_pct=float(sales.sum() / d.sum() * 100),
        unused_GWh=float((g - q - c - h + u).sum() / YEARS),
        surplus_uptake_GWh=float(np.minimum(physical, c + h - u).sum() / YEARS),
        charge_GWh=float(c.sum() / YEARS), discharge_sales_GWh=float(r.sum() / YEARS),
        discharge_hydrogen_GWh=float(u.sum() / YEARS),
        charge_loss_GWh=float((c - r - u).sum() / YEARS),
    )


def fixed_results(frame):
    b = CONTRACT["battery"]
    h = CONTRACT["electrolysers"]
    netback, kwh = h["netback_GBP_per_kg"], h["ac_kWh_per_kg"]
    annual = b["cost_scenarios"][0]["annual_total_GBP"]
    annual_high = b["cost_scenarios"][1]["annual_total_GBP"]
    output = {}
    for policy, scenario in (("A", "uniform_halfhour"), ("B", "daily_flexible")):
        with np.load(COMMON / f"{policy}_{scenario}_dispatch.npz") as curves:
            zero, oracle = (curves[name] for name in ("without_battery", "with_battery"))
        naive = greedy(frame, zero, policy, b)
        ref = zero.copy()
        ref[0] = np.minimum(frame.g, frame.d) * (frame.price >= 0 if policy == "A" else 1)
        ref[5] = 0
        results = {name: metrics(frame, flows, netback, kwh) for name, flows in
                   (("no_investment", ref), ("electrolysis_only", zero), ("simple_storage", naive), ("oracle", oracle))}
        capital = b["capital_cost_low_GBP"]
        v7 = json.loads((V7 / "results" / f"full_{policy}_candidate.json").read_bytes())
        annual_h2 = v7["annual_equipment_mGBP"]
        results["electrolysis_cost_mGBP"] = annual_h2
        results["initial_electrolysis_mGBP"] = v7["initial_capex_mGBP"]
        for name in ("simple_storage", "oracle"):
            row = results[name]
            base = results["electrolysis_only"]
            gain = sum(row[k] - base[k] for k in ("electricity_mGBP", "hydrogen_mGBP")) * 1e6
            row["battery_gross_mGBP"] = gain / 1e6
            row["battery_net_mGBP"] = (gain - annual) / 1e6
            row["battery_net_4pct_mGBP"] = (gain - annual_high) / 1e6
            row["capital_threshold_per_kWh"] = (gain - b["annualised_initial_soc_GBP"]) / (
                b["nominal_MWh"] * 1000 * ((annual - b["annualised_initial_soc_GBP"]) / capital))
            annual_om = b["cost_scenarios"][0]["annual_om_and_augmentation_GBP"]
            if gain > annual_om:
                r, life = b["real_discount_rate"], b["life_years"]
                crf = r / (1 - (1 + r) ** -life)
                row["simple_payback_years"] = (capital + b["annualised_initial_soc_GBP"] / crf) / (gain - annual_om)
        for name, row in results.copy().items():
            if isinstance(row, dict):
                cost = annual_h2 + (annual / 1e6 if name in ("simple_storage", "oracle") else 0)
                if name == "no_investment":
                    cost = 0
                row["total_increment_mGBP"] = row["electricity_mGBP"] + row["hydrogen_mGBP"] - cost - results["no_investment"]["electricity_mGBP"]
        output[policy] = results
    return output


def site_cases(frame):
    _, menu = annual_costs(MODEL)
    product = next(asset for asset in menu if asset["id"] == "itm-neptune-v")
    g, d, p = (frame[col].to_numpy() for col in ("g", "d", "price"))
    days = frame.date.nunique()
    refs = {"A": np.dot(p, np.minimum(g, d) * (p >= 0)) / (1000 * YEARS),
            "B": np.dot(p, np.minimum(g, d)) / (1000 * YEARS)}
    records = []
    for cap, netback in [(4000.0, MODEL["netback"]), (10000.0, 5.0),
                          (10000.0, MODEL["netback"]), (10000.0, 10.0)]:
        cfg = dict(MODEL, cap_kg_day=cap, netback=netback)
        ceiling = (np.dot(np.maximum(p, 0), d) / 1000 + days * cap * netback / 1e6) / YEARS
        maximum = math.ceil(cap / (product["kg_hour"] * 0.5))
        for policy in ("A", "B"):
            blocks = [DispatchBlock(frame.iloc[i:i+672], product, cfg, policy, YEARS)
                      for i in range(0, len(frame), 672)]
            with redirect_stdout(io.StringIO()):
                level, _, trace, _ = capacity_master(blocks, product["annual"], maximum, ceiling, policy)
            options = sorted({0, max(0, int(level) - 1), int(level), math.ceil(level), min(maximum, math.ceil(level) + 1)})
            gains = {
                n: -sum(block.replay(n)[0] for block in blocks) - n * product["annual"] - refs[policy]
                for n in options
            }
            n = max(gains, key=gains.__getitem__)
            upper = -trace[-1]["lower_cost"] - refs[policy]
            records.append(dict(policy=policy, cap_kg_day=cap, netback=netback, modules=n,
                                MW=n * product["MW"], gain_mGBP=gains[n],
                                upper_gap_GBP=(upper - gains[n]) * 1e6))
            print(records[-1], flush=True)
    return records


def data_metrics(frame):
    fuel = pd.read_csv(V7 / "source_data/tier1-multiproduct-20261110-v6/inputs/daily_generation_by_fuel.csv")
    fuel = fuel.loc[fuel.date.between("2020-01-01", "2025-12-31")].copy()
    g, d = frame.g, frame.d
    pair = frame.groupby("date")[["g", "d"]].sum()
    type_energy = (fuel.groupby("psrType").MW.sum() * .024).to_dict()
    seasonal = fuel.assign(month=fuel.date.str[5:7].astype(int))
    seasonal = seasonal[seasonal.month.isin([1, 2, 6, 7, 8, 12])]
    seasonal = seasonal.assign(season=np.where(seasonal.month.isin([12, 1, 2]), "winter", "summer"))
    season_type = seasonal.groupby(["season", "psrType"]).MW.mean().unstack().to_dict()
    offtake_fraction = (g > d).mean()
    return dict(halfhour_surplus_GWh_per_year=float((g-d).clip(lower=0).sum()/YEARS),
                daily_surplus_GWh_per_year=float((pair.g-pair.d).clip(lower=0).sum()/YEARS),
                halfhour_surplus_periods_pct=float(offtake_fraction * 100),
                fuel_energy_GWh=type_energy, mean_seasonal_fuel_MW=season_type,
                demand_TWh_per_year=float(d.sum()/YEARS/1000))


if __name__ == "__main__":
    if os.environ.get("XPRESS_LICENSE_FILE"):
        xp.init(os.environ["XPRESS_LICENSE_FILE"])
    frame = frame_for("2020-01-01", "2025-12-31")
    target = ROOT / "evidence"
    target.mkdir(exist_ok=True)
    fixed = fixed_results(frame)
    (target / "fixed_and_data.json").write_text(json.dumps(dict(fixed=fixed, data=data_metrics(frame)), indent=2))
    pd.DataFrame(site_cases(frame)).to_csv(target / "contract_sizing.csv", index=False)
