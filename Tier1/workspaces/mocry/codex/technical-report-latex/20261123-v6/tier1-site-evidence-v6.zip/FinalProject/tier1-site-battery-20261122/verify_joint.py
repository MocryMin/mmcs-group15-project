"""Check the integer capacity comparisons and verify all six reported dispatches."""

import hashlib
import json
import math

import numpy as np
import pandas as pd

from run_joint import OUTPUT, UPPER_ROUNDING_MGBP, inputs, maximum_receipts, reference_revenue, write_json
from run_site import ROOT, HORIZON_YEARS, PROJECT, SITE_CAP


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def pooled_priority_receipt_bound(frame, config, battery):
    # A strict-priority battery can only charge out of surplus. Even with
    # unconstrained time shifting, its positive-price sales fit this energy pool.
    g, d, p = (frame[col].to_numpy() for col in ("g", "d", "price"))
    ordered = np.argsort(-np.maximum(p, 0))
    limits = np.maximum(d - g, 0)[ordered]
    energy = np.maximum(g - d, 0).sum() * battery["eta"]**2
    prev = np.r_[0, np.cumsum(limits)[:-1]]
    sales = np.maximum(0, np.minimum(limits, energy - prev))
    cash = np.dot(sales, np.maximum(p[ordered], 0)) * 1000
    return (cash + frame.date.nunique()*SITE_CAP*config["netback"]) / (1e6 * HORIZON_YEARS)


def frozen_row(policy, name):
    data = read(ROOT / f"{policy}_summary.json")
    gain = data["mean"]["electrolysis_only_gain_GBP"] if name == "zero" else data["mean"]["combined_net_GBP"]
    upper = gain if name == "zero" else gain + data["oracle_certificate"]["upper_gap_GBP_year"]
    return dict(policy=policy, battery_blocks=int(name == "one"), electrolyser_units=data["modules"],
                annual_net_gain_mGBP=gain/1e6, fixed_configuration_upper_mGBP=upper/1e6)


def candidate_rows(policy):
    return [frozen_row(policy, cls) for cls in ("zero", "one")] + [
        read(path) for path in OUTPUT.glob(f"{policy}_n*_h*.json")
    ]


def economic_upper(rows, n_max, h_max):
    ns, hs = np.ogrid[:n_max+1, :h_max+1]
    bounds = np.full((n_max+1, h_max+1), np.inf)
    for row in rows:
        plane = row.get("supporting_plane_mGBP")
        if plane:
            n, h = plane["at"]
            gn, gh = plane["gradient"]
            estimate = plane["value"] + gn*(ns-n) + gh*(hs-h)
            if plane["scope"] == "all capacities":
                bounds = np.minimum(bounds, estimate)
            else:
                bounds[n] = np.minimum(bounds[n], estimate[n])
    for row in rows:
        n, h = row["battery_blocks"], row["electrolyser_units"]
        bounds[n, h] = min(bounds[n, h], row["fixed_configuration_upper_mGBP"])
    return bounds


def priority_alternatives(frame, config, battery, product, selected, n_max, h_max):
    bounds = np.full((n_max+1, h_max+1), np.inf)
    # No storage: optimal relaxed direct surplus-to-hydrogen allocation
    # is a separable daily fill. Omitting minimum load can only increase it.
    surplus = np.maximum(frame.g - frame.d, 0).to_numpy().reshape(-1, 48)
    for h in range(h_max+1):
        daily = np.minimum(SITE_CAP*product["kWh_kg"]/1e6,
                           np.minimum(surplus, h*product["unit_GWh"]).sum(axis=1))
        bounds[0,h] = (daily.sum()*config["netback"]/product["kWh_kg"]/HORIZON_YEARS
                       - h*product["annual"] + UPPER_ROUNDING_MGBP)
    for path in OUTPUT.glob("B_bound_*.json"):
        row = read(path)
        n0, n1 = row["battery_interval"]
        h0, h1 = row["h2_interval"]
        bounds[n0:n1+1,h0:h1+1] = np.minimum(
            bounds[n0:n1+1,h0:h1+1], row["upper_mGBP"])
    for path in OUTPUT.glob("B_certificate_*.json"):
        row = read(path)
        n = row["n"]
        h0, h1 = row["h_interval"]
        assert abs(sum(row["episode_upper_mGBP"]) - row["battery_annual_cost_mGBP"]
                   - row["upper_mGBP"]) < 0.00001
        assert abs(sum(row["dual_prices_mGBP"]) - row["h2_annual_cost_per_unit_mGBP"]) < 1e-10
        bounds[n,h0:h1+1] = np.minimum(bounds[n,h0:h1+1], row["upper_mGBP"])
    for path in OUTPUT.glob("B_enumeration_*.json"):
        row = read(path)
        for h, upper in row["upper_mGBP_by_unit"]:
            bounds[row["n"],h] = min(bounds[row["n"],h], upper)
    for row in selected:
        n, h = row["battery_blocks"], row["electrolyser_units"]
        bounds[n,h] = min(bounds[n,h], row["fixed_configuration_upper_mGBP"])
    return bounds


def witness(row):
    policy, n, h = row["policy"], row["battery_blocks"], row["electrolyser_units"]
    p = OUTPUT / f"{policy}_n{n}_h{h}_dispatch.npz"
    if p.is_file():
        with np.load(p) as z:
            return z["flows"], z["utc_ns"]
    with np.load(ROOT / f"{policy}_dispatch.npz") as z:
        return z["with_battery" if n else "without_battery"], z["utc_ns"]


def audit_dispatch(frame, config, battery, product, row):
    flows, utc_ns = witness(row)
    q, c, r, u, stock, hydrogen = flows
    assert np.array_equal(utc_ns, frame.index.as_unit("ns").asi8)
    n, h, policy = row["battery_blocks"], row["electrolyser_units"], row["policy"]
    g, d, p = (frame[col].to_numpy() for col in ("g", "d", "price"))
    eta, power = battery["eta"], battery["P_MW"]*n/2000
    prev = np.r_[0, stock[:-1]]
    assert battery["retention"] == 1
    tol = 2e-7
    errors = [
        np.max(q+c+hydrogen-u-g), np.max(q+r-d), np.max(u-hydrogen),
        np.max(c-power), np.max(r+u-power), np.max(stock-battery["usable"]*n),
        np.max(-np.array([q, c, r, u, stock, hydrogen])),
        np.max(np.abs(stock-prev-eta*c+(r+u)/eta)), abs(stock[-1]),
        np.max(np.minimum(c, r+u)), np.max(hydrogen-h*product["unit_GWh"]),
    ]
    if policy == "B":
        errors.extend([np.max(abs(q-np.minimum(g,d))),
                       np.max(abs(r-np.minimum(np.maximum(d-g,0),np.minimum(power,eta*prev))))])
    assert max(errors) < tol, errors
    active = hydrogen > 1e-8
    assert min(hydrogen[active], default=np.inf) >= product["minimum"]*product["unit_GWh"]-1e-8
    assert hydrogen.reshape(-1,48).sum(axis=1).max()*1e6/product["kWh_kg"] <= SITE_CAP+0.01
    for year in np.unique(frame.index.year):
        selected = frame.index.year == year
        throughput = (r[selected]+u[selected]).sum()*1000/eta
        assert throughput <= selected.sum()/48*battery["E_MWh"]*n+0.002
    revenue = (q+r)*p*1000 + hydrogen*config["netback"]*1e6/product["kWh_kg"]
    gain = (revenue-reference_revenue(frame,policy)).sum()/(HORIZON_YEARS*1e6)
    gain -= battery["annual"]*n + product["annual"]*h
    assert abs(gain-row["annual_net_gain_mGBP"]) < 2e-8
    return dict(maximum_physical_residual_GWh=float(max(errors)), reaggregated_mGBP=float(gain))


def main():
    frame, config, battery, product = inputs()
    h_max = math.ceil(SITE_CAP/(product["kg_hour"]*0.5))
    output = []
    for policy in ("A", "B"):
        rows = candidate_rows(policy)
        absolute = maximum_receipts(frame, config, policy) if policy == "A" else pooled_priority_receipt_bound(
            frame, config, battery)
        n_max = math.floor(absolute/battery["annual"])
        bounds = economic_upper(rows, n_max, h_max) if policy == "A" else priority_alternatives(
            frame, config, battery, product, rows, n_max, h_max)
        chosen = []
        for mode, count in (("zero", 0), ("one", 1), ("joint", None)):
            feasible = [row for row in rows if count is None or row["battery_blocks"] == count]
            best = max(feasible, key=lambda row: row["annual_net_gain_mGBP"])
            n, h = best["battery_blocks"], best["electrolyser_units"]
            region = bounds.copy()
            region[n,h] = -np.inf
            if count is not None:
                region[np.arange(len(region)) != count] = -np.inf
            rival = np.unravel_index(region.argmax(), region.shape)
            rival_bound = float(region[rival])
            assert rival_bound < best["annual_net_gain_mGBP"], (policy, mode, best, rival, rival_bound)
            verify = audit_dispatch(frame, config, battery, product, best)
            chosen.append(dict(
                policy=policy, comparison=mode, battery_blocks=n,
                battery_MW=n*battery["P_MW"], battery_MWh=n*battery["E_MWh"],
                electrolyser_units=h, electrolyser_MW=h*product["MW"],
                annual_net_gain_mGBP=best["annual_net_gain_mGBP"],
                highest_alternative_upper_mGBP=rival_bound,
                closest_alternative_capacity=[int(v) for v in rival],
                benefit_over_zero_mGBP=best["annual_net_gain_mGBP"]-chosen[0]["annual_net_gain_mGBP"] if chosen else 0,
                fixed_configuration_gap_GBP=(best["fixed_configuration_upper_mGBP"]-best["annual_net_gain_mGBP"])*1e6,
                audited_net_gain_mGBP=verify["reaggregated_mGBP"],
            ))
        output.extend(chosen)
        print(policy, "cap limits and proof", n_max, h_max, chosen[-1], flush=True)
    pdf = PROJECT/"project-report-20261122-v5/report/report.pdf"
    original_digest = "7b8a9fa573796be5ad80bc0844d8d8cf88efb7a68a07a9cf0b1451db46cc4e72"
    assert hashlib.sha256(pdf.read_bytes()).hexdigest() == original_digest
    pd.DataFrame(output).to_csv(OUTPUT/"comparison.csv", index=False, float_format="%.9f")
    write_json(OUTPUT/"verified_comparison.json", output)


if __name__ == "__main__":
    main()
