"""Bound all integer electrolyser counts for a fixed strict-priority battery count."""

import argparse
import json
from time import perf_counter

import highspy
import numpy as np

from certify_b import episodes
from run_joint import OUTPUT, UPPER_ROUNDING_MGBP, inputs, scaled_battery, write_json
from run_site import HORIZON_YEARS, Problem


def make_problems(frame, config, battery, blocks, maximum):
    jobs = []
    for segment in episodes(frame, scaled_battery(battery, blocks)):
        job = Problem(segment, config, OUTPUT, f"enum_B_{blocks}", blocks, maximum,
                      nbmin=blocks, strict=True, cycles=False,
                      years=HORIZON_YEARS, quiet=True, seconds=15)
        solver = job.solver
        solver.setOptionValue("threads", 1)
        solver.setOptionValue("mip_rel_gap", 1e-9)
        solver.setOptionValue("mip_abs_gap", 1e-10)
        integer = np.asarray([i for i, t in enumerate(solver.getLp().integrality_)
                              if t == highspy.HighsVarType.kInteger], dtype=np.int32)
        if len(integer):
            solver.changeColsIntegrality(len(integer), integer, np.zeros(len(integer), dtype=np.uint8))
        solver.changeColCost(job.n, 0)
        solver.changeColCost(job.nh, 0)
        solver.setOptionValue("solver", "simplex")
        jobs.append((job, integer))
    return jobs


def lp_cut(jobs, units, yearly_cost, h2_annual_cost):
    objective = -yearly_cost - units*h2_annual_cost
    derivative = -h2_annual_cost
    for job, _ in jobs:
        solver = job.solver
        solver.changeColBounds(job.nh, units, units)
        solver.run()
        assert solver.getModelStatus() == highspy.HighsModelStatus.kOptimal
        objective -= solver.getInfo().objective_function_value
        derivative -= solver.getSolution().col_dual[job.nh]
    return objective + UPPER_ROUNDING_MGBP, derivative


def restore_integrality(jobs):
    for job, integer in jobs:
        if len(integer):
            job.solver.changeColsIntegrality(len(integer), integer, np.ones(len(integer), dtype=np.uint8))
        job.solver.setOptionValue("solver", "choose")


def integer_bound(jobs, units, yearly_cost, h2_annual_cost):
    total = -yearly_cost - units*h2_annual_cost
    for job, _ in jobs:
        job.solver.changeColBounds(job.nh, units, units)
        job.run()
        assert job.upper is not None and np.isfinite(job.upper), job.status
        total += job.upper
    return total + UPPER_ROUNDING_MGBP


def enumerate_h(frame, config, battery, product, blocks, target, first, minimum=0, maximum=223,
                omit=()):
    cap = np.arange(minimum, maximum+1)
    allowed = ~np.isin(cap, omit)
    upper = np.full(len(cap), np.inf)
    checked = set()
    for path in OUTPUT.glob(f"B_n{blocks}_h*.json"):
        row = json.loads(path.read_text())
        units = row["electrolyser_units"]
        if minimum <= units <= maximum:
            upper[units-minimum] = row["fixed_configuration_upper_mGBP"]
            checked.add(units)
    for path in OUTPUT.glob(f"B_certificate_{blocks}_*.json"):
        row = json.loads(path.read_text())
        lo, hi = row["h_interval"]
        mask = (lo <= cap) & (cap <= hi)
        upper[mask] = np.minimum(upper[mask], row["upper_mGBP"])

    jobs = make_problems(frame, config, battery, blocks, maximum)
    annual_b = battery["annual"] * blocks
    annual_h = product["annual"]
    cuts = []
    anchors = [first, min(maximum, first+8), max(minimum, first-5)]
    for k in range(12):
        if k < len(anchors):
            units = anchors[k]
        else:
            size = np.where(allowed & ~np.isin(cap, [row[0] for row in cuts]), upper, -np.inf)
            if size.max(initial=-np.inf) < target:
                break
            units = int(cap[np.argmax(size)])
        value, derivative = lp_cut(jobs, units, annual_b, annual_h)
        new_bound = value + derivative*(cap - units)
        upper = np.minimum(upper, new_bound)
        cuts.append([units, value, derivative])
        # Only a few well-placed supporting planes are needed away from the peak.
        if np.max(upper[allowed], initial=-np.inf) < target:
            break
    restore_integrality(jobs)
    order = np.argsort(-upper)
    exact = []
    for index in order:
        units = int(cap[index])
        if not allowed[index] or upper[index] < target or units in checked:
            continue
        bound = integer_bound(jobs, units, annual_b, annual_h)
        upper[index] = min(upper[index], bound)
        exact.append([units, bound])
        if upper[index] >= target:
            print("Remaining", blocks, units, upper[index], flush=True)
    rows = [[int(h), float(u)] for h, u in zip(cap[allowed], upper[allowed])]
    strongest = max(rows, key=lambda row: row[1])
    return dict(n=blocks, h_interval=[minimum, maximum], omitted=list(omit), maximum=strongest,
                lp_cuts=cuts, exact_priority_bounds=exact, upper_mGBP_by_unit=rows)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("n", type=int)
    parser.add_argument("target", type=float)
    parser.add_argument("--first", type=int, default=10)
    parser.add_argument("--omit", type=int, nargs="*", default=[])
    args = parser.parse_args()
    start = perf_counter()
    result = enumerate_h(*inputs(), args.n, args.target, args.first, omit=args.omit)
    result["seconds"] = perf_counter() - start
    write_json(OUTPUT / f"B_enumeration_{args.n}.json", result)
    print("B count complete", args.n, result["maximum"], "seconds", round(result["seconds"], 2), flush=True)
