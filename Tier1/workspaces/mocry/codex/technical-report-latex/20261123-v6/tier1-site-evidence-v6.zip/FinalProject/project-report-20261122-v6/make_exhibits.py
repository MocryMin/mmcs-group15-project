"""Build report exhibits from verified Tier 1 schedules and market stress tests."""
from site_refresh import GBP, HERE, OUTPUT, PROJECT, SITE, YEARS, inputs

import matplotlib
matplotlib.use("Agg")
from matplotlib import pyplot as plt
import numpy as np
import pandas as pd


def numbers(frame, config, battery, product):
    g, d, p = (frame[key].to_numpy() for key in ("g", "d", "price"))
    physical = np.maximum(g - d, 0.)
    fuel = pd.read_csv(PROJECT / "tier1-halfhour-20261113-v7/source_data/tier1-multiproduct-20261110-v6/inputs/daily_generation_by_fuel.csv")
    renewable = fuel[fuel.psrType.isin(["Biomass", "Hydro Run-of-river and poundage", "Solar", "Wind Onshore", "Wind Offshore"])]
    daily_clean = renewable.groupby("date").MW.sum().reindex(frame.date.to_numpy()).to_numpy() + frame.farm_flat_MW.to_numpy()
    # The attribution uses daily mix and must not impose a time-of-day fuel pattern.
    daily_gen = frame.groupby("date")["g"].mean().reindex(frame.date.to_numpy()).to_numpy() * 2000.
    mix = np.divide(daily_clean, daily_gen, out=np.zeros_like(g), where=daily_gen > 0.).clip(0., 1.)
    layout = {"A": [("None", 0, 0, None), ("Electrolysis", 0, 8, "without_battery"),
                     ("One block, simple", 1, 8, "simple_rule"), ("One block, optimised", 1, 7, "joint/A_n1_h7_dispatch.npz"),
                     ("Joint sizing", 45, 6, "joint/A_n45_h6_dispatch.npz")],
              "B": [("None", 0, 0, None), ("Electrolysis", 0, 11, "without_battery"),
                     ("One block, simple", 1, 11, "simple_rule"), ("One block, optimised", 1, 11, "with_battery"),
                     ("Joint sizing", 9, 10, "joint/B_n9_h10_dispatch.npz")]}
    result = []
    rows, finances = [], []
    for policy, cases in layout.items():
        ref = np.minimum(g, d) * ((p >= 0.) if policy == "A" else 1.)
        fixed = np.load(SITE / f"{policy}_dispatch.npz")
        np.testing.assert_array_equal(fixed["utc_ns"], frame.index.as_unit("ns").asi8)
        for label, blocks, modules, source in cases:
            if source is None:
                flows = [ref, *np.zeros((5, len(frame)))]
            elif source in fixed:
                flows = fixed[source]
            else:
                with np.load(SITE / source) as archive:
                    flows = archive["flows"]
                    np.testing.assert_array_equal(archive["utc_ns"], frame.index.as_unit("ns").asi8)
            q, c, r, u, _, h = flows
            sold = q + r
            h_kg = h * GBP / product["kWh_kg"]
            generation_h2 = h - u
            unused = g - q - c - generation_h2
            captured = np.minimum(physical, c + generation_h2)
            capex = (blocks * battery["capital_GBP"] + modules * product["capital_GBP"]) / GBP
            gain = (np.dot(p, sold - ref) * 1000 + h_kg.sum() * config["netback"]) / (GBP * YEARS)
            net = gain - blocks * battery["annual"] - modules * product["annual"]
            result.append(dict(policy=policy, plan=label, battery_blocks=blocks, electrolyser_modules=modules,
                               annual_net_mGBP=net, installed_capex_mGBP=capex, annual_unused_GWh=unused.sum()/YEARS,
                               demand_coverage_pct=100. * sold.sum()/d.sum(), annual_hydrogen_t=h_kg.sum()/YEARS/1000.,
                               surplus_capture_GWh=captured.sum()/YEARS,
                               renewable_mix_attribution_GWh=np.dot(captured, mix)/YEARS,
                               direct_surplus_h2_share=np.minimum(physical, generation_h2).sum()/h.sum() if h.sum() else 0.))
            if label == "Electrolysis":
                for rate, capital_factor in ((.03, 1.), (.05, 1.), (.08, 1.), (.05, 1.2)):
                    af = (1. - (1. + rate) ** -product["life"]) / rate
                    pv_renewals = sum(product["replacement_GBP"] / (1. + rate) ** k for k in product["replacement_years"])
                    pv_cost = modules * (product["capital_GBP"] * capital_factor + pv_renewals) / GBP
                    maint = modules * product["fom_GBP"] / GBP
                    annual_gain = gain - maint - pv_cost / af
                    needed = config["netback"] - annual_gain * YEARS * GBP / h_kg.sum()
                    fraction = (needed - 2.5) / (config["netback"] - 2.5)
                    finances.append(dict(policy=policy, discount=rate, electrolyser_capital_multiplier=capital_factor,
                                         NPV_mGBP=annual_gain * af, break_even_receipt_GBP_kg=needed,
                                         minimum_eligible_share_at_merchant_2_50=fraction, annual_net_mGBP=annual_gain))
        fixed.close()
        year = pd.read_csv(SITE / f"{policy}_annual.csv")
        for name, mask in (("2020-25", year.year >= 2020), ("2023-25", year.year >= 2023),
                           ("2024-25", year.year >= 2024), ("without 2022", year.year != 2022)):
            year_set = year.loc[mask]
            rows.append(dict(policy=policy, window=name, net_mGBP=year_set.battery_net_GBP.mean()/GBP,
                             simple_net_mGBP=year_set.simple_battery_net_GBP.mean()/GBP,
                             net_4pct_mGBP=(year_set.battery_net_GBP.mean() - .015 * battery["capital_GBP"])/GBP))
    pd.DataFrame(result).to_csv(OUTPUT / "site_portfolios.csv", index=False)
    pd.DataFrame(rows).to_csv(OUTPUT / "fixed_block_windows.csv", index=False)
    pd.DataFrame(finances).to_csv(OUTPUT / "electrolyser_finance.csv", index=False)


def figure(frame):
    txt = OUTPUT / "electrolyser_curve.csv"
    curve = pd.read_csv(txt)
    seasons = [({12, 1, 2}, "Winter"), ({3, 4, 5}, "Spring"), ({6, 7, 8}, "Summer"), ({9, 10, 11}, "Autumn")]
    plt.rcParams.update({"font.family": "DejaVu Serif", "font.size": 8})
    fig, (left, right) = plt.subplots(1, 2, figsize=(6.38, 1.59), layout="constrained")
    surplus = (frame.g-frame.d).clip(lower=0.)
    hours = frame.index.hour + frame.index.minute / 60.
    for (months, label), color in zip(seasons, ("#202020", "#6f6f6f", "#426a78", "#453345")):
        selected = frame.index.month.isin(months)
        means = surplus[selected].groupby(hours[selected]).mean()
        left.plot(means.index, means, label=label, color=color, lw=1.)
    left.set(xlim=(0, 24), xticks=[0, 6, 12, 18, 24], xlabel="Hour (UTC)", ylabel="Surplus (GWh per half-hour)")
    left.legend(loc="upper right", frameon=False, fontsize=5.9, handlelength=1.4,
                handletextpad=.4, labelspacing=.22, borderaxespad=.35)
    for policy, line in (("A", "-"), ("B", "--")):
        rows = curve.loc[curve.policy == policy].sort_values("MW")
        right.plot(rows.MW, rows.profit, line, label=f"Policy {policy}", c="#202020", lw=1.1)
        best = rows.loc[rows.profit.idxmax()]
        right.plot(best.MW, best.profit, "o", ms=3.4, c="#202020")
    right.set(xlabel="Electrolyser capacity (MW)", ylabel="Annual net gain (£m)", xlim=(0, 82))
    right.legend(loc="lower right", frameon=False, fontsize=6.8)
    for axes in (left, right):
        axes.tick_params(labelsize=7)
        axes.xaxis.label.set_size(8)
        axes.yaxis.label.set_size(8)
        axes.spines[["top", "right"]].set_visible(False)
        axes.grid(axis="y", color=".9", lw=.45)
    fig.savefig(HERE / "report/figures/site-and-surplus.pdf", bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    frame, config, battery, product = inputs()
    numbers(frame, config, battery, product)
    figure(frame)
