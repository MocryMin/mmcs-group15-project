"""Compare fixed 10 t/day site cases with and without the 100 MW / 400 MWh block."""

import argparse
import json
import os
from pathlib import Path
import sys
from time import perf_counter

import highspy
import numpy as np
import pandas as pd
import xpress as xp

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parent
sys.path[:0] = [
    str(PROJECT / folder)
    for folder in (
        "tier1-halfhour-20261113-v7",
        "tier1-xpress-reproduction-20261122",
        "tier1-common-equipment-20261122",
        "storage-investment-20261116-v3",
        "priority-investment-20261116-v4",
        "project-report-20261122-v5",
    )
]
import investment_model
from compact_b import Problem
from model import annual_costs, frame_for
from replay_xpress import check_and_cash, replay_block
from reproduce import DispatchBlock
from tier1_evidence import greedy

SITE_CAP = 10_000
HORIZON_YEARS = 6
PER_DAY = 48
BLOCK = 4 * PER_DAY
MODULES = {"A": 8, "B": 11}
GBP_PER_MILLION = 1_000_000
OBJECTIVE_PADDING_GBP = 1.0


def electrolysis_only(frame, product, config, policy, count):
    flows = np.zeros((6, len(frame)))
    for start in range(0, len(frame), 14 * PER_DAY):
        stop = min(start + 14 * PER_DAY, len(frame))
        block = DispatchBlock(frame.iloc[start:stop], product, config, policy, HORIZON_YEARS)
        _, flows[0, start:stop], flows[5, start:stop], _, _ = block.replay(count)
    return flows


def repair_economic_anchor(frame, flows, battery, product):
    """Retain inventory and throughput while removing subminimum hydrogen loads."""
    repaired = flows.copy()
    direct, charge, sale, battery_h2, _, h2 = repaired
    eta_squared = battery["eta"] ** 2
    overlap = np.minimum(charge * eta_squared, sale + battery_h2)
    from_h2 = np.minimum(battery_h2, overlap)
    from_sale = overlap - from_h2
    charge -= overlap / eta_squared
    sale -= from_sale
    battery_h2 -= from_h2
    direct += from_sale

    minimum = product["minimum"] * product["unit_GWh"]
    subminimum = (h2 > 1e-8) & (h2 < minimum - 1e-8)
    # Send the same discharge to the market, displacing direct sales if needed.
    # All affected demands exceed this block's discharge power.
    sale[subminimum] += battery_h2[subminimum]
    demand = frame.d.to_numpy()[subminimum]
    assert np.all(sale[subminimum] <= demand)
    direct[subminimum] -= np.maximum(0, direct[subminimum] + sale[subminimum] - demand)
    battery_h2[subminimum] = 0
    h2[subminimum] = 0
    return repaired, int(subminimum.sum())


def economic_dispatch(frame, config, battery, product, count):
    """Find full-horizon interfaces and certify the Xpress replay against a full LP bound."""
    investment_model.ROOT = ROOT
    fixed = {battery["id"]: 1, product["id"]: count}
    anchor = investment_model.solve(
        frame, config, "A", "A_full_anchor", fixed=fixed, relaxation=True, seconds=120,
    )
    ref = pd.read_csv(ROOT / "results/A_full_anchor_schedule.csv.gz")
    key = battery["id"]
    baseline = ref[["direct", "charge", "battery_sale", "battery_h2", key + "__stock", "h2_input"]].to_numpy().T
    fallback, subminimum_slots = repair_economic_anchor(frame, baseline, battery, product)
    stock = baseline[4]
    discharge = (baseline[2] + baseline[3]) / battery["eta"]
    cuts = set(range(0, len(frame), BLOCK)) | {len(frame)}
    cuts.update(np.flatnonzero(frame.index.year[1:] != frame.index.year[:-1]) + 1)
    ends = sorted(cuts)
    plans, fallback_blocks = [], 0
    for start, stop in zip(ends, ends[1:]):
        try:
            plan = replay_block(
                frame.iloc[start:stop], battery, product, count, config["netback"], SITE_CAP, "A", False,
                stock[start - 1] if start else 0, stock[stop - 1] if stop < len(frame) else 0,
                discharge[start:stop].sum() + 1e-10,
            )
        except RuntimeError as exc:
            if str(exc) != "Minimum load repair exhausted":
                raise
            plan = fallback[:, start:stop]
            fallback_blocks += 1
        plans.append(plan)
    return np.concatenate(plans, axis=1), dict(
        full_relaxation_upper_increment_GBP_year=(
            anchor["upper_increment_mGBP"] * GBP_PER_MILLION + OBJECTIVE_PADDING_GBP
        ),
        xpress_blocks=len(plans) - fallback_blocks,
        repaired_anchor_blocks=fallback_blocks,
        anchor_subminimum_slots=subminimum_slots,
    )


def empty_stock_boundaries(frame, battery):
    """Mandatory sales leave no possible stored energy at these UTC day boundaries."""
    eta = battery["eta"]
    power = battery["P_MW"] / 2000
    s = 0.0
    boundaries = [0]
    assert battery["retention"] == 1
    for end, gap in enumerate(frame.g.to_numpy() - frame.d.to_numpy(), 1):
        if gap < 0:
            s = max(0.0, s - min(-gap, power) / eta)
        else:
            s = min(battery["usable"], s + eta * min(power, gap))
        if end % PER_DAY == 0 and s < 1e-12:
            boundaries.append(end)
    return np.unique([*boundaries, len(frame)])


def long_priority_block(frame, config, count, battery_blocks=1):
    """Solve the occasional episode above the size limit of Xpress Community."""
    job = Problem(frame, config, ROOT, "B_episode", battery_blocks, count,
                  fixed=(battery_blocks, count), strict=True,
                  years=1, cycles=False, quiet=True, seconds=45)
    solver = job.solver
    solver.changeColCost(job.n, 0)
    solver.changeColCost(job.nh, 0)
    solver.setOptionValue("mip_abs_gap", 1e-8)
    solver.setOptionValue("mip_rel_gap", 1e-10)
    added = set()
    lower = job.h["minimum"] * job.h["unit_GWh"]
    upper = count * job.h["unit_GWh"]
    for _ in range(10):
        job.run()
        h = job.x[job.v]
        bad = set(np.flatnonzero((h > 1e-8) & (h < lower - 1e-8)))
        if not bad:
            break
        if not (bad - added):
            raise RuntimeError("Minimum-load repair did not advance")
        for slot in bad - added:
            z = solver.getNumCol()
            solver.addVar(0, 1)
            solver.changeColIntegrality(z, highspy.HighsVarType.kInteger)
            columns = np.array([job.v[slot], z], dtype=np.int32)
            solver.addRow(0, highspy.kHighsInf, 2, columns, np.array([1, -lower]))
            solver.addRow(-highspy.kHighsInf, 0, 2, columns, np.array([1, -upper]))
        job.has_int = True
        added |= bad
    else:
        raise RuntimeError("Minimum-load repair did not finish")
    q = np.minimum(job.g, job.d)
    c, r, u, stock = (job.x[indices] for indices in (job.c, job.r, job.bh, job.s))
    overlap = np.minimum(c * job.eta**2, u)
    flows = np.array([q, c - overlap / job.eta**2, r, u - overlap, stock, h])
    if job.upper is None:
        raise RuntimeError("Long episode has no upper bound")
    return flows, (job.upper - job.value) * GBP_PER_MILLION


def priority_dispatch(frame, config, battery, product, count, battery_blocks=1):
    boundaries = empty_stock_boundaries(frame, battery)
    plans, gap, long_count = [], 0.0, 0
    i = 0
    while i < len(boundaries) - 1:
        j = max(i + 1, np.searchsorted(boundaries, boundaries[i] + BLOCK, side="right") - 1)
        start, stop = boundaries[i], boundaries[j]
        segment = frame.iloc[start:stop]
        if stop - start <= BLOCK:
            try:
                plans.append(replay_block(
                    segment, battery, product, count, config["netback"], SITE_CAP, "B", False,
                    0, 0, None,
                ))
                i = j
                continue
            except RuntimeError as exc:
                if str(exc) != "Minimum load repair exhausted":
                    raise
        plan, gap_GBP = long_priority_block(segment, config, count, battery_blocks)
        gap += max(0.0, gap_GBP)
        plans.append(plan)
        long_count += 1
        i = j
    return np.concatenate(plans, axis=1), dict(
        exact_empty_stock_blocks=len(plans),
        xpress_blocks=len(plans) - long_count,
        highs_blocks=long_count,
        upper_gap_GBP_year=(gap + OBJECTIVE_PADDING_GBP) / HORIZON_YEARS,
    )


def run(policy):
    started = perf_counter()
    frame = frame_for("2020-01-01", "2025-12-31")
    config = json.loads((PROJECT / "storage-exploration-20261116-v2/utility4h/configuration.json").read_bytes())
    config["cap_kg_day"] = SITE_CAP
    config["electrolysers"] = [
        item for item in config["electrolysers"] if item["id"] == "itm-neptune-v"
    ]
    (battery,), (product,) = annual_costs(config)
    spec = json.loads((PROJECT / "publication-20261119/tier1/tier2b-equipment.json").read_bytes())
    count = MODULES[policy]
    no_battery = dict(battery, P_MW=0, E_MWh=0, usable=0)
    base = electrolysis_only(frame, product, config, policy, count)
    simple = greedy(frame, base, policy, spec["battery"])
    if policy == "A":
        oracle, certificate = economic_dispatch(frame, config, battery, product, count)
    else:
        oracle, certificate = priority_dispatch(frame, config, battery, product, count)

    def cash(flows, asset):
        return check_and_cash(frame, flows, asset, product, count, config["netback"], SITE_CAP, policy, False)

    base_cash = cash(base, no_battery)
    simple_cash = cash(simple, battery)
    oracle_cash = cash(oracle, battery)
    price = frame.price.to_numpy()
    ref = np.minimum(frame.g.to_numpy(), frame.d.to_numpy()) * (1 if policy == "B" else (price >= 0))
    period_years = frame.index.year
    annual = []
    for (year, base_GBP, _), (_, simple_GBP, _), (_, oracle_GBP, throughput) in zip(
        base_cash, simple_cash, oracle_cash
    ):
        select = period_years == year
        reference_GBP = float(np.dot(price[select], ref[select]) * 1000)
        annual_GBP = battery["annual"] * GBP_PER_MILLION
        base_net_GBP = base_GBP - reference_GBP - count * product["annual"] * GBP_PER_MILLION
        gross = oracle_GBP - base_GBP
        annual.append(dict(
            year=int(year), electrolysis_only_gain_GBP=base_net_GBP,
            battery_gross_GBP=gross, battery_annual_cost_GBP=annual_GBP,
            battery_net_GBP=gross - annual_GBP, combined_net_GBP=base_net_GBP + gross - annual_GBP,
            simple_battery_net_GBP=simple_GBP - base_GBP - annual_GBP,
            oracle_internal_discharge_MWh=throughput,
            base_hydrogen_tonnes=float(base[5, select].sum() * 1000 / product["kWh_kg"]),
            oracle_hydrogen_tonnes=float(oracle[5, select].sum() * 1000 / product["kWh_kg"]),
            base_demand_coverage_pct=float(base[0, select].sum() / frame.d[select].sum() * 100),
            oracle_demand_coverage_pct=float((oracle[0, select] + oracle[2, select]).sum() / frame.d[select].sum() * 100),
        ))
    table = pd.DataFrame(annual)
    mean = table.drop(columns="year").mean().to_dict()
    if policy == "A":
        certificate["upper_gap_GBP_year"] = (
            certificate["full_relaxation_upper_increment_GBP_year"] - mean["combined_net_GBP"]
        )
    if certificate["upper_gap_GBP_year"] < -0.01:
        raise RuntimeError("The feasible return exceeds its stated upper bound")
    reference = pd.read_csv(PROJECT / "project-report-20261122-v5/evidence/contract_sizing.csv")
    known = reference[(reference.policy == policy) & (reference.cap_kg_day == SITE_CAP)
                      & (abs(reference.netback - config["netback"]) < 1e-9)].iloc[0]
    assert abs(known.gain_mGBP * GBP_PER_MILLION - mean["electrolysis_only_gain_GBP"]) < 0.05
    cost_without_initial_fill = spec["battery"]["capital_cost_low_GBP"]
    low_cost = spec["battery"]["cost_scenarios"][0]["annual_total_GBP"]
    high_cost = spec["battery"]["cost_scenarios"][1]["annual_total_GBP"]
    initial_fill = spec["battery"]["annualised_initial_soc_GBP"]
    mean["battery_net_4pct_GBP"] = mean["battery_gross_GBP"] - high_cost
    mean["battery_break_even_GBP_per_kWh"] = (
        (mean["battery_gross_GBP"] - initial_fill) * cost_without_initial_fill / (low_cost - initial_fill)
        / (battery["E_MWh"] * 1000)
    )
    mean["battery_site_upper_GBP"] = mean["battery_net_GBP"] + certificate["upper_gap_GBP_year"]
    summary = dict(
        policy=policy, h2_limit_kg_day=SITE_CAP, hydrogen_netback_GBP_kg=config["netback"],
        modules=count, electrolyser_MW=count * product["MW"],
        electrolyser_initial_capex_GBP=count * product["capital_GBP"],
        oracle_certificate=certificate, mean=mean, seconds=perf_counter() - started,
    )
    table.to_csv(ROOT / f"{policy}_annual.csv", index=False, float_format="%.8f")
    np.savez_compressed(ROOT / f"{policy}_dispatch.npz", with_battery=oracle, without_battery=base,
                        simple_rule=simple, utc_ns=frame.index.as_unit("ns").asi8)
    (ROOT / f"{policy}_summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("policy", choices=MODULES)
    args = cli.parse_args()
    if os.environ.get("XPRESS_LICENSE_FILE"):
        xp.init(os.environ["XPRESS_LICENSE_FILE"])
    run(args.policy)
