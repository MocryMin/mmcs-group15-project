# MMCS Project Report v6

[报告 PDF](report/report.pdf) · [LaTeX](report/report.tex) · [复算档案](tier1-site-evidence-v6.zip) · [SHA-256](SHA256SUMS.txt)

Tier 1 以 10 吨/日氢气承购站点为主线。电力侧两种策略使用同一套课程构造系统和英国尺度电力需求。1,559 吨/日仅在英国氢消费规模的变体中采用。报告采用既有学术版式，Tier 1 占正文第 2–5 页。第 III 章的半小时信息、设备与时间窗说明是向 Tier 2B 的交接。

## 审核落实情况

| 审核事项 | v6 对应证据 |
|---|---|
| Opus 和 CU 提出的规模与投资建议脱节 | 表 II.3 同时列直接售电、仅电解槽、一套电池按简单规则及全知调度、联合定容。单块固定电解槽增量 A/B 为 £5.63m/£1.64m/年，去掉电解槽复算为 £5.70m/£1.65m/年。全国氢消纳规模放在 II.5.3 和附录 C。 |
| 保留题面参照、隔离时间粒度变化 | 表 II.5 给日数据两小时整数最优，以及相同两小时参数、固定五台电解槽时的半小时零／一套对照。日数据两策略均零电池。半小时固定设备下加一套 A/B 分别多 £1.05m、少 £1.32m/年，按题面资本基准加计 2.5% 维护后两者皆负。低价四小时方案单列。 |
| 氢资格、售电取舍与成本风险 | 表 II.4 重算 £2.50、£5、£7.80、£9.50、£10/kg 和盈余资格双价情景。£9.50/kg 与按 2020 年价格换算的 £7.80/kg 区分。正文给电解收益、供电占比、£3.69/£4.70/kg 价格门槛和资格比例，并注明年度等价费用、项目期与首购额。附录 C 公开折现、资本和维护敏感性。 |
| 全知回报与可执行策略的区别 | II.5.4 分列固定一套的全知回收期和使用当期实绩及既定氢计划的简单规则结果，再交接隔期可用信息下的 Tier 2B。两套大容量回放净增分别为 −£20.68m 和 +£7.75m。第 III 章披露 2025 年部分样本与定容数据重叠。 |
| Xpress 与 HiGHS 证据 | 45 套及 6 台 A 方案经 Python Xpress 分块复算，全时序可行值与原档只差约 £4/年，距固定容量上界约 £5/年。附录 C 列优化器、模型规模、证书、用时和分块回退。B 采用 Xpress 及 HiGHS 的严格供电优先分块。 |
| 可再生归因、深度和版面 | 图 II.1 给分季节的日内盈余与电解槽容量收益曲线。正文区分实际盈余捕获、相对减弃量以及按日内燃料份额比例归因。补足 Lazard 的 2025 美元换算、30 个原缺价日与 35 个估计日关系、827/845 与日内承购口径、可用循环数量及站点购置条件。 |

复算档案以 SHA-256 固定实际输入、代码和使用的结果。课程问答转写和项目简报位于档案的 `course-sources` 中。站点 10 吨/日是合同情景。收益以 2020 年不变英镑计，容量大的方案用于全知投资筛查。

## 复编与复算

在 `report` 中运行 `tectonic report.tex` 可复编当前稿。Python 采用 `3.12`，需要 `numpy`、`pandas`、`scipy`、`matplotlib`、`xpress==9.9.0` 和 `highspy==1.16.0`。Xpress 分块使用本机安装的许可，指定许可时设置 `XPRESS_LICENSE_FILE` 指向已有授权文件。四小时费用参数在 `storage-exploration-20261116-v2/utility4h/configuration.json`，站点入口调整日额度和 NEPTUNE V 菜单。

在解开档案的 `FinalProject` 根目录运行以下命令。各项复算写到报告 v6 的 `evidence` 目录，最后一项更新正文两幅并列子图的数据。

```text
python project-report-20261122-v6/site_refresh.py contracts
python project-report-20261122-v6/site_refresh.py reference-day
python project-report-20261122-v6/site_refresh.py reference-pair
python project-report-20261122-v6/site_refresh.py xpress
python project-report-20261122-v6/site_refresh.py battery
python project-report-20261122-v6/make_exhibits.py
```

联合容量已有对应的 `tier1-site-battery-20261122/run_joint.py`、上界生成脚本和 `joint/verified_comparison.json`。站点的待选组合上界及参与正文汇总的调度均在档案中。B 的精确重放针对每个可证明空库存的 UTC 日边界分解，超许可规模的区块由 HiGHS 处理。
