"""Strict-priority capacity upper bounds using exact empty-stock boundaries."""

import argparse
from time import perf_counter

import highspy
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import coo_matrix

from run_joint import OUTPUT, UPPER_ROUNDING_MGBP, inputs, scaled_battery, write_json
from run_site import HORIZON_YEARS, Problem, empty_stock_boundaries


def episodes(frame, battery):
    boundaries = empty_stock_boundaries(frame, battery)
    i = 0
    while i < len(boundaries) - 1:
        j = max(i + 1, np.searchsorted(boundaries, boundaries[i] + 192, side="right") - 1)
        yield frame.iloc[boundaries[i]:boundaries[j]]
        i = j


def episode_models(frame, config, battery, blocks, anchor, lo, hi):
    jobs, gradients = [], []
    for segment in episodes(frame, scaled_battery(battery, blocks)):
        job = Problem(segment, config, OUTPUT, "lagrangian_B", blocks, hi,
                      nbmin=blocks, nhmin=lo, strict=True, cycles=False,
                      years=HORIZON_YEARS, quiet=True, seconds=12)
        solver = job.solver
        solver.setOptionValue("threads", 1)
        solver.setOptionValue("mip_rel_gap", 1e-9)
        solver.setOptionValue("mip_abs_gap", 1e-10)
        integer = np.asarray([i for i, t in enumerate(solver.getLp().integrality_)
                              if t == highspy.HighsVarType.kInteger], dtype=np.int32)
        if len(integer):
            solver.changeColsIntegrality(len(integer), integer, np.zeros(len(integer), dtype=np.uint8))
        solver.changeColCost(job.n, 0)
        solver.changeColCost(job.nh, 0)
        solver.changeColBounds(job.nh, anchor, anchor)
        solver.setOptionValue("solver", "simplex")
        solver.run()
        assert solver.getModelStatus() == highspy.HighsModelStatus.kOptimal
        gradients.append(max(0.0, -solver.getSolution().col_dual[job.nh]))
        if len(integer):
            solver.changeColsIntegrality(len(integer), integer, np.ones(len(integer), dtype=np.uint8))
        solver.changeColBounds(job.nh, lo, hi)
        solver.setOptionValue("solver", "choose")
        jobs.append(job)
    return jobs, np.array(gradients)


def update_prices(choices, annual_h2, initial):
    count = len(choices)
    rows, columns, coefficients, rhs = [], [], [], []
    for i, group in enumerate(choices):
        for size, operating_value in group:
            index = len(rhs)
            rows.extend((index, index))
            columns.extend((i, count+i))
            coefficients.extend((-size, -1))
            rhs.append(-operating_value)
    cuts = coo_matrix((coefficients, (rows, columns)), shape=(len(rhs), 2*count)).tocsr()
    price_sum = np.r_[np.ones(count), np.zeros(count)][None, :]
    limits = np.maximum(4 * initial, 0.12 * annual_h2 / count)
    master = linprog(
        np.r_[np.zeros(count), np.ones(count)],
        A_ub=cuts, b_ub=rhs, A_eq=price_sum, b_eq=[annual_h2],
        bounds=[(0, lim) for lim in limits] + [(None, None)] * count,
        method="highs",
    )
    assert master.success, master.message
    return master.x[:count]


def certify(frame, config, battery, product, blocks, lo, hi, anchor, iterations, target):
    jobs, derivatives = episode_models(frame, config, battery, blocks, anchor, lo, hi)
    annual_h2 = product["annual"]
    initial = (derivatives / derivatives.sum() if derivatives.sum() else
               np.full(len(jobs), 1 / len(jobs))) * annual_h2
    choices = [[] for _ in jobs]
    prices = initial.copy()
    previous = np.full(len(jobs), np.nan)
    upper = np.full(len(jobs), np.inf)
    best, history = None, []
    for iteration in range(iterations):
        for i, (job, price) in enumerate(zip(jobs, prices)):
            if abs(price - previous[i]) <= 1e-12:
                continue
            job.solver.changeColCost(job.nh, price)
            job.run()
            assert job.upper is not None and np.isfinite(job.upper), job.status
            capacity = float(job.x[job.nh])
            choices[i].append((capacity, job.value + price*capacity))
            upper[i] = job.upper
        previous = prices.copy()
        value = float(upper.sum() - blocks*battery["annual"] +
                      abs(prices.sum() - annual_h2)*hi + UPPER_ROUNDING_MGBP)
        history.append(value)
        if best is None or value < best["upper_mGBP"]:
            best = dict(n=blocks, h_interval=[lo, hi], anchor=anchor, upper_mGBP=value,
                        episode_upper_mGBP=upper.tolist(), dual_prices_mGBP=prices.tolist(),
                        h2_annual_cost_per_unit_mGBP=annual_h2, battery_annual_cost_mGBP=blocks*battery["annual"])
        print("B-capacity bound", blocks, (lo, hi), iteration, round(value, 8), flush=True)
        if target is not None and value < target:
            break
        if iteration+1 < iterations:
            prices = update_prices(choices, annual_h2, initial)
    best["history_mGBP"] = history
    return best


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("n", type=int)
    parser.add_argument("lo", type=int)
    parser.add_argument("hi", type=int)
    parser.add_argument("anchor", type=float)
    parser.add_argument("--iterations", type=int, default=1)
    parser.add_argument("--target", type=float)
    args = parser.parse_args()
    assert 0 <= args.lo <= args.anchor <= args.hi and args.n > 0
    start = perf_counter()
    OUTPUT.mkdir(exist_ok=True)
    bound = certify(*inputs(), args.n, args.lo, args.hi, args.anchor, args.iterations, args.target)
    bound["seconds"] = perf_counter() - start
    path = OUTPUT / f"B_certificate_{args.n}_{args.lo}_{args.hi}.json"
    write_json(path, bound)
    print("Wrote", path.name, "seconds", round(bound["seconds"], 2), flush=True)
