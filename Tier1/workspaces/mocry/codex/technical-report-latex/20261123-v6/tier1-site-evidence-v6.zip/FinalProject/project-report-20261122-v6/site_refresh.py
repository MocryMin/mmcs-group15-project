"""Site-scale calculations for the Tier 1 revision."""
import argparse
import io
import json
import math
import os
from contextlib import redirect_stdout
from pathlib import Path
import site
import sys
from time import perf_counter

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent
for environment in ("tier1-halfhour-20261113-v7/.venv", "tier1-strengthened-20261110-v5/.venv"):
    site.addsitedir(str(PROJECT / environment / "Lib/site-packages"))
sys.path.insert(0, str(PROJECT / "tier1-site-battery-20261122"))

import numpy as np
import pandas as pd
import highspy
import xpress as xp

from run_joint import inputs, scaled_battery
from run_site import electrolysis_only, investment_model, priority_dispatch, repair_economic_anchor
from model import annual_costs, solve
import model
from replay_xpress import check_and_cash, replay_block
from reproduce import DispatchBlock, capacity_master


OUTPUT = HERE / "evidence"
SITE = PROJECT / "tier1-site-battery-20261122"
YEARS = 6
GBP = 1_000_000


class EligibleBlock(DispatchBlock):
    """A premium available to an upper screen of separately proven direct supply."""
    def __init__(self, frame, product, config, policy, years):
        self.premium = config["support_premium"] / (product["kWh_kg"] * years)
        super().__init__(frame, product, config, policy, years)

    def build_matrix(self, capacity):
        matrix, q, h = super().build_matrix(capacity)
        eligible = matrix.variables(self.periods, hi=np.maximum(self.g - self.d, 0.), c=-self.premium)
        matrix.rows(self.periods, [(eligible, 1), (h, -1)], hi=0)
        return matrix, q, h


def price_case(frame, config, product, policy, cap, receipt, premium=0., curve=False):
    started = perf_counter()
    cfg = dict(config, cap_kg_day=cap, netback=receipt, support_premium=premium)
    g, d, prices = (frame[key].to_numpy() for key in ("g", "d", "price"))
    theory = np.maximum(g - d, 0.)
    reference = np.minimum(g, d) * (prices >= 0 if policy == "A" else 1.)
    ref = np.dot(reference, prices) / (1000 * YEARS)
    ceiling = (np.dot(d, prices.clip(min=0)) / 1000 + frame.date.nunique() * cap * (receipt + premium) / GBP) / YEARS
    width = (12 if premium else 14) * 48
    block_type = EligibleBlock if premium else DispatchBlock
    blocks = [block_type(frame.iloc[i:i + width], product, cfg, policy, YEARS) for i in range(0, len(frame), width)]
    maximum = math.ceil(cap / (product["kg_hour"] * .5))
    with redirect_stdout(io.StringIO()):
        n0, _, proof, _ = capacity_master(blocks, product["annual"], maximum, ceiling, policy)
    neighbour = set(range(max(0, math.floor(n0) - 1), min(maximum, math.ceil(n0) + 1) + 1)) | {0}
    counts = sorted(neighbour | (set(range(17)) if curve else set()))
    results = []
    for n in counts:
        if n == 0:
            sale, h = reference.copy(), np.zeros(len(frame))
        else:
            solved = [block.replay(n) for block in blocks]
            sale = np.concatenate([s[1] for s in solved])
            h = np.concatenate([s[2] for s in solved])
        kg = h * GBP / product["kWh_kg"]
        eligible_kg = np.minimum(h, theory) * GBP / product["kWh_kg"]
        sales = np.dot(prices, sale - reference) / (1000 * YEARS)
        gross = sales + kg.sum() * receipt / (GBP * YEARS) + eligible_kg.sum() * premium / (GBP * YEARS)
        investment = n * product["capital_GBP"] / GBP
        gain = gross - n * product["annual"]
        assert np.all(sale + h <= g + 1e-8) and np.all(sale <= d + 1e-8)
        assert np.all(h <= n * product["unit_GWh"] + 1e-8)
        assert np.all((h <= 1e-8) | (h >= product["minimum"] * product["unit_GWh"] - 1e-8))
        assert np.all(kg.reshape(-1, 48).sum(axis=1) <= cap + 1e-5)
        if policy == "B":
            np.testing.assert_allclose(sale, reference, rtol=0., atol=1e-8)
        premium_fraction = eligible_kg.sum() / kg.sum() if kg.sum() else 0.
        annuity = (1 - (1 + config["r"]) ** -product["life"]) / config["r"]
        recurring = gross - n * product["fom_GBP"] / GBP
        required = receipt - gain * GBP * YEARS / kg.sum() if kg.sum() and not premium else None
        results.append(dict(policy=policy, buyer_tpd=cap / 1000, base_price=receipt, surplus_premium=premium,
                            modules=n, MW=n * product["MW"], profit=gain, gross=gross, capex_mGBP=investment,
                            annual_kg=kg.sum() / YEARS, physical_surplus_share=premium_fraction,
                            annual_sales_change_GWh=(sale - reference).sum() / YEARS,
                            demand_coverage_pct=100. * sale.sum() / d.sum(), break_even_flat_price=required,
                            annual_unused_GWh=(g - sale - h).sum() / YEARS, NPV_mGBP=gain * annuity,
                            payback_years=investment / recurring if recurring > 0 and n else None))
    best = max(results, key=lambda row: row["profit"]).copy()
    best.update(upper_mGBP=-proof[-1]["lower_cost"] - ref, elapsed_seconds=perf_counter() - started,
                max_lp_rows_and_columns=max(block.matrix.n + block.matrix.nr for block in blocks))
    print(policy, cap, receipt, premium, best["modules"], round(best["profit"], 6), flush=True)
    return best, results


def contracts(frame, config, product):
    support = config["netback"]
    results, curve = [], []
    scenarios = ((4000, support, 0.), (10_000, 2.5, 0.), (10_000, 5., 0.), (10_000, support, 0.),
                 (10_000, 9.5, 0.), (10_000, 10., 0.), (10_000, 2.5, support - 2.5))
    for buyer, price, premium in scenarios:
        is_curve = (buyer, price, premium) == (10_000, support, 0.)
        for policy in ("A", "B"):
            best, samples = price_case(frame, config, product, policy, buyer, price, premium, is_curve)
            results.append(best)
            if is_curve:
                curve.extend(samples)
    pd.DataFrame(results).to_csv(OUTPUT / "contract_sizing.csv", index=False)
    pd.DataFrame(curve).to_csv(OUTPUT / "electrolyser_curve.csv", index=False)


def brief_config(config, hours):
    asset = config["batteries"][0]
    template = dict(asset, id="brief-2h", E_MWh=200., P_MW=100., capital_GBP=200. * 256235., fom_GBP=0.)
    config = dict(config, batteries=[template], dt_hours=hours)
    config["electrolysers"] = [dict(config["electrolysers"][0], minimum=.20)]
    return config


def references(frame, config):
    daily_frame = frame.groupby("date").agg(g=("g", "sum"), d=("d", "sum"), price=("price", "mean"))
    daily_frame["date"] = daily_frame.index
    daily_frame.index = pd.to_datetime(daily_frame.index, utc=True)
    config = brief_config(config, 24.)
    for policy in ("A", "B"):
        result = solve(daily_frame, config, policy, f"reference_day_{policy}_integer", seconds=35, threads=4)
        print(policy, result["investment"], flush=True)


def reference_pair(frame, config):
    """Use the daily reference optimum's H count in the half-hour test of one block."""
    config = brief_config(config, .5)
    (battery,), (product,) = annual_costs(config)
    root = OUTPUT / "reference"
    investment_model.ROOT = root
    n = 5
    fixed = {battery["id"]: 1, product["id"]: n}
    name = "reference_halfhour_A_fixed_one_relaxation"
    upper = investment_model.solve(frame, config, "A", name, fixed=fixed, relaxation=True, seconds=65, threads=3)
    raw = pd.read_csv(root / f"results/{name}_schedule.csv.gz")
    cols = ["direct", "charge", "battery_sale", "battery_h2", "brief-2h__stock", "h2_input"]
    a, _ = repair_economic_anchor(frame, raw[cols].to_numpy().T, battery, product)
    highspy.Highs.resetGlobalScheduler(True)
    b, cert = priority_dispatch(frame, config, battery, product, n)
    g, d, p = (frame[key].to_numpy() for key in ("g", "d", "price"))
    rows = []
    for policy, with_storage in (("A", a), ("B", b)):
        ref = np.dot(np.minimum(g, d) * ((p >= 0.) if policy == "A" else 1.), p) * 1000
        for j, flows in ((0, electrolysis_only(frame, product, config, policy, n)), (1, with_storage)):
            asset = scaled_battery(battery, j)
            cash = check_and_cash(frame, flows, asset, product, n, config["netback"], config["cap_kg_day"], policy, False)
            net = (sum(row[1] for row in cash) - ref) / (YEARS * GBP) - asset["annual"] - n * product["annual"]
            gap = 0. if not j else ((upper["upper_increment_mGBP"] - net) * GBP if policy == "A" else cert["upper_gap_GBP_year"])
            rows.append(dict(policy=policy, battery_blocks=j, electrolyser_modules=n, net_mGBP=net,
                             fixed_configuration_upper_gap_GBP=max(0., gap)))
            np.savez_compressed(root / f"{policy}_2h_{j}_dispatch.npz", flows=flows, utc_ns=frame.index.as_unit("ns").asi8)
    pd.DataFrame(rows).to_csv(root / "fixed_pair.csv", index=False)
    print(rows, flush=True)


def xpress_joint(frame, config, battery, product):
    started = perf_counter()
    n, h = 45, 6
    anchor_path = SITE / f"joint/A_n{n}_h{h}_dispatch.npz"
    with np.load(anchor_path) as archive:
        saved = archive["flows"]
        np.testing.assert_array_equal(frame.index.as_unit("ns").asi8, archive["utc_ns"])
    asset = scaled_battery(battery, n)
    stock = saved[4]
    discharge = (saved[2] + saved[3]) / asset["eta"]
    cuts = set(range(0, len(frame), 4 * 48)) | {len(frame)}
    cuts.update(np.flatnonzero(frame.index.year[1:] != frame.index.year[:-1]) + 1)
    ends = sorted(cuts)
    plans, fallback = [], 0
    for lo, hi in zip(ends, ends[1:]):
        block = frame.iloc[lo:hi]
        try:
            plan = replay_block(block, asset, product, h, config["netback"], config["cap_kg_day"], "A", False,
                                stock[lo - 1] if lo else 0., stock[hi - 1], discharge[lo:hi].sum() + 1.e-11)
        except RuntimeError:
            plan = saved[:, lo:hi]
            fallback += 1
        plans.append(plan)
    flows = np.concatenate(plans, axis=1)
    cash = check_and_cash(frame, flows, asset, product, h, config["netback"], config["cap_kg_day"], "A", False)
    ref = np.dot(frame.price.clip(lower=0.), np.minimum(frame.g, frame.d)) * 1000
    gain = (sum(line[1] for line in cash) - ref) / (YEARS * GBP) - asset["annual"] - h * product["annual"]
    old = json.loads((SITE / f"joint/A_n{n}_h{h}.json").read_text())
    assert gain <= old["fixed_configuration_upper_mGBP"] + 1.e-5
    result = dict(solver="Python Xpress; Optimizer " + str(xp.getVersion()), battery_count=n, electrolyser_count=h,
                  xpress_blocks=len(plans) - fallback, saved_feasible_blocks=fallback, wall_seconds=perf_counter() - started,
                  annual_net_mGBP=gain, archived_net_mGBP=old["annual_net_gain_mGBP"],
                  fixed_configuration_gap_GBP=(old["fixed_configuration_upper_mGBP"] - gain) * GBP)
    (OUTPUT / "site_A_xpress.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    np.savez_compressed(OUTPUT / "site_A_xpress_dispatch.npz", flows=flows, utc_ns=frame.index.as_unit("ns").asi8)
    print(result, flush=True)


def battery_only(frame, config, battery, product):
    root = OUTPUT / "battery_only"
    root.mkdir(exist_ok=True)
    investment_model.ROOT = root
    name = "A_one_block_no_electrolysis_relaxation"
    fixed = {battery["id"]: 1, product["id"]: 0}
    upper = investment_model.solve(frame, config, "A", name, fixed=fixed, relaxation=True, seconds=75, threads=3)
    saved = pd.read_csv(root / f"results/{name}_schedule.csv.gz")
    columns = ["direct", "charge", "battery_sale", "battery_h2", battery["id"] + "__stock", "h2_input"]
    economic, _ = repair_economic_anchor(frame, saved[columns].to_numpy().T, battery, product)
    highspy.Highs.resetGlobalScheduler(True)
    priority, cert = priority_dispatch(frame, config, battery, product, count=0)
    prices, g, d = (frame[key].to_numpy() for key in ("price", "g", "d"))
    results = []
    for policy, flows in (("A", economic), ("B", priority)):
        q, c, r, u, stock, h = flows
        prior = np.r_[0., stock[:-1]]
        tol = 2.e-8
        P = battery["P_MW"] / 2000.
        ref = np.minimum(g, d) * ((prices >= 0.) if policy == "A" else 1.)
        np.testing.assert_allclose([u, h], 0., rtol=0., atol=tol)
        np.testing.assert_allclose(stock, prior + c * battery["eta"] - r / battery["eta"], rtol=0., atol=tol)
        assert abs(stock[-1]) <= tol and flows.min() >= -tol
        assert max(np.max(x) for x in (stock - battery["usable"], q + c - g, q + r - d, c - P, r - P, np.minimum(c, r))) <= tol
        for year in set(frame.index.year):
            use = frame.index.year == year
            assert r[use].sum() / battery["eta"] <= use.sum() / 48 * battery["E_MWh"] / 1000 + tol
        if policy == "B":
            np.testing.assert_allclose(q, ref, rtol=0., atol=tol)
            np.testing.assert_allclose(r, np.minimum.reduce(((d-g).clip(min=0.), np.full(len(r), P),
                                                             prior * battery["eta"])), rtol=0., atol=tol)
        gross = np.dot(prices, q + r - ref) / (1000 * YEARS)
        gain = gross - battery["annual"]
        gap = ((upper["upper_increment_mGBP"] - gain) * GBP if policy == "A" else cert["upper_gap_GBP_year"])
        results.append(dict(policy=policy, annual_gross_mGBP=gross, annual_net_mGBP=gain, upper_gap_GBP=max(0., gap)))
        np.savez_compressed(root / f"{policy}_dispatch.npz", flows=flows, utc_ns=frame.index.as_unit("ns").asi8)
    pd.DataFrame(results).to_csv(root / "comparison.csv", index=False)
    print(results, flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("task", choices=("contracts", "reference-day", "reference-pair", "xpress", "battery"))
    task = parser.parse_args().task
    if os.environ.get("XPRESS_LICENSE_FILE"):
        xp.init(os.environ["XPRESS_LICENSE_FILE"])
    OUTPUT.mkdir(exist_ok=True)
    frame, config, battery, product = inputs()
    if task == "contracts":
        contracts(frame, config, product)
    elif task == "reference-day":
        model.ROOT = OUTPUT / "reference"
        model.ROOT.mkdir(exist_ok=True)
        references(frame, config)
    elif task == "reference-pair":
        reference_pair(frame, config)
    elif task == "xpress":
        xpress_joint(frame, config, battery, product)
    else:
        battery_only(frame, config, battery, product)
