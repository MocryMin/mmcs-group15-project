"""Replay the 12.5% site scenario with the matched four-day controller."""

import argparse
from pathlib import Path
import shutil
import sys

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent / "tier2b-commitment-20-20261124"
sys.path.insert(0, str(SOURCE))
import commitment
import continuous
import replay
import summarize


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--threads", type=int, default=18)
    parser.add_argument("--audit", action="store_true")
    args = parser.parse_args()
    commitment.HERE = continuous.HERE = replay.HERE = summarize.HERE = HERE
    if args.audit:
        import audit_continuous
        audit_continuous.HERE = HERE
        audit_continuous.main()
        return
    sys.argv = [sys.argv[0], "--fleet", "6", "--load-floor", ".125"]
    commitment.main()
    sys.argv = [sys.argv[0], "--years", *map(str, range(2021, 2027)),
                "--sizes", *map(str, range(46)), "--threads", str(args.threads),
                "--keep", "1", "7", "11", "12", "45"]
    continuous.main()
    # B's zero-electrolyser fleet is invariant to the load floor.
    shutil.copy2(SOURCE / "size-sweep-folds.csv", HERE / "size-sweep-folds.csv")
    summarize.main()


if __name__ == "__main__":
    main()
