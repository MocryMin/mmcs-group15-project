# Tier 2B · matched 12.5% four-day replay

Compares 0–45 four-hour battery blocks in six held-out September–August windows. A fixes six electrolysers and applies the 12.5% hydrogen floor, midnight switching and four-day minimum run. B fixes zero electrolysers and reuses the verified, invariant B ledgers. Data, forecasts, five A battery requests and settlement follow the [20% comparison](../tier2b-commitment-20-20261124/README.md).

The 2025/26 reference window peaks at seven blocks in A (+£0.695m rounded to three decimals) and 22 in B (+£12.510m). Six-window sums peak at 11 blocks in both policies. Excluding 2021/22, all positive capacities have negative aggregate net battery gains. In the reference window A at 45 blocks loses £23.980m. One block gives £4.652m across six A windows and £7.579m across six B windows. Excluding 2021/22 those fall to −£1.543m and −£1.230m respectively.

The retained fold-local training can include later years in the earlier windows. Half-hour decisions use only information available at their decision time. The replay is a historical stability test, with no credit for terminal stock.

[All 552 rows](six-fold-capacity-replay.csv) · [Capacity summaries](capacity-summary.csv) · [Xpress window cross-checks](continuous-xpress-audit.csv)

Use `run.py` for the replay and `run.py --audit` for the 192 cross-checks and 48 short-window enumerations. The runner uses the implementation in the sibling 20% study and requires its previous B ledger and the original archived forecast inputs.
