"""Independent scheduling checks for the updated Tier 1 assumptions."""

import json

import numpy as np
from scipy.sparse import coo_matrix
import xpress as xp

from run_a import ALPHA, CAP, HERE, PRIOR, RUN_DAYS, site_inputs, value_table, write
from solve_b import hydrogen_bound
import solve_b
from certify_b import battery_bounds


def dynamic_commitment(values):
    """Maximum cash on the exact day/run-length state graph."""
    fleet = values.shape[1] - 1
    states = [(a, b, c, n) for n in range(fleet+1) for a in range(n+1)
              for b in range(n-a+1) for c in range(n-a-b+1)]
    state_index = {s: i for i, s in enumerate(states)}
    edges = [(i, state_index[(max(0, k-n), a, b, k)], k, k > n)
             for i, (a, b, c, n) in enumerate(states) for k in range(a+b+c, fleet+1)]
    source, target, count, start = np.array(edges, dtype=int).T
    best = np.full(len(states), -np.inf)
    best[state_index[(0, 0, 0, 0)]] = 0.
    for d, rewards in enumerate(values):
        if d > len(values) - RUN_DAYS:
            take = start == 0
        else:
            take = start >= 0
        new = np.full_like(best, -np.inf)
        np.maximum.at(new, target[take], best[source[take]] + rewards[count[take]])
        best = new
    return float(best.max())


def xpress_chunk(values, online, starts, low, high):
    """Reoptimise this chunk with its observed boundary commitment state."""
    nd, levels = high-low, values.shape[1]
    offset = nd*levels
    maximum = levels - 1
    indices = np.arange(offset).reshape(nd, levels)
    startup = offset + np.arange(nd)
    obj = np.r_[values[low:high].ravel() / 1000, np.zeros(nd)]
    lb, ub = np.zeros(len(obj)), np.r_[np.ones(offset), np.full(nd, maximum, dtype=float)]
    # The three outstanding starts and last online count are the boundary
    # state that connects each licensed problem to the full-horizon schedule.
    for d in range(max(low, high-RUN_DAYS+1), high):
        lb[startup[d-low]] = ub[startup[d-low]] = starts[d]
    ub[indices[-1]] = 0.
    lb[indices[-1, online[high-1]]] = ub[indices[-1, online[high-1]]] = 1.
    first = 0 if low == 0 else online[low-1]
    rr, cc, vv, right = [], [], [], []

    def add(cols, coefs, rhs):
        rr.extend([len(right)] * len(cols))
        cc.extend(cols)
        vv.extend(coefs)
        right.append(rhs)

    for j, k in enumerate(indices):
        add(k, np.ones(levels), 1.)
        add(np.r_[k, startup[j], indices[j-1] if j else []],
            np.r_[np.arange(levels), -1, -np.arange(levels) if j else []], float(first if j == 0 else 0.))
        prev = starts[max(0,low+j-RUN_DAYS+1):low].sum() if j < RUN_DAYS-1 else 0
        add(np.r_[startup[max(0,j-RUN_DAYS+1):j+1], k],
            np.r_[np.ones(min(j+1,RUN_DAYS)), -np.arange(levels)], -float(prev))
    matrix = coo_matrix((vv, (rr, cc)), shape=(len(right), len(obj))).tocsr()
    model = xp.problem()
    model.controls.outputlog = 0
    model.controls.threads = 1
    model.controls.miprelstop = 0.
    model.controls.mipabsstop = 1e-7
    model.addCols(objcoef=obj, lb=lb, ub=ub)
    model.addRows(rowtype="ELL"*nd, rhs=right, start=matrix.indptr,
                  colind=matrix.indices, rowcoef=matrix.data)
    model.chgColType(np.arange(offset), "B"*offset)
    model.chgObjSense(xp.maximize)
    warm = np.zeros(len(obj))
    warm[indices[np.arange(nd), online[low:high]]] = 1.
    warm[startup] = starts[low:high]
    model.addMipSol(warm)
    model.optimize()
    if model.attributes.mipstatus != 6:
        raise RuntimeError(f"Xpress did not certify days {low}–{high}: {model.attributes.mipstatus}")
    return dict(first_day=low, last_day=high-1, rows=matrix.shape[0], columns=matrix.shape[1],
                operating_gain_gbp=float(model.attributes.mipobjval)*1000)


def main():
    site, battery, product = site_inputs()
    anchor = json.loads((HERE / "A-zero-finance.json").read_bytes())
    fleet = anchor["modules"]
    values = value_table(site, "A", ALPHA, fleet, CAP)
    with np.load(HERE / "A-zero-schedule.npz") as frozen:
        online = frozen["online"]
    starts = np.maximum(0, np.diff(np.r_[0, online]))
    exact = dynamic_commitment(values)
    planned = values[np.arange(len(values)), online].sum()
    np.testing.assert_allclose(exact, planned, rtol=0., atol=.01)
    chunks = [xpress_chunk(values, online, starts, low, min(len(values), low+320))
              for low in range(0, len(values), 320)]
    xpress_value = sum(x["operating_gain_gbp"] for x in chunks)
    np.testing.assert_allclose(xpress_value, exact, rtol=0., atol=.05)
    write("A-zero-verification.json", dict(days=len(values), dynamic_optimum_operating_GBP=exact,
          highs_operating_GBP=planned, xpress_fixed_boundary_GBP=xpress_value,
          certified_fleet=fleet, chunks=chunks))
    print("A zero battery: HiGHS, full day-state graph and Xpress conditional chunks agree", flush=True)

    solve_b.MIN_LOAD = ALPHA
    proof = hydrogen_bound(site, battery, 70)
    assert proof["annual_hydrogen_receipts_per_unit_upper_mGBP"] < product["annual"]
    prior = json.loads((PRIOR / "B-battery-certificate.json").read_bytes())
    assert prior["electrolyser_units"] == 0 and prior["capacity_certified"]
    screen = battery_bounds(site, battery)
    np.testing.assert_array_equal(np.flatnonzero(screen >= prior["annual_net_mGBP"]), [8, 9])
    write("B-capacity-certificate.json", prior | {"min_load_pct": 20, "min_run_days": 4, "hydrogen_proof": proof,
          "transfer": "Raising the floor only tightens hydrogen dispatch. The optimum at zero modules remains feasible."})
    print("B: the 20% hydrogen screen and earlier exact battery ranking agree", flush=True)


if __name__ == "__main__":
    main()
