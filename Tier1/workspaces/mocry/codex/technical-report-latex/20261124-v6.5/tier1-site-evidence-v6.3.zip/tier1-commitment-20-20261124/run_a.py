"""Repeat the four-day Policy A sizing with the brief's 20% load floor."""

import argparse
import json
from pathlib import Path
import sys

import numpy as np

HERE = Path(__file__).resolve().parent
PRIOR = HERE.parent / "tier1-commitment-125-20261124"
sys.path.insert(0, str(PRIOR))
import solve_a
import economic_witness
from site_model import commit, solve_case, value_table

ALPHA = .20
CAP = solve_a.CAP_KG
RUN_DAYS = solve_a.MIN_DAYS


def write(name, payload):
    (HERE / name).write_text(json.dumps(payload, indent=2, default=lambda v: v.item()) + "\n",
                             encoding="utf-8")


def site_inputs():
    # Change the load floor while retaining all prices, volumes and equipment cost.
    old = solve_a.MIN_LOAD
    try:
        solve_a.MIN_LOAD = .125
        site, battery, product = solve_a.inputs()
    finally:
        solve_a.MIN_LOAD = old
    return site, battery, dict(product, minimum=ALPHA)


def screening_upper():
    upper = economic_witness.operating_upper()
    for file in PRIOR.glob("A-*-*-*.json"):
        name = file.stem.split("-")
        if len(name) != 4 or not name[1].isdigit() or not name[2].isdigit():
            continue
        row = json.loads(file.read_bytes())
        if row.get("upper_mGBP") is not None and np.isfinite(row["upper_mGBP"]):
            b, h = map(int, name[1:3])
            upper[b, h] = min(upper[b, h], row["upper_mGBP"] + 2e-6)
    for file in PRIOR.glob("A-*-*.json"):
        name = file.stem.split("-")
        if len(name) != 3 or not name[1].isdigit() or not name[2].isdigit():
            continue
        row = json.loads(file.read_bytes())
        if row.get("upper_mGBP") is not None and np.isfinite(row["upper_mGBP"]):
            b, h = map(int, name[1:3])
            upper[b, h] = min(upper[b, h], row["upper_mGBP"] + 2e-6)
    assert np.isfinite(upper).all()
    # For midnight commitment a larger installed fleet can only matter through
    # the daily count. Above this count, one can remove idle modules and save cost.
    site, _, unit = site_inputs()
    nmax = int(CAP * unit["kWh_kg"] / (ALPHA * unit["MW"] * 24 * 1000))
    return upper[:, :nmax + 1]


def zero_battery():
    site, _, unit = site_inputs()
    candidates = int(CAP * unit["kWh_kg"] / (ALPHA * unit["MW"] * 24 * 1000))
    value = value_table(site, "A", ALPHA, candidates, CAP)
    records, best = [], None
    for n in [6, *[n for n in range(candidates + 1) if n != 6]]:
        upper = np.max(value[:, :n+1], axis=1).sum() / (site.years_equiv * 1e6) - n * unit["annual"]
        if best is not None and upper + 1e-9 < best["net_m"]:
            records.append(dict(modules=n, upper_mGBP=upper, screened=True))
            continue
        row, path, plan = solve_case(site, "A", ALPHA, n, RUN_DAYS, CAP)
        records.append(row | {"screened": False})
        if best is None or row["net_m"] > best["net_m"]:
            best = row
            np.savez_compressed(HERE / "A-zero-schedule.npz", online=path, hydrogen_mwh=plan["h"])
    best["npv_30_year_mGBP"] = best["net_m"] * (1 - 1.05**-30) / .05
    best["break_even_fixed_dispatch_GBP_kg"] = site.netback - best["net_m"] * 1000 / best["h2_t_per_year"]
    write("A-zero-finance.json", best)
    write("A-zero-sizing.json", records)
    print(json.dumps(best, default=lambda v: v.item()), flush=True)


def warm_for(blocks, units):
    site, battery, product = site_inputs()
    saved = [f for f in PRIOR.glob("A-*-*.npz")
             if len(f.stem.split("-")) == 3 and all(s.isdigit() for s in f.stem.split("-")[1:])]
    source = min(saved, key=lambda f: (abs(int(f.stem.split("-")[1]) - blocks),
                                       abs(int(f.stem.split("-")[2]) - units)))
    with np.load(source) as archive:
        scale = 1000 * min(1, blocks / int(source.stem.split("-")[1]))
        result, flow = economic_witness.witness(site, battery, product, blocks, units,
                                                archive["charge"] * scale, archive["discharge"] * scale)
    warm = HERE / f"warm-{blocks}-{units}.npz"
    np.savez_compressed(warm, battery_blocks=blocks, electrolyser_units=units,
                        **dict(zip(("sales", "charge", "discharge", "stock", "hydrogen", "online"), flow)))
    write(f"warm-{blocks}-{units}.json", result)
    print("Feasible witness", result, flush=True)
    return warm


def fixed(blocks, units, mode, seconds, threads):
    site, battery, product = site_inputs()
    label = f"{blocks}-{units}"
    warm = warm_for(blocks, units) if mode == "fixed" else None
    job = solve_a.EconomicSizing(site, battery, product, seconds, threads, f"20-{label}")
    job.pin(blocks, units)
    if mode in ("relax", "round"):
        solution, status = job.run()
        bound = -float(job.solver.getObjectiveValue()) if status == solve_a.highspy.HighsModelStatus.kOptimal else None
        record = dict(battery_blocks=blocks, electrolyser_units=units, upper_mGBP=bound, status=str(status))
        if mode == "round":
            levels = np.arange(units + 1)
            target = solution[job.online]
            path, _ = commit(-(levels - target[:, None])**2, RUN_DAYS, time_limit=45.)
            job.pin(blocks, units, path.astype(float))
            solution, status = job.run()
            record = job.audit(solution, label + "-rounded") | record
    else:
        integer = np.r_[job.nb, job.nh, job.online].astype(np.int32)
        solver = job.solver
        solver.setOptionValue("solver", "choose")
        solver.changeColsIntegrality(len(integer), integer, np.ones(len(integer), dtype=np.uint8))
        start = solve_a.highspy.HighsSolution()
        start.col_value = job.load_warm(warm).tolist()
        start.value_valid = True
        solver.setSolution(start)
        solution, status = job.run()
        record = job.audit(solution, label)
        info = solver.getInfo()
        record |= dict(upper_mGBP=-info.mip_dual_bound, status=str(status))
    suffix = {"relax": "-relax", "round": "-rounded", "fixed": ""}[mode]
    write(f"A-{label}{suffix}.json", record)
    print(record, flush=True)


def certificate():
    upper = screening_upper()
    witnesses = []
    for path in [*HERE.glob("warm-*-*.json"), *HERE.glob("A-*-*.json")]:
        tokens = path.stem.split("-")
        if len(tokens) < 3 or not all(x.isdigit() for x in tokens[1:3]):
            continue
        row = json.loads(path.read_bytes())
        b, h = map(int, tokens[1:3])
        if row.get("annual_net_mGBP") is not None:
            witnesses.append(row)
        bound = row.get("upper_mGBP")
        if bound is not None and np.isfinite(bound):
            upper[b, h] = min(upper[b, h], bound + 2e-6)
    best = max(witnesses, key=lambda row: row["annual_net_mGBP"])
    n, h = best["battery_blocks"], best["electrolyser_units"]
    rivals = upper.copy()
    rivals[n, h] = -np.inf
    remaining = [(int(b), int(m), float(rivals[b, m]))
                 for b, m in np.argwhere(rivals >= best["annual_net_mGBP"])]
    payload = dict(best, global_upper_mGBP=float(upper.max()),
                   best_alternative_upper_mGBP=float(rivals.max()),
                   capacity_certified=not remaining, remaining=remaining)
    write("A-capacity-certificate.json", payload)
    print(payload, flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    options = parser.add_mutually_exclusive_group(required=True)
    options.add_argument("--zero", action="store_true")
    options.add_argument("--warm", type=int, nargs=2)
    options.add_argument("--fixed", type=int, nargs=2)
    options.add_argument("--relax", type=int, nargs=2)
    options.add_argument("--round", type=int, nargs=2)
    options.add_argument("--certificate", action="store_true")
    parser.add_argument("--seconds", type=float, default=300.)
    parser.add_argument("--threads", type=int, default=4)
    args = parser.parse_args()
    solve_a.MIN_LOAD = economic_witness.MIN_LOAD = ALPHA
    solve_a.HERE = HERE
    if args.zero:
        zero_battery()
    elif args.warm:
        warm_for(*args.warm)
    elif args.certificate:
        certificate()
    else:
        mode = next(key for key in ("relax", "round", "fixed") if getattr(args, key) is not None)
        fixed(*getattr(args, mode), mode, args.seconds, args.threads)


if __name__ == "__main__":
    main()
