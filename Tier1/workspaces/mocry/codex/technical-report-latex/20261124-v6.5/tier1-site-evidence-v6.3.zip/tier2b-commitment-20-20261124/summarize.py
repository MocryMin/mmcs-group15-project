"""Combine the updated A and verified B historical replays."""

from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent


def merge():
    a = pd.concat([pd.read_csv(HERE / f"results-{year}-continuous-0-45.csv")
                   for year in range(2021, 2027)], ignore_index=True)
    b = pd.read_csv(HERE / "size-sweep-folds.csv").rename(columns={
        "battery_blocks": "blocks", "electrolysers": "electrolyser_units",
        "gross_gbp": "gross_battery_GBP", "cost_gbp": "battery_annual_equiv_cost_GBP",
        "net_gbp": "net_battery_GBP", "portfolio_net_gbp": "portfolio_net_GBP",
        "sept_dec_net_gbp": "net_sept_dec_GBP", "terminal_stock_mwh": "final_usable_stock_MWh",
    })
    b["method"] = "binary_surplus_classifier_full_order"
    b["electrolysis_tonnes"] = 0.
    joined = pd.concat([a.assign(policy="A"), b[list(a)].assign(policy="B")], ignore_index=True)
    key = ["policy", "test_end_year", "blocks"]
    assert not joined.duplicated(key).any() and len(joined) == 552
    assert np.array_equal(joined.groupby(["policy", "test_end_year"]).size(), np.full(12, 46))
    np.testing.assert_allclose(joined["gross_battery_GBP"] - joined["battery_annual_equiv_cost_GBP"],
                               joined["net_battery_GBP"], atol=.00001, rtol=0.)
    return joined[["policy", *a.columns]].sort_values(key)


def summarize(joined):
    rows = []
    for (policy, blocks), group in joined.groupby(["policy", "blocks"]):
        reference = group.loc[group.test_end_year == 2026].iloc[0]
        net = group["net_battery_GBP"]
        rows.append(dict(policy=policy, blocks=blocks, electrolyser_units=reference.electrolyser_units,
                         reference_gross_GBP=reference.gross_battery_GBP,
                         reference_battery_cost_GBP=reference.battery_annual_equiv_cost_GBP,
                         reference_net_GBP=reference.net_battery_GBP,
                         reference_portfolio_net_GBP=reference.portfolio_net_GBP,
                         six_fold_net_GBP=net.sum(), profitable_folds=int((net > 0.).sum()),
                         excluding_2021_22_GBP=net[group.test_end_year != 2022].sum(),
                         excluding_reference_GBP=net[group.test_end_year != 2026].sum()))
    return pd.DataFrame(rows)


def main():
    joined = merge()
    summary = summarize(joined)
    joined.to_csv(HERE / "six-fold-capacity-replay.csv", index=False)
    summary.to_csv(HERE / "capacity-summary.csv", index=False)
    keep = joined[(joined.policy == "A") & joined.blocks.isin((0, 1, 7, 11, 45)) |
                  (joined.policy == "B") & joined.blocks.isin((0, 1, 9, 11, 22))]
    keep.pivot(index="test_end_year", columns=["policy", "blocks"], values="net_battery_GBP").to_csv(
        HERE / "selected-six-fold-net-GBP.csv")
    measures = ["reference_net_GBP", "six_fold_net_GBP", "excluding_2021_22_GBP"]
    for policy, group in summary.groupby("policy"):
        print(policy, {field: int(group.loc[group[field].idxmax(), "blocks"]) for field in measures})


if __name__ == "__main__":
    main()
