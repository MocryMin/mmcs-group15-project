"""Create causal midnight commitments for the frozen half-hour forecasts."""

import argparse
from dataclasses import replace
from pathlib import Path
import sys

import numpy as np

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent
JULIAN = PROJECT / "group-collaboration/Tier1/workspaces/julian/claude/tier1-main-results/20261123-v1"
sys.path.insert(0, str(JULIAN))
from site_model import check_path, load, value_table

SLOTS = 48
DAYS = 4
SLOT_SECONDS = 1800


def choose(values, fleet, enforce_terminal=True):
    """Maximise predicted margin over four days, executing today's count only."""
    days = len(values)
    selected, tomorrow = np.zeros(days, dtype=int), np.zeros(days, dtype=int)
    starts = np.zeros(days, dtype=int)
    for d in range(days):
        previous = selected[d - 1] if d else 0
        recent = starts[max(d - DAYS + 1, 0):d]
        count_max = fleet if not enforce_terminal or d <= days - DAYS else previous
        horizon = min(DAYS, days - d) if enforce_terminal else DAYS
        best, chosen = -np.inf, None
        for count in range(recent.sum(), count_max + 1):
            start = max(0, count - previous)
            outstanding = np.r_[np.zeros(DAYS - 1 - len(recent), dtype=int), recent, start]
            path_values = np.zeros(count + 1)
            next_counts = np.arange(count + 1)
            # With four forecast days, only today's new starts can finish a
            # full run inside the planning horizon. Later choices may stop
            # any already-unlocked modules, then midnight reoptimises.
            for lead in range(horizon - 1, 0, -1):
                required = outstanding[lead:].sum()
                scores = values[d, lead, :count+1] + path_values
                scores[:required] = -np.inf
                improved = np.r_[True, scores[1:] > np.maximum.accumulate(scores[:-1])]
                next_counts = np.maximum.accumulate(np.where(improved, np.arange(count + 1), 0))
                path_values = np.maximum.accumulate(scores)
            score = values[d, 0, count] + path_values[count]
            if score > best:
                best, chosen = score, (count, start, next_counts[count] if horizon > 1 else count)
        if chosen is None:
            raise ValueError(f"No feasible commitment on day {d}")
        selected[d], starts[d], tomorrow[d] = chosen
    errors = check_path(selected, DAYS, np.ones((days, fleet + 1), dtype=bool))
    if errors:
        raise ValueError(errors)
    return selected, starts, tomorrow


def prepare(year, fleet, raw_utc, raw_actual, plant, alpha):
    file = PROJECT / "tier2b-capacity-stability-20261124" / f"a-input-{year}.npz"
    with np.load(file) as archived:
        utc, actual, path, signal = (archived[k] for k in ("utc", "actual", "path", "signal"))
    assert path.shape[1:] == (24, 3)
    assert np.all(np.diff(utc) == SLOT_SECONDS) and utc[0] % 86400 == 0
    nd = len(utc) // SLOTS
    origins = utc[::SLOTS]
    leads = np.arange(DAYS * SLOTS) * SLOT_SECONDS
    dates = origins[:, None, None] + leads[None, :, None] - np.arange(1, 5)[None, None, :] * 7 * 86400
    assert np.all(dates < origins[:, None, None])
    indices = np.searchsorted(raw_utc, dates)
    np.testing.assert_array_equal(raw_utc[indices], dates)
    forecast = raw_actual[indices].mean(axis=2)
    forecast[:, :24, :] = path[::SLOTS, :, :]
    p, g, d = (forecast[:, :, i].reshape(-1, SLOTS) for i in range(3))
    forecast_site = replace(plant, p=p, G=np.maximum(g, 0), D=np.maximum(d, 0))
    value = value_table(forecast_site, "A", alpha, fleet, 10_000).reshape(nd, DAYS, fleet + 1)
    online, starts, planned_tomorrow = choose(value, fleet)
    np.savez_compressed(HERE / f"inputs-{year}.npz", utc=utc, actual=actual, path=path, signal=signal,
                        online=online, starts=starts, planned_tomorrow=planned_tomorrow,
                        fleet=fleet, load_floor=alpha, module_slot_mwh=plant.e)
    print(f"{year}: {nd} days, forecast commitment average {online.mean():.3f}/{fleet}, "
          f"{starts.sum()} starts, {int(np.count_nonzero(online))} days online", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fleet", required=True, type=int)
    parser.add_argument("--load-floor", default=.2, type=float)
    args = parser.parse_args()
    with np.load(PROJECT / "tier2b-six-fold-20261123/panels.npz") as panel:
        raw_utc, raw_actual = (panel[k] for k in ("history_utc", "history_actual"))
    assert raw_actual.shape == (len(raw_utc), 3)
    plant = load(PROJECT / "tier1-halfhour-20261113-v7")
    for year in range(2021, 2027):
        prepare(year, args.fleet, raw_utc, raw_actual, plant, args.load_floor)


if __name__ == "__main__":
    main()
