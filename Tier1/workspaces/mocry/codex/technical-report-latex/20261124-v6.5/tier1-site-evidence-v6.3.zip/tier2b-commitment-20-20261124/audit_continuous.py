"""Check the continuous Bellman optimiser against Xpress and small enumerations."""

from itertools import product

import numpy as np

from replay import E, H_DAILY, LEADS, P, read, path_limits
from continuous import HERE, KNOT_LIMIT, optimal_order
from xpress_replay import cash_for_orders, solve
from replay import write_rows


def main():
    random = np.random.default_rng(20261124)
    ws = np.empty((4, 2, KNOT_LIMIT))
    rows = []
    short_count = 0
    for year in range(2021, 2027):
        data = read(year)
        path = data["path"].astype(float)
        signal = data["signal"].astype(float)
        unit = float(data["module_slot_mwh"])
        alpha = float(data["load_floor"])
        for blocks in (1, 7, 12, 45):
            capacity, power = E * blocks, P * blocks
            for sample, index in enumerate(random.choice(len(path)-LEADS, 8, replace=False)):
                stock = capacity * random.uniform()
                budget = power * random.uniform(0, 1.5)
                remaining = H_DAILY * (1 - .8 * (index % 48) / 48)
                lower, upper = np.empty(LEADS), np.empty(LEADS)
                path_limits(index, remaining, path, data["online"], data["planned_tomorrow"], unit, alpha,
                            lower, upper, LEADS)
                yhat = path[index]
                signals = yhat[:, 0].copy()
                signals[0] = signal[index]
                dp_order, dp_value = optimal_order(yhat, signals, lower, upper, stock, capacity, power, budget, ws)
                x_order, x_value, x_gap, status = solve(yhat, signals, lower, upper, stock, capacity, power, budget, .85)
                assert x_value - .025 <= dp_value <= x_value + x_gap + .025, (year, blocks, index, dp_value, x_value, x_gap)
                if sample < 2:
                    actions = np.linspace(-power, power, 5)
                    brute = max(cash_for_orders(np.array(orders), yhat[:4], signals[:4], lower[:4], upper[:4],
                                                stock, capacity, budget)
                                for orders in product(actions, repeat=4))
                    _, exact = optimal_order(yhat[:4], signals[:4], lower[:4], upper[:4], stock, capacity, power, budget, ws)
                    np.testing.assert_allclose(exact, brute, rtol=0., atol=.00005)
                    short_count += 1
                rows.append(dict(year=year, blocks=blocks, slot=int(index), stock_mwh=stock, dp_order=dp_order,
                                 xpress_order=x_order, dp_value_GBP=dp_value, xpress_value_GBP=x_value,
                                 xpress_gap_GBP=x_gap, status=status))
        print(year, "continuous/Xpress comparisons", len(rows), flush=True)
    write_rows(HERE / "continuous-xpress-audit.csv", rows)
    print("Completed", len(rows), "Xpress comparisons and", short_count, "enumerations.")


if __name__ == "__main__":
    main()
