"""Build the figures and model checks for the 12.5% report candidate."""

import csv
import json
from pathlib import Path
import sys

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent
sys.path.insert(0, str(PROJECT / "tier1-commitment-20-20261124"))
from run_a import site_inputs, solve_case, value_table
from verify import dynamic_commitment, xpress_chunk

FLOOR = .125
DAYS = 4
CAP = 10_000
FIGURES = HERE / "report/figures"


def write_json(name, payload):
    (HERE / name).write_text(json.dumps(payload, indent=2, default=lambda v: v.item()) + "\n", encoding="utf-8")


def export_csv(name, rows):
    with (HERE / name).open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def durations(mask):
    boundaries = np.flatnonzero(np.diff(np.r_[False, mask.ravel(), False]))
    return (boundaries[1::2] - boundaries[::2]) / 2


def surplus_figure(site):
    surplus = np.maximum(site.G - site.D, 0)
    months = pd.to_datetime(site.dates).month
    seasons = (("Winter", (12, 1, 2), "#31515f", "-"), ("Spring", (3, 4, 5), "#797474", "--"),
               ("Summer", (6, 7, 8), "#397783", "-."), ("Autumn", (9, 10, 11), "#624862", ":"))
    fig, (a, b) = plt.subplots(1, 2, figsize=(6.28, 1.9))
    half_hours = np.arange(48) / 2
    seasonal_means = {"utc_hour": half_hours}
    for label, period, colour, style in seasons:
        mean = surplus[np.isin(months, period)].mean(axis=0) / 1000
        seasonal_means[f"{label}_GWh_per_slot"] = mean
        a.plot(half_hours, mean, lw=1.25, label=label, color=colour, ls=style)
    pd.DataFrame(seasonal_means).to_csv(HERE / "seasonal-surplus.csv", index=False)
    a.set(xlim=(0, 24), xticks=(0, 6, 12, 18, 24), ylim=(0, 1.58), yticks=(0, .5, 1, 1.5),
          xlabel="Half-hour start (UTC)", ylabel="Mean surplus (GWh/half-hour)")
    a.legend(loc="upper left", bbox_to_anchor=(0.0, 1.155), ncol=4, fontsize=6.65,
             columnspacing=.78, handlelength=1.25, handletextpad=.35, frameon=False, borderaxespad=0)
    runs = durations(surplus >= FLOOR * site.e)
    brief_runs = durations(surplus >= .2 * site.e)
    thresholds = np.unique(runs)
    counts = np.array([(runs >= h).sum() for h in thresholds])
    b.step(thresholds, counts, where="pre", lw=1.15, color="#31515f")
    b.scatter([runs.max()], [counts[-1]], color="#31515f", s=11, zorder=3)
    b.annotate(f"Longest: {runs.max():g} h", (runs.max(), counts[-1]), xytext=(8, 8),
               textcoords="offset points", fontsize=7.2, va="bottom", ha="left")
    b.axvline(96, color="#805450", ls="--", lw=1)
    b.text(94, counts.max() * .63, "96 h minimum", color="#694340", va="top", ha="right", fontsize=7.1)
    b.set(yscale="log", ylim=(.75, 1.4 * counts.max()), xlim=(0, 102), xticks=(0, 24, 48, 72, 96),
          xlabel="Consecutive hours", ylabel="Spells at least this long")
    for ax in (a, b):
        ax.grid(axis="y", color=".88", lw=.55)
        ax.spines[["top", "right"]].set_visible(False)
    fig.subplots_adjust(left=.092, right=.992, bottom=.245, top=.84, wspace=.36)
    fig.savefig(FIGURES / "surplus-and-duration.pdf")
    plt.close(fig)
    write_json("surplus-spells.json", {
        "sample_days": site.nd,
        "positive_surplus_share": float((surplus > 0.).mean()),
        "annual_halfhour_surplus_GWh": float(surplus.sum() / 1000 / site.years_equiv),
        "annual_daily_surplus_GWh": float(np.maximum((site.G-site.D).sum(1), 0).sum() / 1000 / site.years_equiv),
        "longest_12_5_pct_h": float(runs.max()), "longest_20_pct_h": float(brief_runs.max()),
        "number_of_spells_12_5_pct": len(runs), "number_of_spells_20_pct": len(brief_runs),
        "assumed_run_h": 96,
    })
    export_csv("surplus-spell-counts.csv", [dict(min_hours=h, count=n) for h, n in zip(thresholds, counts)])


def annual_figure():
    source = PROJECT / "project-report-20261124-v6.2/main-schedule-summary.json"
    data = json.loads(source.read_bytes())
    fig, axes = plt.subplots(1, 2, figsize=(6.28, 1.88), sharex=True)
    for ax, policy, label, limits in zip(axes, ("A", "B"), ("A. Economic dispatch", "B. Supply priority"),
                                         ((-52, 440), (-31, 90))):
        values = data[policy]["net_mGBP_by_year"]
        years = np.array([int(y) for y in values])
        gain = np.array(list(values.values()))
        mean = float(gain.mean())
        ax.bar(years, gain, width=.58, color=np.where(gain >= 0, "#326776", "#8e6668"), zorder=2)
        ax.axhline(0., lw=.73, color="#545454")
        ax.axhline(mean, lw=.7, color="#545454", ls="--")
        ax.set(title=label, ylabel="Net gain (£m)", ylim=limits,
               xticks=years, xticklabels=[str(y)[-2:] for y in years])
        ax.spines[["top", "right"]].set_visible(False)
        ax.grid(axis="y", color=".9", lw=.55)
    fig.subplots_adjust(left=.08, right=.99, bottom=.25, top=.83, wspace=.31)
    fig.supxlabel("Calendar year", x=.53, y=.06, fontsize=8.5)
    fig.savefig(FIGURES / "annual-net.pdf")
    plt.close(fig)


def price_sweep(site):
    rows = []
    max_counts = int(CAP * site.kwh_per_kg / 1000 / (FLOOR * site.e * 48))
    for price in (2.5, 5., site.netback, 9.5):
        case = site.with_netback(price)
        values = value_table(case, "A", FLOOR, max_counts, CAP)
        unconstrained_by_day = np.maximum.accumulate(values, axis=1).sum(axis=0)
        bounds = unconstrained_by_day / case.years_equiv - np.arange(max_counts+1)*case.annual
        incumbent, best_count = 0., 0
        for count in np.argsort(-bounds):
            if bounds[count] <= incumbent + .01:
                break
            annual = dynamic_commitment(values[:, :count+1]) / case.years_equiv - int(count)*case.annual
            if annual > incumbent + .01:
                incumbent, best_count = float(annual), int(count)
        rows.append(dict(hydrogen_GBP_per_kg=price, modules=best_count, annual_net_mGBP=incumbent/1e6))
    export_csv("four-day-hydrogen-price.csv", rows)
    return rows


def replay_xpress(site):
    finance, online, _ = solve_case(site, "A", FLOOR, 7, DAYS, CAP)
    values = value_table(site, "A", FLOOR, 7, CAP)
    starts = np.maximum(0, np.diff(np.r_[0, online]))
    exact = dynamic_commitment(values)
    np.testing.assert_allclose(exact, values[np.arange(len(values)), online].sum(), atol=.02, rtol=0.)
    chunks = [xpress_chunk(values, online, starts, start, min(start+320, len(online)))
              for start in range(0, len(online), 320)]
    xpress = sum(x["operating_gain_gbp"] for x in chunks)
    np.testing.assert_allclose(exact, xpress, atol=.05, rtol=0.)
    write_json("A-seven-module-xpress.json", {"floor": FLOOR, "modules": 7, "gross_over_horizon_GBP": exact,
                                          "fixed_boundary_xpress_GBP": xpress, "chunks": chunks})
    return finance["net_m"]


def main():
    mpl.rcParams.update({"font.family": "DejaVu Serif", "font.size": 8.3, "pdf.fonttype": 42})
    site, _, _ = site_inputs()
    surplus_figure(site)
    annual_figure()
    print((HERE / "surplus-spells.json").read_text(), flush=True)
    rows = price_sweep(site)
    value = replay_xpress(site)
    np.testing.assert_allclose(rows[2]["annual_net_mGBP"], value, atol=1e-7, rtol=0.)
    print(rows, flush=True)
    print("Xpress seven-module reproduction complete", flush=True)


if __name__ == "__main__":
    main()
