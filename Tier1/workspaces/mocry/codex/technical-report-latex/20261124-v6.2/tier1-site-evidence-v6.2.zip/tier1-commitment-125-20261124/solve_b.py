"""Bound hydrogen value under strict supply priority and resize the battery."""

import argparse
import json
import sys

import numpy as np
import pandas as pd

from solve_a import CAP_KG, HERE, MIN_DAYS, MIN_LOAD, PROJECT, SLOTS, inputs

sys.path.insert(0, str(PROJECT / "priority-investment-20261116-v4"))
from compact_b import Problem


def hydrogen_bound(site, battery, blocks):
    """Optimistic all-possible midnight starts at one module's minimum load."""
    power = battery["P_MW"] / 2 * blocks
    capacity = battery["usable"] * 1000 * blocks
    eta = battery["eta"]
    gap = (site.G - site.D).ravel()
    stock_upper = np.zeros(len(gap) + 1)
    for t, gap_t in enumerate(gap):
        previous = stock_upper[t]
        if gap_t >= 0:
            stock_upper[t + 1] = min(capacity, previous + min(power, gap_t) * eta)
        else:
            stock_upper[t + 1] = max(0., previous - min(power, -gap_t) / eta)

    n_start = site.nd - MIN_DAYS + 1
    stock = stock_upper[::SLOTS][:n_start].copy()
    midnight = np.arange(n_start) * SLOTS
    eligible = np.ones(n_start, dtype=bool)
    for slot in range(MIN_DAYS * SLOTS):
        after_minimum = gap[midnight + slot] - MIN_LOAD * site.e
        need = np.maximum(-after_minimum, 0.)
        eligible &= (need <= power + 1e-8) & (need <= stock * eta + 1e-8)
        charge = np.minimum(np.maximum(after_minimum, 0.), power)
        stock = np.clip(stock + charge * eta - need / eta, 0., capacity)

    days = np.convolve(eligible.astype(int), np.ones(MIN_DAYS, dtype=int)) > 0
    assert len(days) == site.nd
    revenue_per_unit_m = days.sum() * 24 * site.kg_per_hour * site.netback / (site.years_equiv * 1e6)
    return dict(batteries_at_upper=blocks, eligible_starts=int(eligible.sum()), covered_days=int(days.sum()),
                annual_hydrogen_receipts_per_unit_upper_mGBP=revenue_per_unit_m)


def inputs_b():
    site, battery, hydrogen = inputs()
    source = PROJECT / "storage-exploration-20261116-v2/utility4h/configuration.json"
    config = json.loads(source.read_bytes())
    config["cap_kg_day"] = CAP_KG
    config["electrolysers"] = [h for h in config["electrolysers"] if h["id"] == "itm-neptune-v"]
    g, d, price = site.G.ravel() / 1000, site.D.ravel() / 1000, site.p.ravel()
    frame = pd.DataFrame(dict(date=np.repeat(site.dates, SLOTS), g=g, d=d, price=price))
    positive = np.maximum(price, 0.)
    ranked = np.argsort(-positive)
    demand = np.maximum(d - g, 0.)[ranked]
    pool = np.maximum(g - d, 0.).sum() * battery["eta"]**2
    before = np.r_[0., np.cumsum(demand)[:-1]]
    pooled = np.dot(np.clip(pool - before, 0., demand), positive[ranked]) / (1000 * site.years_equiv)
    absolute = pooled + site.nd * CAP_KG * site.netback / (site.years_equiv * 1e6)
    maximum = int(absolute // battery["annual"])
    folder = PROJECT / "tier1-site-battery-20261122/joint"
    large = json.loads((folder / "B_bound_71_174_0_223.json").read_bytes())
    assert maximum <= large["battery_interval"][1] and large["upper_mGBP"] < 0.
    assert large["h2_interval"][1] >= int(CAP_KG * hydrogen["kWh_kg"] / (MIN_LOAD * hydrogen["MW"] * 24 * 1000))
    return site, battery, hydrogen, frame, config, maximum


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--range", type=int, nargs=2, default=(0, 70))
    parser.add_argument("--seconds", type=float, default=180)
    args = parser.parse_args()
    lo, hi = args.range
    assert 0 <= lo <= hi <= 70
    site, battery, hydrogen, frame, config, maximum = inputs_b()
    if lo == 0:
        proof = hydrogen_bound(site, battery, 70)
        assert proof["annual_hydrogen_receipts_per_unit_upper_mGBP"] < hydrogen["annual"]
        proof.update(absolute_economic_max_blocks=maximum, unit_annual_cost_mGBP=hydrogen["annual"])
        (HERE / "B-hydrogen-bound.json").write_text(json.dumps(proof, indent=2), encoding="utf-8")
        print("B hydrogen bound", proof, flush=True)

    label = f"B-{lo}-{hi}"
    job = Problem(frame, config, HERE, label, hi, 0, nbmin=lo, strict=True,
                  integer=True, seconds=args.seconds, years=site.years_equiv)
    solver = job.solver
    solver.setOptionValue("threads", 2)
    solver.setOptionValue("mip_rel_gap", 1e-7)
    solver.setOptionValue("mip_abs_gap", 1e-6)
    # With no stored energy, the mandatory discharge is always zero. HiGHS
    # completes the priority indicator values before using the seed.
    keep = np.r_[job.n, job.nh, job.zero].astype(np.int32)
    solver.setSolution(len(keep), keep, np.array([lo, 0., 0.]))
    value = job.run()
    n = int(round(job.x[job.n]))
    charge, sale, stock = (job.x[ix] for ix in (job.c, job.r, job.s))
    prev = np.r_[0., stock[:-1]]
    eta = battery["eta"]
    errors = (np.max(np.abs(sale - np.minimum(np.minimum(job.deficit, n * job.P), prev * eta))),
              np.max(np.abs(stock - prev - eta * charge + sale / eta)), np.max(charge - job.surplus),
              np.max(charge - n * job.P), np.max(stock - n * battery["usable"]), abs(stock[-1]),
              np.max(np.minimum(charge, sale)), np.max(-np.array([charge, sale, stock])))
    assert max(errors) < 2e-7, errors
    for year in np.unique(site.year):
        mask = site.year == year
        assert sale.reshape(-1, SLOTS)[mask].sum() / eta <= mask.sum() * battery["E_MWh"] * n / 1000 + .002
    net = np.dot(sale, frame.price) / (1000 * site.years_equiv) - n * battery["annual"]
    np.testing.assert_allclose(net, value, rtol=0, atol=1e-7)
    payload = dict(interval=[lo, hi], battery_blocks=n, electrolyser_units=0,
                   annual_net_mGBP=net, upper_mGBP=job.upper, status=job.status)
    np.savez_compressed(HERE / f"{label}.npz", charge=charge, sale=sale, stock=stock)
    (HERE / f"{label}.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(json.dumps(payload), flush=True)


if __name__ == "__main__":
    main()
