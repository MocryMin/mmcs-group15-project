"""Find feasible committed plans using the archived battery dispatch as a starting point."""

from dataclasses import replace
import json

import numpy as np

from solve_a import CAP_KG, HERE, MIN_DAYS, MIN_LOAD, PROJECT, SLOTS, inputs
from site_model import reference, solve_case


JOINT = PROJECT / "tier1-site-battery-20261122/joint"


def operating_upper():
    blocks, units = np.ogrid[:412, :38]
    upper = np.full((412, 38), np.inf)
    for source in JOINT.glob("A_n*_h*.json"):
        row = json.loads(source.read_bytes())
        plane = row.get("supporting_plane_mGBP")
        if plane:
            b, h = plane["at"]
            gb, gh = plane["gradient"]
            support = plane["value"] + gb * (blocks - b) + gh * (units - h)
            if plane["scope"] == "all capacities":
                upper = np.minimum(upper, support)
            else:
                upper[b] = np.minimum(upper[b], support[b])
        b, h = row["battery_blocks"], row["electrolyser_units"]
        if h < upper.shape[1]:
            upper[b, h] = min(upper[b, h], row["fixed_configuration_upper_mGBP"])
    return upper


def witness(site, battery, product, blocks, units, charge, discharge):
    total_output = site.G.ravel() + discharge - charge
    assert total_output.min() >= -1e-6
    adjusted = replace(site, G=np.maximum(total_output, 0.).reshape(-1, SLOTS))
    result, online, plan = solve_case(adjusted, "A", MIN_LOAD, units, MIN_DAYS, CAP_KG)
    hydrogen = plan["h"].ravel()
    sales = (reference(adjusted, "A")["q"] - plan["paid"]).ravel()
    used = np.minimum(discharge, sales + hydrogen)
    eta = battery["eta"]
    stock = np.empty(len(charge))
    final = 0.
    draws = np.empty_like(charge)
    for t in range(len(charge) - 1, -1, -1):
        stock[t] = final
        required = final + used[t] / eta
        previous = max(0., required - eta * charge[t])
        draws[t] = (required - previous) / eta
        final = previous
    tol = .0002
    assert final < tol and abs(stock[-1]) < tol
    assert np.max(draws - charge) < tol and np.max(used - discharge) < tol
    assert np.max(sales + hydrogen + draws - used - site.G.ravel()) < tol
    assert np.max(stock - blocks * battery["usable"] * 1000) < tol
    assert max(draws.max(), used.max()) <= .5 * blocks * battery["P_MW"] + tol
    assert np.max(np.minimum(draws, used)) < tol
    assert np.max(sales - site.D.ravel()) < tol and min(sales.min(), hydrogen.min()) >= -tol
    assert result["path_problems"] == 0
    for year in np.unique(site.year):
        days = site.year == year
        assert used.reshape(-1, SLOTS)[days].sum() / eta <= days.sum() * blocks * battery["E_MWh"] + 2.
    annual_cash = (np.dot(sales, site.p.ravel()) + hydrogen.sum() * site.w) / site.years_equiv
    net = (annual_cash - reference(site, "A")["receipts"]) / 1e6
    net -= blocks * battery["annual"] + units * product["annual"]
    return dict(battery_blocks=blocks, electrolyser_units=units, annual_net_mGBP=net), (sales, draws, used, stock, hydrogen, online)


def main():
    site, battery, product = inputs()
    upper = operating_upper()
    sources = {}
    for file in JOINT.glob("A_n*_h*_dispatch.npz"):
        n, h = (int(v[1:]) for v in file.name.split("_")[1:3])
        if 36 <= n <= 58:
            with np.load(file) as saved:
                _, c, r, rh, _, _ = saved["flows"] * 1000
            sources[(n, h)] = (c, r + rh)
    priority = [(45, 6), (46, 6), (43, 7), (44, 6), (45, 5)]
    ordered = sorted(map(tuple, np.argwhere(upper > 117.)), key=lambda c: upper[c], reverse=True)
    ordered = priority + [pair for pair in ordered if pair not in priority]
    records, best = [], None
    for n, h in ordered:
        if best is not None and upper[n, h] <= best["annual_net_mGBP"]:
            continue
        source_n, source_h = min(sources, key=lambda key: (abs(key[0]-n), abs(key[1]-h)))
        scale = min(1., n / source_n)
        c, u = sources[(source_n, source_h)]
        result, witness_path = witness(site, battery, product, int(n), int(h), c * scale, u * scale)
        records.append(dict(**result, old_relaxed_upper_mGBP=upper[n, h], source=[source_n, source_h]))
        print(records[-1], flush=True)
        if best is None or result["annual_net_mGBP"] > best["annual_net_mGBP"]:
            best = result
            np.savez_compressed(HERE / "A-best-witness.npz", battery_blocks=n, electrolyser_units=h,
                                sales=witness_path[0], charge=witness_path[1], discharge=witness_path[2],
                                stock=witness_path[3], hydrogen=witness_path[4], online=witness_path[5])
        (HERE / "A-committed-witnesses.json").write_text(json.dumps(records, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
