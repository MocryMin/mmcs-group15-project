"""Joint historical sizing with a day-boundary electrolyser commitment."""

import argparse
import json
from pathlib import Path
import sys
from tempfile import gettempdir

import highspy
import numpy as np


HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent
JULIAN = PROJECT / "group-collaboration/Tier1/workspaces/julian/claude/tier1-main-results/20261123-v1"
sys.path.insert(0, str(PROJECT / "storage-investment-20261116-v3"))
sys.path.insert(0, str(JULIAN))
from investment_model import Matrix, annual_costs
from site_model import check_path, commit, load, solve_case, value_table


MIN_LOAD = .125
MIN_DAYS = 4
CAP_KG = 10_000
SLOTS = 48


def inputs():
    site = load(PROJECT / "tier1-halfhour-20261113-v7")
    folder = PROJECT / "storage-exploration-20261116-v2/utility4h"
    config = json.loads((folder / "configuration.json").read_bytes())
    batteries, hydrogen = annual_costs(config)
    unit = next(h for h in hydrogen if h["id"] == "itm-neptune-v")
    assert len(batteries) == 1 and unit["minimum"] == MIN_LOAD
    assert unit["variable_GBP_kg"] == 0 and np.isclose(unit["annual"] * 1e6, site.annual)
    return site, batteries[0], unit


def commitment_rows(matrix, installed, online, starts, days):
    matrix.rows(days, [(online, 1), (installed, -1)], hi=0)
    matrix.rows(1, [(online[0], 1), (starts[0], -1)], hi=0)
    matrix.rows(days - 1, [(online[1:], 1), (online[:-1], -1), (starts[1:], -1)], hi=0)
    for day in range(days):
        recent = starts[max(0, day + 1 - MIN_DAYS):day + 1]
        matrix.rows(1, [(ix, 1) for ix in recent] + [(online[day], -1)], hi=0)


def load_matrix(matrix):
    coefficients = matrix.sparse()
    lp = highspy.HighsLp()
    lp.num_col_ = matrix.n
    lp.num_row_ = matrix.nr
    lp.col_cost_ = np.concatenate(matrix.cost)
    lp.col_lower_ = np.concatenate(matrix.lb)
    lp.col_upper_ = np.concatenate(matrix.ub)
    lp.row_lower_ = np.concatenate(matrix.rl)
    lp.row_upper_ = np.concatenate(matrix.ru)
    lp.a_matrix_.format_ = highspy.MatrixFormat.kColwise
    lp.a_matrix_.start_ = coefficients.indptr
    lp.a_matrix_.index_ = coefficients.indices
    lp.a_matrix_.value_ = coefficients.data
    return lp


class EconomicSizing:
    def __init__(self, site, battery, product, seconds, threads, label):
        self.site, self.battery, self.product = site, battery, product
        self.eta, self.power = battery["eta"], battery["P_MW"] / 2000
        assert battery["retention"] == 1
        g, d, price = (series.ravel() / scale for series, scale in ((site.G, 1000), (site.D, 1000), (site.p, 1)))
        self.g, self.d, self.price = g, d, price
        self.reference = np.dot(price, np.minimum(g, d) * (price >= 0)) / (1000 * site.years_equiv)
        revenue_upper = (np.dot(np.maximum(price, 0), d) / 1000 + CAP_KG * site.nd * site.netback / 1e6) / site.years_equiv
        self.max_blocks = int((revenue_upper - self.reference) // battery["annual"])
        self.day_cap = CAP_KG * product["kWh_kg"] / 1e6
        unit_load = product["unit_GWh"]
        self.max_units = int(self.day_cap // (MIN_LOAD * unit_load * SLOTS))
        eta, power = self.eta, self.power
        m = Matrix()
        self.nb = m.variables(hi=self.max_blocks, c=battery["annual"])
        self.nh = m.variables(hi=self.max_units, c=product["annual"])
        self.online = m.variables(site.nd, hi=self.max_units)
        start_upper = np.r_[np.full(site.nd + 1 - MIN_DAYS, self.max_units), np.zeros(MIN_DAYS - 1)]
        self.starts = m.variables(site.nd, hi=start_upper)
        T = len(g)
        self.sales = sales = m.variables(T, hi=d, c=-price / (1000 * site.years_equiv))
        self.charge = charge = m.variables(T, hi=np.minimum(g, self.max_blocks * power))
        self.discharge = discharge = m.variables(T, hi=self.max_blocks * power)
        self.stock = stock = m.variables(T, hi=np.r_[np.full(T-1, self.max_blocks * battery["usable"]), 0.])
        self.hydrogen = hydrogen = m.variables(T, hi=unit_load * self.max_units, c=-site.w / (1000 * site.years_equiv))
        day_online = np.repeat(self.online, SLOTS)
        commitment_rows(m, self.nh, self.online, self.starts, site.nd)
        m.rows(T, [(hydrogen, 1), (day_online, -unit_load)], hi=0)
        m.rows(T, [(hydrogen, 1), (day_online, -MIN_LOAD * unit_load)], lo=0)
        m.rows(T, [(sales, 1), (hydrogen, 1), (charge, 1), (discharge, -1)], hi=g)
        m.rows(T, [(discharge, 1), (sales, -1), (hydrogen, -1)], hi=0)
        m.rows(T, [(charge, 1), (self.nb, -power)], hi=0)
        m.rows(T, [(discharge, 1), (self.nb, -power)], hi=0)
        m.rows(T - 1, [(stock[:-1], 1), (self.nb, -battery["usable"])], hi=0)
        m.rows(1, [(stock[0], 1), (charge[0], -eta), (discharge[0], 1/eta)], 0, 0)
        m.rows(T - 1, [(stock[1:], 1), (stock[:-1], -1), (charge[1:], -eta), (discharge[1:], 1/eta)], 0, 0)
        hydrogen_by_day = hydrogen.reshape(-1, SLOTS)
        m.rows(site.nd, [(hydrogen_by_day[:, slot], 1) for slot in range(SLOTS)], hi=self.day_cap)
        for year in np.unique(site.year):
            rows = np.repeat(site.year == year, SLOTS)
            energy = (rows.sum() // SLOTS) * battery["E_MWh"] / 1000
            row = m.nr
            m.nr += 1
            m.rr.append(np.full(rows.sum() + 1, row, dtype=np.int32))
            m.cc.append(np.r_[discharge[rows], self.nb])
            m.val.append(np.r_[np.full(rows.sum(), 1/eta), -energy])
            m.rl.append(np.array([-np.inf]))
            m.ru.append(np.array([0.]))
        lp = load_matrix(m)
        lp.offset_ = self.reference
        print("A matrix", lp.num_col_, lp.num_row_, "integer search box", self.max_blocks, self.max_units, flush=True)
        self.cost = np.asarray(lp.col_cost_)
        self.solver = solver = highspy.Highs()
        solver.setOptionValue("threads", threads)
        solver.setOptionValue("time_limit", seconds)
        solver.setOptionValue("log_to_console", False)
        solver.setOptionValue("log_file", str(Path(gettempdir()) / f"mmcs-commitment-A-{label}.log"))
        solver.setOptionValue("solver", "simplex")
        solver.setOptionValue("mip_rel_gap", 1e-7)
        solver.passModel(lp)

    def run(self):
        self.solver.run()
        sol = self.solver.getSolution()
        status = self.solver.getModelStatus()
        if not sol.value_valid:
            raise RuntimeError(f"A solve found no feasible solution: {status}")
        return np.asarray(sol.col_value), status

    def pin(self, blocks, units, online=None):
        self.solver.changeColBounds(self.nb, blocks, blocks)
        self.solver.changeColBounds(self.nh, units, units)
        if online is not None:
            self.solver.changeColsBounds(len(online), self.online, online, online)

    def load_warm(self, path):
        with np.load(path) as warm:
            if "solution" in warm:
                return warm["solution"]
            x = np.zeros(len(self.cost))
            x[self.nb], x[self.nh] = warm["battery_blocks"].item(), warm["electrolyser_units"].item()
            online = warm["online"]
            x[self.online] = online
            x[self.starts] = np.maximum(0., np.diff(np.r_[0., online]))
            for indices, field in ((self.sales, "sales"), (self.charge, "charge"),
                                   (self.discharge, "discharge"), (self.stock, "stock"), (self.hydrogen, "hydrogen")):
                x[indices] = warm[field] / 1000
        return x

    def audit(self, x, label):
        q, c, u, stock, h = (x[i].copy() for i in (self.sales, self.charge, self.discharge, self.stock, self.hydrogen))
        eta = self.eta
        # Cancelling opposing flows leaves AC deliveries and stock unchanged.
        overlap = np.minimum(c * eta**2, u)
        c -= overlap / eta**2
        u -= overlap
        blocks, units = map(lambda i: int(round(x[i])), (self.nb, self.nh))
        np.testing.assert_allclose([x[self.nb], x[self.nh]], [blocks, units], atol=1e-6, rtol=0.)
        path = np.rint(x[self.online]).astype(int)
        np.testing.assert_allclose(path, x[self.online], atol=1e-6, rtol=0.)
        feasible = np.ones((len(path), units + 1), dtype=bool)
        assert path.min() >= 0 and path.max() <= units and not check_path(path, MIN_DAYS, feasible)
        minimum = np.repeat(path * MIN_LOAD * self.product["unit_GWh"], SLOTS)
        maximum = minimum / MIN_LOAD
        prev = np.r_[0, stock[:-1]]
        tol = 2e-7
        errors = (np.max(q + h + c - u - self.g), np.max(q - self.d), np.max(u - q - h),
                  np.max(c - blocks * self.power), np.max(u - blocks * self.power),
                  np.max(stock - blocks * self.battery["usable"]), abs(stock[-1]),
                  np.max(np.abs(stock - prev - eta*c + u/eta)), np.max(np.minimum(c, u)),
                  np.max(minimum - h), np.max(h - maximum),
                  np.max(h.reshape(-1, SLOTS).sum(axis=1) - self.day_cap),
                  np.max(-np.array([q, c, u, stock, h])))
        assert max(errors) < tol, errors
        for year in np.unique(self.site.year):
            mask = self.site.year == year
            assert u.reshape(-1, SLOTS)[mask].sum() / eta <= mask.sum() * self.battery["E_MWh"] * blocks / 1000 + .002
        net = (np.dot(q, self.price) + h.sum() * self.site.w) / (1000 * self.site.years_equiv)
        net -= self.reference + blocks * self.battery["annual"] + units * self.product["annual"]
        objective = -float(np.dot(self.cost, x) + self.reference)
        np.testing.assert_allclose(net, objective, atol=1e-7, rtol=0.)
        np.savez_compressed(HERE / f"A-{label}.npz", solution=x, sales=q, charge=c, discharge=u,
                            stock=stock, hydrogen=h, online=path)
        return dict(battery_blocks=blocks, electrolyser_units=units, annual_net_mGBP=net)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seconds", type=float, default=180)
    parser.add_argument("--threads", type=int, default=4)
    parser.add_argument("--fixed", type=int, nargs=2)
    parser.add_argument("--electrolysis-only", action="store_true")
    parser.add_argument("--mip", action="store_true")
    parser.add_argument("--relax-only", action="store_true")
    parser.add_argument("--warm", type=Path)
    args = parser.parse_args()
    site, battery, product = inputs()
    if args.electrolysis_only:
        max_units = int(CAP_KG * product["kWh_kg"] / (MIN_LOAD * product["MW"] * 24 * 1000))
        values = value_table(site, "A", MIN_LOAD, max_units, CAP_KG)
        best, outcomes = 0., []
        scan_order = [7, *[n for n in range(max_units + 1) if n != 7]]
        for units in scan_order:
            upper = np.max(values[:, :units + 1], axis=1).sum() / (site.years_equiv * 1e6) - product["annual"] * units
            if upper + 1e-8 < best:
                outcomes.append(dict(electrolyser_units=units, upper_mGBP=upper, screened=True))
                continue
            outcome, _, _ = solve_case(site, "A", MIN_LOAD, units, MIN_DAYS, CAP_KG)
            best = max(best, outcome["net_m"])
            outcomes.append(dict(electrolyser_units=units, annual_net_mGBP=outcome["net_m"],
                                 upper_mGBP=outcome["net_m"] + outcome["bound_gap_gbp_per_year"] / 1e6,
                                 screened=False))
        (HERE / "A-electrolysis-only.json").write_text(json.dumps(outcomes, indent=2), encoding="utf-8")
        print("A electrolysis only", best, flush=True)
        return
    label = "global" if args.fixed is None else "-".join(map(str, args.fixed))
    if args.mip:
        label += "-mip"
    job = EconomicSizing(site, battery, product, args.seconds, args.threads, label)
    if args.fixed is not None:
        job.pin(*args.fixed)
    if args.mip:
        solver = job.solver
        solver.setOptionValue("solver", "choose")
        integer = np.r_[job.nb, job.nh, job.online].astype(np.int32)
        solver.changeColsIntegrality(len(integer), integer, np.ones(len(integer), dtype=np.uint8))
        if args.warm:
            sol = highspy.HighsSolution()
            sol.col_value = job.load_warm(args.warm).tolist()
            sol.value_valid = True
            solver.setSolution(sol)
        result, status = job.run()
        payload = job.audit(result, label)
        payload.update(status=str(status), upper_mGBP=-solver.getInfo().mip_dual_bound)
    else:
        largest, status = job.run()
        bound = -float(job.solver.getObjectiveValue()) if status == highspy.HighsModelStatus.kOptimal else None
        print("A relaxation", status, float(largest[job.nb]), float(largest[job.nh]), bound, flush=True)
        if args.relax_only:
            payload = dict(status=str(status), upper_mGBP=bound, relaxed_blocks=float(largest[job.nb]),
                           relaxed_units=float(largest[job.nh]))
            (HERE / f"A-{label}-relax.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
            return
        blocks, units = args.fixed or (int(round(largest[job.nb])), int(round(largest[job.nh])))
        desired = largest[job.online]
        values = -(np.arange(units + 1)[None, :] - desired[:, None]) ** 2
        path, _ = commit(values, MIN_DAYS, time_limit=30.)
        job.pin(blocks, units, path.astype(float))
        result, status = job.run()
        payload = job.audit(result, label)
        payload.update(status=str(status), upper_mGBP=bound, relaxed_blocks=float(largest[job.nb]),
                       relaxed_units=float(largest[job.nh]))
    (HERE / f"A-{label}.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(json.dumps(payload), flush=True)


if __name__ == "__main__":
    main()
