"""Certify the battery-only strict-priority optimum with fixed-capacity replays."""

import json
import sys

import numpy as np
import pandas as pd

from solve_b import HERE, PROJECT, SLOTS, hydrogen_bound, inputs_b

sys.path.insert(0, str(PROJECT / "tier1-site-battery-20261122"))
from run_site import priority_dispatch


def battery_bounds(site, battery):
    n = np.arange(71)
    power = n * battery["P_MW"] / 2
    capacity = n * battery["usable"] * 1000
    eta = battery["eta"]
    stock, receipt = np.zeros_like(n, dtype=float), np.zeros_like(n, dtype=float)
    for gap, price in zip((site.G - site.D).ravel(), site.p.ravel()):
        if gap >= 0:
            stock = np.minimum(capacity, stock + eta * np.minimum(power, gap))
        else:
            sale = np.minimum(np.minimum(power, -gap), stock * eta)
            stock = np.maximum(0., stock - sale / eta)
            receipt += max(0., price) * sale
    return receipt / (site.years_equiv * 1e6) - n * battery["annual"]


def main():
    site, battery, hydrogen, frame, config, _ = inputs_b()
    hydrogen_proof = hydrogen_bound(site, battery, 70)
    assert hydrogen_proof["annual_hydrogen_receipts_per_unit_upper_mGBP"] < hydrogen["annual"]
    frame.index = pd.date_range(site.dates[0], periods=len(frame), freq="30min", tz="UTC")
    upper = battery_bounds(site, battery)
    tested, best = [], 0.
    for n in np.argsort(upper)[::-1]:
        if upper[n] + 1e-8 < best:
            break
        if n == 0:
            continue
        n = int(n)
        sized = dict(battery, **{key: battery[key] * n for key in ("P_MW", "E_MWh", "usable", "annual")})
        flows, proof = priority_dispatch(frame, config, sized, hydrogen, 0, n)
        q, charge, sale, to_h, stock, h = flows
        eta = battery["eta"]
        prev = np.r_[0., stock[:-1]]
        tol = 2e-7
        g, d, price = (frame[key].to_numpy() for key in ("g", "d", "price"))
        np.testing.assert_allclose(q, np.minimum(g, d), rtol=0, atol=tol)
        np.testing.assert_allclose(sale, np.minimum(np.maximum(d-g, 0.), np.minimum(n * battery["P_MW"] / 2000, prev * eta)),
                                  rtol=0, atol=tol)
        np.testing.assert_allclose(stock, prev + eta * charge - sale / eta, rtol=0, atol=tol)
        assert np.max(charge - np.minimum(np.maximum(g-d, 0.), sized["P_MW"] / 2000)) < tol
        assert stock.max() <= sized["usable"] + tol and abs(stock[-1]) < tol
        assert min(charge.min(), sale.min(), stock.min()) >= -tol and np.max(np.minimum(charge, sale)) < tol
        assert np.max(np.abs(to_h)) < tol and np.max(np.abs(h)) < tol
        for year in np.unique(site.year):
            mask = site.year == year
            assert sale.reshape(-1, SLOTS)[mask].sum() / eta <= mask.sum() * n * battery["E_MWh"] / 1000 + .002
        net = np.dot(sale, price) / (1000 * site.years_equiv) - n * battery["annual"]
        exact_bound = net + proof["upper_gap_GBP_year"] / 1e6
        upper[n] = min(upper[n], exact_bound)
        row = dict(battery_blocks=n, electrolyser_units=0, annual_net_mGBP=net, upper_mGBP=upper[n], **proof)
        tested.append(row)
        best = max(best, net)
        print(row, flush=True)
        np.savez_compressed(HERE / f"B-exact-n{n}.npz", charge=charge, sale=sale, stock=stock)
    winner = max(tested, key=lambda r: r["annual_net_mGBP"])
    alternative = np.max(np.delete(upper, winner["battery_blocks"]))
    result = dict(**winner, best_alternative_upper_mGBP=alternative,
                  capacity_certified=bool(alternative < winner["annual_net_mGBP"]), runs=tested)
    (HERE / "B-battery-certificate.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(result, flush=True)


if __name__ == "__main__":
    main()
