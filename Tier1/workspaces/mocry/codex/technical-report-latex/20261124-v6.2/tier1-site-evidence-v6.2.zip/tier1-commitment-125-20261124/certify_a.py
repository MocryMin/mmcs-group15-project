"""Check the new fixed-capacity bounds against every old relaxed capacity."""

import json
import re

import numpy as np

from economic_witness import operating_upper
from solve_a import HERE


def main():
    upper = operating_upper()
    old_upper = upper.copy()
    feasible = json.loads((HERE / "A-committed-witnesses.json").read_bytes())
    checked = []
    for path in HERE.glob("A-*-*.json"):
        name = re.fullmatch(r"A-(\d+)-(\d+)(?:-relax|-mip)?\.json", path.name)
        if name is None:
            continue
        b, h = map(int, name.groups())
        row = json.loads(path.read_bytes())
        if row.get("annual_net_mGBP") is not None:
            feasible.append(row)
        if row["upper_mGBP"] is not None and np.isfinite(row["upper_mGBP"]):
            upper[b, h] = min(upper[b, h], row["upper_mGBP"] + 2e-6)
            checked.append([b, h])
    best = max(feasible, key=lambda r: r["annual_net_mGBP"])
    n, h = best["battery_blocks"], best["electrolyser_units"]
    gain = best["annual_net_mGBP"]
    assert np.isfinite(upper).all()
    assert all(row["annual_net_mGBP"] <= upper[row["battery_blocks"], row["electrolyser_units"]] + 2e-6
               for row in feasible)
    rivals = upper.copy()
    rivals[n, h] = -np.inf
    rival_n, rival_h = np.unravel_index(np.argmax(rivals), rivals.shape)
    rivals_open = np.argwhere(rivals >= gain)
    output = dict(**best, global_upper_mGBP=float(upper.max()),
                  highest_alternative_upper_mGBP=float(rivals.max()),
                  highest_alternative=[int(rival_n), int(rival_h)],
                  capacity_certified=len(rivals_open) == 0,
                  old_screen_candidates=int((old_upper >= gain).sum()),
                  fixed_capacity_day_relaxations=checked, remaining_rivals=rivals_open.tolist())
    (HERE / "A-capacity-certificate.json").write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(json.dumps(output), flush=True)


if __name__ == "__main__":
    main()
