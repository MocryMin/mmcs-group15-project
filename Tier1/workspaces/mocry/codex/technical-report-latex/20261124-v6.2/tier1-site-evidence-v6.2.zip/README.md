# Tier 1 v6.2 evidence

Read the report and the review response together with this bundle. Values are in inflation-adjusted 2020 pounds. A positive net gain is above same-policy direct sales after annual-equivalent equipment costs. Tier 2B battery increments instead hold electrolysers fixed at the zero-battery comparator.

## Files and reproduction

- `tier1-commitment-125-20261124/` contains the commitment solver, strict B bounds, capacity certificates, the winner schedules and the next-best B schedule. The A NPZ stores GWh and per-day online counts. The B NPZ stores GWh of charge, discharged electricity and usable stock. Read `README.md` there for the capacity procedure.
- `project-report-20261124-v6.2/` contains the financial and cash reconciliation script and result JSONs. From the extracted bundle, run `python project-report-20261124-v6.2/summarise_dispatch.py` with NumPy, pandas, SciPy and highspy. It checks historical net cash against the two certificates and independently recomputes A's zero-battery plant.
- Run `python tier1-commitment-125-20261124/certify_a.py` to recalculate the A sizing certificate from the earlier supporting planes and the retained four-day replays and relaxations. `solve_a.py --fixed 45 6 --mip --warm <NPZ> --seconds <budget>` can reproduce the winning optimisation from a warm start. Use a separate extracted copy to keep the supplied schedule hashes intact.
- Run `python tier1-commitment-125-20261124/certify_b.py` with Xpress and HiGHS to repeat the B hydrogen bound, battery screening and final fixed-portfolio solves. Local solver versions or time limits can change the primal schedule within the reported tolerance.
- `tier2b-b-battery-only-20261124/`, `tier2b-capacity-stability-20261124/` and `tier2b-a-window-mip-20261123/` contain the Tier 2B ledgers relevant to the handover. They are result snapshots, with source notes and available scripts. Full forecast training dependencies are maintained with the Tier 2 work. The new pure-battery B size sweep supersedes the flexible B size comparison for that baseline.
- `MANIFEST.json` records byte counts and SHA-256 hashes for each payload file. The common 2020–26 half-hour panel and required Tier 1 code are included. The earlier flexible dispatch NPZ files used to seed A's feasible witnesses are in the [v6 evidence archive](https://github.com/MocryMin/mmcs-group15-project/blob/2f02e3e4936ac34eafae451b8ba1cacec8e41eb3/Tier1/workspaces/mocry/codex/technical-report-latex/20261123-v6/tier1-site-evidence-v6.zip) or the original study workspace.

## Earlier archive clarification

In the pinned v6 archive, `evidence/reference/results/reference_day_A_integer.json` under the working report folder carries a legacy source description for `brief-2h`. The calculation uses EUR 288,000/MWh converted to about £256,235/MWh in 2020 prices, or £51.247m for 200 MWh. Use the numeric inputs and the v6.2 report's cost basis. The archive preserves the original bytes.
