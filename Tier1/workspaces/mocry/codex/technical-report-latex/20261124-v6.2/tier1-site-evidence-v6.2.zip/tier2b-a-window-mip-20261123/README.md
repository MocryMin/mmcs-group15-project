# Tier 2B Policy A with a continuous-inventory window solver

This study uses the final annual holdout from 1 September 2025 to 31 August 2026. It fixes the 10 tonne/day hydrogen site, six NEPTUNE V units, existing forecasts for leads 1–24, and the operating and economic assumptions from the battery-size sweep. The representative battery sizes are one, seven and 45 blocks. Each controller starts with zero usable inventory above the SOC floor. The final 48 requests follow the existing discharge rule.

## Controller

For each half-hour and each feasible initial inventory, a requested action is one of full charge, half charge, idle, half discharge and full discharge. State-dependent physical clipping and the existing electricity and hydrogen allocation rule give a piecewise affine state transition and receipt for each request. The Xpress mixed-integer model selects a segment at every lead and maximises forecast cash subject to all continuous inventory transitions at once. The segment endpoints are physical thresholds. The electrolyser's discontinuous start threshold requires a small numerical separation on the open side of a boundary, at most 0.000108 MWh for the sizes studied. The initial inventory is the latest settled value. The trajectory is replayed independently against the operational rules to verify the returned objective and states. When a solve reaches the time cap, its best verified feasible plan supplies the first decision.

The original first-slot charge budget and remaining day hydrogen allowance are carried into the new controller. Forecast stages use the original forecast allocation of the hydrogen allowance to preserve comparability. The controller settles only the first requested action against actual electricity market, generation and demand values. Each receding window has a zero terminal inventory credit.

## Horizon comparison

- **12-hour grid** retains the high-resolution 960-interval controller from the battery-size sweep.
- **12-hour Xpress** keeps the same forecast and terminal rule, with continuous inventory and a joint five-request solve.
- **24-hour forecast extension** supplies the same first 12 hours and appends 12 hours of the mean from four previous matching weekdays and half-hours. All observations used for this extension precede the decision. The grid runs cover the complete test year for all three sizes. The 24-hour Xpress replay covers the first 90 days at seven blocks, as a paired slice of the annual replay without a separate liquidation rule.
- **Truth diagnostics** give the grid controller the realised path for either horizon. Both use the same five requests and settlement, with the 24-hour case revealing the extra 12 hours. These rows measure the sensitivity to a longer window given the specified information and controller.
- **Same-stock diagnostics** use 96 stratified dates each at one and seven blocks and 36 dates at 45 blocks. Both planners begin at the inventory, budget and hydrogen remainder of the original grid replay. A forced-first-action re-solve values the grid's request in the 12-hour forecast and the 12-hour request in the 24-hour forecast.

## Checks

The piecewise model reproduced the source stock transition and receipts at 28,945 sampled points. On 36 short windows with five slots, the Xpress solution matched enumeration of all 3,125 request sequences. A long-window presolve and cuts trial produced an inconsistent bound, so the comparison uses Xpress with these reductions switched off. The replay rejects inconsistent bounds and validates all reported plans against the original settlement function.

## Results

Annual net gains in millions of 2020 pounds follow. Each comparison uses the same zero-battery site and annual battery charge.

| Battery blocks | 12-hour grid | 12-hour Xpress | 24-hour grid forecast | 12-hour grid with truth | 24-hour grid with truth |
| --- | ---: | ---: | ---: | ---: | ---: |
| 1 | 0.183 | 0.824 | 0.183 | 3.163 | 3.164 |
| 7 | 0.777 | 2.033 | 0.808 | 18.195 | 18.205 |
| 45 | −23.921 | −21.256 | −9.618 | 40.767 | 46.792 |

The 12-hour annual runs performed 52,416 Xpress optimizations. Of these, 322 reached the time cap and used a checked feasible incumbent. One 45-block plan required a stricter integrality retry to pass the independent stock and cash checks. Across 228 same-stock checks, the grid and the 12-hour Xpress solver returned different first requests in 11 cases. Forcing each grid request and solving the tail returned the same forecast value within £0.025 in these cases. Subsequent realized stock paths, and hence realized earnings, can diverge even when the forecast values tie.

At seven blocks, the first 90 days produced −£1.187m with 12-hour Xpress and −£1.004m with the 24-hour extension, an increase of £0.183m. The two replays ended with the same 332.039 MWh of usable stock. At 45 blocks, the full-year 24-hour grid increased net gains by £14.302m using the forecast extension and by £6.024m under the truth diagnostic.

Run `prepare.py` and `prepare.py --truth-diagnostic` in the existing CUDA environment to build the archived forecasts and grid controls. Run `run_experiment.py BLOCKS 24 --seconds .75` for the annual Xpress controls, and `run_experiment.py 7 48 --seconds 1.25 --limit 4320` for the 90-day extension. Run `audit.py` and `summarize.py` for the comparisons. Intermediate replays store restart checkpoints every 384 slots. [Annual replay results](comparison.csv) · [Paired 90-day results](prefix-comparison.csv) · [Matched same-stock diagnostics](same-stock-audit.csv)
