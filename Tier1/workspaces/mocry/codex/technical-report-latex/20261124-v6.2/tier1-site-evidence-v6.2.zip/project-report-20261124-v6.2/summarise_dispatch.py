"""Reconcile the 2020–25 main schedules used in the Tier 1 candidate."""

import json
from pathlib import Path
import sys

import numpy as np


HERE = Path(__file__).resolve().parent
STUDY = HERE.parent / "tier1-commitment-125-20261124"
sys.path.insert(0, str(STUDY))
from solve_a import inputs, solve_case


def main():
    site, battery, plant = inputs()
    generation, demand, price = (x.ravel() for x in (site.G, site.D, site.p))
    year = np.repeat(site.year, site.G.shape[1])
    direct = np.minimum(generation, demand)
    surplus = np.maximum(generation - demand, 0)
    a = np.load(STUDY / "A-45-6.npz")
    b = np.load(STUDY / "B-exact-n9.npz")
    results = {}
    for policy, counts, array in [("A", (45, 6), a), ("B", (9, 0), b)]:
        blocks, modules = counts
        annual_cost = blocks * battery["annual"] + modules * plant["annual"]
        base = direct * (price >= 0) if policy == "A" else direct
        sale = array["sales"] * 1000 if policy == "A" else base + array["sale"] * 1000
        hydrogen = array["hydrogen"] * 1000 if policy == "A" else np.zeros_like(sale)
        revenue = (sale - base) * price + hydrogen * site.w
        net_by_year = {int(y): revenue[year == y].sum() / 1e6 - annual_cost
                       for y in np.unique(year)}
        results[policy] = {
            "battery_blocks": blocks,
            "electrolysers": modules,
            "annual_net_mGBP": sum(net_by_year.values()) / len(net_by_year),
            "annual_cost_mGBP": annual_cost,
            "annual_h2_tonnes": hydrogen.sum() / site.kwh_per_kg / site.years_equiv,
            "demand_served_pct": 100 * sale.sum() / demand.sum(),
            "base_demand_served_pct": 100 * base.sum() / demand.sum(),
            "annual_battery_charge_GWh": array["charge"].sum() / site.years_equiv,
            "annual_battery_delivered_GWh": array["discharge" if policy == "A" else "sale"].sum() / site.years_equiv,
            "annual_unused_mwh": (generation - sale - hydrogen
                                  - array["charge"] * 1000
                                  + array["discharge" if policy == "A" else "sale"] * 1000).sum() / site.years_equiv,
            "net_mGBP_by_year": net_by_year,
        }
    anchor = {
        "A": json.loads((STUDY / "A-45-6.json").read_text())["annual_net_mGBP"],
        "B": json.loads((STUDY / "B-battery-certificate.json").read_text())["annual_net_mGBP"],
    }
    for policy, value in anchor.items():
        np.testing.assert_allclose(results[policy]["annual_net_mGBP"], value, rtol=0, atol=1e-7)
    results["surplus"] = {
        "share_positive_pct": 100 * np.mean(surplus > 0),
        "halfhour_GWh_year": surplus.sum() / (1000 * site.years_equiv),
        "daily_GWh_year": np.maximum((site.G - site.D).sum(axis=1), 0).sum() / (1000 * site.years_equiv),
    }
    finance, _, _ = solve_case(site, "A", .125, 7, 4, 10000)
    finance["npv_30_years_mGBP"] = finance["net_m"] / (.05 / (1 - 1.05**-30))
    finance["fixed_dispatch_break_even_GBP_kg"] = site.netback - (
        finance["net_m"] * 1000 / finance["h2_t_per_year"]
    )
    (HERE / "A-7-finance.json").write_text(
        json.dumps(finance, default=lambda x: x.item(), indent=2) + "\n", encoding="utf-8"
    )
    data = json.dumps(results, indent=2) + "\n"
    (HERE / "main-schedule-summary.json").write_text(data, encoding="utf-8")
    print(data)


if __name__ == "__main__":
    main()
