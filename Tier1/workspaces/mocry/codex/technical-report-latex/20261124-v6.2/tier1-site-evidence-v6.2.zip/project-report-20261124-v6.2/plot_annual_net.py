from pathlib import Path
import json

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np

root = Path(__file__).resolve().parent
data = json.loads((root / "main-schedule-summary.json").read_text())
mpl.rcParams.update({"font.family": "serif", "font.size": 9, "pdf.fonttype": 42,
                     "axes.spines.top": False, "axes.spines.right": False})
fig, axes = plt.subplots(1, 2, figsize=(6.35, 1.98), sharex=True)
for ax, key, label in zip(axes, ("A", "B"), ("A. Economic dispatch", "B. Strict supply priority")):
    points = data[key]["net_mGBP_by_year"]
    years = np.array([int(y) for y in points])
    gains = np.array(list(points.values()))
    ax.bar(years, gains, width=.57, color=np.where(gains >= 0, "#326776", "#8e6668"), zorder=2)
    ax.axhline(0, color="#53585c", lw=.8, zorder=3)
    mean = data[key]["annual_net_mGBP"]
    ax.axhline(mean, color="#4d5155", ls="--", lw=.85, zorder=3)
    ax.set_title(label, fontsize=10, pad=4)
    ax.set_xticks(years, [str(y)[2:] for y in years])
    ax.set_ylabel("Net gain (£m)")
    ax.set_ylim(min(-50, 1.15 * gains.min()) if key == "A" else -31,
                440 if key == "A" else 88)
    ax.grid(axis="y", alpha=.30, lw=.65)
    ax.tick_params(length=3, color="#53585c")
    ax.text(.02, .92, f"Mean £{mean:.2f}m/yr", ha="left", va="top", transform=ax.transAxes,
            fontsize=8, color="#313b42")
fig.supxlabel("Calendar year", x=.53, y=.023, fontsize=9)
fig.subplots_adjust(left=.081, right=.995, bottom=.20, top=.88, wspace=.30)
fig.savefig(root / "report/figures/annual-net.pdf")
plt.close(fig)
