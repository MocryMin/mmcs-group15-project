"""Measure the effect of removing the electrolysers from the Tier 2B B site."""

import csv
import json
from pathlib import Path
import sys

import numpy as np
from scipy.special import expit


HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent
CV = PROJECT / "tier2b-six-fold-20261123"
sys.path.insert(0, str(CV))
from policy_b import folds, history_features, load_labels, logistic, stamp, study_rows
import site_replay as site


def read_json(relative):
    return json.loads((PROJECT / relative).read_bytes())


def evaluate(utc, actual, gate, year, blocks, electrolysers, annual_plant_cost):
    window = site.Window(utc, actual, blocks, electrolysers)
    order = np.where(gate, -window.power, window.power)
    cash, trace = site.run(window, order, audit=True, require_empty=False)
    _, _, charge, battery_sale, battery_to_hydrogen, closing, hydrogen, _ = trace.T
    if electrolysers == 0:
        np.testing.assert_array_equal([hydrogen, battery_to_hydrogen, window.base_hydrogen], 0.)
    electricity_increment = np.dot(window.price, battery_sale)
    hydrogen_cash = site.H_VALUE * hydrogen.sum()
    zero_battery_hydrogen_cash = site.H_VALUE * window.base_hydrogen.sum()
    gross = cash.sum()
    np.testing.assert_allclose(gross, electricity_increment + hydrogen_cash - zero_battery_hydrogen_cash,
                               rtol=0., atol=1e-5)
    cost = site.BATTERY["cost_scenarios"][0]["annual_total_GBP"] * blocks * window.days / 365
    plant_cost = annual_plant_cost * window.days / 365
    net = gross - cost
    autumn = utc < stamp(year, 1)
    autumn_net = cash[autumn].sum() - cost * autumn.mean()
    return dict(test_end_year=year, days=window.days, battery_blocks=blocks, electrolysers=electrolysers,
                gross_gbp=gross, cost_gbp=cost, net_gbp=net,
                electricity_increment_gbp=electricity_increment, hydrogen_cash_gbp=hydrogen_cash,
                zero_battery_hydrogen_cash_gbp=zero_battery_hydrogen_cash, plant_cost_gbp=plant_cost,
                portfolio_net_gbp=net + zero_battery_hydrogen_cash - plant_cost,
                sept_dec_net_gbp=autumn_net, jan_aug_net_gbp=net - autumn_net,
                supply_gain_pp=100 * battery_sale.sum() / window.actual[:, 2].sum(),
                charge_mwh=charge.sum(), battery_sales_mwh=battery_sale.sum(), terminal_stock_mwh=closing[-1])


def main():
    old = read_json("tier1-site-battery-20261122/joint/B_n9_h10.json")
    new = read_json("tier1-commitment-125-20261124/B-battery-certificate.json")
    blocks, old_count = old["battery_blocks"], old["electrolyser_units"]
    assert blocks == new["battery_blocks"] and new["electrolyser_units"] == 0
    annual_plant_cost = old["annual_electrolyser_cost_mGBP"] * 1e6
    old_threshold = old_count * site.H_MODULE_MAX
    full_utc, full_actual = load_labels()
    selected = study_rows(full_utc)
    features, prior = history_features(full_utc, full_actual, selected)
    utc, actual = full_utc[selected], full_actual[selected]
    surplus = actual[:, 1] - actual[:, 2]
    target = surplus >= 0.
    old_offset = (prior - old_threshold) / 400
    new_offset = prior / 400
    weight = .1 + np.exp(-np.abs(prior) / 500)

    with (CV / "policy-b.csv").open(newline="", encoding="utf-8") as stream:
        reference = {int(row["test_end_year"]): row for row in csv.DictReader(stream)}
    rows = []
    for fold in folds(utc):
        with np.load(CV / "folds" / str(fold.year) / "gate-b.npz") as saved:
            centre, spread, coefficients = (saved[k] for k in ("centre", "spread", "coefficients"))
        np.testing.assert_array_equal(centre, features[fold.train].mean(0))
        np.testing.assert_array_equal(spread, features[fold.train].std(0) + .02)
        design = np.c_[np.ones(len(features)), np.clip((features - centre) / spread, -5, 5)]
        fit = fold.train
        refit = logistic(design[fit], target[fit], new_offset[fit], weight[fit], .015)
        test = fold.test
        frozen_gate = expit(old_offset[test] + design[test] @ coefficients) >= .5
        refit_gate = expit(new_offset[test] + design[test] @ refit) >= .5
        np.savez_compressed(HERE / f"gate-b-{fold.year}.npz", coefficients=refit, centre=centre, spread=spread,
                            surplus_threshold_mwh=0.)
        for scenario, count, plant_cost, gate in (
            ("legacy", old_count, annual_plant_cost, frozen_gate),
            ("remove_plant_frozen_gate", 0, 0., frozen_gate),
            ("remove_plant_refit_gate", 0, 0., refit_gate),
            ("remove_plant_truth_gate", 0, 0., target[test]),
        ):
            row = evaluate(utc[test], actual[test], gate, fold.year, blocks, count, plant_cost)
            if scenario == "legacy":
                for key in ("gross_gbp", "cost_gbp", "net_gbp", "sept_dec_net_gbp", "terminal_stock_mwh"):
                    np.testing.assert_allclose(row[key], float(reference[fold.year][key]), rtol=0, atol=1e-5)
            correct = (surplus[test] >= old_threshold) if count else target[test]
            row.update(scenario=scenario, accuracy=float(np.mean(gate == correct)),
                       order_change_fraction=float(np.mean(gate[:-48] != frozen_gate[:-48])))
            rows.append(row)
            print(f"{fold.year} {scenario} {row['net_gbp']:,.0f} ({row['portfolio_net_gbp']:,.0f} total)", flush=True)
    with (HERE / "comparison.csv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


if __name__ == "__main__":
    main()
