"""Sweep the pure-battery Policy B size using the already fitted fold gates."""

from csv import DictReader, DictWriter

import matplotlib
import numpy as np
from scipy.special import expit

from compare import HERE, PROJECT, evaluate, folds, history_features, load_labels, site, study_rows

matplotlib.use("Agg")
import matplotlib.pyplot as plt


MAX_BLOCKS = 45
REFERENCE = 2026
OUTLIER = 2022  # the identified 2021.09--2022.08 high-receipt test window
MILLION = 1e6


def read_rows(path):
    with path.open(encoding="utf-8", newline="") as stream:
        return list(DictReader(stream))


def write_rows(path, rows):
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def plot(summary):
    old = read_rows(PROJECT / "tier2b-capacity-stability-20261124/b-size-sweep.csv")
    sizes = np.arange(MAX_BLOCKS + 1)
    np.testing.assert_array_equal([int(row["blocks"]) for row in old], sizes)
    new_gross = np.asarray([row["reference_gross_gbp"] for row in summary], dtype=float) / MILLION
    new_net = np.asarray([row["reference_net_gbp"] for row in summary], dtype=float) / MILLION
    old_gross = np.asarray([float(row["gross_gbp"]) for row in old]) / MILLION
    old_net = np.asarray([float(row["net_gbp"]) for row in old]) / MILLION
    peak = int(new_net.argmax())
    fixed_cost = site.BATTERY["cost_scenarios"][0]["annual_total_GBP"] / MILLION
    colours = ("#145d6f", "#766693")

    fig, (top, bottom) = plt.subplots(2, 1, sharex=True, figsize=(10.2, 6.9))
    fig.subplots_adjust(left=.105, right=.97, top=.81, bottom=.11, hspace=.26)
    fig.text(.105, .95, "Tier 2B Policy B battery sizing", fontweight="bold", fontsize=18, va="top")
    fig.text(.105, .886, "1 Sep 2025–31 Aug 2026  |  100 MW / 400 MWh per block  |  2020 GBP",
             fontsize=10, color="#475461", va="top")
    for axis in (top, bottom):
        axis.grid(axis="y", color="#d7dee3", lw=.75)
        axis.set_axisbelow(True)
        axis.spines[["right", "top"]].set_visible(False)
        axis.set_xlim(-.4, MAX_BLOCKS + .8)
    top.plot(sizes[1:], np.diff(new_gross), "o-", markersize=3.1, color=colours[0], label="Zero electrolysers, refitted gate")
    top.plot(sizes[1:], np.diff(old_gross), "--", color=colours[1], label="Ten electrolysers, original gate")
    top.axhline(fixed_cost, color="#a84439", ls=(0, (5, 3)), lw=1.3)
    top.annotate(f"Fixed cost £{fixed_cost:.3f}m/block/year", (.99, fixed_cost),
                 xycoords=top.get_yaxis_transform(), xytext=(0, 8), textcoords="offset points",
                 ha="right", color="#a84439", fontsize=9)
    top.set_ylabel("Marginal gross gain\n(£m/block/year)")
    top.legend(loc="upper right", frameon=False, fontsize=9)
    bottom.axhline(0, color="#626b71", lw=1)
    bottom.plot(sizes, new_net, "o-", markersize=3.1, color=colours[0])
    bottom.plot(sizes, old_net, "--", color=colours[1])
    bottom.scatter(peak, new_net[peak], color=colours[0], edgecolor="white", s=47, zorder=4)
    bottom.set_ylim(top=new_net[peak] + 1.55)
    bottom.annotate(f"{peak} blocks · £{new_net[peak]:.2f}m", (peak, new_net[peak]),
                    xytext=(0, 8), textcoords="offset points", va="bottom", ha="center", color=colours[0])
    bottom.set_ylabel("Total net battery gain (£m)")
    bottom.set_xlabel("Battery blocks installed")
    bottom.set_xticks(range(0, MAX_BLOCKS + 1, 5))
    for ext in ("png", "pdf"):
        fig.savefig(HERE / f"battery-only-capacity-curves.{ext}", dpi=200)
    plt.close(fig)


def main():
    full_utc, full_actual = load_labels()
    selected = study_rows(full_utc)
    features, prior = history_features(full_utc, full_actual, selected)
    utc, actual = full_utc[selected], full_actual[selected]
    anchor = {int(row["test_end_year"]): row for row in read_rows(HERE / "comparison.csv")
              if row["scenario"] == "remove_plant_refit_gate"}

    rows = []
    for fold in folds(utc):
        test = fold.test
        with np.load(HERE / f"gate-b-{fold.year}.npz") as model:
            assert model["surplus_threshold_mwh"].item() == 0.
            design = np.c_[np.ones(len(test)), np.clip((features[test] - model["centre"]) / model["spread"], -5, 5)]
            gate = expit(prior[test] / 400 + design @ model["coefficients"]) >= .5
        fold_rows = [evaluate(utc[test], actual[test], gate, fold.year, n, 0, 0.)
                     for n in range(MAX_BLOCKS + 1)]
        for key in ("gross_gbp", "net_gbp", "terminal_stock_mwh"):
            np.testing.assert_allclose(fold_rows[9][key], float(anchor[fold.year][key]), rtol=0, atol=1e-5)
        np.testing.assert_array_equal(fold_rows[0]["net_gbp"], 0.)
        winner = max(fold_rows, key=lambda row: row["net_gbp"])
        print(f"{fold.year}: {winner['battery_blocks']} blocks, GBP {winner['net_gbp']:,.0f}", flush=True)
        rows.extend(fold_rows)

    summary = []
    for n in range(MAX_BLOCKS + 1):
        group = [r for r in rows if r["battery_blocks"] == n]
        reference = next(r for r in group if r["test_end_year"] == REFERENCE)
        net = np.array([r["net_gbp"] for r in group])
        earlier = [r["net_gbp"] for r in group if r["test_end_year"] != REFERENCE]
        summary.append(dict(battery_blocks=n, reference_gross_gbp=reference["gross_gbp"],
                            reference_cost_gbp=reference["cost_gbp"], reference_net_gbp=reference["net_gbp"],
                            earlier_five_net_gbp=sum(earlier), six_fold_net_gbp=net.sum(),
                            profitable_folds=int((net > 0.).sum()), median_gbp=float(np.median(net)),
                            worst_gbp=net.min(), without_2021_22_gbp=sum(r["net_gbp"] for r in group
                                                                         if r["test_end_year"] != OUTLIER)))

    assert max(summary, key=lambda row: row["reference_net_gbp"])["battery_blocks"] < MAX_BLOCKS
    write_rows(HERE / "size-sweep-folds.csv", rows)
    write_rows(HERE / "size-sweep-summary.csv", summary)
    plot(summary)


if __name__ == "__main__":
    main()
