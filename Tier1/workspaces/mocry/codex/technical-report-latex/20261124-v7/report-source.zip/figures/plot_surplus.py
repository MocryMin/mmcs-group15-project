"""Rebuild Figure I.1 from the archived seasonal and duration data."""

import csv
from pathlib import Path

import matplotlib as mpl

mpl.use("Agg")
import matplotlib.pyplot as plt


FIGURES = Path(__file__).resolve().parent


def read_rows(name):
    with (FIGURES / name).open(newline="", encoding="utf-8") as source:
        return list(csv.DictReader(source))


def main():
    mpl.rcParams.update({
        "font.family": "serif", "font.size": 8.5, "axes.labelsize": 8.5,
        "xtick.labelsize": 8, "ytick.labelsize": 8, "pdf.fonttype": 42,
        "axes.spines.top": False, "axes.spines.right": False,
    })
    figure, (left, right) = plt.subplots(1, 2, figsize=(6.28, 1.9))
    seasonal = read_rows("seasonal-surplus.csv")
    hours = [float(row["utc_hour"]) for row in seasonal]
    seasons = (
        ("Winter", "#31515f", "-"), ("Spring", "#797474", "--"),
        ("Summer", "#397783", "-."), ("Autumn", "#624862", ":"),
    )
    for season, colour, style in seasons:
        surplus = [float(row[f"{season}_GWh_per_slot"]) for row in seasonal]
        left.plot(hours, surplus, lw=1.25, label=season, color=colour, ls=style)
    left.set(xlim=(0, 24), xticks=(0, 6, 12, 18, 24), ylim=(0, 1.58),
             yticks=(0, .5, 1, 1.5), xlabel="Half-hour start (UTC)")
    left.set_ylabel("Mean surplus\n(GWh per half-hour)", fontsize=8)
    left.legend(loc="upper left", bbox_to_anchor=(0, 1.17), ncol=4, fontsize=6.65,
                columnspacing=.75, handlelength=1.25, handletextpad=.35,
                frameon=False, borderaxespad=0)

    durations = read_rows("surplus-spell-counts.csv")
    thresholds = [float(row["min_hours"]) for row in durations]
    counts = [int(row["count"]) for row in durations]
    longest, last_count = thresholds[-1], counts[-1]
    minimum_run = 96
    right.step(thresholds, counts, where="pre", lw=1.15, color="#31515f")
    right.scatter([longest], [last_count], color="#31515f", s=11, zorder=3)
    right.annotate(f"Longest: {longest:g} h", (longest, last_count),
                   xytext=(8, 8), textcoords="offset points", fontsize=7.2,
                   va="bottom")
    right.axvline(minimum_run, color="#805450", ls="--", lw=1)
    right.text(minimum_run - 2, counts[0] * .63, f"{minimum_run} h minimum",
               color="#694340", va="top", ha="right", fontsize=7.1)
    right.set(yscale="log", ylim=(.75, 1.4 * counts[0]), xlim=(0, 102),
              xticks=(0, 24, 48, 72, 96), xlabel="Duration threshold $x$ (hours)")
    right.set_ylabel("Number of surplus periods\nlasting at least $x$ hours",
                     fontsize=8, labelpad=5)
    for axis in (left, right):
        axis.grid(axis="y", color=".88", lw=.55)
    figure.subplots_adjust(left=.12, right=.99, bottom=.245, top=.84, wspace=.49)
    figure.savefig(FIGURES / "surplus-and-duration.pdf")
    plt.close(figure)


if __name__ == "__main__":
    main()
