"""Calculate renewable shares of physical surplus for the v7 portfolios."""

import csv
from pathlib import Path

import numpy as np
import pandas as pd


HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent
V7 = PROJECT / "tier1-halfhour-20261113-v7"
XPRESS = PROJECT / "tier1-xpress-full-20261124"
FLEXIBLE = PROJECT / "tier1-site-battery-20261122/joint"
FUELS = ("Biomass", "Hydro Run-of-river and poundage", "Solar", "Wind Onshore", "Wind Offshore")
YEARS = 6


def panel():
    frame = pd.read_csv(V7 / "inputs/halfhour.csv.gz")
    frame = frame[frame.date.between("2020-01-01", "2025-12-31")].copy()
    frame["timestamp"] = pd.to_datetime(frame.utc, utc=True)
    assert len(frame) == 105216 and frame.timestamp.is_monotonic_increasing
    assert frame.groupby("date").size().eq(48).all()
    frame["g"] = (frame.background_MW + frame.farm_flat_MW) / 2000
    frame["d"] = frame.demand_MW / 2000
    fuel_path = V7 / "source_data/tier1-multiproduct-20261110-v6/inputs/daily_generation_by_fuel.csv"
    fuel = pd.read_csv(fuel_path)
    assert not fuel.duplicated(["date", "psrType"]).any()
    shares = fuel[fuel.psrType.isin(FUELS)].pivot(index="date", columns="psrType", values="MW")
    daily = frame.groupby("date").agg(g=("g", "sum"), d=("d", "sum"), farm=("farm_flat_MW", "mean"))
    shares = shares.reindex(daily.index)
    assert shares.notna().all().all()
    daily["mix"] = (shares.sum(axis=1) + daily.farm) * 24 / (daily.g * 1000)
    assert daily.mix.between(0, 1).all()
    frame["mix"] = frame.date.map(daily.mix)
    return frame, daily


def summarise(case, policy, floor, blocks, modules, source, frame, device_input, alternate=None):
    assert len(frame) == len(device_input)
    assert np.min(device_input) >= -1e-7
    physical = np.maximum(frame.g.to_numpy() - frame.d.to_numpy(), 0.)
    captures = np.minimum(physical, np.maximum(device_input, 0.))
    physical_total = physical.sum() / YEARS
    mix = frame.mix.to_numpy()
    renewable_total = np.dot(mix, physical) / YEARS
    renewable_captured = np.dot(mix, captures) / YEARS
    alternate_captured = (renewable_captured if alternate is None else
                          np.dot(mix, np.minimum(physical, np.maximum(alternate, 0.))) / YEARS)
    assert renewable_captured >= alternate_captured - 1e-8
    return dict(case=case, policy=policy, floor=floor, battery_blocks=blocks,
                electrolyser_modules=modules, schedule=source.relative_to(PROJECT).as_posix() if source else "",
                all_fuel_surplus_GWh_year=physical_total, all_fuel_captured_GWh_year=captures.sum()/YEARS,
                renewable_surplus_GWh_year=renewable_total, renewable_captured_GWh_year=renewable_captured,
                renewable_remaining_GWh_year=renewable_total-renewable_captured,
                renewable_captured_if_discharge_to_hydrogen_first_GWh_year=alternate_captured)


def main():
    frame, daily = panel()
    results = [summarise("Half-hour direct sales", "-", "", 0, 0, None, frame, np.zeros(len(frame)))]
    for policy in ("A", "B"):
        path = XPRESS / f"daily-xpress/results/reference_day_{policy}_integer_schedule.csv.gz"
        schedule = pd.read_csv(path).set_index("date")
        assert daily.index.equals(schedule.index)
        np.testing.assert_allclose(daily[["g", "d"]], schedule[["g", "d"]], atol=1e-7, rtol=0.)
        results.append(summarise("Daily two-hour", policy, .20, 0, 5, path, daily,
                                 (schedule.charge + schedule.generation_h2).to_numpy()))

    for floor, modules in ((.20, 6), (.125, 7)):
        path = XPRESS / f"A-zero-{floor:g}-xpress.npz"
        with np.load(path) as schedule:
            hydrogen = schedule["hydrogen_MWh"].ravel() / 1000
        results.append(summarise("Four-day electrolysis only", "A", floor, 0, modules, path, frame, hydrogen))

        path = XPRESS / f"A-A-{floor:g}-xpress-45-6.npz"
        with np.load(path) as schedule:
            q, c, discharge, h = (schedule[name] for name in ("sales", "charge", "discharge", "hydrogen"))
        # The joined flow columns allow either routing. Allocate discharge to sales first.
        direct_h = h - np.maximum(0, discharge - q)
        alternate_h = h - np.minimum(h, discharge)
        results.append(summarise("Four-day joint", "A", floor, 45, 6, path, frame,
                                 c + direct_h, c + alternate_h))

    path = XPRESS / "B-0.2-xpress-winning-dispatch.npz"
    with np.load(path) as schedule:
        charge = schedule["flows"][1]
    results.append(summarise("Four-day joint", "B", "both", 9, 0, path, frame, charge))
    for policy, blocks, modules in (("A", 45, 6), ("B", 9, 10)):
        path = FLEXIBLE / f"{policy}_n{blocks}_h{modules}_dispatch.npz"
        with np.load(path) as schedule:
            np.testing.assert_array_equal(schedule["utc_ns"], frame.timestamp.to_numpy(dtype="datetime64[ns]").astype("int64"))
            _, c, _, battery_hydrogen, _, h = schedule["flows"]
        results.append(summarise("Flexible joint", policy, .125, blocks, modules, path, frame, c + h - battery_hydrogen))

    with (HERE / "renewable-attribution.csv").open("w", newline="", encoding="utf-8") as output:
        writer = csv.DictWriter(output, fieldnames=list(results[0]))
        writer.writeheader()
        writer.writerows(results)
    for row in results:
        print(row["case"], row["policy"], row["floor"],
              *(f'{row[k]:.3f}' for k in ("all_fuel_captured_GWh_year", "renewable_surplus_GWh_year",
                                        "renewable_captured_GWh_year", "renewable_remaining_GWh_year",
                                        "renewable_captured_if_discharge_to_hydrogen_first_GWh_year")))


if __name__ == "__main__":
    main()
