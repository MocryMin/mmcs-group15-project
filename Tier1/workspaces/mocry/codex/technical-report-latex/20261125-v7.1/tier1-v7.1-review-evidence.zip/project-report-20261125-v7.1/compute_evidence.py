"""Rebuild the v7.1 price sweep, electricity attribution and replay table inputs."""

from functools import partial
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd


HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent
XPRESS = PROJECT / "tier1-xpress-full-20261124"
PRIOR_REPORT = PROJECT / "project-report-20261124-v7"
sys.path[:0] = [str(XPRESS), str(PRIOR_REPORT)]
from run import school_licence
from halfhour import rounded_commitment
import solver_adapter
import solve_a
import run_a
import site_model
from renewable_attribution import panel


def price_sweep(site, floors):
    rows = []
    for floor in floors:
        count_max = int(solve_a.CAP_KG * site.kwh_per_kg / (1000 * floor * site.e * 48))
        for price in (2.50, 5., site.netback, 9.50):
            case = site.with_netback(price)
            values = site_model.value_table(case, "A", floor, count_max, solve_a.CAP_KG)
            upper = np.maximum.accumulate(values, axis=1).sum(axis=0) / case.years_equiv
            upper -= np.arange(count_max + 1) * case.annual
            best, capacity, evaluated = 0., 0, []
            for count in np.argsort(-upper):
                if upper[count] <= best + .01:
                    break
                count = int(count)
                row, _, _ = site_model.solve_case(case, "A", floor, count, solve_a.MIN_DAYS, solve_a.CAP_KG)
                evaluated.append((count, row["net_m"], row["bound_gap_gbp_per_year"]))
                gain = row["net_m"] * 1e6
                if gain > best:
                    best, capacity = gain, count
            gap = max((max(0., gap) for _, _, gap in evaluated), default=0.)
            assert gap <= .01, (floor, price, evaluated)
            rows.append(dict(floor=floor, hydrogen_GBP_per_kg=price, modules=capacity,
                             annual_net_mGBP=best/1e6, max_tested_gap_GBP=gap,
                             capacities_solved=len(evaluated)))
    return pd.DataFrame(rows)


def allocations(site):
    frame, _ = panel()
    g, d, p = (frame[key].to_numpy() for key in ("g", "d", "price"))
    direct = np.minimum(g, d) * (p >= 0)
    results = []
    for floor in (.20, .125):
        with np.load(XPRESS / f"A-zero-{floor:g}-xpress.npz") as schedule:
            h = schedule["hydrogen_MWh"].ravel() / 1000
        physical = np.minimum(h, np.maximum(g-d, 0.))
        unsold = np.minimum(h, g-direct)
        negative_price = unsold-physical
        diverted = h-unsold
        assert np.min(negative_price) > -1e-8
        assert np.max(np.abs(negative_price[p >= 0])) < 1e-8
        inp, phys, neg, sale, renov = (np.sum(x) / site.years_equiv
                                       for x in (h, physical, negative_price, diverted, physical*frame.mix))
        np.testing.assert_allclose(inp, phys+neg+sale, atol=1e-8, rtol=0.)
        rows = dict(floor=floor, input_GWh_year=inp, physical_surplus_GWh_year=phys,
                    additional_unsold_at_negative_price_GWh_year=neg, displaced_sales_GWh_year=sale,
                    estimated_renewable_surplus_GWh_year=renov, estimated_renewable_share=renov/inp,
                    demand_served_change_pp=-100*diverted.sum()/d.sum())
        if floor == .20:
            finance = json.loads((PROJECT / "tier1-commitment-20-20261124/A-zero-finance.json").read_bytes())
            low, high = 2.50, site.netback
            breakeven = finance["break_even_fixed_dispatch_GBP_kg"]
            revenue = low + (high-low)*renov/inp
            rows.update(fixed_break_even_GBP_kg=breakeven, break_even_supported_share=(breakeven-low)/(high-low),
                        sensitivity_blended_GBP_kg=revenue,
                        sensitivity_net_mGBP=(revenue-breakeven)*finance["h2_t_per_year"]/1000)
        results.append(rows)
    return pd.DataFrame(results)


if __name__ == "__main__":
    site, _, _ = run_a.site_inputs()
    with school_licence():
        site_model.milp = partial(rounded_commitment, solver_adapter)
        prices = price_sweep(site, (.20, .125))
    splits = allocations(site)
    prices.to_csv(HERE / "four-day-price-sweep.csv", index=False)
    splits.to_csv(HERE / "electricity-input-split.csv", index=False)
    replay = pd.read_csv(PROJECT / "tier2b-commitment-125-20261124/six-fold-capacity-replay.csv")
    rows = replay[replay.blocks.eq(11)][["policy", "test_end_year", "blocks", "net_battery_GBP"]]
    assert len(rows) == 12
    rows.to_csv(HERE / "eleven-block-replay.csv", index=False)
    print(prices.to_string(index=False))
    print(splits.to_string(index=False))
    print(rows.to_string(index=False))
