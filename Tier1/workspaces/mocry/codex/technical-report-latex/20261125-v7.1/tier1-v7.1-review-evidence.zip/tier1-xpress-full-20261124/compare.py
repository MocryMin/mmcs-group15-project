"""Audit published capacities, objective bounds, and the new solver comparison."""

import csv
import hashlib
import json

import numpy as np

from run import HERE, PROJECT, V7, save_json


def read(path):
    return json.loads(path.read_bytes())


def compare():
    import solve_a

    rows = []
    for record in read(HERE / "daily-comparison.json"):
        counts = record.pop("investment")
        rows.append(dict(case="Daily brief", floor=.2,
                         battery_blocks=int(counts["brief-2h"]),
                         electrolyser_units=int(counts["itm-neptune-v"]), **record))
    annual = []
    site, battery, product = solve_a.inputs()
    g, d, price = site.G.ravel(), site.D.ravel(), site.p.ravel()
    for floor, archive in ((.2, "20"), (.125, "125")):
        check_root = PROJECT / f"tier1-commitment-{archive}-20261124"
        for policy in ("A", "B"):
            path = check_root / ("A-capacity-certificate.json" if policy == "A" else
                                 "B-capacity-certificate.json" if floor == .2 else
                                 "B-battery-certificate.json")
            old = read(path)
            assert old["capacity_certified"]
            base_sales = np.minimum(g, d) * (1 if policy == "B" else (price >= 0))
            for solver in ("xpress", "highs"):
                tag = f"{policy}-{floor:g}-{solver}"
                new_file = HERE / f"{tag}.json"
                if not new_file.exists() and policy == "A" and solver == "highs":
                    tag += "-screened"
                    new_file = HERE / f"{tag}.json"
                if not new_file.exists() and (floor != .2 or solver == "highs"):
                    continue
                new = read(new_file)
                assert new["capacity_certified"]
                blocks, units = (new[key] for key in ("battery_blocks", "electrolyser_units"))
                assert (blocks, units) == (old["battery_blocks"], old["electrolyser_units"])
                gain, bound = new["annual_net_mGBP"], new.get("global_upper_mGBP", new["upper_mGBP"])
                old_gain = old["annual_net_mGBP"]
                old_bound = old.get("global_upper_mGBP", old["upper_mGBP"])
                assert gain <= old_bound + 2e-6 and old_gain <= bound + 2e-6
                if policy == "A":
                    dispatch = HERE / f"A-{tag}-{blocks}-{units}.npz"
                    with np.load(dispatch) as saved:
                        receipts = (saved["sales"] * 1000 - base_sales) * price
                        receipts += saved["hydrogen"] * 1000 * site.w
                else:
                    with np.load(HERE / f"{tag}-winning-dispatch.npz") as saved:
                        receipts = (saved["flows"][0] * 1000 + saved["flows"][2] * 1000 - base_sales) * price
                annual_cost = blocks * battery["annual"] + units * product["annual"]
                day_receipts = receipts.reshape(-1, 48).sum(axis=1)
                for year in np.unique(site.year):
                    v = day_receipts[site.year == year].sum() / 1e6 - annual_cost
                    annual.append(dict(case=tag, year=int(year), net_mGBP=float(v)))
                mean = receipts.sum() / (site.years_equiv * 1e6) - annual_cost
                np.testing.assert_allclose(mean, gain, atol=1e-7, rtol=0.)
                rows.append(dict(case="Half-hour four-day", solver=new["solver"], policy=policy, floor=floor,
                                 battery_blocks=blocks, electrolyser_units=units, annual_net_mGBP=gain,
                                 upper_mGBP=bound, wall_seconds=new["wall_seconds"],
                                 status="globally certified counts", archived_gain_mGBP=old_gain,
                                 archived_upper_mGBP=old_bound,
                                 timing_scope="archived capacity screening reused"
                                 if new.get("archived_screen") else "complete current solve",
                                 alternative_upper_mGBP=new["best_alternative_upper_mGBP"]))
    for row in rows:
        row["annual_gap_GBP"] = max(0., (row["upper_mGBP"] - row["annual_net_mGBP"]) * 1e6)
    fields = list(dict.fromkeys(key for row in rows for key in row))
    with (HERE / "comparison.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    with (HERE / "annual-results.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=["case", "year", "net_mGBP"])
        writer.writeheader()
        writer.writerows(annual)
    inputs = (
        V7 / "inputs/halfhour.csv.gz",
        PROJECT / "storage-exploration-20261116-v2/utility4h/configuration.json",
        PROJECT / "project-report-20261124-v7/report.pdf",
    )
    save_json("input-hashes.json", {path.relative_to(PROJECT).as_posix():
                                   hashlib.sha256(path.read_bytes()).hexdigest() for path in inputs})
    for row in rows:
        print(row["case"], row["floor"], row["policy"], row["solver"], row["battery_blocks"],
              row["electrolyser_units"], f'{row["annual_net_mGBP"]:.9f}',
              f'{row["upper_mGBP"]:.9f}', f'{row["wall_seconds"]:.3f}')


if __name__ == "__main__":
    compare()
