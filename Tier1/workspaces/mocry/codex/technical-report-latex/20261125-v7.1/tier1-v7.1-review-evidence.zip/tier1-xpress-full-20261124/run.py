"""Repeat v7 Tier 1 with a process-local school Xpress licence."""

import argparse
from contextlib import contextmanager
import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
import warnings

import xpress as xp

import solver_adapter


HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent
COURSE = PROJECT.parent.parent
V7 = PROJECT / "tier1-halfhour-20261113-v7"
sys.path.append(str(V7 / ".venv/Lib/site-packages"))
sys.path[:0] = [str(PROJECT / folder) for folder in (
    "project-report-20261122-v6", "tier1-commitment-20-20261124",
    "tier1-commitment-125-20261124",
)]


def save_json(filename, result):
    (HERE / filename).write_text(
        json.dumps(result, indent=2, allow_nan=False, default=lambda v: v.item()) + "\n",
        encoding="utf-8",
    )


@contextmanager
def school_licence():
    guide = COURSE / "materials/sync-20261030/licence-instructions-extracted.txt"
    directives = [line.strip() for line in guide.read_text(encoding="utf-8-sig").splitlines()
                  if line.strip().lower().startswith("use_server")]
    assert len(directives) == 1
    with TemporaryDirectory(prefix="mmcs-xpress-school-") as folder:
        licence = Path(folder) / "xpauth.xpr"
        licence.write_text(directives[0] + "\n", encoding="ascii")
        with xp.init(str(licence)):
            print(f"Python Xpress {xp.__version__}: school licence acquired", flush=True)
            yield


def daily():
    import site_refresh
    import model

    frame, config, _, _ = site_refresh.inputs()
    daily_frame = frame.groupby("date").agg(g=("g", "sum"), d=("d", "sum"), price=("price", "mean"))
    daily_frame["date"] = daily_frame.index
    daily_frame.index = site_refresh.pd.to_datetime(daily_frame.index, utc=True)
    config = site_refresh.brief_config(config, 24.)
    save_json("daily-config.json", config)
    original_solver, original_root = model.highspy, model.ROOT
    rows = []
    for label, backend in (("Xpress", solver_adapter), ("HiGHS", original_solver)):
        model.highspy = backend
        model.ROOT = HERE / ("daily-" + label.lower())
        model.ROOT.mkdir(exist_ok=True)
        for policy in ("A", "B"):
            row = model.solve(daily_frame, config, policy, f"reference_day_{policy}_integer",
                              seconds=35, threads=4)
            old = json.loads((PROJECT / "project-report-20261122-v6/evidence/reference/results" /
                              f"reference_day_{policy}_integer.json").read_bytes())
            assert row["variables"] == old["variables"] and row["rows"] == old["rows"]
            assert row["investment"] == old["investment"] and row["exact_operating_feasible"]
            assert abs(row["annual_increment_mGBP"] - old["annual_increment_mGBP"]) < 1e-7
            assert abs(row["upper_increment_mGBP"] - row["annual_increment_mGBP"]) < 1e-7
            rows.append(dict(solver=label, policy=policy, investment=row["investment"],
                             annual_net_mGBP=row["annual_increment_mGBP"],
                             upper_mGBP=row["upper_increment_mGBP"],
                             wall_seconds=row["runtime_seconds"], status=row["status"]))
    model.highspy, model.ROOT = original_solver, original_root
    save_json("daily-comparison.json", rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("case", choices=("daily", "a", "b", "zero"))
    parser.add_argument("--floor", type=float, choices=(.125, .20), default=.20)
    parser.add_argument("--solver", choices=("Xpress", "HiGHS"), default="Xpress")
    parser.add_argument("--threads", type=int, default=4)
    parser.add_argument("--seconds", type=int, default=180)
    parser.add_argument("--highs-initial", choices=("simplex", "ipm"), default="simplex",
                        help="Initial LP algorithm for the HiGHS A benchmark.")
    parser.add_argument("--archived-screen", action="store_true",
                        help="Use the original v7 capacity screening bounds in the HiGHS A benchmark.")
    args = parser.parse_args()
    if args.archived_screen and (args.case != "a" or args.solver != "HiGHS"):
        parser.error("--archived-screen applies to the HiGHS A benchmark only")
    warnings.filterwarnings("ignore", category=DeprecationWarning, module="solver_adapter")
    if args.case == "daily":
        with school_licence():
            daily()
    else:
        import halfhour
        function = getattr(halfhour, "policy_" + args.case)
        if args.solver == "Xpress":
            with school_licence():
                function(args)
        else:
            function(args)


if __name__ == "__main__":
    main()
