"""Reproduce the four-day commitment capacity search and operating schedules."""

from functools import partial
from pathlib import Path
from tempfile import gettempdir
from time import perf_counter
from types import SimpleNamespace

import numpy as np

import solver_adapter
from run import HERE, PROJECT, save_json


def rounded_commitment(matrix_solver, c, *, constraints, bounds, integrality, options):
    """Pass the existing daily commitment subproblem to the selected solver."""
    lp = matrix_solver.HighsLp()
    sparse = constraints.A.tocsc()
    lp.num_row_, lp.num_col_ = sparse.shape
    lp.col_cost_, lp.col_lower_, lp.col_upper_ = c, bounds.lb, bounds.ub
    lp.row_lower_, lp.row_upper_ = constraints.lb, constraints.ub
    lp.a_matrix_.format_ = matrix_solver.MatrixFormat.kColwise
    lp.a_matrix_.start_, lp.a_matrix_.index_, lp.a_matrix_.value_ = (
        sparse.indptr, sparse.indices, sparse.data
    )
    solver = matrix_solver.Highs()
    solver.setOptionValue("output_flag", False)
    solver.setOptionValue("threads", 1)
    solver.setOptionValue("time_limit", options["time_limit"])
    solver.setOptionValue("mip_rel_gap", options["mip_rel_gap"])
    solver.passModel(lp)
    indices = np.flatnonzero(integrality).astype(np.int32)
    solver.changeColsIntegrality(len(indices), indices, np.ones(len(indices), dtype=np.uint8))
    solver.run()
    answer = solver.getSolution()
    return SimpleNamespace(x=np.asarray(answer.col_value) if answer.value_valid else None,
                           message=str(solver.getModelStatus()),
                           mip_dual_bound=solver.getInfo().mip_dual_bound)


def policy_a(args):
    """Bound all capacity configurations with supporting planes from full-horizon LPs."""
    import solve_a
    import run_a
    import site_model

    started = perf_counter()
    method = args.solver.lower()
    tag = f"A-{args.floor:g}-{method}"
    if args.archived_screen:
        tag += "-screened"
    if args.floor == .20:
        site, battery, product = run_a.site_inputs()
    else:
        site, battery, product = solve_a.inputs()
    solve_a.MIN_LOAD = args.floor
    solve_a.HERE = HERE
    # Capture the identical sparse problem also for the HiGHS time comparison.
    original_load = solve_a.load_matrix

    def capture(matrix):
        nonlocal original_matrix
        original_matrix = matrix
        return original_load(matrix)

    original_matrix = None
    solve_a.load_matrix = capture
    if args.solver == "Xpress":
        solve_a.highspy = solver_adapter
        site_model.milp = partial(rounded_commitment, solver_adapter)
    job = solve_a.EconomicSizing(site, battery, product, args.seconds, args.threads, tag)
    solver = job.solver
    solver.setOptionValue("solver", "ipm")
    if args.solver == "Xpress":
        solver.setOptionValue("xpress_return_duals", True)
        solver.setOptionValue("xpress_log", Path(gettempdir()) / f"mmcs-full-{tag}-solver.log")
    else:
        solver.setOptionValue("solver", args.highs_initial)
        solver.setOptionValue("log_file", str(Path(gettempdir()) /
                                              f"mmcs-full-{tag}-{args.highs_initial}.log"))
        solver.setOptionValue("run_crossover", "on")
    sparse = original_matrix.sparse()
    column_lower, column_upper = (np.concatenate(v) for v in (original_matrix.lb, original_matrix.ub))
    row_lower, row_upper = (np.concatenate(v) for v in (original_matrix.rl, original_matrix.ru))
    del original_matrix
    counts = np.array([job.nb, job.nh], dtype=np.int32)
    all_blocks, all_units = np.ogrid[:job.max_blocks + 1, :job.max_units + 1]
    cap_upper = np.full((job.max_blocks + 1, job.max_units + 1), np.inf)
    lp_trials, witnesses = [], []
    best = None
    tried = set()
    padding = 2e-6

    def solve_lp():
        start = perf_counter()
        solution, status = job.run()
        elapsed = perf_counter() - start
        if status != solve_a.highspy.HighsModelStatus.kOptimal:
            raise RuntimeError(f"Full-horizon A LP did not reach optimum: {status}")
        return solution, elapsed

    def supported_upper(solution, elapsed, pair):
        dual = np.asarray(solver.getSolution().row_dual).copy()
        dual[(~np.isfinite(row_lower)) & (dual > 0)] = 0.
        dual[(~np.isfinite(row_upper)) & (dual < 0)] = 0.
        reduced = job.cost - sparse.T @ dual
        lower, upper = column_lower.copy(), column_upper.copy()
        lower[counts], upper[counts] = 0., 0.
        box = np.dot(np.maximum(reduced, 0.), lower) + np.dot(np.minimum(reduced, 0.), upper)
        positive, negative = dual > 0, dual < 0
        constant = -(job.reference + box + np.dot(dual[positive], row_lower[positive])
                     + np.dot(dual[negative], row_upper[negative]))
        gradient = -reduced[counts]
        plane = constant + gradient[0] * all_blocks + gradient[1] * all_units
        b, h = solution[counts]
        primal = -float(np.dot(job.cost, solution) + job.reference)
        check = constant + np.dot(gradient, [b, h]) - primal
        if not -1e-7 <= check <= .005:
            raise RuntimeError(f"Unexpected primal/dual gap in A fixed-capacity LP: {check}")
        np.minimum(cap_upper, plane + padding, out=cap_upper)
        row = dict(capacity=pair, relaxed_capacity=[b, h], lp_mGBP=primal,
                   support_constant_mGBP=constant, slopes_mGBP=gradient.tolist(),
                   dual_gap_GBP=check * 1e6, seconds=elapsed)
        lp_trials.append(row)
        print(tag, row, flush=True)

    if args.archived_screen:
        archived_upper = run_a.screening_upper() if args.floor == .20 else run_a.economic_witness.operating_upper()
        assert archived_upper.shape == cap_upper.shape
        cap_upper[:] = archived_upper
        current_pair = np.unravel_index(np.argmax(cap_upper), cap_upper.shape)
    else:
        relaxed, elapsed = solve_lp()
        supported_upper(relaxed, elapsed, None)
        current_pair = tuple(np.rint(relaxed[counts]).astype(int))
    while len(tried) < 45:
        b, h = current_pair
        job.pin(b, h)
        # The new bounds usually require only a small dual-simplex reoptimisation.
        solver.setOptionValue("solver", "simplex")
        candidate, elapsed = solve_lp()
        supported_upper(candidate, elapsed, [int(b), int(h)])
        tried.add((b, h))
        if best is None or cap_upper[b, h] >= best["annual_net_mGBP"]:
            policy_started = perf_counter()
            desired = candidate[job.online]
            levels = np.arange(h + 1)
            path, proof = site_model.commit(-(levels - desired[:, None])**2,
                                           solve_a.MIN_DAYS, time_limit=30.)
            solver.changeColsBounds(len(job.online), job.online, path, path)
            committed, solve_seconds = solve_lp()
            row = job.audit(committed, f"{tag}-{b}-{h}")
            row.update(rounding_seconds=perf_counter() - policy_started,
                       dispatch_seconds=solve_seconds, commitment_status=proof["status"])
            witnesses.append(row)
            if best is None or row["annual_net_mGBP"] > best["annual_net_mGBP"]:
                best = row
            solver.changeColsBounds(len(job.online), job.online, np.zeros(len(job.online)),
                                    np.full(len(job.online), job.max_units))
            print(tag, "feasible", row, flush=True)
        contenders = cap_upper.copy()
        for pair in tried:
            contenders[pair] = -np.inf
        current_pair = np.unravel_index(np.argmax(contenders), contenders.shape)
        result = a_summary(tag, args, job, best, cap_upper, lp_trials, witnesses, started)
        if result["capacity_certified"]:
            return result
        if contenders[current_pair] < best["annual_net_mGBP"]:
            break
    return result


def a_summary(tag, args, job, best, upper, lp_trials, witnesses, started):
    b, h = best["battery_blocks"], best["electrolyser_units"]
    rivals = upper.copy()
    rivals[b, h] = -np.inf
    bound = float(upper.max())
    rival = float(rivals.max())
    result = dict(
        solver=args.solver, policy="A", floor=args.floor, threads=args.threads,
        archived_screen=args.archived_screen,
        model_columns=len(job.cost), **best,
        upper_mGBP=bound, best_alternative_upper_mGBP=rival,
        certified_gap_GBP=(bound - best["annual_net_mGBP"]) * 1e6,
        capacity_certified=rival < best["annual_net_mGBP"],
        wall_seconds=perf_counter() - started,
        lp_seconds=sum(r["seconds"] for r in lp_trials)
        + sum(r["dispatch_seconds"] for r in witnesses),
        lps=lp_trials, feasible_candidates=witnesses,
    )
    save_json(f"{tag}.json", result)
    return result


def policy_b(args):
    """Search capacity using the original strict-priority bounds and exact episodes."""
    import solve_a
    import solve_b
    import certify_b
    import compact_b
    import run_joint
    import run_site

    start = perf_counter()
    tag = f"B-{args.floor:g}-{args.solver.lower()}"
    site, _, _ = solve_a.inputs()
    frame, config, battery, product = run_joint.inputs()
    solve_b.MIN_LOAD = args.floor
    for key, original in (("g", site.G / 1000), ("d", site.D / 1000), ("price", site.p)):
        np.testing.assert_allclose(frame[key], original.ravel(), rtol=0, atol=1e-12)
        frame[key] = original.ravel()
    if args.solver == "Xpress":
        compact_b.highspy = run_site.highspy = solver_adapter
    standard_solver = compact_b.highspy.Highs

    def timed_solver():
        solver = standard_solver()
        initial_options = solver.setOptionValue

        def options(key, value):
            if key == "threads":
                value = args.threads
            initial_options(key, value)

        class EpisodeSolver:
            setOptionValue = staticmethod(options)

            def __getattr__(self, key):
                return getattr(solver, key)

        return EpisodeSolver()

    # Both solvers receive the same compact model and thread budget.
    compact_b.highspy.Highs = timed_solver
    eligible = solve_b.hydrogen_bound(site, battery, 70)
    assert eligible["annual_hydrogen_receipts_per_unit_upper_mGBP"] < product["annual"]
    print(tag, "hydrogen operating bound", eligible, flush=True)
    upper = certify_b.battery_bounds(site, battery)
    best = dict(battery_blocks=0, electrolyser_units=0, annual_net_mGBP=0., upper_mGBP=0.)
    trials = []
    for blocks in np.argsort(upper)[::-1]:
        if upper[blocks] + 1e-8 < best["annual_net_mGBP"]:
            break
        if not blocks:
            continue
        blocks = int(blocks)
        trial_started = perf_counter()
        flows, bound = priority_episodes(frame, config, battery, blocks, run_site, run_joint)
        audit = audit_priority(site, frame, battery, blocks, flows)
        net = audit["annual_net_mGBP"]
        upper[blocks] = min(upper[blocks], net + bound["gap_GBP_year"] / 1e6)
        row = dict(battery_blocks=blocks, electrolyser_units=0, **audit,
                   upper_mGBP=float(upper[blocks]), candidate_wall_seconds=perf_counter() - trial_started,
                   **bound)
        trials.append(row)
        if net > best["annual_net_mGBP"]:
            best = row
            np.savez_compressed(HERE / f"{tag}-winning-dispatch.npz", flows=flows)
        print(tag, "exact candidate", row, flush=True)
    screen_started = perf_counter()
    # An aggregate, storage-unconstrained receipts envelope rules out larger counts.
    # This calculation retains the four-day, ten-tonne scenario's same initial stock.
    g, d, price = (frame[key].to_numpy() for key in ("g", "d", "price"))
    positive = np.maximum(price, 0.)
    order = np.argsort(-positive)
    demand = np.maximum(d - g, 0.)[order]
    total_pool = np.maximum(g - d, 0.).sum() * battery["eta"]**2
    sale = np.clip(total_pool - np.r_[0., np.cumsum(demand)[:-1]], 0., demand)
    receipts = np.dot(sale, positive[order]) / (1000 * site.years_equiv)
    receipts += site.nd * solve_b.CAP_KG * site.netback / (site.years_equiv * 1e6)
    max_blocks = int(receipts // battery["annual"])
    assert product["minimum"] <= args.floor
    assert max_blocks >= 71
    assert int(solve_b.CAP_KG * product["kWh_kg"] /
               (args.floor * product["MW"] * 24 * 1000)) <= 223
    loose = run_joint.priority_lp(frame, config, battery, product, 71, max_blocks, 0, 223)
    high_capacity_upper = loose["upper_mGBP"]
    assert high_capacity_upper < 0.
    above_limit = receipts - (max_blocks + 1) * battery["annual"]
    assert above_limit < 0.
    remaining = float(np.max(np.delete(upper, best["battery_blocks"])))
    alternative = max(remaining, high_capacity_upper, above_limit)
    global_upper = max(float(upper.max()), high_capacity_upper, above_limit)
    result = dict(solver=args.solver, policy="B", floor=args.floor, threads=args.threads,
                  **best, global_upper_mGBP=global_upper, best_alternative_upper_mGBP=alternative,
                  certified_gap_GBP=(global_upper - best["annual_net_mGBP"]) * 1e6,
                  capacity_certified=alternative < best["annual_net_mGBP"],
                  eligible=eligible, screens_mGBP=upper.tolist(), trials=trials,
                  high_capacity_bound=loose, high_capacity_screen_seconds=perf_counter()-screen_started,
                  wall_seconds=perf_counter()-start)
    save_json(f"{tag}.json", result)
    compact_b.highspy.Highs = standard_solver
    print(tag, "global", {k: result[k] for k in ("global_upper_mGBP",
          "best_alternative_upper_mGBP", "capacity_certified", "wall_seconds")}, flush=True)
    return result


def priority_episodes(frame, config, battery, blocks, run_site, run_joint):
    asset = run_joint.scaled_battery(battery, blocks)
    boundaries = run_site.empty_stock_boundaries(frame, asset)
    index = 0
    plans, gap = [], 0.
    while index < len(boundaries) - 1:
        j = max(index + 1, np.searchsorted(boundaries, boundaries[index] + run_site.BLOCK,
                                           side="right") - 1)
        segment = frame.iloc[boundaries[index]:boundaries[j]]
        plan, gap_GBP = run_site.long_priority_block(segment, config, 0, blocks)
        plans.append(plan)
        gap += max(0., gap_GBP)
        index = j
    return np.concatenate(plans, axis=1), dict(
        episodes=len(plans), gap_GBP_year=(gap + run_site.OBJECTIVE_PADDING_GBP) / run_site.HORIZON_YEARS)


def audit_priority(site, frame, battery, blocks, flows):
    direct, charge, sale, to_h, stock, hydrogen = flows
    eta = battery["eta"]
    previous = np.r_[0., stock[:-1]]
    g, d, price = (frame[key].to_numpy() for key in ("g", "d", "price"))
    power = blocks * battery["P_MW"] / 2000
    discharge = np.minimum(np.maximum(d - g, 0.), np.minimum(power, previous * eta))
    errors = (
        np.max(np.abs(direct - np.minimum(g, d))),
        np.max(np.abs(sale - discharge)),
        np.max(np.abs(stock - previous - eta * charge + sale / eta)),
        np.max(charge - np.minimum(np.maximum(g - d, 0.), power)),
        np.max(stock) - blocks * battery["usable"], abs(stock[-1]),
        np.max(np.minimum(charge, sale)), np.max(-np.array([charge, sale, stock])),
        np.max(np.abs(to_h)), np.max(np.abs(hydrogen)),
    )
    assert max(errors) < 2e-7, errors
    for year in np.unique(site.year):
        mask = site.year == year
        assert sale.reshape(-1, 48)[mask].sum() / eta <= mask.sum() * blocks * battery["E_MWh"] / 1000 + .002
    return dict(annual_net_mGBP=float(np.dot(sale, price) / (1000 * site.years_equiv)
                                     - blocks * battery["annual"]), audit_max_error_GWh=float(max(errors)))


def policy_zero(args):
    """Reproduce the separate v7 stand-alone electrolyser recommendation."""
    import solve_a
    import run_a
    import site_model

    started = perf_counter()
    site, _, product = run_a.site_inputs() if args.floor == .20 else solve_a.inputs()
    if args.solver == "Xpress":
        site_model.milp = partial(rounded_commitment, solver_adapter)
    nmax = int(solve_a.CAP_KG * product["kWh_kg"] /
               (args.floor * product["MW"] * 24 * 1000))
    values = site_model.value_table(site, "A", args.floor, nmax, solve_a.CAP_KG)
    envelope = [float(np.max(values[:, :n + 1], axis=1).sum() / (site.years_equiv * 1e6)
                      - n * product["annual"]) for n in range(nmax + 1)]
    best = None
    results = []
    for n in np.argsort(envelope)[::-1]:
        n = int(n)
        if best is not None and envelope[n] + 1e-8 < best["annual_net_mGBP"]:
            break
        outcome, path, plan = site_model.solve_case(
            site, "A", args.floor, n, solve_a.MIN_DAYS, solve_a.CAP_KG,
        )
        result = dict(electrolyser_units=n, annual_net_mGBP=outcome["net_m"],
                      upper_mGBP=outcome["net_m"] + outcome["bound_gap_gbp_per_year"] / 1e6)
        envelope[n] = min(envelope[n], result["upper_mGBP"] + 1e-8)
        results.append(result)
        if best is None or result["annual_net_mGBP"] > best["annual_net_mGBP"]:
            best = result
            np.savez_compressed(HERE / f"A-zero-{args.floor:g}-{args.solver.lower()}.npz",
                                online=path, hydrogen_MWh=plan["h"])
    summary = dict(solver=args.solver, floor=args.floor, battery_blocks=0, **best,
                   best_alternative_upper_mGBP=max(v for n, v in enumerate(envelope)
                                                   if n != best["electrolyser_units"]),
                   wall_seconds=perf_counter() - started, trials=results)
    save_json(f"A-zero-{args.floor:g}-{args.solver.lower()}.json", summary)
    print(summary, flush=True)
